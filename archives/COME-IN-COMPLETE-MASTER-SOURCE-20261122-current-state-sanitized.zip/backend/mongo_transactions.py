"""Small, conservative MongoDB transaction error classifiers."""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from time import monotonic
from typing import Any

from pymongo.errors import PyMongoError


def has_transaction_error_label(error: BaseException, label: str) -> bool:
    """Return a driver error label without relying on exception class names/codes."""
    checker = getattr(error, "has_error_label", None)
    if not callable(checker):
        return False
    try:
        return bool(checker(label))
    except Exception:
        return False


async def proven_insufficient_stock_conflict(
    transaction_error: BaseException,
    fresh_stock_check: Callable[[], Awaitable[Any]],
) -> BaseException | None:
    """Return an HTTP/business error only when a labeled transient abort is followed
    by a fresh read that explicitly proves insufficient stock. Any diagnostic failure
    is inconclusive and therefore returns None (the caller keeps the infrastructure 503).
    """
    if not has_transaction_error_label(transaction_error, "TransientTransactionError"):
        return None
    try:
        await fresh_stock_check()
    except Exception as check_error:
        detail = getattr(check_error, "detail", None)
        code = detail.get("code") if isinstance(detail, dict) else None
        if getattr(check_error, "status_code", None) == 409 and code == "insufficient_stock":
            return check_error
    return None


async def run_transaction(client: Any, callback: Callable[[Any], Awaitable[Any]]) -> Any:
    """Use the Motor/PyMongo transaction manager for driver-managed retries.

    Callbacks MUST contain only session-bound database operations and MUST be
    safe to re-execute: the driver can retry the whole callback on transient
    transaction errors or retry commit on UnknownTransactionCommitResult.
    Motor 3.7.1 commits while exiting its callback context, before its own commit
    retry loop. Commit inside the callback so unknown commit results are retried
    here and transient errors still reach the driver's whole-transaction retry.
    The commit retry budget shares the driver's 120-second transaction budget.
    No provider API call belongs in either retry path.
    """
    started = monotonic()

    async def commit_with_retry(session: Any) -> Any:
        result = await callback(session)
        # Also respect callbacks that intentionally ended their transaction.
        # Session adapters used by offline tests may own commit internally.
        if not getattr(session, "in_transaction", False):
            return result
        while True:
            try:
                await session.commit_transaction()
                return result
            except PyMongoError as error:
                if (
                    has_transaction_error_label(error, "UnknownTransactionCommitResult")
                    and getattr(error, "code", None) != 50
                    and monotonic() - started < 120
                ):
                    continue
                raise

    async with await client.start_session() as session:
        return await session.with_transaction(commit_with_retry)
