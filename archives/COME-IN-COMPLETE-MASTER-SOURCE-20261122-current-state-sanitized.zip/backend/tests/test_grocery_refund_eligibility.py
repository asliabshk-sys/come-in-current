import pytest

from refund_rules import grocery_refund_amount


def records():
    return ({"_id": "local-order", "payment_method": "online_razorpay", "status": "cancelled", "total": 20},
            {"order_id": "local-order", "gateway": "razorpay", "status": "paid", "amount": 20,
             "currency": "INR", "gateway_payment_id": "pay_local_only"})


def test_only_full_confirmed_cancelled_online_amount_is_eligible():
    order, payment = records()
    assert grocery_refund_amount(order, payment) == 2000
    assert grocery_refund_amount(order, payment, 2000) == 2000


@pytest.mark.parametrize("method", ["cod", "upi", "pickup", "cash_shop"])
def test_cash_and_manual_payment_methods_cannot_use_gateway_refunds(method):
    order, payment = records(); order["payment_method"] = method
    with pytest.raises(ValueError): grocery_refund_amount(order, payment)


@pytest.mark.parametrize("field,value", [("status", "pending"), ("status", "delivered")])
def test_no_new_eligibility_policy_is_invented_for_active_or_delivered_orders(field, value):
    order, payment = records(); order[field] = value
    with pytest.raises(ValueError): grocery_refund_amount(order, payment)


@pytest.mark.parametrize("field,value", [("status", "created"), ("order_id", "unrelated"),
    ("amount", 19), ("currency", "USD"), ("gateway_payment_id", None)])
def test_uncaptured_mismatched_and_unrelated_payments_are_not_refunded(field, value):
    order, payment = records(); payment[field] = value
    with pytest.raises(ValueError): grocery_refund_amount(order, payment)


@pytest.mark.parametrize("amount", [True, 1, 1999, 2001])
def test_partial_or_excess_refund_initiation_is_explicitly_rejected(amount):
    order, payment = records()
    with pytest.raises(ValueError, match="full eligible refund"):
        grocery_refund_amount(order, payment, amount)
