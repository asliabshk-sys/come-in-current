"""Source-contract checks for seller support UI wiring; no live API is called."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCREEN = (ROOT / "frontend/app/seller/support.tsx").read_text()
ACCOUNT = (ROOT / "frontend/app/(tabs)/account.tsx").read_text()
SERVER = (ROOT / "backend/server.py").read_text()


def test_seller_support_screen_uses_existing_authenticated_endpoints_and_response_fields():
    assert 'api.get<SupportTicket[]>("/seller/support")' in SCREEN
    assert 'api.patch<SupportTicket>(`/seller/support/${encodeURIComponent(ticket.id)}`' in SCREEN
    for field in ("id", "ref", "order_id", "order_kind", "order_ref", "category", "message", "status", "updated_at"):
        assert field in SCREEN
    assert 'def doc_out(doc: dict)' in SERVER
    assert 'return doc_out(updated)' in SERVER


def test_seller_ui_sends_actual_expected_status_and_only_allowed_transitions():
    assert 'open: { status: "in_progress"' in SCREEN
    assert 'in_progress: { status: "resolved"' in SCREEN
    assert 'expected_status: ticket.status' in SCREEN
    assert 'closed' not in SCREEN.split('const NEXT:', 1)[1].split('};', 1)[0]


def test_seller_screen_prevents_duplicate_submission_and_refreshes_stale_conflicts():
    assert 'disabled={busyId !== null}' in SCREEN
    assert 'if (!next || busyId) return' in SCREEN
    assert 'status === 409' in SCREEN
    assert 'await load()' in SCREEN


def test_seller_account_navigation_exposes_support_for_shopkeeper_and_restaurant_roles():
    assert 'label: "Seller Support"' in ACCOUNT
    assert 'router.push("/seller/support")' in ACCOUNT
    assert 'user?.role === "shopkeeper"' in ACCOUNT
    # The authenticated Role model stays customer/shopkeeper/admin. A typed
    # membership check also preserves legacy Restaurant support without an
    # impossible literal comparison after the shopkeeper branch narrows Role.
    assert 'const SELLER_SUPPORT_ROLES: readonly string[] = ["shopkeeper", "restaurant"];' in ACCOUNT
    assert 'SELLER_SUPPORT_ROLES.includes(user?.role || "")' in ACCOUNT


def test_support_ui_does_not_trigger_refund_cancellation_or_notification_claims():
    for forbidden in ("/refund", "cancel-order", "refund_status", "sendNotification", "notification delivered"):
        assert forbidden not in SCREEN
