"""ASGI + actual disposable MongoDB, signed LOCAL messages, no provider delivery.

Explicit opt-in avoids pointing ordinary offline test runs at any database.
Local signing material/config is injected in memory; outbound HTTP is forbidden.
"""
import asyncio
import hashlib
import hmac
import json
import os
import secrets
from types import SimpleNamespace
from uuid import uuid4

import pytest


def test_local_signed_webhook_http_and_transaction_scenarios(monkeypatch):
    if os.environ.get("COMEIN_RUN_LOCAL_PAYMENT_TESTS") != "1":
        pytest.skip("requires explicit local disposable payment-test opt-in")
    import httpx
    import server
    from bson import ObjectId
    from motor.motor_asyncio import AsyncIOMotorClient
    from pymongo import MongoClient
    from scripts.mongo.comein_mongo import init_db

    uri = "mongodb://127.0.0.1:27018/?replicaSet=rs0"
    name = "comein_disposable_test_webhooks_" + uuid4().hex[:16]
    sync = MongoClient(uri, serverSelectionTimeoutMS=3000)
    assert sync.admin.command("hello")["setName"] == "rs0"
    init_db(sync[name]); sync.close()
    secret = secrets.token_urlsafe(32)
    monkeypatch.setattr(server, "_razorpay_settings", lambda **_: SimpleNamespace(
        mode="test", webhook_secret=secret, key_id="local-noncredential-id", key_secret=secret))
    def no_outbound(*args, **kwargs):
        raise AssertionError("Provider HTTP is forbidden in local webhook tests")
    monkeypatch.setattr(server.requests, "get", no_outbound)
    monkeypatch.setattr(server.requests, "post", no_outbound)

    async def run():
        mongo = AsyncIOMotorClient(uri); db = mongo[name]
        monkeypatch.setattr(server, "client", mongo); monkeypatch.setattr(server, "db", db)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app, raise_app_exceptions=False), base_url="http://local") as http:
            async def post(payload, event_id, *, valid=True):
                raw = json.dumps(payload, separators=(",", ":")).encode()
                signature = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest() if valid else "invalid"
                return await http.post("/api/restaurant/payments/razorpay-webhook", content=raw,
                    headers={"X-Razorpay-Signature": signature, "X-Razorpay-Event-Id": event_id})
            async def seed(kind):
                oid, pid = ObjectId(), ObjectId(); order_id = "order_" + uuid4().hex
                orders = db.orders if kind == "grocery" else db.restaurant_orders
                payments = db.grocery_payments if kind == "grocery" else db.restaurant_payments
                await orders.insert_one({"_id": oid, "customer_id": "local-only", "idempotency_key": str(oid),
                    "total": 20, "payment_method": "online_razorpay" if kind == "grocery" else "razorpay", "status": "pending_payment", "payment_status": "razorpay_pending" if kind == "grocery" else "pending", "status_history": []})
                await payments.insert_one({"_id": pid, "order_id": str(oid), "gateway_order_id": order_id,
                    "gateway": "razorpay", "amount": 20, "currency": "INR", "status": "created"})
                payload = {"event": "payment.captured", "payload": {"payment": {"entity": {
                    "id": "pay_" + uuid4().hex, "order_id": order_id, "amount": 2000, "currency": "INR", "status": "captured"}}}}
                return oid, pid, orders, payments, payload

            assert (await post([], "evt_invalid")).status_code == 400
            oid, pid, orders, payments, payload = await seed("restaurant")
            assert (await post(payload, "evt_bad_signature", valid=False)).status_code == 400
            assert (await post(payload, "")).status_code == 400
            assert (await orders.find_one({"_id": oid}))["payment_status"] == "pending"
            replies = await asyncio.gather(post(payload, "evt_capture"), post(payload, "evt_capture"))
            assert all(r.status_code == 200 for r in replies)
            assert await db.restaurant_payment_events.count_documents({"event_id": "evt_capture"}) == 1
            assert (await orders.find_one({"_id": oid}))["payment_status"] == "paid"
            assert (await payments.find_one({"_id": pid}))["status"] == "paid"
            changed = json.loads(json.dumps(payload)); changed["payload"]["payment"]["entity"]["amount"] = 1
            assert (await post(changed, "evt_capture")).status_code == 409
            failed = json.loads(json.dumps(payload)); failed["event"] = "payment.failed"; failed["payload"]["payment"]["entity"]["status"] = "failed"
            assert (await post(failed, "evt_delayed_fail")).status_code == 200
            assert (await orders.find_one({"_id": oid}))["payment_status"] == "paid"
            assert (await post({"event": "local.unknown"}, "evt_unknown")).status_code == 200
            assert (await db.restaurant_payment_events.find_one({"event_id": "evt_unknown"}))["ignored"] is True

            oid, pid, orders, payments, grocery = await seed("grocery")
            failed = json.loads(json.dumps(grocery)); failed["event"] = "payment.failed"; failed["payload"]["payment"]["entity"]["status"] = "failed"
            assert (await post(failed, "evt_grocery_fail")).status_code == 200
            assert (await orders.find_one({"_id": oid}))["status"] == "pending_payment"
            assert (await payments.find_one({"_id": pid}))["status"] == "failed"
            assert (await post(grocery, "evt_grocery_capture")).status_code == 200
            assert (await orders.find_one({"_id": oid}))["payment_status"] == "paid"
            assert (await post(failed, "evt_grocery_late_fail")).status_code == 200
            assert (await orders.find_one({"_id": oid}))["payment_status"] == "paid"
            # Provider capture cannot change an unrelated amount/currency; genuine
            # delayed capture can recover after frontend cancellation/interruption.
            oid2, pid2, rows2, pays2, captured2 = await seed("restaurant")
            mismatch = json.loads(json.dumps(captured2)); mismatch["payload"]["payment"]["entity"]["amount"] = 1
            assert (await post(mismatch, "evt_amount_mismatch")).status_code == 200
            assert (await rows2.find_one({"_id": oid2}))["payment_status"] == "pending"
            # Failure after financial commit but before event receipt must be
            # retry-safe and produce a single durable receipt on retry.
            original_record = server._record_razorpay_event
            async def fail_receipt(*args, **kwargs):
                raise RuntimeError("local injected receipt failure")
            with monkeypatch.context() as fake:
                fake.setattr(server, "_record_razorpay_event", fail_receipt)
                assert (await post(captured2, "evt_retry_receipt")).status_code == 500
            assert (await rows2.find_one({"_id": oid2}))["payment_status"] == "paid"
            assert await db.restaurant_payment_events.count_documents({"event_id": "evt_retry_receipt"}) == 0
            assert (await post(captured2, "evt_retry_receipt")).status_code == 200
            assert await db.restaurant_payment_events.count_documents({"event_id": "evt_retry_receipt"}) == 1
            assert server._record_razorpay_event == original_record
            # Signed Grocery partial/full refund events reconcile both records;
            # duplicate and late failed events must not reverse processed money.
            await orders.update_one({"_id": oid}, {"$set": {"status": "cancelled"}})
            pay_id = grocery["payload"]["payment"]["entity"]["id"]
            def refunded(rid, amount, status="processed"):
                return {"event": "refund." + status, "payload": {"refund": {"entity": {
                    "id": rid, "payment_id": pay_id, "amount": amount, "status": status}}}}
            assert (await post(refunded("rf_local_partial", 500), "evt_refund_partial")).status_code == 200
            assert (await orders.find_one({"_id": oid}))["refund_status"] == "partially_refunded"
            assert (await post(refunded("rf_local_remaining", 1500), "evt_refund_remaining")).status_code == 200
            assert (await orders.find_one({"_id": oid}))["refund_status"] == "refunded"
            assert (await post(refunded("rf_local_remaining", 1500), "evt_refund_remaining")).json()["duplicate"] is True
            assert (await post(refunded("rf_local_remaining", 1500, "failed"), "evt_refund_late_failed")).status_code == 200
            assert (await orders.find_one({"_id": oid}))["refund_status"] == "refunded"
            # Concurrent intent requests must not issue two provider orders.
            # The provider here is an in-process mock; no credential/API call.
            for kind in ["grocery", "restaurant"]:
                collection = db.orders if kind == "grocery" else db.restaurant_orders
                payment_collection = db.grocery_payments if kind == "grocery" else db.restaurant_payments
                new_oid = ObjectId()
                await collection.insert_one({"_id": new_oid, "customer_id": "local-only",
                    "idempotency_key": str(new_oid), "ref": "LOCAL_" + str(new_oid), "total": 20,
                    "payment_method": "online_razorpay" if kind == "grocery" else "razorpay",
                    "payment_status": "razorpay_pending" if kind == "grocery" else "pending",
                    "status": "pending_payment"})
                calls = []
                def provider_order(url, **kwargs):
                    assert url == "https://api.razorpay.com/v1/orders"
                    calls.append(url)
                    return SimpleNamespace(status_code=200, json=lambda: {
                        "id": "order_mock_" + str(new_oid), "amount": 2000, "currency": "INR"})
                with monkeypatch.context() as fake:
                    fake.setattr(server.requests, "post", provider_order)
                    fake.setattr(server, "_grocery_razorpay_keys", lambda: ("local-noncredential-id", secret))
                    create = server.create_grocery_payment_intent if kind == "grocery" else server.create_restaurant_payment_intent
                    replies = await asyncio.gather(*[create(str(new_oid), {"id": "local-only"}) for _ in range(2)], return_exceptions=True)
                    assert any(isinstance(reply, dict) for reply in replies)
                    assert len(calls) == 1
                    await payment_collection.update_one({"order_id": str(new_oid)}, {"$set": {"status": "failed"}})
                    retried = await create(str(new_oid), {"id": "local-only"})
                    assert retried["gateway_order_id"] == "order_mock_" + str(new_oid)
                    assert len(calls) == 1
        mongo.close()
    asyncio.run(run())
