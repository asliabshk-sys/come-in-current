"""Local cryptographic inputs, never provider credentials or delivery evidence."""
import hashlib
import hmac
import json
import secrets

import pytest

from payment_webhook import verified_event


def signed(payload, secret=None):
    secret = secret or secrets.token_urlsafe(32)
    raw = json.dumps(payload, separators=(",", ":")).encode()
    return raw, hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest(), secret


def payment():
    return {"event": "payment.captured", "payload": {"payment": {"entity": {
        "id": "pay_local_only", "order_id": "order_local_only", "amount": 2000,
        "currency": "INR", "status": "captured"}}}}


def test_exact_signed_bytes_and_event_header_are_required():
    payload = payment(); raw, sig, secret = signed(payload)
    assert verified_event(raw, sig, secret, "evt_local") == payload
    for altered in [raw + b" ", raw.replace(b"2000", b"2001")]:
        with pytest.raises(ValueError, match="signature"):
            verified_event(altered, sig, secret, "evt_local")
    with pytest.raises(ValueError, match="Event-Id"):
        verified_event(raw, sig, secret, "")


@pytest.mark.parametrize("payload", [[], None, 7, {}, {"event": 12},
    {"event": "payment.captured", "payload": []},
    {"event": "payment.captured", "payload": {"payment": {"entity": []}}}])
def test_invalid_envelopes_are_rejected(payload):
    raw, sig, secret = signed(payload)
    with pytest.raises(ValueError):
        verified_event(raw, sig, secret, "evt_local")


@pytest.mark.parametrize("field,value", [("amount", True), ("amount", -1), ("amount", "2000"),
    ("currency", "USD"), ("id", "../unrelated"), ("order_id", None), ("status", "failed")])
def test_malformed_payment_evidence_never_becomes_capture(field, value):
    payload = payment(); payload["payload"]["payment"]["entity"][field] = value
    raw, sig, secret = signed(payload)
    with pytest.raises(ValueError):
        verified_event(raw, sig, secret, "evt_local")


def test_unknown_signed_event_can_be_audited_without_business_dispatch():
    raw, sig, secret = signed({"event": "account.local_unknown"})
    assert verified_event(raw, sig, secret, "evt_local")["event"] == "account.local_unknown"


def test_invalid_json_and_wrong_secret_are_rejected():
    secret = secrets.token_urlsafe(32); raw = b"{invalid"
    sig = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    with pytest.raises(ValueError, match="JSON"):
        verified_event(raw, sig, secret, "evt_local")
    with pytest.raises(ValueError, match="signature"):
        verified_event(raw, sig, secrets.token_urlsafe(32), "evt_local")
