"""Real local ASGI/auth/transactions with an in-process provider mock only."""
import asyncio
import os
import secrets
from types import SimpleNamespace
from uuid import uuid4

import pytest


def test_local_grocery_refund_authorization_accounting_and_retry(monkeypatch):
    if os.environ.get("COMEIN_RUN_LOCAL_PAYMENT_TESTS") != "1":
        pytest.skip("requires explicit local disposable payment-test opt-in")
    import httpx
    import server
    from bson import ObjectId
    from motor.motor_asyncio import AsyncIOMotorClient
    from pymongo import MongoClient
    from scripts.mongo.comein_mongo import init_db

    uri = "mongodb://127.0.0.1:27018/?replicaSet=rs0"
    name = "comein_disposable_test_refund_" + uuid4().hex[:16]
    sync = MongoClient(uri, serverSelectionTimeoutMS=3000); init_db(sync[name]); sync.close()
    local_material = secrets.token_urlsafe(32)
    monkeypatch.setattr(server, "_razorpay_settings", lambda **_: SimpleNamespace(
        mode="test", key_id="local-noncredential-id", key_secret=local_material, webhook_secret=local_material))
    calls = []; history = []; behavior = {"mode": "processed"}
    def provider_get(url, **kwargs):
        assert url.startswith("https://api.razorpay.com/v1/payments/") and url.endswith("/refunds")
        return SimpleNamespace(status_code=200, json=lambda: {"items": list(history)})
    def provider_post(url, **kwargs):
        assert url.startswith("https://api.razorpay.com/v1/payments/") and url.endswith("/refund")
        calls.append(url)
        if behavior["mode"] == "timeout": raise TimeoutError("local mock timeout")
        return SimpleNamespace(status_code=200, json=lambda: {"id": "rf_mock_" + str(len(calls)),
            "payment_id": url.split("/")[-2], "amount": kwargs["json"]["amount"], "status": behavior["mode"]})
    monkeypatch.setattr(server.requests, "get", provider_get)
    monkeypatch.setattr(server.requests, "post", provider_post)

    async def run():
        mongo = AsyncIOMotorClient(uri); db = mongo[name]
        monkeypatch.setattr(server, "client", mongo); monkeypatch.setattr(server, "db", db)
        admin, customer = ObjectId(), ObjectId()
        for oid, role in [(admin, "admin"), (customer, "customer")]:
            await db.users.insert_one({"_id": oid, "role": role, "email": f"{role}@local.invalid"})
        def headers(oid, role):
            return {"Authorization": "Bearer " + server.create_access_token(str(oid), role, role + "@local.invalid")}
        admin_headers, customer_headers = headers(admin, "admin"), headers(customer, "customer")
        async def seed(method="online_razorpay"):
            oid, pid = ObjectId(), ObjectId()
            await db.orders.insert_one({"_id": oid, "ref": "LOCAL_" + str(oid), "customer_id": str(customer),
                "total": 20, "status": "cancelled", "payment_method": method, "payment_status": "cancelled", "refund_status": "under_review"})
            await db.grocery_payments.insert_one({"_id": pid, "order_id": str(oid), "gateway": "razorpay",
                "status": "paid", "amount": 20, "currency": "INR", "gateway_payment_id": "pay_local_" + str(pid)})
            await db.financial_ledger.insert_one({"idempotency_key": f"order:grocery:{oid}:finalized:v1", "platform_earnings": 2})
            return oid, pid
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=server.app, raise_app_exceptions=False), base_url="http://local") as http:
            async def refund(oid, key, extra=None, auth=admin_headers):
                return await http.post(f"/api/admin/grocery/orders/{oid}/refund", headers=auth,
                    json={"request_id": key, "reason": "Approved local validation case", **(extra or {})})
            oid, pid = await seed()
            assert (await refund(oid, "request_local_unauth", auth={})).status_code == 401
            assert (await refund(oid, "request_local_customer", auth=customer_headers)).status_code == 403
            assert (await refund(oid, "request_local_partial", {"amount_paise": 500})).status_code == 422
            assert len(calls) == 0
            replies = await asyncio.gather(refund(oid, "request_local_full"), refund(oid, "request_local_full"))
            assert all(r.status_code == 200 for r in replies)
            assert len(calls) == 1
            assert (await db.orders.find_one({"_id": oid}))["refund_status"] == "refunded"
            assert (await db.grocery_payments.find_one({"_id": pid}))["refunded_amount_paise"] == 2000
            assert await db.financial_ledger.count_documents({"order_id": str(oid), "event_type": "refund_reversal"}) == 1
            assert (await refund(oid, "request_local_another")).status_code == 409
            assert (await http.get("/api/admin/grocery/refunds", headers=admin_headers)).status_code == 200
            assert (await http.get("/api/admin/grocery/refunds", headers=customer_headers)).status_code == 403
            cod, _ = await seed("cod")
            assert (await refund(cod, "request_local_cod")).status_code == 409
            assert len(calls) == 1

            oid, pid = await seed(); behavior["mode"] = "timeout"
            assert (await refund(oid, "request_local_timeout")).status_code == 502
            assert (await db.orders.find_one({"_id": oid}))["refund_status"] == "refund_uncertain"
            assert (await refund(oid, "request_local_timeout")).json()["provider_request_replayed"] is False
            assert (await refund(oid, "request_local_new_key")).status_code == 409
            assert len(calls) == 2

            oid, pid = await seed(); behavior["mode"] = "processed"
            history.append({"id": "rf_existing_partial", "status": "processed", "amount": 500})
            assert (await refund(oid, "request_local_history")).status_code == 409
            assert len(calls) == 2
            assert (await db.orders.find_one({"_id": oid}))["refund_status"] == "partially_refunded"
            assert await db.financial_ledger.count_documents({"order_id": str(oid), "event_type": "refund_reversal"}) == 0
            assert (await server._apply_grocery_refund_transactionally(pid, oid, "rf_existing_partial", 500, "failed"))["refund_status"] == "partially_refunded"
            assert (await server._apply_grocery_refund_transactionally(pid, oid, "rf_remainder_observed", 1500, "processed"))["refund_status"] == "refunded"
            assert await db.financial_ledger.count_documents({"order_id": str(oid), "event_type": "refund_reversal"}) == 1
            history.clear()

            oid, pid = await seed()
            await db.command({"collMod": "orders", "validator": {"$or": [
                {"_id": {"$ne": oid}}, {"refund_status": {"$ne": "refunded"}}]}, "validationLevel": "strict", "validationAction": "error"})
            assert (await refund(oid, "request_local_db_failure")).status_code == 503
            assert (await db.grocery_payments.find_one({"_id": pid}))["refund_status"] == "refund_requested"
            assert (await db.orders.find_one({"_id": oid}))["refund_status"] == "refund_requested"
            assert await db.financial_ledger.count_documents({"order_id": str(oid), "event_type": "refund_reversal"}) == 0
            assert (await refund(oid, "request_local_db_failure")).json()["provider_request_replayed"] is False
        mongo.close()
    asyncio.run(run())
