"""Execute production endpoints with a deterministic concurrent-state interleaving.

The collection double returns an original snapshot, then exposes an already-paid
or accepted order to the conditional write. No provider or DB side effects.
"""
import ast
import asyncio
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest
from bson import ObjectId
from fastapi import HTTPException

SOURCE = Path(__file__).parents[1] / "server.py"

class InterleavedOrders:
    def __init__(self, initial, concurrent):
        self.initial = initial
        self.current = {**initial, **concurrent}
        self.reads = 0
        self.writes = 0
    async def find_one(self, query):
        self.reads += 1
        return self.initial if self.reads == 1 else self.current
    async def update_one(self, query, update):
        self.writes += 1
        def matches(value, expected):
            if isinstance(expected, dict):
                if "$ne" in expected: return value != expected["$ne"]
                if "$in" in expected: return value in expected["$in"]
            return value == expected
        valid = all(matches(self.current.get(k), v) for k, v in query.items())
        if valid: self.current.update(update.get("$set", {}))
        return SimpleNamespace(modified_count=int(valid), matched_count=int(valid))

def endpoint(name, rows):
    tree = ast.parse(SOURCE.read_text())
    node = next(x for x in tree.body if isinstance(x, ast.AsyncFunctionDef) and x.name == name)
    node.decorator_list = []
    for arg in node.args.args: arg.annotation = None
    node.args.defaults = []
    env = {"db": SimpleNamespace(restaurant_orders=rows), "HTTPException": HTTPException,
           "_object_id_or_404": lambda value, _: ObjectId(value), "doc_out": lambda value: value,
           "now_utc": lambda: datetime.now(timezone.utc), "_razorpay_settings": lambda **_: True}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(SOURCE), "exec"), env)
    return env[name]

@pytest.mark.parametrize("name", ["cancel_restaurant_order", "retry_restaurant_payment"])
@pytest.mark.parametrize("concurrent", [{"payment_status": "paid", "status": "placed"}, {"status": "accepted"}])
def test_customer_transition_cannot_overwrite_concurrent_final_state(name, concurrent):
    oid = ObjectId()
    initial = {"_id": oid, "customer_id": "owner", "status": "pending_payment", "payment_status": "pending", "payment_method": "razorpay"}
    rows = InterleavedOrders(initial, concurrent)
    async def run():
        with pytest.raises(HTTPException) as result:
            await endpoint(name, rows)(str(oid), {"id": "owner"})
        assert result.value.status_code == 409
        assert rows.current == {**initial, **concurrent}
    asyncio.run(run())
