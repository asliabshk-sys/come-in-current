"""An oversized upload must be rejected after a bounded read, before storage."""
import ast
import asyncio
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException


def test_image_upload_bounds_read_before_rejecting_oversize():
    source = Path(__file__).parents[1] / "server.py"
    node = next(n for n in ast.parse(source.read_text()).body if isinstance(n, ast.AsyncFunctionDef) and n.name == "upload_image")
    node.decorator_list = []; node.args.defaults = []
    for arg in node.args.args: arg.annotation = None
    maximum = 5 * 1024 * 1024
    env = {"ALLOWED_IMAGE": {"image/png"}, "MAX_UPLOAD_BYTES": maximum, "HTTPException": HTTPException}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), "exec"), env)
    read_limits = []
    async def read(size=-1):
        read_limits.append(size)
        return b"x" * (maximum + 1)
    async def run():
        with pytest.raises(HTTPException) as error:
            await env["upload_image"](SimpleNamespace(content_type="image/png", read=read), {"id": "local-owner"})
        assert error.value.status_code == 400
        assert read_limits == [maximum + 1]
    asyncio.run(run())
