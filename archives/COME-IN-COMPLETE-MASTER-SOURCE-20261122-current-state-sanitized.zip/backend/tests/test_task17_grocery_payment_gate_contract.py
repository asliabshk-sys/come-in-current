"""Task 17: Grocery online payments remain disabled unless explicitly configured."""
import ast
import os
import pytest
from typing import Optional
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER_PATH = ROOT / "backend" / "server.py"
TREE = ast.parse(SERVER_PATH.read_text())
NODE = next(node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == "_grocery_razorpay_keys")
NAMESPACE = {"os": os, "Optional": Optional}
exec(compile(ast.Module(body=[NODE], type_ignores=[]), str(SERVER_PATH), "exec"), NAMESPACE)
grocery_razorpay_keys = NAMESPACE["_grocery_razorpay_keys"]


@pytest.fixture(autouse=True)
def isolated_payment_mode(monkeypatch):
    monkeypatch.setenv("APP_ENV", "test")
    monkeypatch.setenv("RAZORPAY_MODE", "test")
    monkeypatch.delenv("ENVIRONMENT", raising=False)


def test_grocery_payment_requires_explicit_feature_flag(monkeypatch):
    monkeypatch.delenv("GROCERY_ONLINE_PAYMENTS_ENABLED", raising=False)
    monkeypatch.setenv("RAZORPAY_KEY_ID", "rzp_test_demo")
    monkeypatch.setenv("RAZORPAY_KEY_SECRET", "test-secret")
    assert grocery_razorpay_keys() is None


def test_grocery_payment_requires_both_server_side_keys(monkeypatch):
    monkeypatch.setenv("GROCERY_ONLINE_PAYMENTS_ENABLED", "true")
    monkeypatch.setenv("RAZORPAY_KEY_ID", "rzp_test_demo")
    monkeypatch.delenv("RAZORPAY_KEY_SECRET", raising=False)
    assert grocery_razorpay_keys() is None


def test_grocery_payment_returns_keys_only_when_flag_and_both_keys_exist(monkeypatch):
    monkeypatch.setenv("GROCERY_ONLINE_PAYMENTS_ENABLED", " TRUE ")
    monkeypatch.setenv("RAZORPAY_KEY_ID", "rzp_test_demo")
    monkeypatch.setenv("RAZORPAY_KEY_SECRET", "test-secret")
    assert grocery_razorpay_keys() == ("rzp_test_demo", "test-secret")
