"""Focused regression tests for source-derived MongoDB index portability."""
from collections import Counter

from scripts.mongo import comein_mongo


class _Collection:
    def __init__(self):
        self.indexes = []

    def create_index(self, keys, **options):
        normalized = [(keys, 1)] if isinstance(keys, str) else [tuple(item) for item in keys]
        self.indexes.append({"key": normalized, **options})
        return f"index_{len(self.indexes)}"

    def index_information(self):
        return {str(i): value for i, value in enumerate(self.indexes)}

    def aggregate(self, pipeline, **options):
        self.last_pipeline = pipeline
        self.last_options = options
        return []


class _Database:
    def __init__(self):
        self.collections = {}

    def list_collection_names(self):
        return list(self.collections)

    def create_collection(self, name):
        self.collections[name] = _Collection()

    def __getitem__(self, name):
        return self.collections.setdefault(name, _Collection())


def test_index_inventory_includes_both_startup_initializers_exactly_once():
    specs = comein_mongo.index_specs()
    assert len(specs) == 67
    assert Counter(spec["initializer"] for spec in specs) == {
        "_startup": 61,
        "ensure_delivery_partner_indexes": 6,
    }
    assert len({(spec["collection"], tuple(spec["keys"]), repr(sorted(spec["options"].items()))) for spec in specs}) == 67


def test_spec_and_init_use_complete_67_index_inventory():
    db = _Database()
    result = comein_mongo.init_db(db)
    assert result["indexes_ensured"] == 67
    assert sum(len(collection.indexes) for collection in db.collections.values()) == 67
    assert comein_mongo.missing_indexes(db) == []


def test_drift_detection_checks_unique_sparse_ttl_and_partial_options():
    db = _Database()
    comein_mongo.init_db(db)
    spec = next(item for item in comein_mongo.index_specs() if item["options"].get("sparse"))
    actual = next(index for index in db[spec["collection"]].indexes if comein_mongo.index_matches(spec, index))
    actual["sparse"] = False
    drift = comein_mongo.missing_indexes(db)
    assert any(spec["collection"] in entry for entry in drift)


def test_missing_delivery_partner_index_is_reported_by_health_drift_primitive():
    db = _Database()
    comein_mongo.init_db(db)
    spec = next(item for item in comein_mongo.index_specs() if item["initializer"] == "ensure_delivery_partner_indexes")
    db[spec["collection"]].indexes = [
        index for index in db[spec["collection"]].indexes
        if not comein_mongo.index_matches(spec, index)
    ]
    assert any(spec["collection"] in entry for entry in comein_mongo.missing_indexes(db))


def test_health_reports_all_67_indexes_and_index_status(monkeypatch):
    db = _Database()
    comein_mongo.init_db(db)

    class _Admin:
        def command(self, command):
            if command == "ping":
                return {"ok": 1.0}
            if command == "hello":
                return {"setName": "rs0", "isWritablePrimary": True}
            return {"featureCompatibilityVersion": {"version": "7.0"}}

    class _Client:
        admin = _Admin()

        def __getitem__(self, name):
            return db

        def server_info(self):
            return {"version": "7.0.test"}

        def close(self):
            pass

    monkeypatch.setattr(comein_mongo, "client_for", lambda _url: _Client())
    monkeypatch.setattr(comein_mongo, "verify_transactions", lambda _client, _db: {"ok": True})
    result = comein_mongo.health("mongodb://localhost:27017", "comein_test")
    assert result["indexes_expected"] == 67
    assert result["indexes_missing"] == []
    assert result["indexes_ok"] is True
    assert result["ok"] is True


def test_unexpected_ttl_or_partial_filter_option_is_also_drift():
    plain = {"keys": [("created_at", -1)], "options": {}}
    assert comein_mongo.index_matches(plain, {"key": [("created_at", -1)]})
    assert not comein_mongo.index_matches(plain, {"key": [("created_at", -1)], "expireAfterSeconds": 0})
    assert not comein_mongo.index_matches(plain, {"key": [("created_at", -1)], "partialFilterExpression": {"active": True}})


def test_index_matching_checks_explicit_names_but_accepts_server_generated_names():
    spec = {"keys": [("user_id", 1)], "options": {"name": "user_owner_unique", "unique": True}}
    assert comein_mongo.index_matches(spec, {"key": [("user_id", 1)], "name": "user_owner_unique", "unique": True})
    assert not comein_mongo.index_matches(spec, {"key": [("user_id", 1)], "name": "user_id_1", "unique": True})
    unnamed = {"keys": [("user_id", 1)], "options": {}}
    assert comein_mongo.index_matches(unnamed, {"key": [("user_id", 1)], "name": "user_id_1"})


def test_all_fastapi_startup_handlers_are_discovered_for_index_inventory(monkeypatch, tmp_path):
    source = '''
from fastapi import FastAPI
app = FastAPI()
@app.on_event("startup")
async def first():
    await db.alpha.create_index("key", unique=True)
@app.on_event("startup")
async def second():
    await db.beta.create_index([("owner", 1), ("created", -1)])
'''
    server = tmp_path / "server.py"
    server.write_text(source)
    monkeypatch.setattr(comein_mongo, "SERVER", server)
    specs = comein_mongo.index_specs()
    assert [(item["initializer"], item["collection"]) for item in specs] == [("first", "alpha"), ("second", "beta")]


def test_index_init_returns_only_after_all_declared_indexes_verify():
    db = _Database()
    result = comein_mongo.init_db(db)
    assert result["indexes_ensured"] == 67
    assert result["indexes_verified"] == 67


def test_application_collection_inventory_includes_catalogue_audit_and_payment_collections():
    collections = set(comein_mongo.collections_used())
    assert len(collections) == 52
    assert {"catalogue_import_jobs", "catalogue_import_audit", "grocery_payments", "restaurant_payments", "financial_ledger", "security_locks"} <= collections


def test_health_never_emits_the_connection_uri(monkeypatch):
    db = _Database()

    class _Admin:
        def command(self, command):
            if command == "ping": return {"ok": 1.0}
            if command == "hello": return {"setName": "rs0", "isWritablePrimary": True}
            return {"featureCompatibilityVersion": {"version": "7.0"}}

    class _Client:
        admin = _Admin()
        def __getitem__(self, name): return db
        def server_info(self): return {"version": "7.0.test"}
        def close(self): pass

    comein_mongo.init_db(db)
    monkeypatch.setattr(comein_mongo, "client_for", lambda _url: _Client())
    monkeypatch.setattr(comein_mongo, "verify_transactions", lambda _client, _db: {"ok": True})
    result = comein_mongo.health("mongodb://private-user:private-password@localhost:27017", "comein_test")
    assert result["mongo_url"] == "REDACTED"
    assert "private-password" not in str(result)
    assert "private-user" not in str(result)


def test_unique_index_preflight_is_read_only_and_does_not_expose_duplicate_keys():
    db = _Database()
    comein_mongo.init_db(db)
    result = comein_mongo.preflight_unique_indexes(db)
    assert result["ok"] is True
    assert result["duplicates"] == []
    assert result["unique_indexes_checked"] > 0
    assert all(collection.last_options["maxTimeMS"] == 30000 for collection in db.collections.values() if hasattr(collection, "last_options"))
