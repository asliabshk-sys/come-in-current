"""Static integration contracts for Shopping/Restaurant shared systems.

These checks do not replace browser, MongoDB, GPS-device, gateway, or provider tests.
"""
import ast
import re
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text()
TREE = ast.parse(SERVER)
CHECKOUT = (ROOT / "frontend" / "app" / "restaurant" / "checkout.tsx").read_text()
AUTH_STORE = (ROOT / "frontend" / "src" / "store" / "auth.tsx").read_text()
ROOT_LAYOUT = (ROOT / "frontend" / "app" / "_layout.tsx").read_text()
TRACKING_UI = (ROOT / "frontend" / "app" / "order-tracking.tsx").read_text()
RESTAURANT_ORDER_UI = (ROOT / "frontend" / "app" / "restaurant" / "orders" / "[id].tsx").read_text()


def route_exists(method, path):
    for node in ast.walk(TREE):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute)
                    and isinstance(dec.func.value, ast.Name) and dec.func.value.id == "api"
                    and dec.func.attr.upper() == method and dec.args
                    and isinstance(dec.args[0], ast.Constant) and dec.args[0].value == path):
                return True
    return False


def function_source(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SERVER, node)


def test_shopping_and_restaurant_share_one_auth_provider_and_token_store():
    assert "<AuthProvider>" in ROOT_LAYOUT
    assert "TOKEN_KEY = \"@comein_auth_token_v1\"" in (ROOT / "frontend" / "src" / "lib" / "api.ts").read_text()
    assert "useAuth()" in CHECKOUT
    assert 'api.get<SavedAddress[]>(\'/addresses\')' in CHECKOUT
    assert "No separate restaurant account is needed" in CHECKOUT
    assert 'api.post("/auth/login"' in AUTH_STORE or '"/auth/login"' in AUTH_STORE


def test_saved_addresses_are_authenticated_and_scoped_to_the_signed_in_user():
    assert route_exists("GET", "/addresses")
    assert route_exists("POST", "/addresses")
    assert route_exists("PATCH", "/addresses/{address_id}")
    assert route_exists("DELETE", "/addresses/{address_id}")
    assert 'db.addresses.find({"user_id": user["id"]})' in function_source("list_addresses")
    assert '"user_id":user["id"]' in function_source("update_address")
    assert re.sub(r"\s+", "", '"user_id":user["id"]') in re.sub(r"\s+", "", function_source("delete_address"))


def test_restaurant_checkout_reuses_saved_address_ids_and_defaults_without_faking_gps():
    assert 'address_id: fulfillment === \'delivery\' && addressId ? addressId : undefined' in CHECKOUT
    assert "item.is_default" in CHECKOUT
    assert "formatAddress(selected)" in CHECKOUT
    assert "router.push('/delivery-address'" in CHECKOUT
    assert "GPS access is requested only when you choose it" in CHECKOUT
    assert "navigator.geolocation" not in CHECKOUT


def test_backend_resolves_saved_address_by_authenticated_owner_and_validates_delivery_availability():
    create = function_source("create_restaurant_order")
    assert 'db.addresses.find_one({"_id": _object_id_or_404(body.address_id, "Address"), "user_id": user["id"]})' in create
    assert 'if body.fulfillment == "delivery" and not restaurant.get("delivery_available", True)' in create
    assert 'if body.fulfillment == "pickup" and not restaurant.get("pickup_available", True)' in create
    assert "calculate_restaurant_totals(subtotal" in create
    assert '"total":totals["total"]' in create


def test_restaurant_orders_reuse_authenticated_customer_order_contract_and_idempotency():
    assert route_exists("POST", "/restaurant/orders")
    assert route_exists("GET", "/restaurant/orders/mine")
    create = function_source("create_restaurant_order")
    assert 'Depends(get_current_user)' in create
    assert 'db.restaurant_orders.find_one({"customer_id": user["id"], "idempotency_key": body.idempotency_key})' in create
    assert '"customer_id":user["id"]' in function_source("my_restaurant_orders")


def test_shared_tracking_endpoint_supports_restaurant_orders_without_fake_coordinates():
    assert route_exists("GET", "/orders/{order_id}/tracking")
    assert route_exists("POST", "/orders/{order_id}/tracking/location")
    assert 'if kind == "restaurant":\n        collection = db.restaurant_orders' in function_source("_tracking_order")
    assert 'order.get("delivery_location") if active else None' in function_source("get_order_tracking")
    assert "No driver movement, route, or ETA is simulated" in TRACKING_UI
    assert "no live delivery-partner location is connected" in RESTAURANT_ORDER_UI
    permission = function_source("_tracking_can_read")
    assert 'order.get("restaurant_owner_id") != user.get("id")' in permission
    assert 'db.restaurants.find_one' in permission
    assert 'restaurant.get("owner_id") == user.get("id")' in permission


def test_restaurant_payment_ui_does_not_claim_success_or_call_gateway_without_sdk():
    assert "payment-intent" not in CHECKOUT
    assert "payments/verify" not in CHECKOUT
    assert 'paymentConfig?.razorpay_enabled && razorpaySupported()' in CHECKOUT
    assert "onlineEnabled && restaurantPaymentMethods.includes('razorpay')" in CHECKOUT
    assert "Online payment is confirmed only by the backend" in CHECKOUT
    assert "'/restaurant/orders/[id]'" in CHECKOUT
    component = (ROOT / 'frontend/src/components/GroceryOnlinePayment.tsx').read_text()
    assert 'const result = await openRazorpay(intent)' in component
    assert '`/${kind}/payments/verify`' in component
    assert 'if (verified.verified) { onChange(verified.order)' in component
    detail = (ROOT / 'frontend/app/restaurant/orders/[id].tsx').read_text()
    assert '<GroceryOnlinePayment kind="restaurant"' in detail
    assert route_exists("POST", "/restaurant/orders/{order_id}/payment-intent")
    assert route_exists("POST", "/restaurant/payments/verify")
    assert route_exists("POST", "/restaurant/payments/razorpay-webhook")
    assert 'Depends(get_current_user)' in function_source("verify_restaurant_payment")
    assert 'Payment amount does not match the order total' in function_source("verify_restaurant_payment")


def test_shared_logout_clears_the_same_token_and_existing_roles_remain_authoritative():
    assert "const logout = useCallback(async () =>" in AUTH_STORE
    assert "await clearToken()" in AUTH_STORE
    assert 'type Role = "customer" | "shopkeeper" | "admin"' in AUTH_STORE
    assert 'if user.get("role") != "admin" and restaurant.get("owner_id") != user.get("id")' in SERVER
    assert 'Depends(require_role("admin"))' in function_source("admin_refund_restaurant_order")


def test_no_shared_notification_delivery_provider_is_claimed_by_current_source():
    # In-app notifications exist; native push registration/delivery remains unconfigured.
    routes = {
        (dec.func.attr.upper(), dec.args[0].value)
        for node in ast.walk(TREE) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        for dec in node.decorator_list
        if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute)
        and isinstance(dec.func.value, ast.Name) and dec.func.value.id == "api"
        and dec.args and isinstance(dec.args[0], ast.Constant) and isinstance(dec.args[0].value, str)
    }
    paths = {path for _, path in routes}
    assert "/notifications/mine" in paths and "/notifications/read-all" in paths
    assert not any(any(key in path.lower() for key in ("push-token", "device-token", "push/register")) for path in paths)


def test_restaurant_payment_intents_reuse_existing_gateway_order_and_reject_closed_orders():
    intent = function_source("create_restaurant_payment_intent")
    retry = function_source("retry_restaurant_payment")
    assert '"status":"created"' in intent
    assert "Existing payment intent does not match the current order total" in intent
    assert 'order.get("status")!="pending_payment"' in intent
    assert 'order.get("status")!="pending_payment"' in retry


def test_restaurant_payment_verification_requires_gateway_captured_payment_lookup():
    verify = function_source("verify_restaurant_payment")
    assert 'http_requests.get(' in verify
    assert '"status") != "captured"' in verify
    assert '"currency") != "INR"' in verify
    assert '"order_id") != body.razorpay_order_id' in verify
    assert "Payment status could not be confirmed with the gateway" in verify
    assert 'await _commit_restaurant_capture(' in verify
    capture = function_source("_commit_restaurant_capture")
    assert '"status": "pending_payment"' in capture
    assert 'return await run_transaction(client, commit)' in capture


def test_restaurant_checkout_uses_backend_configured_pincode_serviceability():
    assert "explicitly configured verified pincode coverage list" in CHECKOUT
    create = function_source("create_restaurant_order")
    assert "check_restaurant_serviceability(restaurant, delivery_pincode)" in create
    assert 'raise HTTPException(status_code=status_code, detail=serviceability["reason"])' in create
    assert '"/restaurants/{restaurant_id}/serviceability"' in SERVER
    assert 'pincode: Optional[str] = None' in function_source("list_restaurants")
    assert "delivery_serviceable_pincodes" in SERVER
    assert "delivery_radius_km" not in create


def test_captured_webhook_never_resurrects_cancelled_restaurant_order():
    webhook = function_source("razorpay_webhook")
    capture = function_source("_commit_restaurant_capture")
    assert 'await _commit_restaurant_capture(' in webhook
    assert '"payment_reconciliation_required": True' in capture
    assert 'order.get("status") == "pending_payment"' in capture
    assert '"status": "placed"' in capture
    assert '"status": order.get("status")' in capture
    assert '"payment_status": "paid"' in capture


def test_payment_failure_retry_and_late_capture_paths_are_guarded():
    retry = function_source("retry_restaurant_payment")
    verify = function_source("verify_restaurant_payment")
    webhook = function_source("razorpay_webhook")
    assert 'order.get("payment_status") not in {"failed","pending"}' in retry
    assert 'order.get("payment_status") == "paid"' in verify
    capture = function_source("_commit_restaurant_capture")
    assert 'await _commit_restaurant_capture(' in webhook
    assert '"payment_reconciliation_required": True' in capture
    assert 'order.get("status") == "pending_payment"' in capture
    assert '"duplicate": True' in webhook
    assert '"gateway_payment_id"' in verify


def test_restaurant_discovery_uses_shared_saved_address_and_refreshes_pincode_filter():
    frontend = ROOT / "frontend"
    hook = (frontend / "src/restaurant/useDiscoveryAddress.ts").read_text()
    home = (frontend / "app/restaurant/index.tsx").read_text()
    search = (frontend / "app/restaurant/search.tsx").read_text()
    categories = (frontend / "app/restaurant/categories.tsx").read_text()
    api_client = (frontend / "src/restaurant/api.ts").read_text()
    assert "api.get<DiscoveryAddress[]>('/addresses')" in hook
    assert "validIndianPincode" in hook and "pincodeFromLocationText" in hook
    assert "listLiveRestaurants('',{pincode:deliveryAddress.selectedPincode})" in home
    assert "[deliveryAddress.selectedPincode]" in home
    assert "pincode:deliveryAddress.selectedPincode" in search
    assert "pincode:deliveryAddress.selectedPincode" in categories
    assert "params.set('pincode',filters.pincode)" in api_client
    assert "coverage filter, not a final delivery guarantee" in home


def test_discovery_address_handles_missing_or_invalid_pincode_without_claiming_serviceability():
    frontend = ROOT / "frontend"
    hook = (frontend / "src/restaurant/useDiscoveryAddress.ts").read_text()
    home = (frontend / "app/restaurant/index.tsx").read_text()
    assert "No saved addresses found" in hook
    assert "A valid pincode" in hook
    assert "No valid pincode is available yet" in home
    assert "This is a coverage filter, not a final delivery guarantee" in home
