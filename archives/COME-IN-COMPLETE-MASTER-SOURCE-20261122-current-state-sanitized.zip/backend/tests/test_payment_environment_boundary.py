"""Configuration-only cases; no provider credentials or network operations."""
import secrets

import pytest

from payment_config import razorpay_settings


def inputs(app="test", mode="test", key_mode="test"):
    # Non-credential structural IDs and ephemeral local material never leave
    # this process and are never used to contact a payment provider.
    return {"APP_ENV": app, "RAZORPAY_MODE": mode,
            "RAZORPAY_KEY_ID": f"rzp_{key_mode}_local-validation-only",
            "RAZORPAY_KEY_SECRET": secrets.token_urlsafe(24)}


def test_disabled_is_allowed_but_an_operation_requires_both_keys():
    assert razorpay_settings({}) is None
    with pytest.raises(ValueError, match="both server-side keys"):
        razorpay_settings({}, required=True)


@pytest.mark.parametrize("app,mode,key_mode", [
    ("test", "live", "live"), ("development", "live", "live"),
    ("production", "test", "test"), ("prod", "test", "test"),
    ("test", "test", "live"), ("production", "live", "test"),
])
def test_conflicting_environment_or_key_modes_fail_closed(app, mode, key_mode):
    with pytest.raises(ValueError):
        razorpay_settings(inputs(app, mode, key_mode), required=True)


@pytest.mark.parametrize("app,mode", [("test", "test"), ("development", "test"), ("production", "live")])
def test_explicit_consistent_mode_is_retained_without_fallback(app, mode):
    env = inputs(app, mode, mode)
    result = razorpay_settings(env, required=True)
    assert result.mode == mode
    assert result.key_id == env["RAZORPAY_KEY_ID"]
    assert env["RAZORPAY_KEY_SECRET"] not in repr(result)
    assert env["RAZORPAY_KEY_ID"] not in repr(result)


def test_missing_mode_is_not_inferred_from_key():
    env = inputs(); env.pop("RAZORPAY_MODE")
    with pytest.raises(ValueError, match="RAZORPAY_MODE is required"):
        razorpay_settings(env)


def test_webhook_requires_its_separate_secret():
    env = inputs()
    with pytest.raises(ValueError, match="webhook secret"):
        razorpay_settings(env, webhook=True)
    env["RAZORPAY_WEBHOOK_SECRET"] = secrets.token_urlsafe(24)
    result = razorpay_settings(env, webhook=True)
    assert result.webhook_secret == env["RAZORPAY_WEBHOOK_SECRET"]
    assert result.webhook_secret not in repr(result)


def test_errors_never_echo_key_values():
    env = inputs(key_mode="live")
    with pytest.raises(ValueError) as error:
        razorpay_settings(env)
    assert env["RAZORPAY_KEY_ID"] not in str(error.value)
    assert env["RAZORPAY_KEY_SECRET"] not in str(error.value)


def test_conflicting_environment_aliases_fail_closed():
    env = inputs(); env["ENVIRONMENT"] = "production"
    with pytest.raises(ValueError, match="disagree"):
        razorpay_settings(env)
