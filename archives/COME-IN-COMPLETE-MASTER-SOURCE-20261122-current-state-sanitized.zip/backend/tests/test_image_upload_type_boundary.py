"""Execute the real upload endpoint with local storage doubles; no cloud calls."""
import ast
import asyncio
import mimetypes
from pathlib import Path
from types import SimpleNamespace
import uuid

import pytest
from fastapi import HTTPException


def upload_endpoint(content_type, data):
    path = Path(__file__).parents[1] / "server.py"
    node = next(n for n in ast.parse(path.read_text()).body if isinstance(n, ast.AsyncFunctionDef) and n.name == "upload_image")
    node.decorator_list = []; node.args.defaults = []
    for arg in node.args.args: arg.annotation = None
    writes = []
    async def insert(doc): writes.append(doc)
    async def read(size=-1): return data[:size] if size >= 0 else data
    def put(path, blob, mime):
        writes.append((blob, mime)); return {"path": path, "size": len(blob)}
    env = {"ALLOWED_IMAGE": {"image/jpeg", "image/png", "image/webp", "image/gif"},
           "MAX_UPLOAD_BYTES": 5 * 1024 * 1024, "HTTPException": HTTPException,
           "mimetypes": mimetypes, "uuid": uuid, "APP_NAME": "local-test",
           "put_object": put, "db": SimpleNamespace(files=SimpleNamespace(insert_one=insert)), "now_utc": lambda: None}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), env)
    return env["upload_image"](SimpleNamespace(content_type=content_type, filename="upload", read=read), {"id": "local-owner"}), writes

@pytest.mark.parametrize("mime", ["image/jpeg", "image/png", "image/gif", "image/webp"])
@pytest.mark.parametrize("data", [b"", b"<html>not an image</html>"])
def test_declared_image_mime_cannot_store_non_image_bytes(mime, data):
    call, writes = upload_endpoint(mime, data)
    with pytest.raises(HTTPException) as error:
        asyncio.run(call)
    assert error.value.status_code == 400
    assert writes == []


@pytest.mark.parametrize("mime,data", [
    ("image/jpeg", b"\xff\xd8\xff\xe0local-header-test"),
    ("image/png", b"\x89PNG\r\n\x1a\nlocal-header-test"),
    ("image/gif", b"GIF89alocal-header-test"),
    ("image/webp", b"RIFF\x04\x00\x00\x00WEBP"),
])
def test_matching_format_headers_preserve_supported_upload_paths(mime, data):
    # Header contract only; this intentionally does not claim full image decode.
    call, writes = upload_endpoint(mime, data)
    result = asyncio.run(call)
    assert result["url"].startswith("/api/uploads/local-test/uploads/local-owner/")
    assert writes[0] == (data, mime)
    assert len(writes) == 2


@pytest.mark.parametrize("mime,data", [
    ("image/jpeg", b"\x89PNG\r\n\x1a\n"),
    ("image/png", b"GIF89a"),
    ("image/gif", b"\xff\xd8\xff"),
    ("image/webp", b"RIFFno-webp"),
])
def test_mismatched_or_truncated_headers_are_not_stored(mime, data):
    call, writes = upload_endpoint(mime, data)
    with pytest.raises(HTTPException) as error:
        asyncio.run(call)
    assert error.value.status_code == 400
    assert writes == []
