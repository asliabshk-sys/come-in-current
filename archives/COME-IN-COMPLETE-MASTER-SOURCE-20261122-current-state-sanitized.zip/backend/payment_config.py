"""Razorpay environment boundary; never infer or switch gateway modes silently."""
from collections.abc import Mapping
from dataclasses import dataclass, field


@dataclass(frozen=True)
class RazorpaySettings:
    mode: str
    key_id: str = field(repr=False)
    key_secret: str = field(repr=False)
    webhook_secret: str = field(default="", repr=False)


def razorpay_settings(env: Mapping[str, str], *, required: bool = False,
                      webhook: bool = False) -> RazorpaySettings | None:
    app_env = (env.get("APP_ENV") or env.get("ENVIRONMENT") or "development").strip().lower()
    other_env = (env.get("ENVIRONMENT") or "").strip().lower()
    production = app_env in {"production", "prod"}
    if other_env and production != (other_env in {"production", "prod"}):
        raise ValueError("APP_ENV and ENVIRONMENT disagree about production")
    key_id = (env.get("RAZORPAY_KEY_ID") or "").strip()
    secret = (env.get("RAZORPAY_KEY_SECRET") or "").strip()
    mode = (env.get("RAZORPAY_MODE") or "").strip().lower()
    if mode and mode not in {"test", "live"}:
        raise ValueError("RAZORPAY_MODE must explicitly be test or live")
    if mode and ((production and mode != "live") or (not production and mode != "test")):
        raise ValueError("Razorpay mode is incompatible with APP_ENV")
    if not key_id or not secret:
        if required:
            raise ValueError("Razorpay is not configured: both server-side keys are required")
        return None
    if not mode:
        raise ValueError("RAZORPAY_MODE is required when Razorpay keys are configured")
    if not key_id.startswith(f"rzp_{mode}_") or not key_id[len(f"rzp_{mode}_"):]:
        raise ValueError("Razorpay key mode does not match the configured environment")
    webhook_secret = (env.get("RAZORPAY_WEBHOOK_SECRET") or "").strip()
    if webhook and not webhook_secret:
        raise ValueError("Razorpay webhook secret is not configured")
    return RazorpaySettings(mode, key_id, secret, webhook_secret)
