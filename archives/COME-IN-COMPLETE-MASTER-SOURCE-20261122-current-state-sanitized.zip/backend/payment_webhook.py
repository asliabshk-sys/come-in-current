"""Verify signed provider bytes before interpreting strictly bounded event data."""
import hashlib
import hmac
import json
import re

SUPPORTED_EVENTS = {"payment.captured", "payment.failed", "refund.processed", "refund.failed"}


def verified_event(raw: bytes, signature: str, secret: str, event_id: str) -> dict:
    if not raw or len(raw) > 1024 * 1024:
        raise ValueError("Invalid webhook body size")
    expected = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    if not isinstance(signature, str) or not hmac.compare_digest(expected, signature):
        raise ValueError("Invalid webhook signature")
    return event_payload(raw, event_id)


def event_payload(raw: bytes, event_id: str) -> dict:
    if not raw or len(raw) > 1024 * 1024:
        raise ValueError("Invalid webhook body size")
    if not isinstance(event_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,200}", event_id):
        raise ValueError("A valid X-Razorpay-Event-Id is required")
    try:
        payload = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise ValueError("Invalid webhook JSON") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("event"), str):
        raise ValueError("Invalid webhook envelope")
    event = payload["event"]
    if event in SUPPORTED_EVENTS:
        section = "refund" if event.startswith("refund.") else "payment"
        fields = payload.get("payload")
        if not isinstance(fields, dict) or not isinstance(fields.get(section), dict):
            raise ValueError("Invalid webhook payload")
        entity = fields[section].get("entity")
        if not isinstance(entity, dict):
            raise ValueError("Invalid webhook entity")
        for key in ["id", "payment_id" if section == "refund" else "order_id"]:
            if not isinstance(entity.get(key), str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", entity[key]):
                raise ValueError("Invalid webhook entity identifier")
        amount = entity.get("amount")
        if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
            raise ValueError("Invalid webhook amount")
        if section == "payment" and entity.get("currency") != "INR":
            raise ValueError("Invalid webhook currency")
        expected_status = event.split(".")[1]
        if entity.get("status") != expected_status:
            raise ValueError("Webhook event and entity status disagree")
    return payload
