"""Safe, source-preserving adapters for COME-IN catalogue imports.

This module extracts source evidence only. It does not create or update products,
assign categories, infer stock, or publish records. All extracted rows require
seller review and explicit application by the existing catalogue workflow.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import zipfile
from dataclasses import dataclass, asdict
from pathlib import PurePosixPath
from typing import Any

MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_BATCH_TOTAL_BYTES = 20 * 1024 * 1024
MAX_BATCH_FILES = 20
MAX_ZIP_MEMBERS = 100
MAX_ZIP_UNCOMPRESSED = 50 * 1024 * 1024
MAX_ROWS = 10000
SUPPORTED = {".csv", ".xls", ".xlsx", ".pdf", ".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"}

ALIASES = {
    "name": {"name", "product", "product name", "item", "item name", "वस्तु", "उत्पाद", "प्रोडक्ट", "सामान"},
    "brand": {"brand", "manufacturer", "ब्रांड", "कंपनी"},
    "price": {"price", "selling price", "sale price", "रेट", "कीमत", "मूल्य"},
    "mrp": {"mrp", "list price"},
    "stock": {"stock", "quantity", "qty", "available quantity", "स्टॉक", "मात्रा", "संख्या"},
    "unit": {"unit", "uom", "measure", "इकाई", "यूनिट"},
    "sku": {"sku", "item code", "product code", "कोड"},
    "barcode": {"barcode", "ean", "upc", "बारकोड"},
    "category": {"category", "subcategory", "श्रेणी", "उपश्रेणी"},
    "description": {"description", "details", "विवरण"},
    "sell_by": {"sell_by", "sell by", "selling mode", "product mode"},
    "dimension": {"dimension", "measure dimension"},
    "base_unit": {"base_unit", "base unit", "inventory unit"},
    "price_basis": {"price_basis", "price basis", "rate basis"},
    "min_qty": {"min_qty", "minimum quantity", "min quantity"},
    "step": {"step", "quantity step"},
    "max_qty": {"max_qty", "maximum quantity", "max quantity"},
    "presets": {"presets", "quick quantities"},
}

@dataclass
class ExtractedRecord:
    source_file: str
    source_location: str
    raw_values: dict[str, Any]
    normalized: dict[str, Any]
    status: str = "NEEDS_REVIEW"
    warnings: list[str] | None = None

@dataclass
class ExtractionResult:
    filename: str
    detected_type: str
    sha256: str
    records: list[dict[str, Any]]
    pages_or_sheets: int
    warnings: list[str]


def _extension(filename: str) -> str:
    return PurePosixPath(filename.replace("\\", "/")).suffix.lower()


def _detect(raw: bytes, ext: str) -> str:
    if not raw:
        raise ValueError("empty file")
    signatures = {
        ".xls": raw.startswith(bytes.fromhex("D0CF11E0A1B11AE1")),
        ".pdf": raw.startswith(b"%PDF-"),
        ".png": raw.startswith(b"\x89PNG\r\n\x1a\n"),
        ".jpg": raw.startswith(b"\xff\xd8\xff"),
        ".jpeg": raw.startswith(b"\xff\xd8\xff"),
        ".webp": len(raw) >= 12 and raw[:4] == b"RIFF" and raw[8:12] == b"WEBP",
        ".tif": raw.startswith((b"II*\x00", b"MM\x00*")),
        ".tiff": raw.startswith((b"II*\x00", b"MM\x00*")),
        ".bmp": raw.startswith(b"BM"),
        ".xlsx": raw.startswith(b"PK\x03\x04"),
    }
    if ext in {".csv"}:
        try:
            raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError("CSV must be UTF-8 or UTF-8 with BOM") from exc
        return "csv"
    if ext not in SUPPORTED:
        raise ValueError(f"unsupported file type: {ext or 'unknown'}")
    if not signatures.get(ext, False):
        raise ValueError("file content does not match its extension")
    return ext[1:]


def validate_upload_metadata(filename: str, content_type: str | None, raw: bytes) -> str:
    """Validate upload metadata while treating browser octet-stream as neutral."""
    if not isinstance(filename, str) or not filename.strip() or len(filename) > 255:
        raise ValueError("filename is missing or too long")
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in filename):
        raise ValueError("filename contains control characters")
    ext = _extension(filename)
    if ext == ".zip":
        if not raw or not raw.startswith(b"PK\x03\x04"):
            raise ValueError("ZIP content signature is invalid")
        detected = "zip"
    else:
        detected = _detect(raw, ext)
    mime = (content_type or "").split(";", 1)[0].strip().lower()
    allowed = {
        ".csv": {"text/csv", "text/plain", "application/csv", "application/octet-stream"},
        ".xls": {"application/vnd.ms-excel", "application/octet-stream"},
        ".xlsx": {"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream"},
        ".pdf": {"application/pdf", "application/octet-stream"},
        ".jpg": {"image/jpeg", "application/octet-stream"}, ".jpeg": {"image/jpeg", "application/octet-stream"},
        ".png": {"image/png", "application/octet-stream"},
        ".webp": {"image/webp", "application/octet-stream"},
        ".tif": {"image/tiff", "application/octet-stream"}, ".tiff": {"image/tiff", "application/octet-stream"},
        ".bmp": {"image/bmp", "application/octet-stream"},
        ".zip": {"application/zip", "application/x-zip-compressed", "application/octet-stream"},
    }
    if mime and mime not in allowed.get(ext, set()):
        raise ValueError("MIME type does not match the supported file extension")
    return detected


def _normalize_row(row: dict[str, Any]) -> dict[str, Any]:
    normalized = {k: None for k in ALIASES}
    for key, value in row.items():
        label = str(key or "").strip().casefold()
        for target, aliases in ALIASES.items():
            if label in aliases and value not in (None, ""):
                normalized[target] = str(value).strip()
                break
    # Deliberately do not coerce ambiguous values or infer missing stock/price.
    return normalized


def _rows_from_csv(raw: bytes, filename: str) -> tuple[list[dict], int, list[str]]:
    text = raw.decode("utf-8-sig")
    dialect = csv.excel
    try:
        if text.strip():
            # Column separators come from the header, not punctuation inside
            # untrusted cell values (for example a formula containing '|').
            dialect = csv.Sniffer().sniff(text.splitlines()[0], delimiters=",;\t|")
            try:
                dialect = csv.Sniffer().sniff(text[:8192], delimiters=dialect.delimiter)
            except csv.Error:
                # Irregular source rows must not change the header's separator.
                pass
    except csv.Error:
        pass
    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    if not reader.fieldnames or any(not str(h or "").strip() for h in reader.fieldnames):
        raise ValueError("CSV needs a non-empty header row")
    rows, warnings = [], []
    for idx, row in enumerate(reader, start=2):
        if idx > MAX_ROWS + 1:
            raise ValueError(f"row limit exceeded ({MAX_ROWS})")
        if not any(v not in (None, "") for v in row.values()):
            continue
        rows.append(ExtractedRecord(filename, f"row:{idx}", dict(row), _normalize_row(row)).__dict__)
    return rows, 1, warnings


def _rows_from_xlsx(raw: bytes, filename: str) -> tuple[list[dict], int, list[str]]:
    # XLSX is a ZIP container; bound its expansion before passing it to openpyxl.
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as container:
            members = container.infolist()
            if len(members) > 1000:
                raise ValueError("XLSX contains too many internal files")
            expanded = sum(member.file_size for member in members)
            if expanded > MAX_ZIP_UNCOMPRESSED:
                raise ValueError("XLSX uncompressed size limit exceeded")
            for member in members:
                if member.file_size and member.file_size / max(member.compress_size, 1) > 100:
                    raise ValueError("XLSX compression ratio limit exceeded")
    except zipfile.BadZipFile as exc:
        raise ValueError("invalid XLSX container") from exc
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise RuntimeError("XLSX adapter unavailable: openpyxl is not installed") from exc
    wb = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
    records, warnings = [], []
    try:
        for ws in wb.worksheets:
            iterator = ws.iter_rows(values_only=True)
            headers = next(iterator, None)
            if not headers or not any(str(x or "").strip() for x in headers):
                warnings.append(f"{ws.title}: missing header row")
                continue
            names = [str(x or "").strip() for x in headers]
            if any(not n for n in names) or len({n.casefold() for n in names}) != len(names):
                warnings.append(f"{ws.title}: blank or duplicate headers; sheet skipped")
                continue
            for row_num, values in enumerate(iterator, start=2):
                if len(records) >= MAX_ROWS:
                    raise ValueError(f"row limit exceeded ({MAX_ROWS})")
                if not any(v not in (None, "") for v in values):
                    continue
                raw_values = {names[i]: values[i] if i < len(values) else None for i in range(len(names))}
                records.append(ExtractedRecord(filename, f"sheet:{ws.title}/row:{row_num}", raw_values, _normalize_row(raw_values)).__dict__)
    finally:
        wb.close()
    return records, len(wb.sheetnames), warnings


def _rows_from_xls(raw: bytes, filename: str) -> tuple[list[dict], int, list[str]]:
    try:
        import pandas as pd
    except ImportError as exc:
        raise RuntimeError("XLS adapter unavailable: pandas is not installed") from exc
    try:
        sheets = pd.read_excel(io.BytesIO(raw), sheet_name=None, dtype=object, engine="xlrd")
    except ImportError as exc:
        raise RuntimeError("XLS adapter unavailable: xlrd is not installed") from exc
    except Exception as exc:
        raise ValueError("invalid or unreadable XLS workbook") from exc
    records, warnings = [], []
    for sheet, frame in sheets.items():
        if frame.empty and len(frame.columns) == 0:
            warnings.append(f"{sheet}: missing header row")
            continue
        names = [str(x or "").strip() for x in frame.columns]
        if any(not n for n in names) or len({n.casefold() for n in names}) != len(names):
            warnings.append(f"{sheet}: blank or duplicate headers; sheet skipped")
            continue
        for row_num, values in enumerate(frame.itertuples(index=False, name=None), start=2):
            if len(records) >= MAX_ROWS:
                raise ValueError(f"row limit exceeded ({MAX_ROWS})")
            raw_values = {names[i]: (None if i >= len(values) or (isinstance(values[i], float) and values[i] != values[i]) else values[i]) for i in range(len(names))}
            if not any(v not in (None, "") for v in raw_values.values()):
                continue
            records.append(ExtractedRecord(filename, f"sheet:{sheet}/row:{row_num}", raw_values, _normalize_row(raw_values)).__dict__)
    return records, len(sheets), warnings


def _rows_from_pdf(raw: bytes, filename: str) -> tuple[list[dict], int, list[str]]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise RuntimeError("PDF text adapter unavailable: pypdf is not installed") from exc
    reader = PdfReader(io.BytesIO(raw), strict=True)
    if len(reader.pages) > 100:
        raise ValueError("PDF page limit exceeded (100)")
    records, warnings, scanned_pages = [], [], []
    for page_no, page in enumerate(reader.pages, start=1):
        text = (page.extract_text() or "").strip()
        if not text:
            scanned_pages.append((page_no, page))
            continue
        records.append(ExtractedRecord(filename, f"page:{page_no}", {"extracted_text": text}, {}, "NEEDS_REVIEW", ["PDF text requires seller/AI field review"]).__dict__)
    # Optional offline OCR fallback: only when the already-installed PyMuPDF and
    # pytesseract stack is present. Bound the work to five scanned pages per file.
    if scanned_pages:
        try:
            import fitz
            from PIL import Image
            import pytesseract
            if len(scanned_pages) > 5:
                warnings.append("scanned PDF OCR limited to first 5 textless pages; remaining pages require manual review")
            for page_no, _page in scanned_pages[:5]:
                doc = fitz.open(stream=raw, filetype="pdf")
                try:
                    pix = doc.load_page(page_no - 1).get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
                    if pix.width * pix.height > 20_000_000:
                        warnings.append(f"page:{page_no}: OCR skipped due to pixel limit")
                        continue
                    image = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                    try:
                        text = pytesseract.image_to_string(image, lang="eng+hin", timeout=20)
                    except Exception:
                        text = pytesseract.image_to_string(image, lang="eng", timeout=20)
                    if text.strip():
                        records.append(ExtractedRecord(filename, f"page:{page_no}/ocr", {"extracted_text": text}, {}, "NEEDS_REVIEW", ["Scanned PDF OCR is unverified; manual seller review required"]).__dict__)
                    else:
                        warnings.append(f"page:{page_no}: OCR produced no text; manual review required")
                finally:
                    doc.close()
        except ImportError:
            warnings.extend([f"page:{page_no}: no selectable text; OCR dependencies unavailable" for page_no, _ in scanned_pages])
        except Exception as exc:
            warnings.append(f"scanned PDF OCR unavailable: {str(exc)[:160]}")
    return records, len(reader.pages), warnings

def _rows_from_image(raw: bytes, filename: str) -> tuple[list[dict], int, list[str]]:
    try:
        from PIL import Image, ImageOps
        import pytesseract
    except ImportError as exc:
        raise RuntimeError("Image OCR adapter unavailable: Pillow and pytesseract are required") from exc
    try:
        image = Image.open(io.BytesIO(raw))
        image.verify()
        image = Image.open(io.BytesIO(raw))
        if image.width * image.height > 40_000_000:
            raise ValueError("image pixel limit exceeded")
        image = ImageOps.exif_transpose(image).convert("RGB")
        try:
            text = pytesseract.image_to_string(image, lang="eng+hin", timeout=20)
        except Exception:
            text = pytesseract.image_to_string(image, lang="eng", timeout=20)
    except Exception as exc:
        raise ValueError(f"image could not be safely decoded or OCR processed: {exc}") from exc
    if not text.strip():
        return [], 1, ["image contains no confidently extracted text; manual review required"]
    record = ExtractedRecord(filename, "image:1", {"extracted_text": text}, {}, "NEEDS_REVIEW", ["OCR output is unverified; no fields were inferred"])
    return [record.__dict__], 1, []


def process_file(filename: str, raw: bytes) -> ExtractionResult:
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError(f"file exceeds {MAX_FILE_BYTES} byte limit")
    ext = _extension(filename)
    kind = _detect(raw, ext)
    if kind == "xls": records, units, warnings = _rows_from_xls(raw, filename)
    elif kind == "csv": records, units, warnings = _rows_from_csv(raw, filename)
    elif kind == "xlsx": records, units, warnings = _rows_from_xlsx(raw, filename)
    elif kind == "pdf": records, units, warnings = _rows_from_pdf(raw, filename)
    elif kind in {"jpg", "jpeg", "png", "webp", "tif", "tiff", "bmp"}: records, units, warnings = _rows_from_image(raw, filename)
    else: raise ValueError("no processing adapter for detected file type")
    return ExtractionResult(filename, kind, hashlib.sha256(raw).hexdigest(), records, units, warnings)


def process_zip(filename: str, raw: bytes) -> list[ExtractionResult]:
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError("ZIP exceeds upload size limit")
    if not raw.startswith(b"PK\x03\x04"):
        raise ValueError("ZIP content signature is invalid")
    results = []
    total_size = 0
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            members = [m for m in archive.infolist() if not m.is_dir()]
            if len(members) > MAX_ZIP_MEMBERS:
                raise ValueError("ZIP contains too many files")
            for member in members:
                path = PurePosixPath(member.filename.replace("\\", "/"))
                if path.is_absolute() or ".." in path.parts or member.flag_bits & 1:
                    raise ValueError("ZIP contains unsafe path or encrypted entry")
                total_size += member.file_size
                if total_size > MAX_ZIP_UNCOMPRESSED:
                    raise ValueError("ZIP uncompressed size limit exceeded")
                if member.file_size and member.file_size / max(member.compress_size, 1) > 100:
                    raise ValueError("ZIP compression ratio limit exceeded")
                if _extension(member.filename) not in SUPPORTED:
                    continue
                data = archive.read(member)
                results.append(process_file(path.name, data))
    except zipfile.BadZipFile as exc:
        raise ValueError("invalid or corrupted ZIP archive") from exc
    if not results:
        raise ValueError("ZIP contains no supported catalogue files")
    return results
