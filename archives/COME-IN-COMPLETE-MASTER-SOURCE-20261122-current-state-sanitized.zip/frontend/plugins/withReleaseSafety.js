const { withInfoPlist, withAndroidManifest, AndroidConfig } = require('expo/config-plugins');

module.exports = (config, { production = false } = {}) => {
  config = withInfoPlist(config, (mod) => {
    // image-picker disables its microphone permission, but CHAND audio recording
    // still needs its own usage description. Verify the final generated plist.
    mod.modResults.NSMicrophoneUsageDescription = 'COME-IN uses your microphone only when you choose to record a shopping request.';
    if (production) mod.modResults.NSAppTransportSecurity = { NSAllowsArbitraryLoads: false };
    return mod;
  });
  return withAndroidManifest(config, (mod) => {
    if (production) AndroidConfig.Manifest.getMainApplicationOrThrow(mod.modResults).$['android:usesCleartextTraffic'] = 'false';
    return mod;
  });
};
