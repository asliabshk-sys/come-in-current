import { NativeModules, Platform, TurboModuleRegistry } from "react-native";
import type { RazorpayIntent, RazorpayResult } from "./razorpay";

// Expo Go has no Razorpay module. This adapter is resolved only by native Metro.
export const checkoutSupported = () => (Platform.OS === "android" || Platform.OS === "ios") &&
  Boolean(NativeModules.RNRazorpayCheckout || TurboModuleRegistry.get("RNRazorpayCheckout"));
let checkoutOpen = false;
export async function openCheckout(intent: RazorpayIntent): Promise<RazorpayResult> {
  if (!checkoutSupported()) throw new Error("Online payment requires a COME-IN development build with Razorpay installed; Expo Go is not supported.");
  if (checkoutOpen) throw new Error("A payment window is already open. Return to it before retrying.");
  checkoutOpen = true;
  try {
    const { default: RazorpayCheckout } = await import("react-native-razorpay");
    return await RazorpayCheckout.open({ key: intent.key_id, order_id: intent.gateway_order_id,
      amount: intent.amount, currency: intent.currency, name: "COME-IN",
      description: `Order ${intent.order_ref}`, prefill: intent.prefill });
  } catch (error: unknown) {
    const detail = error as { code?: number; description?: string };
    throw new Error(detail.code === 0 ? "Payment window closed. Check the server payment status before retrying." :
      detail.description || "Payment was not confirmed. Check the server payment status before retrying.");
  } finally { checkoutOpen = false; }
}
