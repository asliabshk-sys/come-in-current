import type { RazorpayIntent, RazorpayResult } from "./razorpay";

let scriptPromise: Promise<void> | null = null;
function loadCheckoutScript(): Promise<void> {
  if ((window as any).Razorpay) return Promise.resolve();
  if (!scriptPromise) {
    scriptPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://checkout.razorpay.com/v1/checkout.js";
      s.async = true;
      s.onload = () => resolve();
      s.onerror = () => { scriptPromise = null; reject(new Error("Could not load the payment window. Check your connection and try again.")); };
      document.body.appendChild(s);
    });
  }
  return scriptPromise;
}

export async function openCheckout(intent: RazorpayIntent): Promise<RazorpayResult> {
  if (typeof window === "undefined") throw new Error("Online payment currently works in the web app. The Android/iOS app needs a native payment build first.");
  await loadCheckoutScript();
  return new Promise((resolve, reject) => {
    const rz = new (window as any).Razorpay({
      key: intent.key_id, order_id: intent.gateway_order_id, amount: intent.amount, currency: intent.currency,
      name: "COME-IN", description: `Order ${intent.order_ref}`, prefill: intent.prefill,
      handler: (r: RazorpayResult) => resolve(r),
      modal: { ondismiss: () => reject(new Error("Payment window closed. No payment was confirmed.")) },
    });
    rz.on("payment.failed", (r: any) => reject(new Error(r?.error?.description || "Payment failed. No payment was confirmed.")));
    rz.open();
  });
}

export const checkoutSupported = () => typeof window !== "undefined";
