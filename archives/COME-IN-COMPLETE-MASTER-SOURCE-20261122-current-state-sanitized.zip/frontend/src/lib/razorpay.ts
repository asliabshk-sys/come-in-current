import { useEffect, useState } from "react";
import { checkoutSupported, openCheckout } from "./razorpay-checkout";

import { api } from "@/src/lib/api";

// Task 17: Razorpay Standard Checkout for Grocery. Only the public key ID ever reaches the client.
export type RazorpayIntent = { key_id: string; gateway_order_id: string; amount: number; currency: string; order_ref: string; prefill?: { name?: string; contact?: string } };
export type RazorpayResult = { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string };
export type GroceryPaymentConfig = { razorpay_enabled: boolean; razorpay_key_id: string | null; mode: "test" | "live" | null };

export const razorpaySupported = checkoutSupported;
export const openRazorpay = openCheckout;

export function useGroceryPaymentConfig(kind: "grocery" | "restaurant" = "grocery"): GroceryPaymentConfig | null {
  const [config, setConfig] = useState<GroceryPaymentConfig | null>(null);
  useEffect(() => {
    let active = true;
    api.get<GroceryPaymentConfig>(`/${kind}/payments/config`, false)
      .then((c) => { if (active) setConfig(c); })
      .catch(() => { if (active) setConfig({ razorpay_enabled: false, razorpay_key_id: null, mode: null }); });
    return () => { active = false; };
  }, [kind]);
  return config;
}

