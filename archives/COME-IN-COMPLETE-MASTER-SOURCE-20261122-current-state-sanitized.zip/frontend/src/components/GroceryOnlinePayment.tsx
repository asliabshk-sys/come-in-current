import { useCallback, useEffect, useRef, useState } from "react";
import { AppState, Pressable, Text, View } from "react-native";

import { api } from "@/src/lib/api";
import { openRazorpay, RazorpayIntent } from "@/src/lib/razorpay";
import { makeStyles, radius, spacing } from "@/src/theme";

type Props = { order: any; kind?: "grocery" | "restaurant"; onChange: (order: any) => void };

/** Task 17: pay / retry / cancel an unpaid Grocery Razorpay order. Paid state comes only from the server. */
export function GroceryOnlinePayment({ order, onChange, kind = "grocery" }: Props) {
  const styles = useStyles();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const busyRef = useRef(false);
  const refresh = useCallback(async () => {
    const updated = kind === "grocery" ? await api.get<any>(`/orders/${order.id}`) :
      (await api.get<any[]>("/restaurant/orders/mine")).find((row) => row.id === order.id);
    if (updated) onChange(updated);
    return updated;
  }, [kind, order.id, onChange]);
  useEffect(() => {
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "active") void refresh().catch(() => setMessage("Could not refresh payment status. Check order history before retrying."));
    });
    return () => subscription.remove();
  }, [refresh]);
  const pay = async () => {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true); setMessage("");
    try {
            const current = await refresh();
      if (!current || current.status !== "pending_payment" || current.payment_status === "paid") return;
      if (kind === "restaurant" && current.payment_status === "failed") await api.post(`/restaurant/orders/${order.id}/payment-retry`, {});
      const intent = await api.post<RazorpayIntent>(`${kind === "restaurant" ? "/restaurant" : ""}/orders/${order.id}/payment-intent`, {});
      const result = await openRazorpay(intent);
      setMessage("Confirming payment with the server…");
      const verified = await api.post<{ verified: boolean; order: any }>(`/${kind}/payments/verify`, { order_id: order.id, ...result });
      if (verified.verified) { onChange(verified.order); setMessage("Payment confirmed."); }
    } catch (e: any) {
      setMessage(e?.message || "Payment was not confirmed. Check order history before retrying.");
      try { await refresh(); } catch { /* Preserve original error; never infer payment success. */ }
    }
    finally { busyRef.current = false; setBusy(false); }
  };
  const cancel = async () => {
    setBusy(true); setMessage("");
    try { onChange(await api.post<any>(`${kind === "restaurant" ? "/restaurant" : ""}/orders/${order.id}/cancel`, {})); setMessage("Order cancellation saved. Any late payment will require reconciliation."); }
    catch (e: any) { setMessage(e?.message || "Could not cancel the order."); }
    finally { busyRef.current = false; setBusy(false); }
  };

  if (!(kind === "grocery" ? order.payment_status === "razorpay_pending" : ["pending", "failed"].includes(order.payment_status)) || order.status !== "pending_payment") return null;
  return (
    <View style={styles.wrap} testID={`grocery-online-payment-${order.id}`}>
      <Text style={styles.note}>{kind === "grocery" ? "Online payment pending. Stock is held for a limited time; unpaid orders are cancelled when the window ends." : "Online payment pending. The restaurant receives confirmation only after server verification."}</Text>
      <View style={styles.row}>
        <Pressable testID={`grocery-pay-now-${order.id}`} disabled={busy} onPress={pay} style={[styles.btn, busy && { opacity: 0.5 }]}><Text style={styles.btnText}>Pay ₹{Number(order.total).toFixed(2)} online</Text></Pressable>
        <Pressable testID={`grocery-pay-cancel-${order.id}`} disabled={busy} onPress={cancel} style={[styles.ghost, busy && { opacity: 0.5 }]}><Text style={styles.ghostText}>Cancel order</Text></Pressable>
      </View>
      {message ? <Text style={styles.note} testID={`grocery-pay-message-${order.id}`}>{message}</Text> : null}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  wrap: { gap: spacing.sm, marginTop: spacing.sm },
  row: { flexDirection: "row", gap: spacing.sm, flexWrap: "wrap" },
  btn: { minHeight: 44, paddingHorizontal: spacing.lg, borderRadius: radius.md, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" },
  btnText: { color: colors.onBrandPrimary, fontWeight: "800" },
  ghost: { minHeight: 44, paddingHorizontal: spacing.lg, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  ghostText: { color: colors.onSurface, fontWeight: "700" },
  note: { fontSize: 12, color: colors.muted },
}));
