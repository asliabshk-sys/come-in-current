import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { Pressable, Text, View } from "react-native";
import { useState } from "react";

import { QuantityStepper } from "@/src/components/QuantityStepper";
import { getProductPlaceholder, Product } from "@/src/data/catalog";
import { bigUnit, formatAmount, isMeasured, soldByLabel } from "@/src/lib/measure";
import { useT } from "@/src/i18n";
import { useCart } from "@/src/store/cart";
import { makeStyles, radius, spacing } from "@/src/theme";

type Props = {
  product: Product;
  width?: number;
};

export function ProductCard({ product, width }: Props) {
  const styles = useStyles();
  const router = useRouter();
  const { t } = useT();
  const { getQty, addProduct, increment, decrement, startBuyNow } = useCart();
  const [imageFailed, setImageFailed] = useState(!product.image);
  const [imageSource, setImageSource] = useState({ id: product.id, image: product.image });
  if (imageSource.id !== product.id || imageSource.image !== product.image) {
    setImageSource({ id: product.id, image: product.image });
    setImageFailed(!product.image);
  }
  const hasVariants = Boolean(product.variants?.length);
  const measured = isMeasured(product);
  const qty = getQty(product.id);
  const canBuyThisNow = product.source === "live" && Boolean(product.shopId) && !hasVariants && !measured && (product.stock === undefined || product.stock >= Math.max(1, qty));
  const buyNow = () => {
    if (product.source !== "live" || hasVariants || measured) { router.push(`/product/${product.id}`); return; }
    if (!canBuyThisNow) return;
    if (startBuyNow(product, undefined, Math.max(1, qty))) router.push("/checkout");
  };
  const discount =
    product.mrp && product.mrp > product.price
      ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
      : 0;

  return (
    <Pressable
      testID={`product-card-${product.id}`}
      onPress={() => router.push(`/product/${product.id}`)}
      style={[styles.card, width ? { width } : undefined]}
    >
      <View style={styles.imageWrap}>
        <Image source={imageFailed ? getProductPlaceholder(product.categoryId) : product.image} onError={() => setImageFailed(true)} style={styles.image} contentFit="cover" transition={150} />
        {discount > 0 && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{discount}% OFF</Text>
          </View>
        )}
      </View>
      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={2}>
          {product.name}
        </Text>
        <Text style={styles.unit}>{product.source === "catalog" ? "Pack size set by shop" : measured ? soldByLabel(product, t) : product.unit}</Text>
        {product.source === "catalog" && <Text style={styles.previewLabel}>Catalog reference · price and stock set by shop</Text>}
        {product.source === "demo" && <Text style={styles.previewLabel}>Preview only · not orderable</Text>}
        {product.source === "live" && product.shopName && <Text style={styles.unit}>Sold by {product.shopName}</Text>}
        {product.source === "live" && product.description?.trim() ? <Text style={styles.descriptionPreview} numberOfLines={2}>{product.description}</Text> : null}
        <View style={styles.footer}>
          <View style={styles.priceCol}>
            <Text style={styles.price}>{product.source === "catalog" ? "Price set by shop" : product.source === "demo" ? "Preview price only" : `₹${product.price}${measured ? `/${bigUnit(product)}` : ""}`}</Text>
            {product.mrp && product.mrp > product.price && (
              <Text style={styles.mrp}>₹{product.mrp}</Text>
            )}
          </View>
          {product.source !== "live" ? (
            <View style={styles.chooseBtn}><Text style={styles.chooseText}>{product.source === "catalog" ? "CATALOG" : "PREVIEW"}</Text></View>
          ) : hasVariants ? (
            <Pressable
              testID={`choose-variant-${product.id}`}
              accessibilityRole="button"
              onPress={() => router.push(`/product/${product.id}`)}
              style={styles.chooseBtn}
            >
              <Text style={styles.chooseText}>OPTIONS</Text>
            </Pressable>
          ) : (
            <QuantityStepper
              testID={`stepper-${product.id}`}
              qty={qty}
              label={measured && qty ? formatAmount(product, qty) : undefined}
              onAdd={() => addProduct(product)}
              onInc={() => increment(product.id, undefined, product)}
              onDec={() => decrement(product.id)}
            />
          )}
        </View>
        {product.source === "live" && <Pressable testID={`buy-now-card-${product.id}`} accessibilityRole="button" disabled={!hasVariants && !measured && !canBuyThisNow} onPress={buyNow} style={[styles.buyNowCardButton, !hasVariants && !measured && !canBuyThisNow && { opacity: 0.45 }]}><Text style={styles.buyNowCardText}>{hasVariants ? "Choose options to buy" : measured ? t("m.chooseBtn") : canBuyThisNow ? "Buy Now" : "Unavailable"}</Text></Pressable>}
      </View>
    </Pressable>
  );
}

const useStyles = makeStyles((colors) => ({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },
  imageWrap: {
    width: "100%",
    aspectRatio: 1,
    backgroundColor: colors.surfaceTertiary,
    position: "relative",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  discountBadge: {
    position: "absolute",
    top: spacing.sm,
    left: spacing.sm,
    backgroundColor: colors.brandSecondary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radius.sm,
  },
  discountText: {
    fontSize: 10,
    fontWeight: "800",
    color: colors.onBrandSecondary,
    letterSpacing: 0.3,
  },
  info: {
    padding: spacing.md,
    gap: spacing.xs,
  },
  name: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.onSurface,
    lineHeight: 18,
  },
  unit: {
    fontSize: 12,
    color: colors.muted,
    marginBottom: spacing.xs,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: spacing.xs,
  },
  buyNowCardButton: { marginTop: spacing.sm, minHeight: 30, borderRadius: radius.md, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.sm },
  buyNowCardText: { color: colors.onBrandPrimary, fontSize: 11, fontWeight: "800" },
  chooseBtn: { minWidth: 68, height: 32, paddingHorizontal: spacing.sm, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" },
  chooseText: { color: colors.brandPrimary, fontSize: 11, fontWeight: "800" },
  previewLabel: { color: colors.muted, fontSize: 10, fontWeight: "700" },
  descriptionPreview: { color: colors.muted, fontSize: 11, lineHeight: 15 },
  priceCol: {
    flexDirection: "row",
    alignItems: "baseline",
    gap: spacing.xs,
    flexShrink: 1,
  },
  price: {
    fontSize: 15,
    fontWeight: "800",
    color: colors.onSurface,
  },
  mrp: {
    fontSize: 12,
    color: colors.muted,
    textDecorationLine: "line-through",
  },
}));
