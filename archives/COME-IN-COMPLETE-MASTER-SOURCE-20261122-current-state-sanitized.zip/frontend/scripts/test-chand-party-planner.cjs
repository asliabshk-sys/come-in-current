/* Run with: node frontend/scripts/test-chand-party-planner.cjs
 * Requires the project's TypeScript devDependency. This test compiles the
 * pure planner helper in memory and exercises its deterministic calculations.
 */
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const Module = require("node:module");
const ts = require("typescript");

const helperPath = path.resolve(path.dirname(module.filename), "../src/lib/chand-party-planner.ts");
const source = fs.readFileSync(helperPath, "utf8");
const compiled = ts.transpileModule(source, {
  compilerOptions: {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.CommonJS,
  },
  reportDiagnostics: true,
});
const errors = (compiled.diagnostics || []).filter((item) => item.category === ts.DiagnosticCategory.Error);
assert.equal(errors.length, 0, errors.map((item) => ts.flattenDiagnosticMessageText(item.messageText, "\n")).join("\n"));
const loaded = new Module(helperPath, module);
loaded.filename = helperPath;
loaded.paths = Module._nodeModulePaths(path.dirname(helperPath));
loaded._compile(compiled.outputText, helperPath);
const { buildPartyPlanGroups, DEFAULT_PARTY_SERVING_ASSUMPTIONS, PARTY_OCCASION_SERVING_ASSUMPTIONS } = loaded.exports;

const live = (id, name, categoryId, unit, price, extras = {}) => ({
  id, name, brand: "", unit, price, image: "", categoryId, description: "", source: "live", ...extras,
});
const products = [
  live("s1", "Snack 500 g", "snacks", "500 g", 100),
  live("s2", "Snack 1 kg", "snacks", "1 kg", 180),
  live("b1", "Drink 1 L", "beverages", "1 L", 50),
  live("k1", "Cake 6 pcs", "bakery", "6 pcs", 240),
  live("f1", "Fruit measured", "fruits", "kg", 80, {
    sellBy: "weight",
    measure: { min_qty: 250, max_qty: 5000, step: 50, presets: [250, 500] },
    stock: 5000,
  }),
  live("d1", "Demo snack", "snacks", "500 g", 1, { source: "demo" }),
  live("sv1", "Unknown variant stock", "snacks", "500 g", 80, {
    variants: [{ id: "v1", unit: "500 g", price: 80 }],
  }),
];
const groups = buildPartyPlanGroups(products, 10, DEFAULT_PARTY_SERVING_ASSUMPTIONS);
assert.equal(groups.length, 4);
assert.equal(groups[0].requiredAmount, 1200);
assert.equal(groups[0].candidates[0].product.id, "s1");
assert.equal(groups[0].candidates[0].quantity, 3);
assert.equal(groups[1].requiredAmount, 3000);
assert.equal(groups[1].candidates[0].quantity, 3);
assert.equal(groups[2].candidates[0].quantity, 2);
assert.equal(groups[3].candidates[0].quantity, 800);
assert.equal(groups[0].candidates.some((item) => item.product.id === "d1"), false);
assert.equal(groups[0].candidates.some((item) => item.product.id === "sv1"), false);
assert.deepEqual(buildPartyPlanGroups(products, 0, DEFAULT_PARTY_SERVING_ASSUMPTIONS), []);
assert.notEqual(
  PARTY_OCCASION_SERVING_ASSUMPTIONS.birthday.snacksGramsPerGuest,
  PARTY_OCCASION_SERVING_ASSUMPTIONS["small party"].snacksGramsPerGuest,
);
console.log("CHAND_PARTY_PLANNER_TEST: 11 assertions PASS");
