const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const ts = require('typescript');
const filename = require('node:path').join(process.cwd(), 'src/lib/razorpay-checkout.native.ts');
const compiled = ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText;
function adapter(present, open) {
  const exports = {};
  const native = { NativeModules: present ? { RNRazorpayCheckout: {} } : {}, Platform: { OS: 'android' }, TurboModuleRegistry: { get: () => null } };
  vm.runInNewContext(compiled, { exports, require: (name) => name === 'react-native' ? native : { __esModule: true, default: { open } } });
  return exports;
}
(async () => {
  let passed = 0;
  const intent = { key_id: 'local-public-id-not-a-provider-key', gateway_order_id: 'local-order', amount: 1050, currency: 'INR', order_ref: 'LOCAL' };
  const absent = adapter(false, () => { throw Error('must not call'); });
  assert.equal(absent.checkoutSupported(), false); await assert.rejects(absent.openCheckout(intent), /development build/); passed++;
  let resolve; let calls = 0;
  const a = adapter(true, (options) => { calls++; assert.equal(options.key, intent.key_id); assert.equal(options.order_id, intent.gateway_order_id); assert.equal(options.amount, 1050); assert.equal('key_secret' in options, false); return new Promise((done) => { resolve = done; }); });
  const first = a.openCheckout(intent); await new Promise(setImmediate);
  await assert.rejects(a.openCheckout(intent), /already open/); assert.equal(calls, 1); passed++;
  const result = { razorpay_order_id: 'local-order', razorpay_payment_id: 'local-payment', razorpay_signature: 'local-result-not-valid-signature' };
  resolve(result); assert.equal(await first, result); passed++;
  const cancelled = adapter(true, () => Promise.reject({ code: 0 })); await assert.rejects(cancelled.openCheckout(intent), /window closed/); passed++;
  const failed = adapter(true, () => Promise.reject({ code: 2, description: 'Local failure' })); await assert.rejects(failed.openCheckout(intent), /Local failure/); passed++;
  console.log(`${passed} PASS, 0 FAIL, 0 SKIPPED: native adapter mocked contract checks; no native binary/device/provider tested.`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
