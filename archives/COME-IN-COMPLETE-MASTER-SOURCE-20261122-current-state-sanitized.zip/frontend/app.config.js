const base = require('./app.json').expo;

module.exports = () => {
  const environment = process.env.COMEIN_BUILD_ENV || 'development';
  if (!['development', 'test', 'production'].includes(environment)) throw new Error('COMEIN_BUILD_ENV must be development, test or production.');
  if (environment === 'production') {
    let url;
    try { url = new URL(process.env.EXPO_PUBLIC_BACKEND_URL || ''); } catch { throw new Error('Production builds require an HTTPS EXPO_PUBLIC_BACKEND_URL.'); }
    if (url.protocol !== 'https:' || ['localhost', '127.0.0.1', '::1', '[::1]'].includes(url.hostname) || url.username || url.password) throw new Error('Production builds require a public HTTPS backend URL without credentials.');
  }
  return { ...base, plugins: [...base.plugins, ['./plugins/withReleaseSafety', { production: environment === 'production' }]] };
};
