import Feather from "@react-native-vector-icons/feather";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useEffect, useState } from "react";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { QuantityStepper } from "@/src/components/QuantityStepper";
import { MeasuredQuantityPicker } from "@/src/components/MeasuredQuantityPicker";
import { RestockAlertButton } from "@/src/components/RestockAlertButton";
import { api } from "@/src/lib/api";
import { bigUnit, formatAmount, isMeasured, lineAmount } from "@/src/lib/measure";
import { getProductById, getProductPlaceholder, PRODUCTS } from "@/src/data/catalog";
import { useCatalogProducts } from "@/src/data/useCatalogProducts";
import { useCart } from "@/src/store/cart";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useT } from "@/src/i18n";

export default function ProductDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  const { getQty, addProduct, increment, decrement, startBuyNow, setAmount } = useCart();
  const { liveProducts } = useCatalogProducts();
  const [selectedVariantId, setSelectedVariantId] = useState<string | undefined>(undefined);
  const [imageFailed, setImageFailed] = useState(false);
  const [comparison, setComparison] = useState<any | null>(null);
  const [comparisonMessage, setComparisonMessage] = useState("");
  const [cartMessage, setCartMessage] = useState("");

  const product = id ? (liveProducts.find((p) => p.id === id) ?? getProductById(id)) : undefined;

  const productKey = `${product?.id || ""}:${product?.image || ""}`;
  const [previousProductKey, setPreviousProductKey] = useState(productKey);
  if (previousProductKey !== productKey) {
    setPreviousProductKey(productKey);
    setImageFailed(false); setSelectedVariantId(undefined); setCartMessage("");
  }
  const comparisonKey = `${product?.masterProductId || ""}:${product?.masterVariantId || ""}:${product?.sellBy || ""}`;
  const [previousComparisonKey, setPreviousComparisonKey] = useState<string | null>(null);
  if (previousComparisonKey !== comparisonKey) {
    setPreviousComparisonKey(comparisonKey);
    if (!product?.masterProductId || !product?.masterVariantId) { setComparison(null); setComparisonMessage(""); }
    else setComparisonMessage("Loading verified offers…");
  }

  useEffect(() => {
    let active = true;
    if (!product?.masterProductId || !product?.masterVariantId) {
      return () => { active = false; };
    }
    api.get<any>(`/catalog/price-comparison?master_product_id=${encodeURIComponent(product.masterProductId)}&variant_id=${encodeURIComponent(product.masterVariantId)}${product.sellBy === "weight" || product.sellBy === "volume" ? `&sell_by=${product.sellBy}` : ""}`, false)
      .then((result) => { if (active) { setComparison(result); setComparisonMessage(""); } })
      .catch(() => { if (active) { setComparison(null); setComparisonMessage("Price comparison is currently unavailable. This offer's displayed price is from its own shop listing."); } });
    return () => { active = false; };
  }, [product?.masterProductId, product?.masterVariantId, product?.sellBy]);

  if (!product) {
    return (
      <View style={styles.notFound}>
        <Text style={styles.notFoundTitle}>Product not found</Text>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const selectedVariant = product.variants?.find((variant) => variant.id === selectedVariantId) ?? product.variants?.find((variant) => variant.available !== false && (variant.stock === undefined || variant.stock > 0)) ?? product.variants?.[0];
  const displayedProduct = selectedVariant
    ? { ...product, unit: selectedVariant.unit, price: selectedVariant.price, mrp: selectedVariant.mrp }
    : product;
  const qty = getQty(product.id, selectedVariant?.id);
  const measured = isMeasured(product);
  const selectedStock = selectedVariant ? selectedVariant.stock : product.stock;
  const unavailable = selectedVariant?.available === false || (selectedStock !== undefined && selectedStock <= 0);
  const canBuyNow = product.source === "live" && !unavailable && Boolean(product.shopId) && (!product.variants?.length || Boolean(selectedVariant?.id)) && (selectedStock === undefined || selectedStock >= Math.max(1, qty));
  const addSelectedToCart = () => {
    if (unavailable) { setCartMessage("This pack is unavailable. Please choose another variant."); return; }
    if (qty >= 1000) { setCartMessage("You can add up to 1000 packs of one variant per order."); return; }
    if (selectedStock !== undefined && qty >= selectedStock) { setCartMessage(`Only ${selectedStock} pack(s) are currently available.`); return; }
    addProduct(product, selectedVariant?.id);
    setCartMessage("");
  };
  const incrementSelected = () => {
    if (qty >= 1000 || unavailable || (selectedStock !== undefined && qty >= selectedStock)) {
      setCartMessage(qty >= 1000 ? "You can add up to 1000 packs of one variant per order." : selectedStock !== undefined ? `Only ${selectedStock} pack(s) are currently available.` : "This pack is unavailable.");
      return;
    }
    increment(product.id, selectedVariant?.id, product);
    setCartMessage("");
  };
  const buyNow = () => {
    if (!canBuyNow) {
      setCartMessage(unavailable ? "This selected pack is unavailable." : "Please select an available variant and quantity.");
      return;
    }
    const buyQty = measured ? qty : Math.max(1, qty);
    if (measured && !qty) { setCartMessage(t("m.addFirst")); return; }
    if (!startBuyNow(product, selectedVariant?.id, buyQty)) {
      setCartMessage("The selected quantity is not currently available. Please review the stock and try again.");
      return;
    }
    router.push("/checkout");
  };
  const discount =
    displayedProduct.mrp && displayedProduct.mrp > displayedProduct.price
      ? Math.round(((displayedProduct.mrp - displayedProduct.price) / displayedProduct.mrp) * 100)
      : 0;

  const related = [...liveProducts, ...PRODUCTS].filter(
    (p) => p.categoryId === product.categoryId && p.id !== product.id,
  ).slice(0, 6);
  const matchingLiveListings = product.source === "catalog"
    ? liveProducts.filter((p) => p.categoryId === product.categoryId && p.name.trim().toLocaleLowerCase() === product.name.trim().toLocaleLowerCase())
    : [];

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="back-btn" onPress={() => router.back()} style={styles.iconBtn}>
          <Feather name="arrow-left" size={20} color={colors.onSurface} />
        </Pressable>
        <Text style={styles.topTitle} numberOfLines={1}>
          Product details
        </Text>
        <Pressable
          testID="goto-cart-btn"
          onPress={() => router.push("/(tabs)/cart")}
          style={styles.iconBtn}
        >
          <Feather name="shopping-bag" size={20} color={colors.onSurface} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: 200 + insets.bottom }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.heroImgWrap}>
          <Image source={imageFailed ? getProductPlaceholder(product.categoryId) : product.image} onError={() => setImageFailed(true)} style={styles.heroImg} contentFit="cover" transition={200} />
          {discount > 0 && (
            <View style={styles.heroBadge}>
              <Text style={styles.heroBadgeText}>{discount}% OFF</Text>
            </View>
          )}
        </View>

        <View style={styles.body}>
          {product.source === "catalog" && <Text style={styles.sectionTitle}>CATALOG REFERENCE — A SHOP MUST SET PRICE, STOCK AND PACK SIZE</Text>}
          {product.source === "demo" && <Text style={styles.sectionTitle}>DEMO PREVIEW — NOT AVAILABLE FOR CHECKOUT</Text>}
          {product.source === "live" && product.shopName && <Text style={styles.brand}>Sold by {product.shopName}</Text>}
          <Text style={styles.brand}>{product.brand}</Text>
          <Text testID="product-title" style={styles.name}>
            {product.name}
          </Text>
          <Text style={styles.unit}>{product.source === "catalog" ? "Pack size set by shop" : measured ? t(product.sellBy === "volume" ? "m.soldByVolume" : "m.soldByWeight", { unit: bigUnit(product) }) : displayedProduct.unit}</Text>

          {measured && product.source === "live" && !unavailable && (
            <MeasuredQuantityPicker product={product} cartQty={qty} onSave={(amount) => setAmount(product, amount)} />
          )}

          {product.variants && product.variants.length > 0 && (
            <View style={styles.variantSection}>
              <Text style={styles.sectionTitle}>Choose size / pack</Text>
              <View style={styles.variantOptions}>
                {product.variants.map((variant) => {
                  const selected = variant.id === selectedVariant?.id;
                  const soldOut = variant.available === false || (variant.stock !== undefined && variant.stock <= 0);
                  return (
                    <Pressable
                      key={variant.id}
                      testID={`variant-option-${variant.id}`}
                      accessibilityRole="button"
                      accessibilityState={{ selected, disabled: soldOut }}
                      disabled={soldOut}
                      onPress={() => { setSelectedVariantId(variant.id); setCartMessage(""); }}
                      style={[styles.variantOption, selected && styles.variantOptionSelected, soldOut && styles.variantOptionDisabled]}
                    >
                      <Text style={[styles.variantUnit, selected && styles.variantTextSelected]}>{variant.unit}</Text>
                      <Text style={[styles.variantPrice, selected && styles.variantTextSelected]}>₹{variant.price}</Text>
                      {soldOut && <Text style={styles.soldOutText}>Out of stock</Text>}
                    </Pressable>
                  );
                })}
              </View>
            </View>
          )}

          <View style={styles.priceRow}>
            <Text testID="product-price" style={styles.price}>
              {product.source === "catalog" ? "Price set by shop" : product.source === "demo" ? "Preview price only" : `₹${displayedProduct.price}${measured ? `/${bigUnit(product)}` : ""}`}
            </Text>
            {displayedProduct.mrp && displayedProduct.mrp > displayedProduct.price && (
              <>
                <Text style={styles.mrp}>₹{displayedProduct.mrp}</Text>
                <View style={styles.saveBadge}>
                  <Text style={styles.saveText}>Save ₹{displayedProduct.mrp - displayedProduct.price}</Text>
                </View>
              </>
            )}
          </View>

          <View style={styles.deliveryBar}>
            <Feather name="clock" size={14} color={colors.brandPrimary} />
            <Text style={styles.deliveryBarText}>Delivery timing depends on the selected shop and address.</Text>
          </View>

          {(comparisonMessage || comparison) && <View style={styles.comparisonCard} testID="price-comparison-panel">
            <Text style={styles.sectionTitle}>Compare verified shop prices · {comparison?.unit || displayedProduct.unit}</Text>
            {comparisonMessage ? <Text style={styles.comparisonMeta}>{comparisonMessage}</Text> : null}
            {comparison?.offers?.length ? comparison.offers.map((offer: any, index: number) => <View key={offer.product_id} style={styles.comparisonRow}>
              <View style={{ flex: 1 }}><Text style={styles.comparisonShop}>{offer.shop_name || "Approved shop"}{index === 0 ? " · Lowest" : ""}</Text><Text style={styles.comparisonMeta}>Stock: {offer.stock} · Updated: {offer.updated_at ? new Date(offer.updated_at).toLocaleDateString() : "not provided"}</Text></View>
              <Text style={styles.comparisonPrice}>₹{Number(offer.price).toFixed(2)}{offer.sell_by && offer.sell_by !== "pack" ? `/${offer.unit}` : ""}</Text>
            </View>) : null}
            {comparison && comparison.offer_count === 0 ? <Text style={styles.comparisonMeta}>No other verified available offers for this exact master variant.</Text> : null}
          </View>}

          {cartMessage ? <Text style={styles.stockMessage} accessibilityRole="alert">{cartMessage}</Text> : null}

          <View style={styles.divider} />

          <Text style={styles.sectionTitle}>About this product</Text>
          <Text style={styles.description}>{product.description}</Text>
          {product.source === "catalog" && <Text style={styles.deliveryBarText}>This is a catalog reference, not a live offer. Choose an actual listing from an approved shop to see its price, pack options and stock.</Text>}
          {product.source === "catalog" && (
            <View style={styles.comparisonCard} testID="catalog-live-listings">
              <Text style={styles.sectionTitle}>Matching shop listings</Text>
              {matchingLiveListings.length === 0 ? (
                <Text style={styles.comparisonMeta}>No matching live shop listing was found. This item cannot be ordered until a shopkeeper adds and prices it.</Text>
              ) : matchingLiveListings.map((listing) => (
                <Pressable key={listing.id} onPress={() => router.push(`/product/${listing.id}`)} style={styles.comparisonRow} testID={`catalog-listing-${listing.id}`}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.comparisonShop}>{listing.shopName || "Approved shop"}</Text>
                    <Text style={styles.comparisonMeta}>{listing.unit} · stock {listing.stock ?? "not provided"}</Text>
                  </View>
                  <Text style={styles.comparisonPrice}>₹{listing.price}</Text>
                </Pressable>
              ))}
            </View>
          )}

          <View style={styles.featureRow}>
            <Feature icon="check-circle" title="100% Authentic" sub="Sourced from trusted brands" />
            <Feature icon="refresh-ccw" title="Easy returns" sub="Within 15 minutes" />
          </View>
        </View>

        {related.length > 0 && (
          <View style={styles.relatedWrap}>
            <Text style={styles.sectionTitle}>You may also like</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ gap: spacing.md, paddingVertical: spacing.sm }}
            >
              {related.map((r) => (
                <Pressable
                  key={r.id}
                  testID={`related-${r.id}`}
                  onPress={() => router.push(`/product/${r.id}`)}
                  style={styles.relCard}
                >
                  <Image source={r.image} style={styles.relImg} contentFit="cover" />
                  <Text style={styles.relName} numberOfLines={2}>
                    {r.name}
                  </Text>
                  <Text style={styles.relPrice}>{r.source === "catalog" ? "Shop price needed" : r.source === "demo" ? "Preview only" : `₹${r.price}`}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}
      </ScrollView>

      <View style={[styles.ctaBar, { paddingBottom: insets.bottom + spacing.sm }]}>
        <View style={{ flex: 1 }}>
          <Text style={styles.ctaPrice}>{product.source === "catalog" ? "Shop price needed" : product.source === "demo" ? "Preview only" : measured ? `₹${lineAmount(product, qty).toFixed(2)}` : `₹${displayedProduct.price * Math.max(1, qty)}`}</Text>
          <Text style={styles.ctaLabel}>
            {product.source === "catalog" ? "Catalog reference" : unavailable ? "Out of stock" : measured ? (qty > 0 ? t("m.inCart", { amount: formatAmount(product, qty) }) : t("m.chooseAbove")) : qty > 0 ? `${qty} in cart` : displayedProduct.unit}
          </Text>
        </View>
        <View style={{ minWidth: 160, gap: spacing.xs }}>
          {product.source !== "live" ? (
            <View style={styles.unavailableButton}><Text style={styles.unavailableButtonText}>{product.source === "catalog" ? "Shop listing needed" : "Preview only"}</Text></View>
          ) : unavailable ? (
            <RestockAlertButton productId={product.id} />
          ) : (
            <>
              <QuantityStepper
                qty={qty}
                label={measured && qty ? formatAmount(product, qty) : undefined}
                onAdd={measured ? () => { addProduct(product); setCartMessage(""); } : addSelectedToCart}
                onInc={measured ? () => { increment(product.id, undefined, product); setCartMessage(""); } : incrementSelected}
                onDec={() => { decrement(product.id, selectedVariant?.id); setCartMessage(""); }}
                size="md"
                testID="pdp-stepper"
              />
              <Pressable testID="buy-now-btn" accessibilityRole="button" disabled={!canBuyNow} onPress={buyNow} style={[styles.buyNowButton, !canBuyNow && { opacity: 0.45 }]}>
                <Text style={styles.buyNowButtonText}>{canBuyNow ? "Buy Now" : "Use one shop per checkout"}</Text>
              </Pressable>
            </>
          )}
        </View>
      </View>
    </View>
  );
}

function Feature({
  icon,
  title,
  sub,
}: {
  icon: React.ComponentProps<typeof Feather>["name"];
  title: string;
  sub: string;
}) {
  const styles = useStyles();
  const { colors } = useTheme();
  return (
    <View style={styles.feature}>
      <Feather name={icon} size={16} color={colors.brandPrimary} />
      <Text style={styles.featureTitle}>{title}</Text>
      <Text style={styles.featureSub}>{sub}</Text>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  topBar: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.sm,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: spacing.md,
    backgroundColor: colors.surface,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  iconBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.surfaceTertiary,
    alignItems: "center",
    justifyContent: "center",
  },
  topTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: colors.onSurface,
  },
  heroImgWrap: {
    width: "100%",
    aspectRatio: 1,
    backgroundColor: colors.surfaceTertiary,
    position: "relative",
  },
  heroImg: { width: "100%", height: "100%" },
  heroBadge: {
    position: "absolute",
    top: spacing.lg,
    left: spacing.lg,
    backgroundColor: colors.brandSecondary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.sm,
  },
  heroBadgeText: {
    fontSize: 11,
    fontWeight: "800",
    color: colors.onBrandSecondary,
    letterSpacing: 0.5,
  },
  body: { padding: spacing.lg, gap: spacing.xs },
  brand: {
    fontSize: 12,
    fontWeight: "700",
    color: colors.brandPrimary,
    letterSpacing: 0.4,
    textTransform: "uppercase",
  },
  name: { fontSize: 22, fontWeight: "800", color: colors.onSurface, marginTop: 4 },
  unit: { fontSize: 13, color: colors.muted, marginTop: 2 },
  variantSection: { marginTop: spacing.md, gap: spacing.xs },
  variantOptions: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  variantOption: { minWidth: 92, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, backgroundColor: colors.surface, gap: 3 },
  variantOptionSelected: { borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary },
  variantOptionDisabled: { opacity: 0.45 },
  variantUnit: { fontSize: 12, fontWeight: "700", color: colors.onSurface },
  variantPrice: { fontSize: 13, fontWeight: "800", color: colors.onSurface },
  buyNowButton: { minHeight: 38, borderRadius: radius.md, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md, backgroundColor: colors.brandPrimary },
  buyNowButtonText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 13 },
  variantTextSelected: { color: colors.brandPrimary },
  soldOutText: { fontSize: 10, color: colors.error },
  stockMessage: { color: colors.error, fontSize: 12, fontWeight: "600", marginTop: spacing.sm },
  unavailableButton: { minWidth: 120, height: 46, borderRadius: radius.md, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  unavailableButtonText: { fontSize: 13, fontWeight: "700", color: colors.muted },
  priceRow: {
    marginTop: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    flexWrap: "wrap",
  },
  price: { fontSize: 24, fontWeight: "800", color: colors.onSurface },
  mrp: { fontSize: 14, color: colors.muted, textDecorationLine: "line-through" },
  saveBadge: {
    backgroundColor: colors.brandTertiary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  saveText: { fontSize: 11, fontWeight: "800", color: colors.onBrandTertiary },
  deliveryBar: {
    marginTop: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: colors.brandTertiary,
    padding: spacing.sm,
    borderRadius: radius.sm,
    alignSelf: "flex-start",
  },
  deliveryBarText: { fontSize: 12, fontWeight: "700", color: colors.onBrandTertiary },
  divider: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
    marginVertical: spacing.lg,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "800",
    color: colors.onSurface,
    marginBottom: spacing.sm,
  },
  description: { fontSize: 13, color: colors.onSurfaceSecondary, lineHeight: 20 },
  featureRow: { flexDirection: "row", gap: spacing.md, marginTop: spacing.lg },
  feature: {
    flex: 1,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    gap: 4,
  },
  featureTitle: { fontSize: 13, fontWeight: "700", color: colors.onSurface, marginTop: 4 },
  featureSub: { fontSize: 11, color: colors.muted },

  relatedWrap: {
    paddingHorizontal: spacing.lg,
    marginTop: spacing.sm,
  },
  relCard: {
    width: 130,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
    padding: spacing.sm,
    gap: 4,
  },
  relImg: {
    width: "100%",
    aspectRatio: 1,
    borderRadius: radius.sm,
    backgroundColor: colors.surfaceTertiary,
  },
  relName: { fontSize: 12, fontWeight: "600", color: colors.onSurface, marginTop: 4 },
  relPrice: { fontSize: 13, fontWeight: "800", color: colors.onSurface },

  ctaBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  ctaPrice: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  ctaLabel: { fontSize: 11, color: colors.muted, marginTop: 2 },

  notFound: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.md,
    backgroundColor: colors.surface,
  },
  notFoundTitle: { fontSize: 16, fontWeight: "700", color: colors.onSurface },
  backBtn: {
    backgroundColor: colors.brandPrimary,
    paddingHorizontal: spacing.lg,
    paddingVertical: 12,
    borderRadius: radius.md,
  },
  backBtnText: { color: colors.onBrandPrimary, fontWeight: "700" },
  comparisonCard: { marginTop: spacing.md, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, gap: spacing.xs },
  comparisonRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.divider },
  comparisonShop: { fontSize: 13, fontWeight: "700", color: colors.onSurface },
  comparisonMeta: { fontSize: 11, color: colors.muted },
  comparisonPrice: { fontSize: 14, fontWeight: "800", color: colors.brandPrimary },
}));
