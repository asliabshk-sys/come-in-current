import Feather from "@react-native-vector-icons/feather";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  FlatList,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { BrandLogo } from "@/src/components/BrandLogo";
import { AnnouncementBanner } from "@/src/components/AnnouncementBanner";
import { useAuth } from "@/src/store/auth";
import { api } from "@/src/lib/api";

import { ProductCard } from "@/src/components/ProductCard";
import {
  CATEGORIES,
  POPULAR_PRODUCTS,
  QUICK_DELIVERY_PRODUCTS,
  SERVICES,
} from "@/src/data/catalog";
import { useCatalogProducts } from "@/src/data/useCatalogProducts";
import { useT } from "@/src/i18n";
import { useLocationCtx } from "@/src/store/location";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

const DEFAULT_LOCATION = "Set delivery location";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { location, setLocation } = useLocationCtx();
  const { t } = useT();
  const { liveProducts } = useCatalogProducts();
  const { user } = useAuth();
  const [referralClaim, setReferralClaim] = useState<{ userId: string; show: boolean } | null>(null);
  const showProminentReferral = user?.role === "customer" && referralClaim?.userId === user.id && referralClaim.show;
  const [unread, setUnread] = useState(0);

  // Task 20: unread in-app notification badge, refreshed whenever Home regains focus.
  useFocusEffect(useCallback(() => {
    let active = true;
    if (!user?.id) { setUnread(0); return () => { active = false; }; }
    api.get<{ unread: number }>("/notifications/unread-count").then((r) => { if (active) setUnread(Number(r.unread) || 0); }).catch(() => {});
    return () => { active = false; };
  }, [user?.id]));
  useEffect(() => {
    let active = true;
    if (!user?.id || user.role !== "customer") return () => { active = false; };
    void api.post<{ show_prominent: boolean }>("/referrals/home-banner-claim", {}).then((result) => {
      if (active) setReferralClaim({ userId: user.id, show: Boolean(result.show_prominent) });
    }).catch(() => { if (active) setReferralClaim({ userId: user.id, show: false }); });
    return () => { active = false; };
  }, [user?.id, user?.role]);
  const quickProducts = liveProducts.length ? liveProducts.slice(0, 6) : QUICK_DELIVERY_PRODUCTS.slice(0, 6);
  const livePopular = liveProducts.filter((p) => p.popular);
  const popularProducts = liveProducts.length ? (livePopular.length ? livePopular.slice(0, 6) : liveProducts.slice(0, 6)) : POPULAR_PRODUCTS.slice(0, 6);
  const [locModalOpen, setLocModalOpen] = useState(false);
  const [locInput, setLocInput] = useState(
    location === DEFAULT_LOCATION ? "" : location,
  );

  // Re-sync the modal input with the currently-saved location every time
  // the modal is opened so stale text from a prior session isn't shown
  // after the address was changed from Account settings.
  const [locationSync, setLocationSync] = useState({ open: locModalOpen, location });
  if (locationSync.open !== locModalOpen || locationSync.location !== location) {
    setLocationSync({ open: locModalOpen, location });
    if (locModalOpen) setLocInput(location === DEFAULT_LOCATION ? "" : location);
  }

  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" />
      {/* Sticky Header */}
      <View
        style={[styles.header, { paddingTop: insets.top + spacing.sm }]}
      >
        <View style={styles.topRow}>
          <View style={styles.brandLogoWrap}>
            <BrandLogo testID="brand-logo" size="md" />
          </View>
          <View style={styles.headerActions}>
            <Pressable testID="header-voice-search" accessibilityRole="button" accessibilityLabel="Open CHAND AI voice typing" onPress={() => router.push("/chand?voice=1")} style={styles.headerAction}>
              <Feather name="mic" size={19} color={colors.brandForest} />
            </Pressable>
            <Pressable testID="header-language" accessibilityRole="button" accessibilityLabel="Choose language" onPress={() => router.push("/language")} style={styles.headerAction}>
              <Feather name="globe" size={19} color={colors.brandForest} />
            </Pressable>
            <Pressable testID="header-notifications" accessibilityRole="button" accessibilityLabel={unread ? `${unread} unread notifications` : "View notifications"} onPress={() => router.push(user ? "/notifications" : "/orders")} style={styles.headerAction}>
              <Feather name="bell" size={19} color={colors.brandForest} />
              {unread > 0 && <View style={styles.bellBadge} testID="header-notifications-badge"><Text style={styles.bellBadgeText}>{unread > 9 ? "9+" : unread}</Text></View>}
            </Pressable>
            <Pressable testID="header-account" accessibilityRole="button" accessibilityLabel="Open account" onPress={() => router.push("/(tabs)/account")} style={[styles.headerAction, styles.headerAccountAction]}>
              <Feather name="user" size={19} color="#FFFFFF" />
            </Pressable>
          </View>
        </View>
      </View>
      {/* Search sits on the mint page surface, directly below the yellow brand header. */}
      <View style={styles.searchArea}>
        <View style={styles.searchRow}>
          <Pressable
            testID="home-search-bar"
            accessibilityRole="button"
            onPress={() => router.push("/(tabs)/search")}
            style={styles.searchBar}
          >
            <Feather name="search" size={18} color={colors.brandForest} />
            <Text style={styles.searchPlaceholder}>{t("home.searchPlaceholder")}</Text>
          </Pressable>
          <Pressable
            testID="home-filter-button"
            accessibilityRole="button"
            accessibilityLabel="Browse categories and filters"
            onPress={() => router.push("/(tabs)/categories")}
            style={styles.filterButton}
          >
            <Feather name="sliders" size={19} color={colors.brandForest} />
          </Pressable>
        </View>

      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: spacing.xxl }}
      >
        {/* Hero Banner */}
        <View style={styles.heroWrap}>
          <Pressable testID="fresh-groceries-banner" accessibilityRole="button" onPress={() => router.push("/(tabs)/categories")} style={styles.hero}>
            <Image
              source="https://images.unsplash.com/photo-1542838132-92c53300491e?crop=entropy&cs=srgb&fm=jpg&w=1200&q=80"
              style={styles.heroImage}
              contentFit="cover"
            />
            <LinearGradient
              colors={["#D9F5DF", "#D9F5DFD9", "#D9F5DF12"]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.heroContent}>
              <Text style={styles.heroTitle}>Fresh Groceries</Text>
              <Text style={styles.heroTitle}><Text style={styles.heroRed}>& Delicious Food</Text></Text>
              <Text style={styles.heroSub}>Fruits • Vegetables • Daily Essentials</Text>
              <Text style={styles.heroSub}> & Restaurant Favorites</Text>
              <View style={styles.heroCta}>
                <Text style={styles.heroCtaText}>Shop Now</Text>
                <Feather name="arrow-right" size={14} color="#FFFFFF" />
              </View>
            </View>
          </Pressable>
          <View style={styles.carouselDots} accessibilityLabel="Promotional banners">
            {[0,1,2,3,4].map((dot) => <View key={dot} style={[styles.carouselDot, dot === 0 && styles.carouselDotActive]} />)}
          </View>
        </View>

        {user?.role === "customer" && (
          <View style={[styles.referralBanner, showProminentReferral && styles.referralBannerProminent]} testID={showProminentReferral ? "referral-first-login-banner" : "referral-returning-banner"}>
            <View style={styles.referralBannerIcon}><Feather name="gift" size={showProminentReferral ? 24 : 19} color="#FFFFFF" /></View>
            <View style={styles.referralBannerCopy}>
              <Text style={styles.referralBannerTitle}>{showProminentReferral ? "Referral & Earn — Welcome!" : "Refer friends & earn ₹500"}</Text>
              <Text style={styles.referralBannerText}>{showProminentReferral ? "Refer 10 eligible new customers to earn a total reward of ₹500. Each must complete at least ₹100 eligible shopping, delivery, payment confirmation and admin review." : "10 eligible new customers = ₹500 total reward, after shopping, delivery, payment and review checks."}</Text>
            </View>
            <Pressable accessibilityRole="button" testID="home-referral-open" onPress={() => router.push("/referral-dashboard")} style={styles.referralBannerButton}>
              <Text style={styles.referralBannerButtonText}>Open</Text>
            </Pressable>
          </View>
        )}

        {/* Four separate discovery entry points; Shopping and Restaurant remain separate routes. */}
        <AnnouncementBanner />
        <View style={styles.modeGrid}>
          <ModeCard testID="online-shops-card" title="Online Shops" subtitle="Shop from your favorite online stores" artwork="online" onPress={() => router.push("/shops?type=online")} />
          <ModeCard testID="offline-shops-card" title="Offline Shops" subtitle="Support local businesses in your town" artwork="offline" onPress={() => router.push("/shops?type=offline")} />
          <ModeCard testID="restaurant-mode-card" title="Restaurants" subtitle="Tasty food, great flavors, delivered" artwork="restaurant" onPress={() => router.push("/restaurant")} />
          <ModeCard testID="home-services-card" title="Home Services" subtitle="Trusted help for your home" artwork="services" onPress={() => router.push("/services")} />
        </View>



        {/* Grocery Categories */}
        <SectionHeader title={t("home.shopByCategory")} onSeeAll={() => router.push("/(tabs)/categories")} />
        <View style={styles.categoryGrid} testID="home-category-grid">
          {CATEGORIES.map((item) => (
            <Pressable
              key={item.id}
              testID={`home-cat-${item.id}`}
              accessibilityRole="button"
              onPress={() => router.push(`/category/${item.id}`)}
              style={[styles.catTile, { backgroundColor: "#DFF8E7", borderColor: "#C9F0D7" }]}
            >
              <Image source={item.image} style={styles.catImage} contentFit="cover" />
              <Text style={styles.catName} numberOfLines={2}>
                {{
                  "fruits-veggies": "Fruits & Vegetables",
                  "dairy-breakfast": "Dairy & Breakfast",
                  snacks: "Snacks & Munchies",
                  beverages: "Beverages",
                  bakery: "Bakery",
                  "personal-care": "Personal Care",
                  household: "Household Essentials",
                }[item.id] ?? item.name}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Keep the existing delivery-location selector functional without expanding the yellow header. */}
        <Pressable
          testID="location-selector"
          accessibilityRole="button"
          onPress={() => setLocModalOpen(true)}
          style={styles.locRow}
        >
          <Feather name="map-pin" size={14} color={colors.brandPrimary} />
          <Text style={styles.locLabel}>{t("home.deliverTo")}</Text>
          <Text style={styles.locValue} numberOfLines={1}>
            {location === DEFAULT_LOCATION ? t("home.setLocation") : location}
          </Text>
          <Feather name="chevron-down" size={16} color={colors.onSurfaceSecondary} />
        </Pressable>

        {/* Shared CHAND assistant entry; keeps existing Shopping/Restaurant modes intact. */}
        <View style={styles.chandWrap}>
          <Pressable testID="chand-home-entry" accessibilityRole="button" accessibilityLabel="Open CHAND by COME-IN assistant" onPress={() => router.push("/chand")} style={styles.chandCard}>
            <View style={styles.chandIcon}><Feather name="moon" size={23} color="#FFFFFF" /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.chandTitle}>Meet CHAND</Text>
              <Text style={styles.chandSub}>by COME-IN · आपका अपना स्मार्ट साथी</Text>
              <Text style={styles.chandHint}>Your Smart Shopping Assistant · Live catalog search; AI provider optional</Text>
            </View>
            <Feather name="arrow-up-right" size={20} color="#FFFFFF" />
          </Pressable>
        </View>

        {/* Quick Delivery */}
        <View style={styles.quickHeader}>
          <View style={styles.quickBadge}>
            <Feather name="zap" size={12} color={colors.onBrandSecondary} />
            <Text style={styles.quickBadgeText}>{t("home.minBadge")}</Text>
          </View>
          <Text style={styles.quickTitle}>{t("home.quickDelivery")}</Text>
        </View>
        <FlatList
          data={quickProducts}
          keyExtractor={(p) => p.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}
          renderItem={({ item }) => <ProductCard product={item} width={160} />}
        />

        {/* Popular Products */}
        <SectionHeader title={t("home.popular")} onSeeAll={() => router.push("/(tabs)/categories")} />
        <View style={styles.popularGrid}>
          {popularProducts.map((p) => (
            <View key={p.id} style={styles.gridItem}>
              <ProductCard product={p} />
            </View>
          ))}
        </View>

        {/* Home Services */}
        <SectionHeader title={t("home.homeServices")} onSeeAll={() => router.push("/services")} />
        <FlatList
          data={SERVICES.slice(0, 4)}
          keyExtractor={(s) => s.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}
          renderItem={({ item }) => (
            <Pressable
              testID={`home-service-${item.id}`}
              onPress={() => router.push("/services")}
              style={styles.serviceCard}
            >
              <Image source={item.image} style={styles.serviceImg} contentFit="cover" />
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceTitle} numberOfLines={1}>
                  {item.title}
                </Text>
                <Text style={styles.serviceTag} numberOfLines={1}>
                  {item.tagline}
                </Text>
                <Text style={styles.servicePrice}>{item.price}</Text>
              </View>
            </Pressable>
          )}
        />

      </ScrollView>

      {/* Location modal */}
      <Modal
        visible={locModalOpen}
        animationType="slide"
        transparent
        onRequestClose={() => setLocModalOpen(false)}
      >
        <Pressable style={styles.modalBackdrop} onPress={() => setLocModalOpen(false)} />
        <View style={[styles.modalSheet, { paddingBottom: insets.bottom + spacing.lg }]}>
          <View style={styles.modalHandle} />
          <Text style={styles.modalTitle}>{t("home.whereDeliver")}</Text>
          <Text style={styles.modalSub}>{t("home.whereDeliverSub")}</Text>
          <TextInput
            testID="location-input"
            value={locInput}
            onChangeText={setLocInput}
            placeholder={t("home.locationExample")}
            placeholderTextColor={colors.muted}
            style={styles.modalInput}
            autoFocus
          />
          <Pressable
            testID="location-save-btn"
            onPress={() => {
              setLocation(locInput);
              setLocModalOpen(false);
            }}
            style={styles.modalBtn}
          >
            <Text style={styles.modalBtnText}>{t("home.saveLocation")}</Text>
          </Pressable>
        </View>
      </Modal>
    </View>
  );
}

function ModeCard({
  testID, title, subtitle, artwork, onPress,
}: {
  testID: string; title: string; subtitle: string;
  artwork: "online" | "offline" | "restaurant" | "services"; onPress: () => void;
}) {
  const styles = useStyles();
  const cardTint = title === "Offline Shops" ? "#FFFBE4" : title === "Restaurants" ? "#FFF0EF" : "#DFF8EC";
  const artworkSource = {
    online: require("@/assets/illustrations/online-shops.png"),
    offline: require("@/assets/illustrations/offline-shops.png"),
    restaurant: require("@/assets/illustrations/restaurants.png"),
    services: require("@/assets/illustrations/home-services.png"),
  }[artwork];
  return (
    <Pressable testID={testID} accessibilityRole="button" onPress={onPress} style={[styles.modeCard, { backgroundColor: cardTint }]}>
      <Image source={artworkSource} style={styles.modeArtwork} contentFit="contain" accessibilityLabel={`${title} illustration`} />
      <View style={styles.modeCopy}>
        <Text style={styles.modeTitle}>{title}</Text>
        <Text style={styles.modeSubtitle}>{subtitle}</Text>
      </View>
      <View style={styles.modeArrow}><Feather name="arrow-right" size={16} color="#FFFFFF" /></View>
    </Pressable>
  );
}

function SectionHeader({ title, onSeeAll }: { title: string; onSeeAll?: () => void }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  return (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {onSeeAll && (
        <Pressable onPress={onSeeAll} hitSlop={10}>
          <Text style={[styles.seeAll, { color: colors.brandPrimary }]}>{t("home.seeAll")}</Text>
        </Pressable>
      )}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surface },
  header: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    backgroundColor: colors.brandHeader,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  topRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  brandLogoWrap: { flex: 1, maxWidth: 220, alignItems: "flex-start" },
  headerActions: { flexDirection: "row", alignItems: "center", gap: 7 },
  headerAction: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#FFFFFFE8", alignItems: "center", justifyContent: "center" },
  headerAccountAction: { backgroundColor: colors.brandForest },
  bellBadge: { position: "absolute", top: -2, right: -2, minWidth: 16, height: 16, borderRadius: 8, paddingHorizontal: 3, backgroundColor: colors.error, alignItems: "center", justifyContent: "center" },
  bellBadgeText: { color: colors.onError, fontSize: 9, fontWeight: "900" },
  logoWrap: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  logoBadge: {
    width: 32,
    height: 32,
    borderRadius: radius.md,
    backgroundColor: colors.brandPrimary,
    alignItems: "center",
    justifyContent: "center",
  },
  brand: {
    fontSize: 20,
    fontWeight: "800",
    color: colors.onSurface,
    letterSpacing: -0.3,
  },
  tagline: {
    fontSize: 11,
    color: colors.muted,
    marginTop: -2,
  },
  searchArea: {
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.xs,
  },
  locRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    paddingHorizontal: spacing.xs,
    paddingTop: spacing.sm,
    paddingBottom: spacing.xs,
  },
  locLabel: { fontSize: 10, color: colors.muted, fontWeight: "600", letterSpacing: 0.2 },
  locValue: { flex: 1, fontSize: 12, color: colors.onSurface, fontWeight: "600" },
  searchRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  searchBar: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    backgroundColor: "#F9FFFB",
    borderRadius: radius.pill,
    minHeight: 42,
    shadowColor: "#145C3B",
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
    paddingHorizontal: spacing.md,
    paddingVertical: Platform.OS === "ios" ? 14 : 12,
    borderWidth: 1,
    borderColor: colors.borderStrong,
  },
  filterButton: {
    width: 40, height: 40, borderRadius: radius.md,
    backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: colors.borderStrong,
    alignItems: "center", justifyContent: "center",
  },
  searchPlaceholder: {
    color: colors.muted,
    fontSize: 14,
  },
  heroWrap: { paddingHorizontal: spacing.lg, marginTop: spacing.md },
  hero: {
    height: 152,
    borderRadius: radius.lg,
    overflow: "hidden",
    backgroundColor: "#DDF5DF",
    justifyContent: "center",
  },
  heroImage: { position: "absolute", right: 0, top: 0, bottom: 0, width: "66%", height: "100%" },
  heroContent: {
    width: "74%",
    padding: spacing.md,
    justifyContent: "center",
    alignItems: "flex-start",
    gap: 2,
  },
  heroRed: { color: "#EF202B" },
  carouselDots: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 7, paddingTop: spacing.sm },
  carouselDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#BFE6D1" },
  carouselDotActive: { backgroundColor: colors.brandForest, width: 10, height: 10 },
  heroPill: {
    backgroundColor: colors.brandSecondary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  heroPillText: {
    fontSize: 10,
    fontWeight: "800",
    color: colors.onBrandSecondary,
    letterSpacing: 0.5,
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: "900",
    color: colors.brandForest,
    lineHeight: 26,
  },
  heroSub: { fontSize: 12, color: colors.brandForest, lineHeight: 17 },
  heroCta: {
    marginTop: spacing.sm,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    backgroundColor: "#F21D2B",
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
  },
  heroCtaText: { fontSize: 13, fontWeight: "700", color: "#FFFFFF" },
  referralBanner: { marginHorizontal: spacing.lg, marginTop: spacing.md, flexDirection: "row", alignItems: "center", gap: spacing.sm, padding: spacing.md, borderRadius: radius.lg, backgroundColor: "#E4F7E9", borderWidth: 1, borderColor: "#B7E8C7" },
  referralBannerProminent: { backgroundColor: "#D3F3DC", borderColor: "#17834E", borderWidth: 1.5, padding: spacing.lg },
  referralBannerIcon: { width: 40, height: 40, borderRadius: radius.md, backgroundColor: "#087A4B", alignItems: "center", justifyContent: "center" },
  referralBannerCopy: { flex: 1, gap: 3 },
  referralBannerTitle: { color: "#07583A", fontSize: 14, fontWeight: "900" },
  referralBannerText: { color: "#267453", fontSize: 11, lineHeight: 15 },
  referralBannerButton: { backgroundColor: "#087A4B", borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
  referralBannerButtonText: { color: "#FFFFFF", fontSize: 12, fontWeight: "800" },
  modeGrid: {
    paddingHorizontal: spacing.lg,
    marginTop: spacing.md,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.md,
  },
  modeCard: {
    flexBasis: "46%", flexGrow: 1, minWidth: 0, minHeight: 88,
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    padding: spacing.sm, gap: 5,
    borderRadius: radius.lg, backgroundColor: "#DFF7EA",
    borderWidth: 1.2, borderColor: "#BCEED7",
  },
  modeArtwork: { width: 40, height: 44, flexShrink: 0 },
  modeCopy: { flex: 1, minWidth: 0, gap: 5 },
  modeArrow: { width: 24, height: 24, flexShrink: 0, borderRadius: 13, backgroundColor: "#087A4B", alignItems: "center", justifyContent: "center", alignSelf: "flex-end" },
  modeTitle: { fontSize: 12, fontWeight: "900", color: "#07583A", lineHeight: 16 },
  modeSubtitle: { fontSize: 10, lineHeight: 12, color: "#267453" },
  chandWrap: { paddingHorizontal: spacing.lg, marginTop: spacing.md },
  chandCard: { flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md, borderRadius: radius.lg, backgroundColor: colors.brandForest },
  chandIcon: { width: 44, height: 44, borderRadius: radius.md, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" },
  chandTitle: { fontSize: 15, fontWeight: "900", color: "#FFFFFF" },
  chandSub: { fontSize: 11, fontWeight: "600", color: "#E5F4E9", marginTop: 2 },
  chandHint: { fontSize: 10, color: "#D1E7D7", marginTop: 4 },
  sectionHeader: {
    paddingHorizontal: spacing.lg,
    marginTop: spacing.md,
    marginBottom: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: colors.onSurface,
  },
  seeAll: { fontSize: 13, fontWeight: "700" },
  categoryGrid: {
    paddingHorizontal: spacing.lg,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    rowGap: spacing.sm,
    columnGap: spacing.xs,
  },
  catTile: {
    width: "18.6%",
    minHeight: 96,
    borderRadius: radius.md,
    padding: 4,
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.xs,
    borderWidth: 1,
  },
  catImage: {
    width: "100%",
    height: 54,
    borderRadius: radius.sm,
  },
  catName: {
    fontSize: 9,
    fontWeight: "600",
    color: colors.onSurface,
    textAlign: "center",
  },
  quickHeader: {
    paddingHorizontal: spacing.lg,
    marginTop: spacing.xl,
    marginBottom: spacing.md,
    gap: spacing.sm,
  },
  quickBadge: {
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: colors.brandSecondary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  quickBadgeText: {
    fontSize: 10,
    fontWeight: "800",
    color: colors.onBrandSecondary,
    letterSpacing: 0.5,
  },
  quickTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  popularGrid: {
    paddingHorizontal: spacing.lg,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.md,
  },
  gridItem: {
    flexBasis: "48%",
    flexGrow: 1,
    maxWidth: "48.5%",
  },
  serviceCard: {
    width: 220,
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },
  serviceImg: {
    width: "100%",
    height: 110,
    backgroundColor: colors.surfaceTertiary,
  },
  serviceInfo: { padding: spacing.md, gap: 2 },
  serviceTitle: { fontSize: 14, fontWeight: "700", color: colors.onSurface },
  serviceTag: { fontSize: 12, color: colors.muted },
  servicePrice: {
    fontSize: 13,
    color: colors.brandPrimary,
    fontWeight: "700",
    marginTop: 4,
  },
  requestWrap: { paddingHorizontal: spacing.lg, marginTop: spacing.md },
  requestCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: spacing.md,
    borderRadius: radius.lg,
    backgroundColor: "#F4FBE6",
    borderWidth: 1.5,
    borderColor: "#F0D900",
    gap: spacing.md,
  },
  requestLeft: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    minWidth: 0,
  },
  requestArtwork: { width: 82, height: 86, flexShrink: 0 },
  requestTitle: {
    fontSize: 17,
    fontWeight: "900",
    color: "#07583A",
  },
  requestSub: { fontSize: 12, color: "#267453", marginTop: 2 },
  requestOptions: { flexDirection: "row", flexWrap: "wrap", columnGap: spacing.sm, rowGap: 2, marginTop: spacing.xs },
  requestOption: { fontSize: 11, fontWeight: "600", color: "#07583A" },
  requestArrow: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#087A4B", alignItems: "center", justifyContent: "center", flexShrink: 0 },

  // Modal
  modalBackdrop: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  modalSheet: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.lg,
    borderTopRightRadius: radius.lg,
    padding: spacing.lg,
    gap: spacing.md,
  },
  modalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.border,
    alignSelf: "center",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: colors.onSurface,
  },
  modalSub: { fontSize: 13, color: colors.muted, marginTop: -spacing.sm },
  modalInput: {
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceTertiary,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: Platform.OS === "ios" ? 14 : 12,
    fontSize: 15,
    color: colors.onSurface,
  },
  modalBtn: {
    backgroundColor: colors.brandPrimary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: "center",
  },
  modalBtnText: { fontSize: 15, fontWeight: "800", color: colors.onBrandPrimary },
}));
