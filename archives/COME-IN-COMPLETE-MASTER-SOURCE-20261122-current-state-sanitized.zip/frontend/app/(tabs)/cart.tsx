import Feather from "@react-native-vector-icons/feather";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useState } from "react";
import { getProductPlaceholder } from "@/src/data/catalog";

import { QuantityStepper } from "@/src/components/QuantityStepper";
import { useT } from "@/src/i18n";
import { useCart } from "@/src/store/cart";
import { bigUnit, formatAmount, isMeasured, lineAmount, stepUp } from "@/src/lib/measure";
import { useCatalogProducts } from "@/src/data/useCatalogProducts";
import { useLocationCtx } from "@/src/store/location";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

const DEFAULT_LOCATION = "Set delivery location";
const DELIVERY_FEE_THRESHOLD = 199;

export default function CartScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { cartLines, subtotal, deliveryFee, total, increment, decrement, remove, removeKey, replaceLine, clear, unresolvedKeys, getQty } =
    useCart();
  const { liveProducts } = useCatalogProducts();
  const { location } = useLocationCtx();
  const { t } = useT();
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  const [quantityNotice, setQuantityNotice] = useState<Record<string, string>>({});
  const [previousLines, setPreviousLines] = useState(cartLines);
  if (previousLines !== cartLines) {
    setPreviousLines(cartLines);
    const valid = new Set(cartLines.map((line) => line.key));
    setFailedImages((current) => Object.fromEntries(Object.entries(current).filter(([key]) => valid.has(key))));
  }

  if (cartLines.length === 0) {
    return (
      <View style={styles.root}>
        <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
          <Text style={styles.title}>{t("cart.title")}</Text>
        </View>
        <View style={styles.emptyWrap}>
          <View style={styles.emptyIcon}>
            <Feather name="shopping-bag" size={34} color={colors.brandPrimary} />
          </View>
          <Text style={styles.emptyTitle}>{unresolvedKeys.length ? "Some saved cart items need attention" : t("cart.empty")}</Text>
          <Text style={styles.emptySub}>{unresolvedKeys.length ? "These older or unavailable items could not be matched to a current product. Remove them here; your saved cart was not silently deleted." : t("cart.emptySub")}</Text>
          {unresolvedKeys.map((key) => <Pressable key={key} onPress={() => removeKey(key)} style={{ padding: 10 }}><Text style={{ color: colors.error }}>Remove saved item: {key}</Text></Pressable>)}
          <Pressable
            testID="start-shopping-btn"
            onPress={() => router.replace("/(tabs)")}
            style={styles.emptyBtn}
          >
            <Text style={styles.emptyBtnText}>{t("cart.startShopping")}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const shopIds = Array.from(new Set(cartLines.map((line) => line.product.shopId).filter(Boolean)));
  const hasMixedShops = shopIds.length > 1;
  const hasDemoItems = cartLines.some((line) => line.product.source === "demo");
  const savings = cartLines.reduce(
    (s, l) => s + (l.product.mrp ? lineAmount(l.product, l.qty, l.product.mrp) - lineAmount(l.product, l.qty) : 0),
    0,
  );

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Text style={styles.title}>{t("cart.title")}</Text>
        <Pressable testID="clear-cart-btn" onPress={clear} hitSlop={10}>
          <Text style={[styles.clearText, { color: colors.error }]}>{t("cart.clear")}</Text>
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 160 + insets.bottom }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.deliveryCard}>
          <Feather name="clock" size={18} color={colors.brandPrimary} />
          <View style={{ flex: 1 }}>
            <Text style={styles.deliveryTitle}>{t("cart.deliveryIn")}</Text>
            <Text style={styles.deliveryTo} numberOfLines={1}>
              {t("cart.to", { loc: location === DEFAULT_LOCATION ? t("home.setLocation") : location })}
            </Text>
          </View>
        </View>

        {savings > 0 && (
          <View style={styles.savingBanner}>
            <Feather name="tag" size={14} color={colors.onBrandSecondary} />
            <Text style={styles.savingText}>{t("cart.savings", { n: savings })}</Text>
          </View>
        )}

        {hasMixedShops && <Text style={styles.errorText}>Your cart contains products from different shops. One checkout can include only one shop. Remove items from other shops before continuing.</Text>}
        {hasDemoItems && <Text style={styles.errorText}>Demo preview items cannot be ordered. Remove these items to continue.</Text>}
        {unresolvedKeys.length > 0 && <View style={{ padding: spacing.md }}><Text style={styles.errorText}>Some older saved items are unresolved. Remove them before checkout.</Text>{unresolvedKeys.map((key) => <Pressable key={key} onPress={() => removeKey(key)}><Text style={{ color: colors.error, paddingVertical: 6 }}>Remove saved item: {key}</Text></Pressable>)}</View>}
        <Text style={styles.sectionLabel}>
          {t(cartLines.length === 1 ? "cart.item" : "cart.items", { n: cartLines.length })}
        </Text>
        <View style={styles.card}>
          {cartLines.map((line, idx) => (
            <View key={line.key}>
              <View style={styles.row} testID={`cart-row-${line.key}`}>
                <Image
                  source={failedImages[line.key] ? getProductPlaceholder(line.product.categoryId) : line.product.image}
                  onError={() => setFailedImages((current) => ({ ...current, [line.key]: true }))}
                  style={styles.rowImage}
                  contentFit="contain"
                  transition={120}
                />
                <View style={{ flex: 1 }}>
                  <Text style={styles.rowName} numberOfLines={2}>
                    {line.product.name}
                  </Text>
                  <Text style={styles.rowUnit} testID={`cart-unit-${line.key}`}>{isMeasured(line.product) ? `${formatAmount(line.product, line.qty)} · ₹${line.product.price}/${bigUnit(line.product)}` : line.product.unit}{line.product.source === "live" && line.product.shopName ? ` · ${line.product.shopName}` : ""}</Text>
                  {line.product.source !== "live" && <Text style={styles.errorText}>Catalog/preview item — a live shop listing is required before checkout</Text>}
                  <View style={styles.rowBottom}>
                    <View style={styles.priceWrap}>
                      <Text style={styles.rowPrice} testID={`cart-price-${line.key}`}>₹{isMeasured(line.product) ? lineAmount(line.product, line.qty).toFixed(2) : line.product.price * line.qty}</Text>
                      {line.product.mrp && (
                        <Text style={styles.rowMrp}>
                          ₹{isMeasured(line.product) ? lineAmount(line.product, line.qty, line.product.mrp).toFixed(2) : line.product.mrp * line.qty}
                        </Text>
                      )}
                    </View>
                    <QuantityStepper
                      qty={line.qty}
                      label={isMeasured(line.product) ? formatAmount(line.product, line.qty) : undefined}
                      onAdd={() => increment(line.product.id, line.variant?.id)}
                      onInc={() => {
                        if (isMeasured(line.product)) {
                          if (stepUp(line.product, line.qty) === line.qty) { setQuantityNotice((current) => ({ ...current, [line.key]: t("m.maxAvailable", { amount: formatAmount(line.product, line.qty) }) })); return; }
                          setQuantityNotice((current) => { const next = { ...current }; delete next[line.key]; return next; });
                          increment(line.product.id, undefined, line.product);
                          return;
                        }
                        const available = line.variant ? line.variant.stock : line.product.stock;
                        if (line.qty >= 1000) {
                          setQuantityNotice((current) => ({ ...current, [line.key]: "Maximum 1000 packs of one variant per order." }));
                          return;
                        }
                        if (available !== undefined && line.qty >= available) {
                          setQuantityNotice((current) => ({ ...current, [line.key]: `Only ${available} pack(s) are currently available.` }));
                          return;
                        }
                        setQuantityNotice((current) => { const next = { ...current }; delete next[line.key]; return next; });
                        increment(line.product.id, line.variant?.id);
                      }}
                      onDec={() => { setQuantityNotice((current) => { const next = { ...current }; delete next[line.key]; return next; }); decrement(line.product.id, line.variant?.id); }}
                      testID={`cart-stepper-${line.key}`}
                    />
                    <Pressable accessibilityRole="button" accessibilityLabel={`Remove ${line.product.name} from cart`} testID={`remove-cart-line-${line.key}`} onPress={() => remove(line.product.id, line.variant?.id)} style={styles.removeLine}>
                      <Feather name="trash-2" size={15} color={colors.error} />
                      <Text style={[styles.removeLineText, { color: colors.error }]}>Remove</Text>
                    </Pressable>
                  </View>
                  {quantityNotice[line.key] ? <Text style={styles.errorText} accessibilityRole="alert">{quantityNotice[line.key]}</Text> : null}
                </View>
              </View>
              {line.product.source === "live" && !liveProducts.some((candidate) => candidate.id === line.product.id && candidate.shopId === line.product.shopId && (!line.variant || candidate.variants?.some((variant) => variant.id === line.variant?.id))) && <Text style={styles.unavailableNotice} testID={`cart-unavailable-${line.key}`}>This item or selected pack is no longer available in the current live catalog. Remove it or choose a replacement below.</Text>}
              {line.product.source === "live" && !liveProducts.some((candidate) => candidate.id === line.product.id && candidate.shopId === line.product.shopId && (!line.variant || candidate.variants?.some((variant) => variant.id === line.variant?.id))) && liveProducts.some((candidate) => candidate.id !== line.product.id && candidate.shopId === line.product.shopId && candidate.categoryId === line.product.categoryId && (candidate.variants?.length ? candidate.variants.some((variant) => variant.available !== false && Number(variant.stock ?? 0) >= line.qty + getQty(candidate.id, variant.id)) : Number(candidate.stock ?? 0) >= line.qty + getQty(candidate.id))) && (
                <View style={styles.replacementWrap} testID={`replacement-options-${line.key}`}>
                  <Text style={styles.replacementTitle}>Choose a replacement from the same shop and category</Text>
                  {liveProducts.filter((candidate) => candidate.id !== line.product.id && candidate.shopId === line.product.shopId && candidate.categoryId === line.product.categoryId && (candidate.variants?.length ? candidate.variants.some((variant) => variant.available !== false && Number(variant.stock ?? 0) >= line.qty + getQty(candidate.id, variant.id)) : Number(candidate.stock ?? 0) >= line.qty + getQty(candidate.id))).slice(0, 3).map((candidate) => {
                    const variant = candidate.variants?.find((item) => item.available !== false && Number(item.stock ?? 0) >= line.qty + getQty(candidate.id, item.id));
                    return <Pressable key={candidate.id} testID={`replace-${line.key}-with-${candidate.id}`} onPress={() => replaceLine(line.product.id, line.variant?.id, candidate, variant?.id, line.qty)} style={styles.replacementOption}>
                      <Text style={styles.replacementName} numberOfLines={1}>{candidate.name} · {variant?.unit || candidate.unit}</Text>
                      <Text style={styles.replacementPrice}>₹{variant?.price ?? candidate.price} · Replace {line.qty}</Text>
                    </Pressable>;
                  })}
                </View>
              )}
              {idx < cartLines.length - 1 && <View style={styles.divider} />}
            </View>
          ))}
        </View>

        <Text style={styles.sectionLabel}>{t("cart.billDetails")}</Text>
        <View style={styles.billCard}>
          <BillRow label={t("cart.itemTotal")} value={`₹${subtotal}`} />
          <BillRow
            label={t("cart.deliveryFee")}
            value={deliveryFee === 0 ? t("cart.free") : `₹${deliveryFee}`}
            highlight={deliveryFee === 0}
          />
          <View style={styles.divider} />
          <BillRow label={t("cart.toPay")} value={`₹${total}`} bold />
        </View>
        {deliveryFee > 0 && (
          <Text style={styles.hint}>
            {t("cart.hint", { n: DELIVERY_FEE_THRESHOLD - subtotal })}
          </Text>
        )}
      </ScrollView>

      <View
        style={[styles.checkoutBar, { paddingBottom: insets.bottom + spacing.sm }]}
      >
        <View style={{ flex: 1 }}>
          <Text style={styles.checkoutTotal}>₹{total}</Text>
          <Text style={styles.checkoutLabel}>{t("cart.total")}</Text>
        </View>
        <Pressable testID="checkout-btn" onPress={() => router.push("/checkout")} disabled={hasMixedShops || hasDemoItems || unresolvedKeys.length > 0 || cartLines.some((line) => line.product.source !== "live")} style={[styles.checkoutBtn, (hasMixedShops || hasDemoItems || unresolvedKeys.length > 0 || cartLines.some((line) => line.product.source !== "live")) && { opacity: 0.45 }]}>
          <Text style={styles.checkoutBtnText}>{t("cart.checkout")}</Text>
          <Feather name="arrow-right" size={18} color={colors.onBrandPrimary} />
        </Pressable>
      </View>
    </View>
  );
}

function BillRow({
  label,
  value,
  bold,
  highlight,
}: {
  label: string;
  value: string;
  bold?: boolean;
  highlight?: boolean;
}) {
  const styles = useStyles();
  const { colors } = useTheme();
  return (
    <View style={styles.billRow}>
      <Text style={[styles.billLabel, bold && { fontWeight: "800", color: colors.onSurface }]}>
        {label}
      </Text>
      <Text
        style={[
          styles.billValue,
          bold && { fontWeight: "800", fontSize: 16 },
          highlight && { color: colors.brandPrimary, fontWeight: "800" },
        ]}
      >
        {value}
      </Text>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surfaceSecondary },
  header: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    backgroundColor: colors.surface,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  title: { fontSize: 22, fontWeight: "800", color: colors.onSurface },
  clearText: { fontSize: 13, fontWeight: "700" },
  removeLine: { flexDirection: "row", alignItems: "center", gap: 4, paddingVertical: 5, paddingHorizontal: 6 },
  removeLineText: { fontSize: 11, fontWeight: "700" },
  unavailableNotice: { marginTop: spacing.xs, fontSize: 11, fontWeight: "700", color: colors.error },
  replacementWrap: { marginTop: spacing.xs, marginBottom: spacing.sm, padding: spacing.sm, backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, gap: 6 },
  replacementTitle: { fontSize: 11, fontWeight: "800", color: colors.onSurfaceSecondary },
  replacementOption: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8, paddingVertical: 7, paddingHorizontal: spacing.sm, backgroundColor: colors.surface, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.border },
  replacementName: { flex: 1, fontSize: 12, fontWeight: "700", color: colors.onSurface },
  replacementPrice: { fontSize: 11, fontWeight: "800", color: colors.brandPrimary },

  emptyWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: spacing.xl,
    gap: spacing.sm,
    backgroundColor: colors.surface,
  },
  emptyIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.brandTertiary,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.sm,
  },
  emptyTitle: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  emptySub: {
    fontSize: 13,
    color: colors.muted,
    textAlign: "center",
    maxWidth: 260,
  },
  emptyBtn: {
    marginTop: spacing.lg,
    backgroundColor: colors.brandPrimary,
    paddingHorizontal: spacing.xl,
    paddingVertical: 14,
    borderRadius: radius.pill,
  },
  emptyBtnText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 14 },

  deliveryCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    backgroundColor: colors.surface,
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.md,
  },
  deliveryTitle: { fontSize: 14, fontWeight: "800", color: colors.onSurface },
  deliveryTo: { fontSize: 12, color: colors.muted, marginTop: 2 },

  savingBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: colors.brandSecondary,
    padding: spacing.sm,
    borderRadius: radius.sm,
    marginBottom: spacing.md,
  },
  savingText: { fontSize: 12, fontWeight: "700", color: colors.onBrandSecondary },

  sectionLabel: {
    fontSize: 11,
    fontWeight: "800",
    color: colors.muted,
    letterSpacing: 0.6,
    marginTop: spacing.md,
    marginBottom: spacing.sm,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
  },
  row: { flexDirection: "row", gap: spacing.md, paddingVertical: spacing.sm },
  rowImage: {
    width: 68,
    height: 68,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceTertiary,
  },
  rowName: { fontSize: 14, fontWeight: "600", color: colors.onSurface },
  rowUnit: { fontSize: 12, color: colors.muted, marginTop: 2 },
  rowBottom: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: spacing.sm,
  },
  priceWrap: { flexDirection: "row", alignItems: "baseline", gap: spacing.xs },
  rowPrice: { fontSize: 15, fontWeight: "800", color: colors.onSurface },
  rowMrp: {
    fontSize: 12,
    color: colors.muted,
    textDecorationLine: "line-through",
  },
  errorText: { color: colors.error, fontSize: 12, marginVertical: spacing.xs },
  divider: { height: StyleSheet.hairlineWidth, backgroundColor: colors.divider, marginVertical: 2 },

  billCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    gap: spacing.xs,
  },
  billRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 6,
  },
  billLabel: { fontSize: 13, color: colors.onSurfaceSecondary },
  billValue: { fontSize: 13, color: colors.onSurface, fontWeight: "600" },

  hint: {
    fontSize: 12,
    color: colors.brandPrimary,
    fontWeight: "600",
    marginTop: spacing.sm,
    textAlign: "center",
  },

  checkoutBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  checkoutTotal: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  checkoutLabel: { fontSize: 10, color: colors.muted, letterSpacing: 0.5, fontWeight: "700" },
  checkoutBtn: {
    flex: 2,
    backgroundColor: colors.brandPrimary,
    paddingVertical: 14,
    borderRadius: radius.md,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: spacing.sm,
  },
  checkoutBtnText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 15 },
}));
