// Admin — Operations dashboard (shops approvals + requests queue).
import Feather from "@react-native-vector-icons/feather";
import * as React from "react";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/lib/api";
import { Alert } from "@/src/utils/alert";
import { useAuth } from "@/src/store/auth";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Tab = "overview" | "users" | "shops" | "orders" | "restaurants" | "foodOrders" | "support" | "anything" | "assist" | "catalog" | "imports" | "retailImport" | "announcements" | "homeFees" | "referrals" | "earnings" | "chandFeedback";

export default function AdminScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { user } = useAuth();
  const [tab, setTab] = useState<Tab>("overview");
  const [dashboard, setDashboard] = useState<any | null>(null);
  const [editingAnnouncement, setEditingAnnouncement] = useState<string | null>(null);
  const [shops, setShops] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [anything, setAnything] = useState<any[]>([]);
  const [assist, setAssist] = useState<any[]>([]);
  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [foodOrders, setFoodOrders] = useState<any[]>([]);
  const [support, setSupport] = useState<any[]>([]);
  const [chandFeedback, setChandFeedback] = useState<any[]>([]);
  const [masterProducts, setMasterProducts] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [homeFeeMode, setHomeFeeMode] = useState<"provider"|"fixed"|"waived">("provider");
  const [homeFixedFee, setHomeFixedFee] = useState("0");
  const [announcementTitle, setAnnouncementTitle] = useState("");
  const [announcementBody, setAnnouncementBody] = useState("");
  const [announcementAudience, setAnnouncementAudience] = useState<"all" | "customers" | "shopkeepers">("all");
  const [announcementDays, setAnnouncementDays] = useState("");
  const [masterName, setMasterName] = useState("");
  const [masterBrand, setMasterBrand] = useState("");
  const [masterCategory, setMasterCategory] = useState("atta-rice-dal");
  const [masterUnit, setMasterUnit] = useState("1 piece");
  const [masterSource, setMasterSource] = useState("");
  const [masterQuery, setMasterQuery] = useState("");
  const [masterSaving, setMasterSaving] = useState(false);
  const [importShopId, setImportShopId] = useState("");
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importPreview, setImportPreview] = useState<any | null>(null);
  const [importBusy, setImportBusy] = useState(false);
  const [importHistory, setImportHistory] = useState<any[]>([]);
  const [priceAudit, setPriceAudit] = useState<any[]>([]);
  const [retailFile, setRetailFile] = useState<File | null>(null);
  const [retailPreview, setRetailPreview] = useState<any | null>(null);
  const [retailHistory, setRetailHistory] = useState<any[]>([]);
  const [referralRows, setReferralRows] = useState<any[]>([]);
  const [referralRewards, setReferralRewards] = useState<any[]>([]);
  const [referralPayoutReference, setReferralPayoutReference] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [adminNotice, setAdminNotice] = useState("");

  const load = useCallback(async () => {
    return Promise.all([
      api.get<any[]>("/admin/users"),
      api.get<any[]>("/admin/shops"),
      api.get<any[]>("/admin/orders"),
      api.get<any[]>("/admin/requests/anything"),
      api.get<any[]>("/admin/requests/assist"),
      api.get<any[]>("/admin/restaurants"),
      api.get<any[]>("/admin/restaurant/orders"),
      api.get<any[]>("/admin/restaurant/support"),
      api.get<any[]>("/catalog/master-products?limit=100"),
      api.get<any[]>("/admin/announcements"),
      api.get<any>("/home-services/fee-policy", false),
      api.get<any>("/admin/dashboard"),
    ]).then(async ([userRows, s, o, a, g, restaurantRows, foodOrderRows, supportRows, masterRows, announcementRows, homeFeePolicy, summary]) => {
    setDashboard(summary);
    setUsers(userRows); setShops(s); setOrders(o); setAnything(a); setAssist(g); setRestaurants(restaurantRows); setFoodOrders(foodOrderRows); setSupport(supportRows); setMasterProducts(masterRows); setAnnouncements(announcementRows); setHomeFeeMode(homeFeePolicy.mode || "provider"); setHomeFixedFee(String(homeFeePolicy.fixed_visit_fee ?? 0));
  
    });
  }, []);

  useEffect(() => {
    if (tab !== "chandFeedback" || user?.role !== "admin") return;
    let active = true;
    void api.get<any[]>("/admin/chand/feedback").then((rows) => {
      if (active) setChandFeedback(rows);
    }).catch((e: any) => { if (active) setAdminNotice(e?.message || "Chand feedback could not be loaded."); });
    return () => { active = false; };
  }, [tab, user?.role]);

  useEffect(() => {
    if (tab !== "referrals" || user?.role !== "admin") return;
    let active = true;
    void api.get<any>("/admin/referrals").then((result) => {
      if (!active) return;
      setReferralRows(result.referrals || []); setReferralRewards(result.rewards || []);
    }).catch((e: any) => { if (active) setAdminNotice(e?.message || "Referral review queue could not be loaded."); });
    return () => { active = false; };
  }, [tab, user?.role]);

  useEffect(() => {
    if (!user) return;
    if (user.role !== "admin") return;
    load().catch((e: any) => setAdminNotice(e?.message || "Admin data could not be loaded.")).finally(() => setLoading(false));
  }, [user, load]);

  if (!user) {
    return (
      <View style={styles.centered}>
        <Text style={styles.msg}>Please sign in as admin to continue.</Text>
        <Pressable style={styles.primary} onPress={() => router.push("/auth")}><Text style={styles.primaryText}>Sign in</Text></Pressable>
      </View>
    );
  }
  if (user.role !== "admin") {
    return (
      <View style={styles.centered}>
        <Feather name="shield" size={32} color={colors.muted} />
        <Text style={styles.msg}>This area is restricted to Come In admins.</Text>
      </View>
    );
  }
  if (loading) return <View style={styles.centered}><ActivityIndicator color={colors.brandPrimary} /></View>;

  const setShopStatus = async (id: string, status: string) => {
    await api.patch(`/admin/shops/${id}/status`, { status });
    await load();
  };

  const setRestaurantStatus = async (id: string, status: string) => {
    await api.patch(`/admin/restaurants/${id}/status`, { status, available: false });
    await load();
  };

  const setSupportStatus = async (id: string, status: string) => {
    await api.patch(`/admin/restaurant/support/${id}`, { status });
    await load();
  };

  const requestRefund = async (id: string) => {
    try {
      const result = await api.post<any>(`/admin/restaurant/orders/${id}/refund`, {});
      const status = String(result?.refund_status || "unknown").replace(/_/g, " ");
      setAdminNotice(status === "refunded"
        ? "The payment provider confirmed the full refund."
        : status === "refund pending"
          ? "The provider accepted the refund request; settlement is still pending."
          : status === "refund failed"
            ? "The provider reported that the refund failed. Reconciliation is required before retrying."
            : `Provider refund status: ${status}.`);
      await load();
    } catch (e: any) {
      setAdminNotice(e?.message || "Refund request could not be sent.");
      await load();
    }
  };

  const setReqStatus = async (kind: "anything" | "assist", id: string, status: string) => {
    await api.patch(`/admin/requests/${kind}/${id}/status`, { status, note: "" });
    await load();
  };

  const createMasterProduct = async () => {
    if (!masterName.trim() || !masterCategory.trim() || !masterUnit.trim() || masterSource.trim().length < 4) {
      setAdminNotice("Enter product name, category ID, unit and a source reference before creating a master product.");
      return;
    }
    setMasterSaving(true);
    try {
      await api.post("/admin/master-products", {
        name: masterName.trim(), brand: masterBrand.trim(), category_id: masterCategory.trim(),
        source_reference: masterSource.trim(), variants: [{ id: "default", unit: masterUnit.trim() }],
      });
      setAdminNotice("Master catalog record created. Source reference was recorded; review source/licensing before seller use.");
      setMasterName(""); setMasterBrand(""); setMasterSource("");
      const rows = await api.get<any[]>(`/catalog/master-products?q=${encodeURIComponent(masterQuery)}&limit=100`);
      setMasterProducts(rows);
    } catch (e: any) { setAdminNotice(e?.message || "Could not create master catalog record."); }
    finally { setMasterSaving(false); }
  };

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} style={styles.iconBtn}><Feather name="arrow-left" size={20} color={colors.onSurface} /></Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Admin</Text>
          <Text style={styles.sub}>Come In operations</Text>
        </View>
      </View>

      <View style={styles.tabs}>
        {([
          { k: "overview", label: "Overview" },
          { k: "users", label: `Users (${users.length})` },
          { k: "shops", label: `Shops (${shops.length})` },
          { k: "orders", label: `Shop orders (${orders.length})` },
          { k: "restaurants", label: `Restaurants (${restaurants.length})` },
          { k: "foodOrders", label: `Food orders (${foodOrders.length})` },
          { k: "support", label: `Food support (${support.length})` },
          { k: "chandFeedback", label: `Chand feedback (${chandFeedback.length})` },
          { k: "anything", label: `Requests (${anything.length})` },
          { k: "assist", label: `Agent (${assist.length})` },
          { k: "catalog", label: `Master catalog (${masterProducts.length})` },
          { k: "imports", label: "Shop Excel / CSV" },
          { k: "retailImport", label: "Retail Price Import" },
          { k: "announcements", label: `Announcements (${announcements.length})` },
          { k: "homeFees", label: "Home-service fees" },
          { k: "referrals", label: "Referrals" },
          { k: "earnings", label: "Owner Earnings" },
        ] as const).map((t) => (
          <Pressable key={t.k} onPress={() => setTab(t.k as Tab)} style={[styles.tab, tab === t.k && { backgroundColor: colors.brandPrimary }]} testID={`admin-tab-${t.k}`}>
            <Text style={[styles.tabText, tab === t.k && { color: colors.onBrandPrimary }]}>{t.label}</Text>
          </Pressable>
        ))}
      </View>

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, gap: spacing.sm }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await load(); setRefreshing(false); }} />}
      >
        {adminNotice ? <Text style={styles.cardMeta} testID="admin-notice">{adminNotice}</Text> : null}
        {tab === "overview" && <View style={styles.card} testID="admin-overview">
          <Text style={styles.cardTitle}>Operations overview</Text>
          {!dashboard ? <Text style={styles.cardMeta}>Summary not loaded. Pull to refresh.</Text> : <>
            {([
              ["Users", dashboard.users?.total, Object.entries(dashboard.users?.by_role || {}).map(([k, v]) => `${k} ${v}`).join(" · "), "users"],
              ["Shops awaiting approval", dashboard.shops?.pending_approval, `${dashboard.shops?.total ?? 0} shops total`, "shops"],
              ["Restaurants awaiting approval", dashboard.restaurants?.pending_approval, `${dashboard.restaurants?.total ?? 0} restaurants total`, "restaurants"],
              ["Shop orders (24h)", dashboard.grocery_orders?.last_24h, `${dashboard.grocery_orders?.total ?? 0} total · pending ${dashboard.grocery_orders?.by_status?.pending ?? 0}`, "orders"],
              ["Food orders (24h)", dashboard.restaurant_orders?.last_24h, `${dashboard.restaurant_orders?.total ?? 0} total · placed ${dashboard.restaurant_orders?.by_status?.placed ?? 0}`, "foodOrders"],
              ["Open food support tickets", dashboard.open_support_tickets, "Not resolved or closed", "support"],
              ["Open requests", dashboard.open_requests, "Request Anything queue", "anything"],
              ["Active announcements", dashboard.active_announcements, "Shown in the app", "announcements"],
            ] as const).map(([label, value, meta, target]) => (
              <Pressable key={label} testID={`admin-stat-${target}`} onPress={() => setTab(target as Tab)} style={styles.catalogRow}>
                <Text style={styles.cardTitle}>{label}: {value ?? 0}</Text>
                <Text style={styles.cardMeta}>{meta}</Text>
              </Pressable>
            ))}
            <Text style={styles.cardMeta} testID="admin-overview-gross">Delivered shop-order gross (not platform revenue): ₹{Number(dashboard.delivered_grocery_gross_inr || 0).toFixed(2)}</Text>
            <Text style={styles.cardMeta}>Push notifications: {dashboard.push_configured ? "configured" : "not configured — users get in-app notifications only"}</Text>
          </>}
        </View>}
        {tab === "earnings" && <View style={styles.card} testID="admin-owner-earnings-entry"><Text style={styles.cardTitle}>Owner Earnings Dashboard</Text><Text style={styles.cardMeta}>Platform commission, fees, refunds, referral liabilities, bank destination and manual settlement review. Gross shop sales are reported separately from platform revenue.</Text><ActionBtn label="Open Owner Earnings Dashboard" onPress={() => router.push("/admin-earnings")} /></View>}
        {tab === "users" && users.map((u) => (
          <View key={u.id} style={styles.card} testID={`admin-user-${u.id}`}>
            <Text style={styles.cardTitle}>{u.name || "Unnamed user"}</Text>
            <Text style={styles.cardMeta}>{u.email} · {u.phone || "No phone"} · current role: {u.role}</Text>
            <View style={styles.btnRow}>
              {(["customer", "shopkeeper", "admin"] as const).filter((role) => role !== u.role).map((role) => <ActionBtn key={role} label={`Set ${role}`} tone={role === "admin" ? "danger" : "ghost"} onPress={async () => { Alert.alert("Change user role", `Set ${u.email} to ${role}? This changes server-authorized access.`, [{text:"Cancel",style:"cancel"},{text:"Confirm",onPress:async()=>{try{await api.patch(`/admin/users/${u.id}/role`,{role});setAdminNotice(`Role updated for ${u.email}.`);await load();}catch(e:any){setAdminNotice(e?.message||"Role update failed.");}}}]); }} />)}
            </View>
          </View>
        ))}
        {tab === "shops" && shops.map((s) => (
          <View key={s.id} style={styles.card} testID={`admin-shop-${s.id}`}>
            <Text style={styles.cardTitle}>{s.name}</Text>
            <Text style={styles.cardMeta}>{s.area || s.address || "—"} · {s.shop_type} · {s.status}</Text>
            <Text style={styles.cardMeta}>phone {s.phone || "—"}</Text>
            <View style={styles.btnRow}>
              {s.status !== "approved" && <ActionBtn label="Approve" onPress={() => setShopStatus(s.id, "approved")} testID={`approve-${s.id}`} />}
              {s.status !== "suspended" && <ActionBtn label="Suspend" onPress={() => setShopStatus(s.id, "suspended")} testID={`suspend-${s.id}`} tone="danger" />}
              {s.status !== "pending" && <ActionBtn label="Reset" onPress={() => setShopStatus(s.id, "pending")} tone="ghost" />}
            </View>
          </View>
        ))}
        {tab === "orders" && orders.map((o) => (
          <View key={o.id} style={styles.card}>
            <Text style={styles.cardTitle}>{o.ref} — ₹{o.total}</Text>
            <Text style={styles.cardMeta}>{o.customer_name || "Guest"} · {o.payment_method} · {o.status}</Text>
            <Text style={styles.cardMeta}>{o.delivery_address}</Text>
          </View>
        ))}
        {tab === "restaurants" && restaurants.map((r) => (
          <View key={r.id} style={styles.card}>
            <Text style={styles.cardTitle}>{r.name}</Text>
            <Text style={styles.cardMeta}>{r.city} · {r.status} · {r.available ? "available" : "offline"}</Text>
            <Text style={styles.cardMeta}>{r.address} · {r.phone}</Text>
            <View style={styles.btnRow}>
              {r.status !== "approved" && <ActionBtn label="Approve" onPress={() => setRestaurantStatus(r.id, "approved")} />}
              {r.status !== "suspended" && <ActionBtn label="Suspend" onPress={() => setRestaurantStatus(r.id, "suspended")} tone="danger" />}
              {r.status !== "pending" && <ActionBtn label="Set pending" onPress={() => setRestaurantStatus(r.id, "pending")} tone="ghost" />}
            </View>
          </View>
        ))}
        {tab === "foodOrders" && foodOrders.map((o) => (
          <View key={o.id} style={styles.card}>
            <Text style={styles.cardTitle}>{o.ref} — ₹{o.total}</Text>
            <Text style={styles.cardMeta}>{o.restaurant_name} · {o.status} · payment {o.payment_status}</Text>
            <Text style={styles.cardMeta}>{o.contact_name} · {o.contact_phone} · refund {o.refund_status || "not requested"}</Text>
            {Number(o.refunded_amount_paise || 0) > 0 ? <Text style={styles.cardMeta}>Provider-confirmed refunded: ₹{(Number(o.refunded_amount_paise) / 100).toFixed(2)}</Text> : null}
            {Number(o.refund_pending_amount_paise || 0) > 0 ? <Text style={styles.cardMeta}>Provider refund pending: ₹{(Number(o.refund_pending_amount_paise) / 100).toFixed(2)}</Text> : null}
            {o.payment_status === "paid" && !["refund_requested", "refund_uncertain", "refund_pending", "pending", "processed", "refunded", "partially_refunded", "refund_reconciliation_required", "under_review", "completed", "succeeded"].includes(o.refund_status || "") && <View style={styles.btnRow}><ActionBtn label="Request full refund" onPress={() => requestRefund(o.id)} tone="danger" /></View>}
          </View>
        ))}
        {tab === "support" && support.map((r) => (
          <View key={r.id} style={styles.card}>
            <Text style={styles.cardTitle}>{r.ref} · {r.category}</Text>
            <Text style={styles.cardMeta}>{r.message}</Text>
            <Text style={styles.cardMeta}>Status: {r.status}</Text>
            <View style={styles.btnRow}>
              <ActionBtn label="In progress" onPress={() => setSupportStatus(r.id, "in_progress")} />
              <ActionBtn label="Resolve" onPress={() => setSupportStatus(r.id, "resolved")} />
              <ActionBtn label="Close" onPress={() => setSupportStatus(r.id, "closed")} tone="ghost" />
            </View>
          </View>
        ))}
        {tab === "chandFeedback" && chandFeedback.map((r) => (
          <View key={r.id} style={styles.card} testID={`admin-chand-feedback-${r.id}`}>
            <Text style={styles.cardTitle}>{r.rating === "positive" ? "Positive" : "Negative"} · {r.category} · {r.status}</Text>
            <Text style={styles.cardMeta}>{r.comment || "No additional comment"}</Text>
            <Text style={styles.cardMeta}>Reference: {r.conversation_ref} · Submitted: {r.created_at ? new Date(r.created_at).toLocaleString() : "—"}</Text>
            {r.resolution_note ? <Text style={styles.cardMeta}>Resolution: {r.resolution_note}</Text> : null}
            <View style={styles.btnRow}>
              {r.status === "open" && <ActionBtn label="Start review" onPress={async () => { try { await api.patch(`/admin/chand/feedback/${r.id}`, { status: "reviewing", resolution_note: "" }); setChandFeedback((rows) => rows.map((x) => x.id === r.id ? { ...x, status: "reviewing" } : x)); } catch (e: any) { setAdminNotice(e?.message || "Feedback update failed."); } }} />}
              {r.status === "reviewing" && <ActionBtn label="Resolve" onPress={async () => { try { await api.patch(`/admin/chand/feedback/${r.id}`, { status: "resolved", resolution_note: "Reviewed by admin" }); setChandFeedback((rows) => rows.map((x) => x.id === r.id ? { ...x, status: "resolved", resolution_note: "Reviewed by admin" } : x)); } catch (e: any) { setAdminNotice(e?.message || "Feedback update failed."); } }} />}
              {r.status !== "closed" && <ActionBtn label="Close" tone="ghost" onPress={async () => { try { await api.patch(`/admin/chand/feedback/${r.id}`, { status: "closed", resolution_note: "Closed by admin" }); setChandFeedback((rows) => rows.map((x) => x.id === r.id ? { ...x, status: "closed", resolution_note: "Closed by admin" } : x)); } catch (e: any) { setAdminNotice(e?.message || "Feedback update failed."); } }} />}
            </View>
          </View>
        ))}
        {tab === "anything" && anything.map((r) => (
          <View key={r.id} style={styles.card}>
            <Text style={styles.cardTitle}>{r.ref}</Text>
            <Text style={styles.cardMeta}>{r.description}</Text>
            <Text style={styles.cardMeta}>drop {r.drop} · {r.status}</Text>
            <View style={styles.btnRow}>
              <ActionBtn label="Assign" onPress={() => setReqStatus("anything", r.id, "assigned")} />
              <ActionBtn label="Complete" onPress={() => setReqStatus("anything", r.id, "completed")} />
              <ActionBtn label="Cancel" onPress={() => setReqStatus("anything", r.id, "cancelled")} tone="danger" />
            </View>
          </View>
        ))}
        {tab === "assist" && assist.map((r) => (
          <View key={r.id} style={styles.card}>
            <Text style={styles.cardTitle}>{r.ref}</Text>
            <Text style={styles.cardMeta}>{r.reason}</Text>
            <Text style={styles.cardMeta}>shop {r.shop_id || "–"} · {r.status}</Text>
            <View style={styles.btnRow}>
              <ActionBtn label="Assign" onPress={() => setReqStatus("assist", r.id, "assigned")} />
              <ActionBtn label="Complete" onPress={() => setReqStatus("assist", r.id, "completed")} />
            </View>
          </View>
        ))}
        {tab === "homeFees" && <View style={styles.card} testID="admin-home-service-fees">
          <Text style={styles.cardTitle}>Home-visit fee policy</Text>
          <Text style={styles.cardMeta}>This policy applies to new appointment requests. Existing appointments retain their fee snapshot. It does not charge customers or imply payment.</Text>
          {([ ["provider", "Use each provider’s configured visit fee"], ["fixed", "Use one platform-wide fixed fee"], ["waived", "Waive the home-visit fee"] ] as const).map(([value,label]) => <Pressable key={value} onPress={() => setHomeFeeMode(value)} style={[styles.catalogRow,{borderWidth:1,borderColor:homeFeeMode===value?colors.brandPrimary:colors.border,borderRadius:radius.md,padding:spacing.md}]}><Text style={styles.cardMeta}>{homeFeeMode===value?"● ":"○ "}{label}</Text></Pressable>)}
          {homeFeeMode === "fixed" && <TextInput value={homeFixedFee} onChangeText={setHomeFixedFee} keyboardType="decimal-pad" placeholder="Fixed fee in INR" style={styles.input} />}
          <ActionBtn label="Save home-visit fee policy" onPress={async () => { const fee=Number(homeFixedFee); if (!Number.isFinite(fee)||fee<0||fee>100000) { setAdminNotice("Enter a valid fee between ₹0 and ₹100,000."); return; } try { await api.patch("/admin/home-services/fee-policy",{mode:homeFeeMode,fixed_visit_fee:fee,currency:"INR"}); setAdminNotice("Home-visit fee policy saved for new appointment requests."); } catch(e:any) { setAdminNotice(e?.message||"Could not save fee policy."); } }} />
        </View>}
        {tab === "announcements" && <View style={styles.card} testID="admin-announcements">
          <Text style={styles.cardTitle}>Create an announcement</Text>
          <TextInput accessibilityLabel="Announcement title" placeholder="Title" value={announcementTitle} onChangeText={setAnnouncementTitle} style={styles.input} />
          <TextInput accessibilityLabel="Announcement body" placeholder="Message" value={announcementBody} onChangeText={setAnnouncementBody} multiline style={[styles.input, { minHeight: 80, textAlignVertical: "top" }]} />
          <View style={styles.btnRow}>
            {(["all", "customers", "shopkeepers"] as const).map((audience) => <ActionBtn key={audience} label={audience} tone={announcementAudience === audience ? undefined : "ghost"} onPress={() => setAnnouncementAudience(audience)} />)}
          </View>
          <TextInput accessibilityLabel="Announcement active days" testID="admin-announcement-days" placeholder="Show for N days (blank = until deactivated)" value={announcementDays} onChangeText={setAnnouncementDays} keyboardType="number-pad" style={styles.input} />
          <ActionBtn label={editingAnnouncement ? "Save changes" : "Publish announcement"} testID="admin-announcement-create" onPress={async () => {
            if (announcementTitle.trim().length < 3 || announcementBody.trim().length < 3) { setAdminNotice("Enter an announcement title and message."); return; }
            const days = announcementDays.trim() ? Number(announcementDays) : null;
            if (days !== null && (!Number.isInteger(days) || days < 1 || days > 365)) { setAdminNotice("Active days must be a whole number from 1 to 365."); return; }
            const payload = { title: announcementTitle.trim(), body: announcementBody.trim(), audience: announcementAudience, expires_at: days ? new Date(Date.now() + days * 86400000).toISOString() : null };
            try {
              if (editingAnnouncement) await api.patch(`/admin/announcements/${editingAnnouncement}`, payload);
              else await api.post("/admin/announcements", { ...payload, active: true });
              setAdminNotice(editingAnnouncement ? "Announcement updated." : "Announcement published.");
              setEditingAnnouncement(null); setAnnouncementTitle(""); setAnnouncementBody(""); setAnnouncementDays(""); setAnnouncements(await api.get<any[]>("/admin/announcements"));
            }
            catch (e: any) { setAdminNotice(e?.message || "Could not save announcement."); }
          }} />
          {editingAnnouncement && <ActionBtn label="Cancel edit" tone="ghost" testID="admin-announcement-cancel-edit" onPress={() => { setEditingAnnouncement(null); setAnnouncementTitle(""); setAnnouncementBody(""); setAnnouncementDays(""); }} />}
          {announcements.map((announcement) => <View key={announcement.id} style={styles.catalogRow}><Text style={styles.cardTitle}>{announcement.title}</Text><Text style={styles.cardMeta}>{announcement.audience} · {announcement.active ? "active" : "inactive"}{announcement.expires_at ? ` · until ${new Date(announcement.expires_at).toLocaleDateString()}` : ""}</Text><Text style={styles.cardMeta}>{announcement.body}</Text><View style={styles.btnRow}><ActionBtn label="Edit" tone="ghost" testID={`admin-announcement-edit-${announcement.id}`} onPress={() => { setEditingAnnouncement(announcement.id); setAnnouncementTitle(announcement.title || ""); setAnnouncementBody(announcement.body || ""); setAnnouncementAudience(announcement.audience || "all"); setAnnouncementDays(""); setAdminNotice("Editing announcement. Leave days blank to keep it until deactivated."); }} /><ActionBtn label={announcement.active ? "Deactivate" : "Activate"} tone={announcement.active ? "danger" : undefined} onPress={async () => { try { await api.patch(`/admin/announcements/${announcement.id}`, { active: !announcement.active }); setAnnouncements(await api.get<any[]>("/admin/announcements")); } catch (e: any) { setAdminNotice(e?.message || "Could not update announcement."); } }} /></View></View>)}
          {!announcements.length && <Text style={styles.cardMeta}>No announcements have been created.</Text>}
        </View>}
        {tab === "imports" && <View style={styles.card} testID="admin-catalog-import">
          <Text style={styles.cardTitle}>Store product import</Text>
          <Text style={styles.cardMeta}>Admin-only management. Select an existing store, download the template, upload CSV/XLSX/XLS, preview validation, then explicitly confirm. The server checks store authorization again on every request.</Text>
          <Text style={styles.cardMeta}>Target store</Text>
          {shops.filter((shop) => Boolean(shop.id)).map((shop) => <Pressable key={shop.id} onPress={() => { setImportShopId(shop.id); setImportPreview(null); }} style={[styles.catalogRow,{borderWidth:1,borderColor:importShopId===shop.id?colors.brandPrimary:colors.border,borderRadius:radius.md,padding:spacing.sm}]}><Text style={styles.cardMeta}>{importShopId===shop.id?"● ":"○ "}{shop.name} · {shop.shop_type} · {shop.status}</Text></Pressable>)}
          {!shops.length && <Text style={styles.cardMeta}>No stores are loaded. Refresh the admin dashboard and verify the backend connection.</Text>}
          <View style={styles.btnRow}>
            <ActionBtn label="Download CSV template" tone="ghost" onPress={async () => { if (!importShopId) { setAdminNotice("Select a store first."); return; } try { const blob = await api.downloadShopImportTemplate(importShopId); if (typeof document === "undefined" || typeof URL === "undefined") { setAdminNotice("Template download is supported in the web admin. On native, use the project web admin for this download."); return; } const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "come-in-grocery-import-template.csv"; a.click(); URL.revokeObjectURL(url); setAdminNotice("Template downloaded."); } catch(e:any) { setAdminNotice(e?.message || "Template download failed."); } }} />
            <ActionBtn label={importBusy?"Working…":"Refresh history / audit"} tone="ghost" onPress={async () => { setImportBusy(true); try { const [h,a] = await Promise.all([api.get<any[]>("/admin/catalog-import-history"),api.get<any[]>("/admin/catalog-price-audit")]); setImportHistory(h); setPriceAudit(a); setAdminNotice("Import history and price audit refreshed."); } catch(e:any) { setAdminNotice(e?.message || "History/audit could not be loaded."); } finally { setImportBusy(false); } }} />
          </View>
          {typeof document !== "undefined" ? React.createElement("input" as any, { type:"file", accept:".csv,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel", disabled:!importShopId || importBusy, onChange:(event:any)=>{ const file=event?.target?.files?.[0] as File | undefined; setImportFile(file || null); setImportPreview(null); if(file) setAdminNotice(`Selected ${file.name} (${file.size} bytes). Choose Preview before applying.`); }, style:{marginTop:10,marginBottom:10,maxWidth:"100%"}, "aria-label":"Choose product CSV or Excel file" }) : <Text style={styles.cardMeta}>CSV/Excel file selection is available in the web admin. Use the web admin for import files.</Text>}
          {importFile && <Text style={styles.cardMeta}>Selected: {importFile.name} · {(importFile.size/1024).toFixed(1)} KB</Text>}
          <View style={styles.btnRow}>
            <ActionBtn label={importBusy?"Checking…":"Preview and validate"} onPress={async () => { if(!importShopId || !importFile){setAdminNotice("Select a store and a CSV/XLS/XLSX file first.");return;} setImportBusy(true);setImportPreview(null);try{const result=await api.importShopProducts(importShopId,importFile,importFile.name,false);setImportPreview(result);setAdminNotice(result.applied?"Server returned an applied result.":result.errors?.length?"Preview found invalid rows. Correct the file before importing.":"Preview completed. No changes have been committed.");}catch(e:any){setAdminNotice(e?.message||"Import preview failed.");}finally{setImportBusy(false);}}} />
            <ActionBtn label={importBusy?"Working…":"Confirm and import"} tone="danger" onPress={() => { if(!importShopId||!importFile||!importPreview||importPreview.errors?.length||!importPreview.valid_rows){setAdminNotice("Run a successful preview with no errors before confirming import.");return;} Alert.alert("Confirm catalogue import", `Apply ${importPreview.valid_rows} validated row(s) to ${shops.find((shop)=>shop.id===importShopId)?.name || "the selected store"}? This may create listings and update prices.`, [{text:"Cancel",style:"cancel"},{text:"Import now",style:"destructive",onPress:async()=>{setImportBusy(true);try{const result=await api.importShopProducts(importShopId,importFile,importFile.name,true);setImportPreview(result);setAdminNotice(result.applied?`Import completed: ${result.created||0} created, ${result.updated||0} updated.`:(result.errors?.[0]?.error||"Import was not committed."));if(result.applied){setImportHistory(await api.get<any[]>("/admin/catalog-import-history"));setPriceAudit(await api.get<any[]>("/admin/catalog-price-audit"));setImportFile(null);}}catch(e:any){setAdminNotice(e?.message||"Import failed; check server response and history.");}finally{setImportBusy(false);}}}]);}} />
          </View>
          {importPreview && <View style={styles.catalogRow}>
            <Text style={styles.cardTitle}>Server validation result · {importPreview.mode || "result"}</Text>
            <Text style={styles.cardMeta}>Valid rows: {importPreview.valid_rows ?? 0} · Created: {importPreview.created ?? 0} · Updated: {importPreview.updated ?? 0} · Skipped: {importPreview.skipped ?? 0} · Applied: {importPreview.applied ? "yes" : "no"}</Text>
            {importPreview.message ? <Text style={styles.cardMeta}>{importPreview.message}</Text> : null}
            {(importPreview.errors || []).map((err:any,i:number)=><Text key={`${err.row}-${i}`} style={[styles.cardMeta,{color:colors.error}]}>Row {err.row}: {err.error}</Text>)}
            <Text style={styles.cardTitle}>New products ({(importPreview.new_products||[]).length})</Text>
            {(importPreview.new_products||[]).map((row:any)=><Text key={`new-${row.row}`} style={styles.cardMeta}>Row {row.row}: {row.name} · {row.brand||"No brand"} · {row.unit} · SKU {row.sku} · ₹{row.price}</Text>)}
            <Text style={styles.cardTitle}>Price changes ({(importPreview.price_changes||[]).length})</Text>
            {(importPreview.price_changes||[]).map((row:any)=><Text key={`price-${row.row}`} style={styles.cardMeta}>Row {row.row}: {row.name} · ₹{row.old_price} → ₹{row.new_price}</Text>)}
            <Text style={styles.cardTitle}>Matched updates ({(importPreview.matched_updates||[]).length})</Text>
            {(importPreview.matched_updates||[]).map((row:any)=><Text key={`match-${row.row}`} style={styles.cardMeta}>Row {row.row}: {row.name} · SKU {row.sku||"—"} · existing ₹{row.old_price}, proposed ₹{row.new_price}</Text>)}
            {!importPreview.errors?.length && !importPreview.applied && <Text style={styles.cardMeta}>No changes are committed during preview. Explicit confirmation is required.</Text>}
          </View>}
          <Text style={styles.cardTitle}>Recent imports</Text>
          {importHistory.map((item:any,i:number)=><Text key={item.id||`${item.filename}-${i}`} style={styles.cardMeta}>{item.filename} · store {item.shop_id} · {item.status} · created {item.created||0}, updated {item.updated||0}, skipped {item.skipped||0}</Text>)}
          <Text style={styles.cardTitle}>Price-change audit</Text>
          {priceAudit.map((item:any,i:number)=><Text key={item.id||`${item.product_id}-${i}`} style={styles.cardMeta}>{item.product_name} · SKU {item.sku||"—"} · ₹{item.old_price} → ₹{item.new_price} · store {item.shop_id}</Text>)}
          {!importHistory.length && !priceAudit.length && <Text style={styles.cardMeta}>Press “Refresh history / audit” to load records from the admin-only endpoints.</Text>}
        </View>}
        {tab === "referrals" && <View style={styles.card} testID="admin-referral-review">
          <Text style={styles.cardTitle}>Referral qualification and reward review</Text>
          <Text style={styles.cardMeta}>Approve only after independently verifying the referred customer&#39;s contact, confirming the qualifying payment, and completing refund/return and fraud checks. This admin action records your attestation; it does not perform bank payout.</Text>
          <ActionBtn label="Refresh referral queue" tone="ghost" onPress={async()=>{try{const result=await api.get<any>("/admin/referrals");setReferralRows(result.referrals||[]);setReferralRewards(result.rewards||[]);setAdminNotice("Referral queue refreshed.");}catch(e:any){setAdminNotice(e?.message||"Could not refresh referral queue.");}}} />
          <Text style={styles.section}>Referral registrations</Text>
          {referralRows.map((r:any)=><View key={r.id} style={styles.catalogRow}>
            <Text style={styles.cardTitle}>Status: {r.status} · Order total: {r.order_total == null ? "not available" : `₹${r.order_total}`}</Text>
            <Text style={styles.cardMeta}>Created: {r.created_at || "unknown"} · Referral record: {r.id}</Text>
            {r.status === "pending_review" && <View style={styles.btnRow}>
              <ActionBtn label="Approve after all checks" onPress={()=>Alert.alert("Verify referral eligibility", "Only continue if you have independently verified customer contact, confirmed payment, and completed refund/return and fraud checks.", [{text:"Cancel",style:"cancel"},{text:"I verified all checks",onPress:async()=>{try{await api.patch(`/admin/referrals/${r.id}/review`,{decision:"approve",note:"Admin verified contact, payment, refund/return and fraud checks.",contact_verified:true,contact_verification_method:"authorized_manual_check",payment_confirmed:true,refund_return_checks_passed:true});setAdminNotice("Referral approved after admin attestation.");const result=await api.get<any>("/admin/referrals");setReferralRows(result.referrals||[]);setReferralRewards(result.rewards||[]);}catch(e:any){setAdminNotice(e?.message||"Referral approval failed.");}}}])} />
              <ActionBtn label="Reject" tone="danger" onPress={()=>Alert.alert("Reject referral", "Reject this referral qualification?", [{text:"Cancel",style:"cancel"},{text:"Reject",style:"destructive",onPress:async()=>{try{await api.patch(`/admin/referrals/${r.id}/review`,{decision:"reject",note:"Rejected by admin review."});const result=await api.get<any>("/admin/referrals");setReferralRows(result.referrals||[]);setReferralRewards(result.rewards||[]);setAdminNotice("Referral rejected and audited.");}catch(e:any){setAdminNotice(e?.message||"Referral rejection failed.");}}}])} />
            </View>}
          </View>)}
          {!referralRows.length && <Text style={styles.cardMeta}>No referral records returned by the backend.</Text>}
          <Text style={styles.section}>₹500 reward workflow</Text>
          {referralRewards.map((r:any)=><View key={r.id} style={styles.catalogRow}>
            <Text style={styles.cardTitle}>₹{r.amount} · {r.status}</Text><Text style={styles.cardMeta}>Eligible referrals: {r.eligible_referrals || 10} · Reward record: {r.id}</Text>
            {r.status === "pending_verification" && <ActionBtn label="Approve ₹500 reward" onPress={()=>Alert.alert("Approve reward", "Approve the single ₹500 reward only after validating all 10 qualified referrals and fraud review.", [{text:"Cancel",style:"cancel"},{text:"Approve reward",onPress:async()=>{try{await api.patch(`/admin/referral-rewards/${r.id}`,{decision:"approve",note:"10 qualifying customers verified."});const result=await api.get<any>("/admin/referrals");setReferralRows(result.referrals||[]);setReferralRewards(result.rewards||[]);setAdminNotice("Reward approved; ledger credit recorded.");}catch(e:any){setAdminNotice(e?.message||"Reward approval failed.");}}}])} />}
            {r.status === "approved" && <ActionBtn label="Make reward available" onPress={async()=>{try{await api.patch(`/admin/referral-rewards/${r.id}`,{decision:"available",note:"Reward cleared for use."});const result=await api.get<any>("/admin/referrals");setReferralRewards(result.rewards||[]);setAdminNotice("Reward marked available in the ledger.");}catch(e:any){setAdminNotice(e?.message||"Could not release reward.");}}} />}
            {(r.status === "available" || r.status === "processing") && <View style={{gap:spacing.xs}}><TextInput value={referralPayoutReference} onChangeText={setReferralPayoutReference} placeholder="Verified payout reference (required to mark paid)" placeholderTextColor={colors.muted} style={styles.input} /><View style={styles.btnRow}>{r.status === "available" && <ActionBtn label="Mark processing" tone="ghost" onPress={async()=>{try{await api.patch(`/admin/referral-rewards/${r.id}`,{decision:"processing",note:"Manual payout processing started."});const result=await api.get<any>("/admin/referrals");setReferralRewards(result.rewards||[]);}catch(e:any){setAdminNotice(e?.message||"Could not update payout status.");}}} />}<ActionBtn label="Mark paid" onPress={async()=>{if(!referralPayoutReference.trim()){setAdminNotice("Enter a verified bank payout reference first.");return;}try{await api.patch(`/admin/referral-rewards/${r.id}`,{decision:"paid",note:"Manual bank payout verified.",payout_reference:referralPayoutReference.trim()});setReferralPayoutReference("");const result=await api.get<any>("/admin/referrals");setReferralRewards(result.rewards||[]);setAdminNotice("Payout reference recorded; reward marked paid.");}catch(e:any){setAdminNotice(e?.message||"Could not mark reward paid.");}}} /></View></View>}
          </View>)}
          {!referralRewards.length && <Text style={styles.cardMeta}>No ₹500 reward workflow has been triggered yet.</Text>}
        </View>}

        {tab === "retailImport" && <View style={styles.card} testID="admin-retail-price-import">
          <Text style={styles.cardTitle}>Retail Price Import</Text>
          <Text style={styles.cardMeta}>Admin-only source-scoped import for authorized retailer files. Each offer is stored under its own retailer + retailer shop ID + SKU/name key, so one retailer cannot overwrite another retailer or a COME-IN shop&#39;s checkout price. Preview does not write data.</Text>
          <Text style={styles.cardMeta}>Required columns: retailer, retailer_shop_id, name, price. Recommended: sku, category_id, brand, pack_size/unit, stock, last_updated, source_url.</Text>
          <View style={styles.btnRow}>
            <ActionBtn label="Download Retail CSV template" tone="ghost" onPress={async () => { try { const blob = await api.downloadRetailPriceImportTemplate(); if (typeof document === "undefined" || typeof URL === "undefined") { setAdminNotice("Template download is supported in the web admin."); return; } const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "come-in-retail-price-template.csv"; a.click(); URL.revokeObjectURL(url); setAdminNotice("Retail Price Import template downloaded."); } catch(e:any) { setAdminNotice(e?.message || "Retail template download failed."); } }} />
            <ActionBtn label="Refresh retail history" tone="ghost" onPress={async () => { setImportBusy(true); try { setRetailHistory(await api.get<any[]>("/admin/retail-price-import/history")); setAdminNotice("Retail import history refreshed."); } catch(e:any) { setAdminNotice(e?.message || "Retail history could not be loaded."); } finally { setImportBusy(false); } }} />
          </View>
          {typeof document !== "undefined" ? React.createElement("input" as any, { type:"file", accept:".csv,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel", disabled:importBusy, onChange:(event:any)=>{ const file=event?.target?.files?.[0] as File | undefined; setRetailFile(file || null); setRetailPreview(null); if(file) setAdminNotice(`Selected retailer file ${file.name}. Preview before applying.`); }, style:{marginTop:10,marginBottom:10,maxWidth:"100%"}, "aria-label":"Choose retailer price CSV or Excel file" }) : <Text style={styles.cardMeta}>CSV/Excel file selection is available in the web admin.</Text>}
          {retailFile && <Text style={styles.cardMeta}>Selected: {retailFile.name} · {(retailFile.size/1024).toFixed(1)} KB</Text>}
          <View style={styles.btnRow}>
            <ActionBtn label={importBusy?"Checking…":"Preview and validate"} onPress={async()=>{ if(!retailFile){setAdminNotice("Choose a retailer CSV/XLS/XLSX file first.");return;} setImportBusy(true);setRetailPreview(null);try{const result=await api.importRetailPrices(retailFile,retailFile.name,false);setRetailPreview(result);setAdminNotice(result.errors?.length?"Retail preview found invalid rows; correct them before importing.":"Retail preview complete. No changes have been committed.");}catch(e:any){setAdminNotice(e?.message||"Retail preview failed.");}finally{setImportBusy(false);}}} />
            <ActionBtn label={importBusy?"Working…":"Confirm Retail Import"} tone="danger" onPress={()=>{if(!retailFile||!retailPreview||retailPreview.errors?.length||!retailPreview.valid_rows){setAdminNotice("Run a successful preview with no errors before confirming.");return;} Alert.alert("Confirm Retail Price Import",`Apply ${retailPreview.valid_rows} retailer offer row(s)? Existing offers update only within the same retailer and retailer shop ID.`,[{text:"Cancel",style:"cancel"},{text:"Import now",style:"destructive",onPress:async()=>{setImportBusy(true);try{const result=await api.importRetailPrices(retailFile,retailFile.name,true);setRetailPreview(result);setAdminNotice(result.applied?`Retail import complete: ${result.created||0} created, ${result.updated||0} updated.`:(result.errors?.[0]?.error||"Import was not committed."));if(result.applied){setRetailHistory(await api.get<any[]>("/admin/retail-price-import/history"));setRetailFile(null);}}catch(e:any){setAdminNotice(e?.message||"Retail import failed.");}finally{setImportBusy(false);}}}]);}} />
          </View>
          {retailPreview && <View style={styles.catalogRow}>
            <Text style={styles.cardTitle}>Preview result · {retailPreview.mode}</Text>
            <Text style={styles.cardMeta}>Valid: {retailPreview.valid_rows||0} · Created: {retailPreview.created||0} · Updated: {retailPreview.updated||0} · Skipped: {retailPreview.skipped||0} · Applied: {retailPreview.applied?"yes":"no"}</Text>
            {(retailPreview.errors||[]).map((err:any,i:number)=><Text key={`retail-err-${err.row}-${i}`} style={[styles.cardMeta,{color:colors.error}]}>Row {err.row}: {err.error}</Text>)}
            {(retailPreview.rows||[]).slice(0,100).map((row:any,i:number)=><Text key={`retail-row-${row.row}-${i}`} style={styles.cardMeta}>Row {row.row}: {row.retailer} / {row.retailer_shop_id} · {row.name} · {row.action} · ₹{row.old_price ?? "—"} → ₹{row.price} · source updated: {row.source_last_updated||"not provided"}</Text>)}
            {!retailPreview.errors?.length&&!retailPreview.applied&&<Text style={styles.cardMeta}>Preview only; no price data was written. Confirm to apply.</Text>}
          </View>}
          <Text style={styles.cardTitle}>Recent Retail imports</Text>
          {retailHistory.map((item:any,i:number)=><Text key={item.id||`${item.filename}-${i}`} style={styles.cardMeta}>{item.filename} · {(item.source_retailers||[]).join(", ")} · {item.status} · {item.created||0} created / {item.updated||0} updated · {item.created_at||"time unavailable"}</Text>)}
          {!retailHistory.length&&<Text style={styles.cardMeta}>Use Refresh retail history to load previous successful import records.</Text>}
        </View>}
        {tab === "catalog" && <View style={styles.card} testID="admin-master-catalog">
          <Text style={styles.cardTitle}>Add canonical master product</Text>
          <Text style={styles.cardMeta}>Master records describe a product/variant identity; each shop still sets its own price and stock. Use an authorized source reference.</Text>
          <TextInput accessibilityLabel="Master product name" placeholder="Product name" value={masterName} onChangeText={setMasterName} style={styles.input} />
          <TextInput accessibilityLabel="Brand" placeholder="Brand (optional)" value={masterBrand} onChangeText={setMasterBrand} style={styles.input} />
          <TextInput accessibilityLabel="Category ID" placeholder="Category ID" value={masterCategory} onChangeText={setMasterCategory} style={styles.input} />
          <TextInput accessibilityLabel="Variant unit" placeholder="Variant unit, e.g. 1 kg" value={masterUnit} onChangeText={setMasterUnit} style={styles.input} />
          <TextInput accessibilityLabel="Source reference" placeholder="Source URL/reference" value={masterSource} onChangeText={setMasterSource} autoCapitalize="none" style={styles.input} />
          <ActionBtn label={masterSaving ? "Saving…" : "Create master product"} onPress={() => { void createMasterProduct(); }} testID="admin-master-create" />
          <TextInput accessibilityLabel="Search master catalog" placeholder="Search master catalog" value={masterQuery} onChangeText={setMasterQuery} style={styles.input} />
          <ActionBtn label="Search" onPress={async () => { try { setMasterProducts(await api.get<any[]>(`/catalog/master-products?q=${encodeURIComponent(masterQuery)}&limit=100`)); } catch (e: any) { setAdminNotice(e?.message || "Catalog search failed."); } }} />
          {masterProducts.map((m) => <View key={m.id} style={styles.catalogRow}><Text style={styles.cardTitle}>{m.name}</Text><Text style={styles.cardMeta}>{m.brand || "No brand"} · {m.category_id} · {m.active ? "active" : "inactive"}</Text><Text style={styles.cardMeta}>Variants: {(m.variants || []).map((v: any) => `${v.unit} (${v.id})`).join(", ")}</Text><Text style={styles.cardMeta}>Source: {m.source_reference || "legacy source not recorded"}</Text></View>)}
          {!masterProducts.length && <Text style={styles.cardMeta}>No master records found. This does not imply the live catalog is empty; the list is limited to the current search/result cap.</Text>}
        </View>}
      </ScrollView>
    </View>
  );
}

function ActionBtn({ label, onPress, tone, testID }: { label: string; onPress: () => void; tone?: "danger" | "ghost"; testID?: string }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const bg = tone === "danger" ? colors.error : tone === "ghost" ? colors.surfaceTertiary : colors.brandPrimary;
  const fg = tone === "ghost" ? colors.onSurface : colors.onBrandPrimary;
  return (
    <Pressable testID={testID} onPress={onPress} style={[styles.actionBtn, { backgroundColor: bg }]}>
      <Text style={[styles.actionText, { color: fg }]}>{label}</Text>
    </Pressable>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surfaceSecondary },
  centered: { flex: 1, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", padding: spacing.xl, gap: spacing.md },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.lg, paddingBottom: spacing.sm, backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  iconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  sub: { fontSize: 11, color: colors.muted },
  tabs: { flexDirection: "row", gap: 6, padding: spacing.sm, backgroundColor: colors.surface, flexWrap: "wrap" },
  tab: { paddingHorizontal: spacing.md, paddingVertical: 8, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.border },
  tabText: { fontSize: 11, fontWeight: "800", color: colors.onSurfaceSecondary },
  card: { backgroundColor: colors.surface, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, gap: 4 },
  cardTitle: { fontSize: 14, fontWeight: "800", color: colors.onSurface },
  cardMeta: { fontSize: 11, color: colors.muted },
  input: { minHeight: 42, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, color: colors.onSurface, backgroundColor: colors.surfaceSecondary },
  catalogRow: { paddingVertical: spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border, gap: 3 },
  section: { marginTop: spacing.md, fontSize: 12, fontWeight: "800", color: colors.onSurfaceSecondary },
  btnRow: { flexDirection: "row", gap: 6, marginTop: 6, flexWrap: "wrap" },
  actionBtn: { paddingHorizontal: spacing.md, paddingVertical: 7, borderRadius: radius.pill },
  actionText: { fontSize: 11, fontWeight: "800" },
  msg: { fontSize: 14, color: colors.onSurface, textAlign: "center" },
  primary: { backgroundColor: colors.brandPrimary, paddingVertical: 12, paddingHorizontal: spacing.lg, borderRadius: radius.md },
  primaryText: { color: colors.onBrandPrimary, fontWeight: "800" },
}));
