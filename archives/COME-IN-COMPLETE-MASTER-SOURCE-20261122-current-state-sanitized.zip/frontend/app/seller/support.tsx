import Feather from "@react-native-vector-icons/feather";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

type SupportTicket = {
  id: string;
  ref?: string;
  order_id?: string | null;
  order_kind?: "grocery" | "restaurant" | string;
  order_ref?: string | null;
  category?: string;
  message?: string;
  status: "open" | "in_progress" | "resolved" | "closed" | string;
  created_at?: string;
  updated_at?: string;
};

const SELLER_SUPPORT_ROLES: readonly string[] = ["shopkeeper", "restaurant"];

const NEXT: Record<string, { status: "in_progress" | "resolved"; label: string }> = {
  open: { status: "in_progress", label: "Start handling" },
  in_progress: { status: "resolved", label: "Mark resolved" },
};

export default function SellerSupportScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { user } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    return api.get<SupportTicket[]>("/seller/support").then((rows) => {
      setTickets(Array.isArray(rows) ? rows : []); setError("");
    }).catch((e: any) => {
      const status = (e as any)?.status;
      setError(status === 401 ? "Your session has expired. Please sign in again." : status === 403 ? "Seller access is not authorized for this account." : e?.message || "Support tickets could not be loaded.");
      throw e;
    });
  }, []);

  useEffect(() => {
    if (!user) return;
    if (!SELLER_SUPPORT_ROLES.includes(user.role)) return;
    load().catch(() => undefined).finally(() => setLoading(false));
  }, [user, load]);

  const refresh = async () => {
    setRefreshing(true);
    try { await load(); } catch { /* load sets the visible error */ } finally { setRefreshing(false); }
  };

  const updateStatus = async (ticket: SupportTicket) => {
    const next = NEXT[ticket.status];
    if (!next || busyId) return;
    setBusyId(ticket.id);
    setError("");
    setNotice("");
    try {
      const updated = await api.patch<SupportTicket>(`/seller/support/${encodeURIComponent(ticket.id)}`, {
        status: next.status,
        expected_status: ticket.status,
      });
      setTickets((current) => current.map((row) => row.id === ticket.id ? updated : row));
      setNotice(`Ticket ${updated.ref || updated.id} updated to ${updated.status}.`);
    } catch (e: any) {
      const status = (e as any)?.status;
      if (status === 409) {
        try {
          await load();
          setError("This ticket changed elsewhere. The latest status has been refreshed; review it before trying again.");
        } catch { /* load() keeps its own error visible */ }
      } else if (status === 401 || status === 403) {
        setError(status === 401 ? "Your session has expired. Please sign in again." : "You are not authorized to update this ticket.");
      } else if (status === 404) {
        setError("This ticket is no longer available to your seller account. Refresh the list.");
        try { await load(); } catch { /* keep the refresh error */ }
      } else {
        setError(e?.message || "Ticket update failed. No status change is assumed.");
      }
    } finally {
      setBusyId(null);
    }
  };

  if (!user) return <View style={styles.centered}><Text style={styles.message}>Please sign in to view seller support.</Text><Pressable style={styles.button} onPress={() => router.push("/auth")}><Text style={styles.buttonText}>Sign in</Text></Pressable></View>;
  if (!SELLER_SUPPORT_ROLES.includes(user.role)) return <View style={styles.centered}><Text style={styles.message}>Seller access is required.</Text></View>;

  return <View style={styles.root}>
    <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
      <Pressable onPress={() => router.back()} style={styles.back}><Feather name="arrow-left" size={19} color={colors.onSurface}/></Pressable>
      <View style={{ flex: 1 }}><Text style={styles.title}>Seller Support</Text><Text style={styles.subtitle}>Your authorized Grocery and Restaurant order tickets</Text></View>
    </View>
    {loading ? <View style={styles.centered}><ActivityIndicator color={colors.brandPrimary}/><Text style={styles.message}>Loading support tickets…</Text></View> : <FlatList
      data={tickets}
      keyExtractor={(item) => item.id}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh}/>}
      contentContainerStyle={{ padding: spacing.lg, gap: spacing.sm, flexGrow: 1 }}
      ListEmptyComponent={<View style={styles.centered}><Text style={styles.message}>{error || "No support tickets are currently linked to your shop or restaurant."}</Text><Pressable style={styles.secondary} onPress={refresh}><Text style={styles.secondaryText}>Retry / refresh</Text></Pressable></View>}
      renderItem={({ item }) => {
        const action = NEXT[item.status];
        return <View style={styles.card}>
          <View style={styles.row}><Text style={styles.ref}>{item.ref || `Ticket ${item.id}`}</Text><Text style={styles.status}>{String(item.status).replaceAll("_", " ").toUpperCase()}</Text></View>
          <Text style={styles.meta}>Order: {item.order_ref || item.order_id || "Not linked"} · {item.order_kind === "restaurant" ? "Restaurant" : item.order_kind === "grocery" ? "Grocery" : "Order type unavailable"}</Text>
          <Text style={styles.meta}>Category: {(item.category || "other").replaceAll("_", " ")}</Text>
          <Text style={styles.body}>{item.message || "No details provided."}</Text>
          {item.updated_at ? <Text style={styles.timestamp}>Last updated: {new Date(item.updated_at).toLocaleString()}</Text> : null}
          {action ? <Pressable disabled={busyId !== null} onPress={() => void updateStatus(item)} style={[styles.button, busyId !== null && styles.disabled]}><Text style={styles.buttonText}>{busyId === item.id ? "Updating…" : action.label}</Text></Pressable> : <Text style={styles.meta}>No seller action available for this status.</Text>}
        </View>;
      }}
    />}
    {error ? <View style={styles.feedback}><Text style={styles.error}>{error}</Text><Pressable onPress={refresh}><Text style={styles.link}>Refresh tickets</Text></Pressable></View> : null}
    {notice ? <Text accessibilityRole="status" style={styles.notice}>{notice}</Text> : null}
  </View>;
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surfaceSecondary },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.lg, paddingBottom: spacing.md, backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  back: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  subtitle: { fontSize: 11, color: colors.muted },
  centered: { flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl, gap: spacing.md },
  message: { color: colors.onSurface, textAlign: "center", fontSize: 13 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: radius.md, padding: spacing.md, gap: spacing.sm },
  row: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: spacing.sm },
  ref: { color: colors.onSurface, fontWeight: "900", fontSize: 14, flex: 1 },
  status: { color: colors.brandPrimary, fontWeight: "900", fontSize: 10 },
  meta: { color: colors.muted, fontSize: 11 },
  body: { color: colors.onSurface, fontSize: 13, lineHeight: 19 },
  timestamp: { color: colors.muted, fontSize: 10 },
  button: { alignSelf: "flex-start", backgroundColor: colors.brandPrimary, paddingHorizontal: spacing.md, paddingVertical: 9, borderRadius: radius.pill },
  buttonText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 11 },
  disabled: { opacity: 0.55 },
  secondary: { paddingHorizontal: spacing.md, paddingVertical: 9, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.border },
  secondaryText: { color: colors.onSurface, fontWeight: "800" },
  feedback: { paddingHorizontal: spacing.lg, paddingBottom: spacing.sm, gap: 5 },
  error: { color: colors.error, fontSize: 11 },
  link: { color: colors.brandPrimary, fontWeight: "800", fontSize: 11 },
  notice: { color: colors.brandPrimary, paddingHorizontal: spacing.lg, paddingBottom: spacing.sm, fontSize: 11, fontWeight: "700" },
}));
