// Customer — combined Grocery and Restaurant order history.
import Feather from "@react-native-vector-icons/feather";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { useCart } from "@/src/store/cart";
import { useCatalogProducts } from "@/src/data/useCatalogProducts";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useT } from "@/src/i18n";
import { amountError, isMeasured } from "@/src/lib/measure";
import { GroceryOnlinePayment } from "@/src/components/GroceryOnlinePayment";

export default function MyOrdersScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  const { user } = useAuth();
  const { addProduct, cartLines, getQty, setAmount } = useCart();
  const { liveProducts, loading: catalogLoading } = useCatalogProducts();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [actionNotice, setActionNotice] = useState("");
  const [busyOrderId, setBusyOrderId] = useState("");

  const fetchOrders = useCallback(() => {
    if (!user) return Promise.resolve();
    return Promise.allSettled([
      api.get<any[]>("/orders/mine"),
      api.get<any[]>("/restaurant/orders/mine"),
    ]).then(([grocery, restaurant]) => {
    const combined: any[] = [];
    if (grocery.status === "fulfilled") combined.push(...grocery.value.map((o) => ({ ...o, kind: "grocery" })));
    if (restaurant.status === "fulfilled") combined.push(...restaurant.value.map((o) => ({ ...o, kind: "restaurant" })));
    combined.sort((a, b) => String(b.created_at || "").localeCompare(String(a.created_at || "")));
    setOrders(combined);
    if (grocery.status === "rejected" && restaurant.status === "rejected") setLoadError("Order history could not be loaded. Check your connection and retry.");
    else if (grocery.status === "rejected" || restaurant.status === "rejected") setLoadError("Some order history is unavailable; the displayed orders are from the API that responded successfully.");
    setLoading(false);
    });
  }, [user]);
  const loadOrders = useCallback(() => {
    setLoading(Boolean(user)); setLoadError("");
    return fetchOrders();
  }, [user, fetchOrders]);
  const [ordersUser, setOrdersUser] = useState(user?.id);
  if (ordersUser !== user?.id) { setOrdersUser(user?.id); setLoading(Boolean(user)); setLoadError(""); }
  useEffect(() => { void fetchOrders(); }, [fetchOrders]);

  const repeatOrder = (order: any) => {
    setActionNotice("");
    if (catalogLoading) { setActionNotice("The live shop catalog is still loading. Try again in a moment."); return; }
    const lines = Array.isArray(order.items) ? order.items : [];
    if (!lines.length) { setActionNotice("This order has no reusable item details."); return; }
    const shopId = String(order.shop_id || "");
    if (!shopId) { setActionNotice("This order is missing its shop reference and cannot be repeated safely."); return; }
    if (cartLines.some((line) => line.product.shopId !== shopId)) {
      setActionNotice("Your cart already contains items from another shop. Complete or clear that cart before repeating this order.");
      return;
    }
    // Old orders can contain repeated rows for the same product/variant. Aggregate
    // them before checking stock so the cart cannot silently truncate a quantity.
    const grouped = new Map<string, { productId: string; variantId?: string; qty: number; name: string; measured: boolean }>();
    const unavailable: string[] = [];
    for (const line of lines) {
      const productId = String(line.product_id || "");
      const variantId = line.variant_id ? String(line.variant_id) : undefined;
      const qty = Number(line.qty);
      const name = String(line.name || "Order item");
      const savedMeasured = line.sell_by === "weight" || line.sell_by === "volume";
      if (!productId || !Number.isInteger(qty) || qty < 1) {
        unavailable.push(`${name}: invalid saved item details`);
        continue;
      }
      const key = JSON.stringify([productId, variantId || null]);
      const current = grouped.get(key);
      const combinedQty = (current?.qty || 0) + qty;
      // Measured lines store grams/ml; their limits are checked against the live product below.
      if (!savedMeasured && combinedQty > 1000) {
        unavailable.push(`${name}: combined quantity exceeds the 1,000-item limit`);
        grouped.delete(key);
        continue;
      }
      grouped.set(key, { productId, variantId, qty: combinedQty, name, measured: savedMeasured });
    }
    const resolved: { product: (typeof liveProducts)[number]; variantId?: string; qty: number; measured?: boolean }[] = [];
    for (const saved of grouped.values()) {
      const product = liveProducts.find((p) => p.id === saved.productId && p.shopId === shopId && p.source === "live");
      if (!product) {
        unavailable.push(`${saved.name}: product is missing or unavailable`);
        continue;
      }
      if (saved.measured || isMeasured(product)) {
        if (!saved.measured) { unavailable.push(t("m.repeatNowMeasured", { name: saved.name })); continue; }
        if (!isMeasured(product) || saved.variantId) { unavailable.push(t("m.repeatNowPack", { name: saved.name })); continue; }
        const total = saved.qty + getQty(product.id);
        const issue = amountError(product, total, t);
        if (issue) { unavailable.push(`${t("m.repeatInvalid", { name: saved.name })} (${issue})`); continue; }
        resolved.push({ product, qty: total, measured: true });
        continue;
      }
      if (product.variants?.length && !saved.variantId) {
        unavailable.push(`${saved.name}: choose a current variant`);
        continue;
      }
      const variant = saved.variantId ? product.variants?.find((v) => v.id === saved.variantId) : undefined;
      if (saved.variantId && (!variant || variant.available === false)) {
        unavailable.push(`${saved.name}: saved variant is no longer available`);
        continue;
      }
      const alreadyInCart = getQty(product.id, variant?.id);
      if (saved.qty + alreadyInCart > 1000) {
        unavailable.push(`${saved.name}: cart quantity would exceed the 1,000-item limit`);
        continue;
      }
      const available = variant ? Number(variant.stock ?? 0) : Number(product.stock ?? 0);
      if (available < saved.qty + alreadyInCart) {
        unavailable.push(`${saved.name}: only ${Math.max(0, available - alreadyInCart)} currently available`);
        continue;
      }
      resolved.push({ product, variantId: variant?.id, qty: saved.qty });
    }
    if (unavailable.length) {
      const details = unavailable.slice(0, 3).join("; ");
      const remaining = unavailable.length > 3 ? `; and ${unavailable.length - 3} more item(s)` : "";
      setActionNotice(`Nothing was added so your cart stays unchanged. Unavailable items: ${details}${remaining}. Review the current shop catalog and try again.`);
      return;
    }
    if (!resolved.length) {
      setActionNotice("This order has no currently available items to repeat.");
      return;
    }
    // Only current catalog product/variant snapshots enter the normal cart.
    // Checkout obtains a fresh backend quote; historical prices are never reused.
    resolved.forEach((line) => {
      // Measured lines set the exact combined grams/ml in one step (already validated above).
      if (line.measured) { setAmount(line.product, line.qty); return; }
      for (let unit = 0; unit < line.qty; unit += 1) addProduct(line.product, line.variantId);
    });
    setActionNotice("Current available items were added to your cart. Checkout will recheck today’s prices and stock.");
    router.push("/(tabs)/cart");
  };

  const cancelOrder = async (order: any) => {
    setBusyOrderId(order.id);
    setActionNotice("");
    try {
      const updated = await api.post<any>(`/orders/${encodeURIComponent(order.id)}/cancel`, {});
      setOrders((current) => current.map((row) => row.id === order.id && row.kind === "grocery" ? { ...row, ...updated, kind: "grocery" } : row));
      setActionNotice("Order cancelled. Reserved stock was restored. No refund was issued or marked as completed.");
    } catch (error: any) {
      setActionNotice(error?.message || "This order could not be cancelled. Refresh your order history.");
    } finally {
      setBusyOrderId("");
    }
  };

  if (!user) {
    return (
      <View style={styles.centered}>
        <Text style={styles.msg}>Sign in to see your past orders.</Text>
        <Pressable style={styles.primary} onPress={() => router.push({ pathname: "/auth", params: { next: "/orders" } })}>
          <Text style={styles.primaryText}>Sign in</Text>
        </Pressable>
      </View>
    );
  }
  if (loading) return <View style={styles.centered}><ActivityIndicator color={colors.brandPrimary} /></View>;

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} style={styles.iconBtn}><Feather name="arrow-left" size={20} color={colors.onSurface} /></Pressable>
        <Text style={styles.title}>Your orders</Text>
        <Pressable onPress={() => void loadOrders()} style={styles.refreshBtn}><Feather name="refresh-cw" size={17} color={colors.brandPrimary} /></Pressable>
      </View>
      <FlatList
        data={orders}
        keyExtractor={(o) => `${o.kind}:${o.id}`}
        contentContainerStyle={{ padding: spacing.lg, gap: spacing.sm }}
        ListHeaderComponent={<>{loadError ? <Text style={styles.msg}>{loadError}</Text> : null}{actionNotice ? <Text accessibilityLiveRegion="polite" style={styles.notice}>{actionNotice}</Text> : null}</>}
        ListEmptyComponent={<Text style={styles.msg}>No orders yet. Start adding items to your cart!</Text>}
        renderItem={({ item }) => {
          const canCancel = item.kind === "grocery" && ["pending", "pending_payment"].includes(item.status);
          return (
            <View style={styles.card}>
              <Pressable onPress={() => router.push(item.kind === "restaurant" ? { pathname: "/restaurant/orders/[id]", params: { id: item.id } } : { pathname: "/order-tracking", params: { id: item.id, kind: "grocery" } })} accessibilityRole="button" accessibilityLabel={`Track order ${item.ref}`}>
                <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                  <Text style={styles.ref}>{item.ref}</Text>
                  <Text style={styles.status}>{String(item.status || "unknown").toUpperCase()}</Text>
                </View>
                <Text style={styles.meta}>{item.items?.length || 0} items · ₹{item.total} · {item.kind === "restaurant" ? "Restaurant · " : "Grocery · "}{item.payment_method === "cod" ? "COD" : item.payment_method}</Text>
                <Text style={styles.addr}>{item.fulfillment === "pickup" ? "Pickup from shop" : item.kind === "restaurant" ? `Delivering to ${item.delivery_address || "saved address"}` : `Delivering to ${item.delivery_address || "saved address"}`}</Text>
                <Text style={[styles.status, { marginTop: spacing.sm }]}>View order and delivery tracking →</Text>
              </Pressable>
              {item.kind === "grocery" && item.refund_summary && item.refund_summary.refund_status !== "not_applicable" ? (
                <Text testID={`order-refund-status-${item.id}`} style={styles.meta}>{t("n.refundLabel")}: {item.refund_summary.message}</Text>
              ) : null}
              {item.kind === "grocery" && item.payment_method === "online_razorpay" ? (
                <GroceryOnlinePayment order={item} onChange={(updated) => setOrders((current) => current.map((row) => row.id === item.id && row.kind === "grocery" ? { ...row, ...updated, kind: "grocery" } : row))} />
              ) : null}
              <Pressable testID={`order-help-${item.id}`} onPress={() => router.push({ pathname: "/chand", params: { openHelp: "1", order_id: item.id, order_kind: item.kind } } as never)} style={{ paddingTop: spacing.sm }}>
                <Text style={[styles.status, { color: colors.brandPrimary }]}>Need help with this order? →</Text>
              </Pressable>
              {item.kind === "grocery" ? <View style={styles.actions}>
                <Pressable testID={`repeat-order-${item.id}`} disabled={catalogLoading} onPress={() => repeatOrder(item)} style={[styles.actionButton, catalogLoading && styles.disabled]}>
                  <Text style={styles.actionText}>Repeat order</Text>
                </Pressable>
                {canCancel ? <Pressable testID={`cancel-order-${item.id}`} disabled={busyOrderId === item.id} onPress={() => void cancelOrder(item)} style={[styles.cancelButton, busyOrderId === item.id && styles.disabled]}>
                  <Text style={styles.cancelText}>{busyOrderId === item.id ? "Cancelling…" : "Cancel order"}</Text>
                </Pressable> : null}
              </View> : null}
            </View>
          );
        }}
      />
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surfaceSecondary },
  centered: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface, padding: spacing.xl, gap: spacing.md },
  header: { flexDirection: "row", gap: spacing.md, paddingHorizontal: spacing.lg, paddingBottom: spacing.sm, backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border, alignItems: "center" },
  iconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  refreshBtn: { marginLeft: "auto", padding: 8 },
  title: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  card: { backgroundColor: colors.surface, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, gap: spacing.sm },
  ref: { fontSize: 14, fontWeight: "800", color: colors.onSurface },
  status: { fontSize: 10, fontWeight: "800", color: colors.brandPrimary, letterSpacing: 0.5 },
  meta: { fontSize: 12, color: colors.onSurfaceSecondary, marginTop: 4 },
  addr: { fontSize: 11, color: colors.muted, marginTop: 2 },
  msg: { fontSize: 14, color: colors.onSurface, textAlign: "center", marginBottom: spacing.sm },
  notice: { fontSize: 12, color: colors.onSurfaceSecondary, backgroundColor: colors.surfaceTertiary, padding: spacing.sm, borderRadius: radius.sm, marginBottom: spacing.sm },
  actions: { flexDirection: "row", gap: spacing.sm, flexWrap: "wrap", marginTop: spacing.xs },
  actionButton: { backgroundColor: colors.brandPrimary, paddingHorizontal: spacing.md, paddingVertical: 9, borderRadius: radius.pill },
  actionText: { color: colors.onBrandPrimary, fontSize: 11, fontWeight: "800" },
  cancelButton: { borderWidth: 1, borderColor: colors.error, paddingHorizontal: spacing.md, paddingVertical: 9, borderRadius: radius.pill },
  cancelText: { color: colors.error, fontSize: 11, fontWeight: "800" },
  disabled: { opacity: 0.5 },
  primary: { backgroundColor: colors.brandPrimary, paddingVertical: 12, paddingHorizontal: spacing.lg, borderRadius: radius.md },
  primaryText: { color: colors.onBrandPrimary, fontWeight: "800" },
}));
