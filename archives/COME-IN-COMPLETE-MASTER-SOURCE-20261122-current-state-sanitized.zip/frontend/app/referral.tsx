import Feather from "@react-native-vector-icons/feather";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { api } from "@/src/lib/api";
import { storage } from "@/src/utils/storage";
import { useAuth } from "@/src/store/auth";
import { makeStyles, spacing, useTheme } from "@/src/theme";

export default function ReferralLandingScreen() {
  const { code } = useLocalSearchParams<{ code?: string }>();
  const router = useRouter(); const insets = useSafeAreaInsets(); const styles = useStyles(); const { colors } = useTheme(); useAuth();
  const [valid, setValid] = useState<boolean | null>(null); const [error, setError] = useState("");
  const normalized = typeof code === "string" ? code.trim().toUpperCase() : "";
  const [previousCode, setPreviousCode] = useState<string | null>(null);
  if (previousCode !== normalized) {
    setPreviousCode(normalized); setValid(normalized ? null : false);
    setError(normalized ? "" : "This referral link does not include a referral code.");
  }
  useEffect(() => { let active = true;
    if (!normalized) return;
    void api.get<{valid:boolean}>(`/referral/validate?code=${encodeURIComponent(normalized)}`, false).then((r) => { if (active) { setValid(r.valid); if (r.valid) void storage.setItem("comein.pendingReferralCode", normalized); else setError("This referral code is invalid or no longer eligible."); } }).catch((e:any) => { if(active){setValid(false);setError(e?.message || "Could not validate this referral link.");} });
    return () => { active = false; };
  }, [normalized]);
  return <ScrollView style={styles.root} contentContainerStyle={{padding:spacing.lg,paddingTop:insets.top+spacing.xl,gap:spacing.md}}>
    <View style={{alignItems:"center",marginTop:spacing.xl}}><Feather name="gift" size={48} color={colors.brandPrimary}/><Text style={styles.title}>Join COME-IN</Text><Text style={styles.sub}>Explore shops, restaurants, products, and services.</Text></View>
    {valid === null ? <ActivityIndicator /> : valid ? <Text style={styles.sub}>Referral code verified. Continue to create a new customer account to attach this referral.</Text> : <Text style={{color:colors.error}}>{error}</Text>}
    <Pressable disabled={!valid} onPress={() => router.push({pathname:"/auth",params:{mode:"signup",ref:typeof code==="string"?code:""}})} style={[styles.button,{opacity:valid?1:0.5}]}><Text style={styles.buttonText}>Create Account</Text></Pressable>
    <Pressable onPress={() => router.push({pathname:"/auth",params:{ref:typeof code==="string"?code:""}})} style={styles.secondary}><Text style={styles.secondaryText}>Already have an account? Sign in</Text></Pressable>
  </ScrollView>;
}
const useStyles = makeStyles((colors) => ({root:{flex:1,backgroundColor:colors.background},title:{fontSize:28,fontWeight:"800",color:colors.onSurface,marginTop:spacing.md},sub:{fontSize:15,color:colors.muted,textAlign:"center",lineHeight:22},button:{backgroundColor:colors.brandPrimary,padding:spacing.md,borderRadius:14,alignItems:"center",marginTop:spacing.md},buttonText:{color:colors.onBrandPrimary,fontWeight:"800"},secondary:{padding:spacing.md,alignItems:"center"},secondaryText:{color:colors.brandPrimary,fontWeight:"700"}} as any));
