import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { api } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { radius, spacing, useTheme } from "@/src/theme";

type QueueItem = { id: string; status: string; phone_verified: boolean; aadhaar_verified: boolean; pan_verified: boolean; documents_status: string; created_at: string; updated_at: string };
type Detail = QueueItem & { full_name: string; mobile: string; residential_address: string; alternate_contact: string };

export default function AdminDeliveryPartnersScreen() {
  const insets = useSafeAreaInsets(); const { colors } = useTheme(); const { user } = useAuth();
  const [items, setItems] = useState<QueueItem[]>([]); const [selected, setSelected] = useState<Detail | null>(null); const [reason, setReason] = useState(""); const [busy, setBusy] = useState(true); const [notice, setNotice] = useState("");
  const load = useCallback(() => {
    if (user?.role !== "admin") return Promise.resolve();
    return api.get<QueueItem[]>("/delivery-partner/admin/applications").then(setItems)
      .catch((e: any) => setNotice(e?.message || "Could not load applications."))
      .finally(() => setBusy(false));
  }, [user]);
  useEffect(() => { load(); }, [load]);
  const open = async (id: string) => { setNotice(""); try { setSelected(await api.get<Detail>(`/delivery-partner/admin/applications/${id}`)); setReason(""); } catch (e: any) { setNotice(e?.message || "Could not open application."); } };
  const decide = async (decision: "approve" | "reject" | "correction" | "suspend" | "reactivate") => { if (!selected || reason.trim().length < 3) { setNotice("Enter an administrative reason of at least 3 characters."); return; } setBusy(true); try { await api.patch(`/delivery-partner/admin/applications/${selected.id}`, { decision, reason: reason.trim() }); setSelected(null); setReason(""); setNotice(`Application ${decision} action recorded.`); await load(); } catch (e: any) { setNotice(e?.message || "Action failed."); } finally { setBusy(false); } };
  if (user?.role !== "admin") return <View style={[styles.root, { paddingTop: insets.top + 24 }]}><Text style={styles.title}>Admin access required</Text></View>;
  return <ScrollView style={[styles.root, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingTop: insets.top + spacing.md, paddingBottom: 48 }}><Text style={[styles.title, { color: colors.onSurface }]}>Delivery Partner Applications</Text><Text style={[styles.note, { color: colors.muted }]}>Restricted admin review. Identity details are only revealed on this authorized detail screen and each view is audited.</Text>
    {busy && <ActivityIndicator color={colors.brandPrimary} />}{items.map((item) => <Pressable key={item.id} onPress={() => open(item.id)} style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.onSurface }]}>{item.id.slice(-8)} · {item.status}</Text><Text style={[styles.note, { color: colors.muted }]}>Mobile {item.phone_verified ? "verified" : "pending"} · Aadhaar {item.aadhaar_verified ? "verified" : "pending"} · PAN {item.pan_verified ? "verified" : "pending"}</Text><Text style={[styles.note, { color: colors.muted }]}>Documents: {item.documents_status}</Text></Pressable>)}
    {selected ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.onSurface }]}>Application details</Text><Text style={[styles.note, { color: colors.onSurface }]}>Name: {selected.full_name}{"\n"}Mobile: {selected.mobile}{"\n"}Address: {selected.residential_address}{"\n"}Alternate contact: {selected.alternate_contact}{"\n"}Status: {selected.status}</Text><TextInput value={reason} onChangeText={setReason} placeholder="Required decision / correction reason" multiline style={[styles.input, { color: colors.onSurface, borderColor: colors.border }]} />
      {selected.status === "PENDING_ADMIN_APPROVAL" ? <><Action label="Approve" onPress={() => decide("approve")} /><Action label="Reject" onPress={() => decide("reject")} /><Action label="Request correction" onPress={() => decide("correction")} /></> : null}{selected.status === "APPROVED" ? <Action label="Suspend" onPress={() => decide("suspend")} /> : null}{selected.status === "SUSPENDED" ? <Action label="Reactivate" onPress={() => decide("reactivate")} /> : null}<Action label="Close details" onPress={() => setSelected(null)} /></View> : null}
    {notice ? <Text accessibilityRole="alert" style={styles.notice}>{notice}</Text> : null}
  </ScrollView>;
}
function Action({ label, onPress }: { label: string; onPress: () => void }) { const { colors } = useTheme(); return <Pressable onPress={onPress} style={[styles.action, { borderColor: colors.border }]}><Text style={{ color: colors.brandPrimary, fontWeight: "700" }}>{label}</Text></Pressable>; }
const styles = StyleSheet.create({ root: { flex: 1, paddingHorizontal: 18 }, title: { fontSize: 22, fontWeight: "800", marginBottom: 8 }, note: { fontSize: 13, lineHeight: 19, marginTop: 5 }, card: { borderWidth: 1, borderRadius: radius.lg, padding: 14, marginTop: 12 }, cardTitle: { fontWeight: "800", fontSize: 15 }, input: { borderWidth: 1, borderRadius: radius.md, padding: 12, minHeight: 70, marginTop: 12 }, action: { borderWidth: 1, borderRadius: radius.md, padding: 12, alignItems: "center", marginTop: 8 }, notice: { marginTop: 12, color: "#A15C00" } });
