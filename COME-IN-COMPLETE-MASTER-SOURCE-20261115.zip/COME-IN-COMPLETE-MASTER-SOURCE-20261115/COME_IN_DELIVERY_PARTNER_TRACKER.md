# COME-IN Delivery Partner Onboarding — Addendum Tracker

| Area | Status | Evidence / remaining gate |
|---|---|---|
| Separate applicant route and Account entry | PASS | `frontend/app/delivery-partner.tsx`; account entry added |
| Separate admin review screen | PARTIAL | `frontend/app/admin-delivery-partners.tsx`; live API runtime not tested |
| Seller workflow isolation | PASS | Seller registration and dashboard files unchanged against baseline |
| Draft validation and consent | PASS | Backend contract tests |
| Encryption-at-rest boundary | PARTIAL | Fernet encryption code; managed key not provisioned; runtime persistence not tested |
| OTP | BLOCKED | Authorized SMS provider adapter/credentials unavailable; endpoints fail closed |
| Aadhaar verification | BLOCKED | Authorized provider not selected/integrated; no Aadhaar data collected |
| PAN verification | BLOCKED | Authorized provider not selected/integrated; no PAN data collected |
| Secure document upload/storage | BLOCKED | Secure document storage adapter not integrated; upload disabled |
| Admin approval and audit | PARTIAL | Role-protected state machine and audit writes; runtime DB verification not run |
| Referral sharing/attribution | PARTIAL | Approval-gated code and attribution record; live sharing/abuse testing not run |
| Backend focused contract tests | PASS | 34 passed, 0 failed |
| Backend runtime / MongoDB | NOT RUN | Motor/PyMongo and isolated DB unavailable |
| Frontend typecheck / Expo / device | NOT RUN | Dependencies and native platforms unavailable |
| Production readiness | BLOCKED | Provider, storage, DB, TLS and device verification gates remain |
