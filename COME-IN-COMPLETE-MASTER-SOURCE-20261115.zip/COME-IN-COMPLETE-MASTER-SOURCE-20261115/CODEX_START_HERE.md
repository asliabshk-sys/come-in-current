# CODEX — START HERE (COME-IN)

**This is the existing COME-IN application. It is NOT a new project. Do not rebuild it, re-scaffold it, or re-run `create-expo-app`.**

The project root is the folder that contains this file: `COME-IN-MASTER-PROJECT/`.
Every path below is relative to that root.

## Reading order (mandatory)
1. `CODEX_START_HERE.md` (this file)
2. `CODEX_HANDOFF.md` — full architecture, feature status, MongoDB handoff, test evidence, next task
3. `PROJECT_MANIFEST.json` — machine-readable paths, entry points, manifests, file count, git revision
4. `MASTER_TASK_TRACKER.md` — task status and the exact next tasks
5. Verify the real files against those documents, then continue from the **last verified checkpoint** (2026-11-14, see `CODEX_HANDOFF.md` §D).

## 1–5. Where things are
| What | Exact path |
|---|---|
| Frontend root (Expo SDK 58.0.17, React Native 0.88.0, Expo Router 58.0.25, TypeScript 6.0.3) | `frontend/` |
| Frontend entry point | `frontend/package.json` → `"main": "expo-router/entry"`; root layout `frontend/app/_layout.tsx`; tabs `frontend/app/(tabs)/` |
| Frontend API client | `frontend/src/lib/api.ts` (reads `EXPO_PUBLIC_BACKEND_URL`) |
| Backend root (FastAPI 0.110.1 + Motor 3.7.1, Python 3.11) | `backend/` |
| Backend entry point | `backend/server.py` → `app` (all 177 `/api` routes, startup index creation at `_startup()`) |
| Backend helper modules | `backend/financial_rules.py`, `referral_rules.py`, `refund_rules.py`, `restaurant_pricing.py`, `restaurant_serviceability.py`, `security_config.py`, `catalogue_import_engine.py`, `catalogue_chand_adapter.py`, `backend/integrations/` |
| MongoDB connection config | `backend/.env` (create from `backend/.env.example`) → `MONGO_URL`, `DB_NAME`; read in `backend/server.py` via `load_dotenv` |
| MongoDB tooling / infra | `scripts/mongo/setup.sh`, `scripts/mongo/start-replset.sh`, `scripts/mongo/comein_mongo.py`, `infra/mongodb/` (docker-compose, mongod conf, rs-init.js), docs in `docs/mongodb/` |
| Backend tests | `backend/tests/` (config `backend/pytest.ini`) |
| Frontend test | `frontend/scripts/test-chand-party-planner.cjs` (no Jest suite exists) |

## 6. Setup commands (verified 2026-11-14 in an isolated environment)
```bash
cd COME-IN-MASTER-PROJECT
cp backend/.env.example backend/.env          # fill JWT_SECRET, Fernet keys etc. (never commit)
cp frontend/.env.example frontend/.env        # EXPO_PUBLIC_BACKEND_URL=http://localhost:8001
# MongoDB 7.0.x single-node replica set on 127.0.0.1:27018 (transactions REQUIRED):
MONGO_RS_DBPATH=/tmp/mongo-rs0-data LAUNCHER=nohup bash scripts/mongo/setup.sh
# Backend deps (emergentintegrations comes from a private index; see RESTORE_AND_SETUP.md):
pip install -r backend/requirements.txt
# Frontend deps (Yarn Classic 1.22.22):
chmod +x frontend/scripts/*.js frontend/scripts/*.sh
cd frontend && yarn install --frozen-lockfile
```

## 7. Frontend startup
```bash
cd frontend && yarn web          # expo start --web
# or: yarn start                 # expo start --port ${PORT:-8081}
# or: bash scripts/preview.sh    # from project root, web preview on PORT (default 3000)
```

## 8. Backend startup
```bash
cd backend && python -m uvicorn server:app --host 0.0.0.0 --port 8001 --reload
curl http://localhost:8001/api/     # {"service":"come-in","status":"ok",...}
```

## 9. Backend test commands
```bash
cd backend
# Offline/contract suite (no server needed):
python -m pytest -q --ignore=tests/test_preview_runtime_e2e.py --ignore=tests/test_batch_5task_runtime.py \
  --ignore=tests/test_task5_live_mongo_transactions.py --ignore=tests/test_iter_notifications_admin_measured.py \
  --ignore=tests/backend_test.py
# Live suite (running backend + DISPOSABLE replica-set DB only):
source tests/preview_test_env.sh && export EXPO_PUBLIC_BACKEND_URL=http://127.0.0.1:8001
python tests/seed_preview_test_accounts.py   # needs ADMIN_EMAIL/ADMIN_PASSWORD in backend/.env = COMEIN_TEST_ADMIN_*
python -m pytest -n 0 tests/test_preview_runtime_e2e.py tests/test_batch_5task_runtime.py \
  tests/test_task5_live_mongo_transactions.py tests/test_iter_notifications_admin_measured.py
```

## 10. Frontend validation commands
```bash
cd frontend
yarn typecheck        # tsc --noEmit        -> currently FAILS (29 pre-existing errors, see KNOWN_ISSUES.md)
yarn lint             # expo lint           -> currently FAILS (54 errors / 40 warnings, pre-existing)
yarn build:web        # expo export web     -> PASS
node scripts/test-chand-party-planner.cjs   # -> PASS (11 assertions)
```

## 11. Required environment variables
Backend (`backend/.env.example` is the full list): **required** `MONGO_URL`, `DB_NAME`, `JWT_SECRET`, `CORS_ORIGINS`, `FINANCIAL_TIMEZONE`; **feature-required** `BANK_DATA_ENCRYPTION_KEY`, `DELIVERY_PARTNER_DATA_ENCRYPTION_KEY` (distinct Fernet keys); optional `ADMIN_EMAIL`/`ADMIN_PASSWORD`, `EMERGENT_LLM_KEY`/`INTEGRATION_PROXY_URL` (uploads), `RAZORPAY_*` + `GROCERY_ONLINE_PAYMENTS_ENABLED`, `SMTP_*`, `COMEIN_AI_*` (Chand), `DELIVERY_*_PROVIDER_*`.
Frontend: `EXPO_PUBLIC_BACKEND_URL` (required).

## 12–14. Feature status (evidence summary — details in CODEX_HANDOFF.md §B)
- **Implemented:** Customer app, Product catalogue, Cart & Checkout (COD / pay-at-shop / pickup), Orders & tracking, Seller Dashboard, Admin Panel, Restaurant Mode, MongoDB transactions, Fixed-Pack & Measured Grocery, Referral & Earn, Earnings dashboards, in-app Notifications.
- **Partial:** Chand AI (catalog-only mode works; generative/STT/vision need provider), Universal Catalogue Import (staging + review only; apply does not write products), Delivery Partner onboarding (draft + admin review; OTP/Aadhaar/PAN/doc storage blocked), Payments (Razorpay code gated, no TEST keys), Notifications (push not configured).
- **Pending/Blocked:** Production build & launch (Task 19, owner-blocked), native Android/iOS builds, push delivery, SMTP reset email, provider integrations.

## 15–16. Tests (2026-11-14, isolated MongoDB 7.0.45 replica set `rs0`, DB `comein_preview_test`)
- **PASS:** offline contract suite 408 passed / 3 failed / 4 skipped (415 total); live runtime suite **70/70 PASS** (incl. 9/9 live MongoDB transaction scenarios); Delivery Partner live API check 8/8 expected results; MongoDB health (commit visible + abort rolled back) PASS; backup→restore verification PASS; `yarn build:web` PASS; Chand party-planner 11 assertions PASS.
- **FAIL (pre-existing, not fixed):** 3 offline tests, `yarn typecheck`, `yarn lint`, legacy `tests/backend_test.py` (17 pass / 2 fail / 3 error / 1 skip — outdated contract).
- **Blocked / untested:** native Android/iOS, push, Razorpay TEST, SMTP, Chand AI provider, OTP/Aadhaar/PAN providers, visual UI E2E in a browser this session.

## 17. NEVER run these against production
- Any live test: `tests/test_preview_runtime_e2e.py`, `tests/test_batch_5task_runtime.py`, `tests/test_task5_live_mongo_transactions.py`, `tests/test_iter_notifications_admin_measured.py`, `tests/backend_test.py` (they create TEST_ users/shops/orders).
- `backend/tests/seed_preview_test_accounts.py` (creates/promotes accounts).
- `python3 scripts/mongo/comein_mongo.py testdb-cycle|testdb-drop|init` and `bash scripts/mongo/setup.sh`.
- `scripts/restore-db.sh` with `TARGET_DB=<live>` / `CONFIRM_LIVE_RESTORE=yes` (drops target collections).
- `scripts/mongo/export_sanitized_preview_backup.py` (creates and drops scratch DBs).
- `scripts/delivery-partner-live-api-check.sh`.
- `database-backup/*.archive.gz` restore into any production database (it is preview test data).

## Rules for continuing
Do not rebuild. Do not repeat completed tasks. Do not overwrite working modules. Do not change UI, theme, navigation or Restaurant Mode without explicit owner authorization. Preserve MongoDB transaction code and Chand AI integration. Use isolated test databases. Never expose or commit secrets.
