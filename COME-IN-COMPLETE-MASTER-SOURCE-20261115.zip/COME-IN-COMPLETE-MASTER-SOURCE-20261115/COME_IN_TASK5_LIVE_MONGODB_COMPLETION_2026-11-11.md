# COME-IN — Task 5 Live MongoDB + Preview Verification (2026-11-11)

**Final Task 5 status: COMPLETED in the Emergent preview environment** (local single-node replica set; COD only). One low-severity behaviour finding recorded (F-1).

## Environment
- MongoDB 7.0.45 replica set `rs0` on 127.0.0.1:27018, DB `test_database` (preview only, synthetic data).
- Backend FastAPI (supervisor, :8001) + Expo 58.0.17 web preview (:3000) on the Emergent preview URL.
- Suite: `backend/tests/test_task5_live_mongo_transactions.py` (run `-n 0`); creates `test_t5_*` users / `TEST T5 Shop <run>` and deletes them at teardown. JUnit: `project-reports/mongodb-portability-20261111/task5-live-junit.xml`.

## Seven MongoDB scenarios — all PASS (run twice, 9/9 each)

| ID | Scenario | Result | Evidence (DB readback via PyMongo) |
|---|---|---|---|
| T5-MONGO-01 | Transaction behaviour | PASS | quote `consumed`, 1 order, stock 5000→4250 g committed together; same idempotency key returns same order, stock unchanged; consumed quote + new key → 409 |
| T5-MONGO-02 | Measured stock deduction | PASS | 3000 g → 250 → 1000 → 1750 g orders: 2750 / 1750 / 0; stored qty per line exact |
| T5-MONGO-03 | Insufficient-stock rejection | PASS | 500 g vs 400 g stock → 409 `insufficient_stock`, `available_stock` 400; stock + order count unchanged |
| T5-MONGO-04 | Concurrent order protection | PASS | 4 customers, barrier-synchronised orders for the last 500 g: exactly 1 × 200, stock 0, 1 order, never negative |
| T5-MONGO-05 | Failed order creation rollback | PASS | server-side insert failure injected (temporary `orders` validator) after quote claim + stock decrement inside the transaction → 503; stock 2000 g restored, quote back to `open`, no order; same quote then succeeds |
| T5-MONGO-06 | Measured precision + pricing | PASS | ₹123.45/kg × 1250 g = ₹154.31 (ROUND_HALF_UP), label `1.25 kg`, fee ₹29, total ₹183.31 stored; 260 g off-step → 422 `measured_quantity_invalid` |
| T5-MONGO-07 | Fixed-Pack compatibility | PASS | mixed cart 500 g @₹80/kg + 3 × ₹55 pack: measured `line_total` 40, pack priced qty×price, subtotal 205, free delivery; stocks 4500 g / 7 packs; over-stock pack → 409 |

## Other remaining Task 5 checks
| Check | Result | Evidence |
|---|---|---|
| Measured Repeat Order E2E (API) | PASS | past 1500 g order re-quoted after seller price change 100→110/kg: qty preserved, fresh price, ₹165 subtotal, stock revalidated (third repeat → 409) |
| Transaction-backed CSV measured import | PASS | valid apply creates measured product (sell_by weight, unit kg, 20000 g, min 250); invalid row → nothing written; duplicate SKU rows → nothing written; injected failure on 2nd row → 503, **no partial import**, history unchanged |
| Expo Customer Preview (testing agent, 390×844) | PASS | presets 250/500/1000 with server price (500 g ₹20.00, 1 kg ₹40.00); invalid 260/100/6000 → error + save disabled; cart separates measured (750 g ₹30.00) and pack (2 × ₹95) lines, persists on reload; COD checkout subtotal ₹220, free delivery, order persisted (qty 750, line_total 30); Repeat Order repopulates 750 g |
| Expo Seller Preview | PASS | seller adds measured product (by weight, ₹/kg, min/max/step/presets) → in seller list + customer search; CSV template download + import preview (errors + valid row) |
| Full backend regression (serial) | 415 PASS / 0 FAIL / 23 skipped + 9 live PASS | after fixing environment-bound test data (below) |

## Defects / changes this session
| ID | Finding | Action |
|---|---|---|
| BUG-14 | Measured picker: non-numeric / empty custom amount kept the previous amount and left "Add" enabled | Fixed `frontend/src/components/MeasuredQuantityPicker.tsx` (non-numeric → error + save disabled; empty → back to preset). Verified by screenshot. |
| BUG-15 | Seller measured hint said price field is "above" (it is below) | Fixed in 9 languages, `frontend/src/i18n/translations.ts` |
| BUG-16 | Seller product form inputs had no testIDs | Added `prod-name/brand/unit/price/mrp/stock/description` in `frontend/app/seller/products.tsx` |
| BUG-17 | `test_iter_notifications_admin_measured.py` used a hard-coded product id from the old environment (4 failures in a new DB) | Fixture now finds/creates "TEST Loose Sugar" — portable |
| F-1 (open, low) | Under concurrent checkout the losing requests get MongoDB `WriteConflict` (TransientTransactionError) → HTTP 503 "temporarily unavailable" instead of 409 "out of stock". Safe (no oversell, no partial write) but the message is misleading. | Not changed (core checkout). Recommended: retry the transaction on `TransientTransactionError` (2–3 attempts) so losers receive 409 `insufficient_stock`. |
| Note | "Add Your Shop" still shown to sellers who own a shop | Left as-is: the sheet also offers other business modes (restaurant / services). |

Not verified: native Android/iOS device runtime, Razorpay online payment (keys not configured), push delivery.
