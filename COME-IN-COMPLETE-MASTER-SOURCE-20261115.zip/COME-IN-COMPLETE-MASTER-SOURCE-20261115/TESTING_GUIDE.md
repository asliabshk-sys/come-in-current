# COME-IN — Testing Guide

**Never run live tests against production.** Live tests create `TEST_`/`test_t5_*` users, shops, products and orders.

## Backend
`backend/pytest.ini` enforces `-n 2 --dist loadscope` (pytest-xdist required). Use `-n 0` for serial runs.

### Offline / contract (no server, no DB)
```bash
cd backend
python -m pytest -q --ignore=tests/test_preview_runtime_e2e.py --ignore=tests/test_batch_5task_runtime.py \
  --ignore=tests/test_task5_live_mongo_transactions.py --ignore=tests/test_iter_notifications_admin_measured.py \
  --ignore=tests/backend_test.py
```
2026-11-14: 408 passed, 3 failed (KI-1, KI-2, KI-3), 4 skipped.

### Live (running backend + disposable replica set)
```bash
cd backend
source tests/preview_test_env.sh                    # disposable preview accounts (not secrets)
export EXPO_PUBLIC_BACKEND_URL=http://127.0.0.1:8001
# backend/.env must have ADMIN_EMAIL/ADMIN_PASSWORD equal to COMEIN_TEST_ADMIN_EMAIL/PASSWORD
python tests/seed_preview_test_accounts.py
python -m pytest -n 0 tests/test_preview_runtime_e2e.py tests/test_batch_5task_runtime.py \
  tests/test_task5_live_mongo_transactions.py tests/test_iter_notifications_admin_measured.py
COMEIN_TEST_BASE_URL=http://127.0.0.1:8001 python -m pytest -n 0 tests/backend_test.py   # legacy, KI-7
COMEIN_API_BASE=http://127.0.0.1:8001/api bash ../scripts/delivery-partner-live-api-check.sh
```
2026-11-14: 70/70 PASS; legacy 17 pass / 2 fail / 3 error / 1 skip; delivery-partner check 8/8 expected.

### MongoDB
```bash
python3 scripts/mongo/comein_mongo.py health          # ping, replica set, tx commit/abort, index drift
python3 scripts/mongo/comein_mongo.py testdb-cycle    # creates + drops comein_disposable_test_* DB
```

## Frontend
```bash
cd frontend
yarn typecheck      # FAIL today: 29 errors (KI-5)
yarn lint           # FAIL today: 54 errors (KI-6)
yarn build:web      # PASS
node scripts/test-chand-party-planner.cjs   # PASS, 11 assertions
```
There is no Jest/Detox suite. Browser/device E2E must be done in Expo web preview or devices.

## Evidence
JUnit XML and logs: `reports/testing/`. Summary table: `CODEX_HANDOFF.md` §E. Historical: `project-reports/`, `COME_IN_TEST_REPORT.md`, `COME_IN_QA_REPORT.md`.
