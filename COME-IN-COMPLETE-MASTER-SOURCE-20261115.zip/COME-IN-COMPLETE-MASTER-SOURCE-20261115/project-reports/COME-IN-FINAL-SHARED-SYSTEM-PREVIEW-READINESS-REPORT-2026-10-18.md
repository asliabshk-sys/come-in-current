# COME-IN — Final Shared System Fix + Preview Readiness (Follow-up v2)

Date: 2026-10-18
Working copy: `/mnt/data/come-in-final-shared-preview-20261018/`
Baseline preserved: `/mnt/data/come-in-candidate-audit-20261018/come-in-phase2-work/`
Previous versioned ZIPs preserved; no browser/device Preview launched.

## New implementation in this follow-up

- `frontend/app/restaurant/checkout.tsx`: removed the editable free-text delivery address from Restaurant checkout. Delivery now must use an account-owned saved address selected from the shared `/addresses` API. The serviceability pincode is read only from that selected saved-address record. Removed the unsupported `delivery_address` fallback from the Restaurant order payload so an unvalidated typed string cannot bypass the shared address-book flow. If no saved address is selected, checkout routes to `/addresses`.
- `backend/tests/test_functional_blockers_regression.py`: added a regression contract to prevent reintroducing manual unvalidated delivery address entry or an unverified `delivery_address` payload in Restaurant checkout.
- `memory/COME-IN-MASTER-ROADMAP.md`: appended evidence for Task 7; the existing 22-task structure remains unchanged.

## Feature status

- **Account/Auth — PARTIAL:** one root AuthProvider, shared auth token/session implementation, and Restaurant Account compatibility redirect to Shopping Account. Runtime session continuity/logout/expiry remains UNVERIFIED.
- **Addresses — PARTIAL:** Shopping and Restaurant use the shared account-owned `/addresses` API. Restaurant checkout auto-selects default/first saved address and no longer accepts a free-text address as a delivery bypass. Runtime serviceability and saved-address selection remain UNVERIFIED.
- **Cart/Checkout — PARTIAL:** grocery and Restaurant carts remain deliberately separate. Restaurant order creation retains its restaurant-specific pricing, menu identity, fulfilment, and idempotency contract; shared auth and saved-address infrastructure are reused. It is not the same checkout screen or same order-creation endpoint as Grocery.
- **Payments — PARTIAL/BLOCKED for online checkout:** Shopping checkout supports COD. Restaurant checkout submits COD for delivery or pay-at-pickup for pickup, subject to backend method validation. Razorpay server-side intent/verification/webhook guards exist, but customer-facing Razorpay checkout and sandbox verification are not complete.
- **Order history/support — PARTIAL:** shared order-history UI combines Grocery and Restaurant orders; CHAND support carries order kind/ID and backend validates order ownership before linking. Live database integration and customer-facing refund execution are UNVERIFIED/not available.
- **Notifications — BLOCKED for delivery:** no device-token registration/refresh API or configured push provider; fail-closed provider behavior retained.
- **GPS/live tracking — BLOCKED for live rider tracking:** one-shot location request has denial/timeout handling; no configured live delivery provider/rider stream.

## Actual verification

- Backend tests, run from `backend/`:
  `PYTHONPATH=. python -m pytest -c /dev/null -q tests`
  **113 passed, 23 skipped, 0 failed**.
- Python syntax check:
  `python -m py_compile backend/server.py backend/restaurant_pricing.py backend/restaurant_serviceability.py backend/integrations/order_notifications.py backend/integrations/delivery_provider.py`
  **PASS (exit 0)**.
- ZIP integrity test on the generated versioned archive: **PASS**.
- Frontend TypeScript: **BLOCKED**; `node_modules` and Expo base config unavailable, registry request failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- Lint: **BLOCKED**, `expo: not found` (exit 127).
- Web build: **BLOCKED**, `expo: not found` (exit 127).
- Browser/device E2E, live DB ownership integration, Razorpay sandbox, push delivery, device GPS permissions and rider tracking: **UNVERIFIED/BLOCKED**. No real payment, external notification, production deploy or Preview launch was performed.

## Preview readiness decision

**NOT VERIFIED READY TO LAUNCH.** Source-level work and backend tests pass, but frontend install/typecheck/lint/web export are blocked by unavailable dependencies and registry DNS. The current pinned dependency manifest was not upgraded and no lockfile was fabricated. Restore registry access, install through the declared Yarn/Corepack path, then run TypeScript, lint and web build before Preview.

## Existing roadmap

The existing `memory/COME-IN-MASTER-ROADMAP.md` remains the only master roadmap with 22 main tasks. Only evidence-backed status notes for existing Tasks 7, 10, 11, 13, 17, 18 and 20 are maintained; no new main task was created.
