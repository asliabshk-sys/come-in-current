# COME-IN APP — MASTER PROJECT PROMPT

## Project Memory • 22 Main Tasks • Restaurant Mode • Safety • Next Steps

इस प्रॉम्प्ट को पढ़कर Come-In प्रोजेक्ट का संदर्भ समझें। यह चल रहे प्रोजेक्ट की जानकारी और आवश्यकताएँ हैं, नया ऐप शुरू करने का निर्देश नहीं। इसे भविष्य की बातचीत में संदर्भ के रूप में इस्तेमाल करें।

---

## 1. COME-IN क्या है?

Come-In एक स्थानीय शॉपिंग और सेवाओं वाला ऐप है, जिसका उद्देश्य एक ही ऐप में ये चीज़ें उपलब्ध कराना है:

- Online Shops

- Offline Local Shops

- Grocery और Daily Essentials

- Restaurants और Food Ordering

- Home Services

- भविष्य में स्थानीय कारोबार और ग्राहक सुविधा से जुड़े अन्य फीचर

**Restaurants Come-In का मुख्य बिज़नेस हिस्सा है**, कोई छोटा या वैकल्पिक ऐड-ऑन नहीं। हमारा अंतर यह है कि ग्राहक किराना, स्थानीय दुकानें, रेस्टोरेंट और Home Services एक ही ऐप में पा सके।

## 2. काम करने के अनिवार्य नियम

1. इसे मौजूदा प्रोजेक्ट मानें। बिना जाँच के यह न मानें कि ऐप पूरा है या खराब है।

2. किसी नए फीचर पर काम शुरू करने से पहले उपलब्ध प्रोजेक्ट, frontend, backend, API, database, navigation, authentication, cart और मौजूदा स्क्रीन का audit करें।

3. पहले से काम कर रहे फीचर, डेटा और डिज़ाइन को सुरक्षित रखें।

4. मौजूदा स्क्रीन/API/component को सुरक्षित रूप से इस्तेमाल किया जा सकता हो तो डुप्लिकेट न बनाएँ।

5. डेटा मिटाने, database reset/migration, बड़े बदलाव या production deployment से पहले जोखिम समझाएँ और मेरी स्पष्ट अनुमति लें।

6. किसी paid service, API, subscription या hosting cost को मेरी अनुमति के बिना सक्रिय न करें।

7. जो काम वास्तव में नहीं किया, उसे completed, tested या working न बताएं।

8. स्थिति स्पष्ट रूप से बताएँ: Planned / Implemented / Tested / Verified Working / Blocked / Pending।

9. GitHub, ZIP, hosting, Emergent, Replit, API या database का access न हो तो साफ़ बताएँ कि क्या चाहिए।

10. मुझे आसान हिंदी/Hinglish में एक-एक करके निर्देश दें। मैं तकनीकी विशेषज्ञ नहीं हूँ; ज़रूरत हो तो मैं स्क्रीनशॉट भेजूँगा।

11. एक बार में छोटे, नियंत्रित और जाँचने योग्य बदलाव करें। बिना ज़रूरत पूरा ऐप rewrite न करें।

12. पहले मौजूदा काम और backup की स्थिति समझें; उसके बाद ही बदलाव करें।

13. टेस्ट और परिणाम का प्रमाण दें। केवल कोड देखकर runtime success का दावा न करें।

14. कोई नया feature मुख्य roadmap में जोड़ने से पहले मुझसे पूछें।

15. मेरे मुख्य roadmap में **22 काम** हैं। इन्हें अपने-आप 23 या अधिक मुख्य काम न बनाएँ। नीचे बताए गए नए फीचर मौजूदा कामों के subtask हैं।

## 3. Come-In के 22 मुख्य काम

### Phase 1 — Audit

**Task 1: Existing Project Audit**

- वर्तमान ऐप, स्क्रीन, navigation, frontend/backend, API, database और authentication की जाँच।

- कौन-से बटन और workflows वास्तव में काम करते हैं, जाँचें।

- Grocery, online/offline shops, restaurants और Home Services के मौजूदा फीचर पहचानें।

- duplicate routes/components, errors और अधूरे काम नोट करें।

- पहले read-only audit करें; बिना अनुमति fixes न करें।

### Phase 2 — Design और Customer Experience

**Task 2: Theme and Design**

- साफ़, consistent, mobile-friendly डिज़ाइन।

- मुख्य shopping theme: Yellow + Forest Green + Pale Mint।

- rounded cards, readable text, subtle shadows और consistent spacing।

**Task 3: Home Screen and Navigation**

- Home screen, category entry points और bottom navigation।

- Online Shops, Offline Shops, Restaurants और Home Services तक स्पष्ट पहुँच।

- सेक्शन बदलने और वापस आने का आसान रास्ता।

### Phase 3 — Product Catalog और Shopping

**Task 4: Categories and Catalog**

- Grocery, daily essentials, local shops और restaurant/food categories व menu/catalog।

- मौजूदा data model audit करें।

**Task 5: Quantity, Variants and Units**

- product size, weight, quantity, variants और unit selection।

- जहाँ लागू हो, price per unit स्पष्ट करें।

**Task 6: Search and Filters**

- products, shops, restaurants और food items की खोज।

- relevant filters, जैसे category, veg/non-veg, cuisine और availability जहाँ डेटा उपलब्ध हो।

- price comparison के नियम Task 21 से जुड़ें।

### Phase 4 — Cart और Orders

**Task 7: Cart and Checkout**

- सुरक्षित cart, price/stock revalidation और checkout।

- Restaurant cart और grocery/shop cart अलग रहें; गलती से mix न हों।

- checkout, delivery fee और order summary स्पष्ट हों।

**Task 8: Repeat Order**

- पहले के order से items दोबारा चुनना; current price और stock फिर जाँचना।

**Task 9: Out-of-Stock Replacement**

- item unavailable होने पर replacement या removal का विकल्प।

- अनुमति के बिना अनचाहा replacement न करें।

### Phase 5 — Delivery और Customer Support

**Task 10: Live Tracking**

- वास्तविक data/integration होने पर order status/tracking।

- live tracking का दावा तभी करें जब सच में काम करे।

- शुरुआत में restaurant अपनी delivery संभाल सकता है, यदि arrangement स्पष्ट हो।

**Task 11: Order Help and Refund Status**

- order issue, cancellation/help और refund status।

- Shop Call Assistance subtask: shop का phone connect न हो तो ग्राहक Come-In agent/representative से दुकान पर जाकर बात करवाने का अनुरोध कर सके। Operational व्यवस्था पहले तय करनी होगी।

### Phase 6 — Seller Tools और Data

**Task 12: Excel/CSV Price and Stock Import**

- shops के लिए products, price और stock upload/update।

- importer schema audit करें।

- stable product ID से update करें; duplicates न बनाएँ।

- invalid prices, missing names, invalid stock और wrong columns पर errors दिखाएँ।

- पहले test/staging में जाँचें; production data पर बिना अनुमति परीक्षण न करें।

### Phase 7 — Accounts और Operations

**Task 13: Login and Account**

- सुरक्षित login/account, profile और order history।

- mode बदलने पर login/account न खोएँ।

**Task 14: Seller/Shop/Restaurant Panel**

- shop panel में products, prices, availability और orders।

- restaurant partners के लिए menu, item prices, availability और food orders।

- मौजूदा सुविधा को reuse करें।

**Task 15: Admin Panel**

- admin controls, shop/restaurant management, catalog, orders और announcements।

- role permissions जाँचें।

### Phase 8 — Backend, Security और Payments

**Task 16: Backend, Database and Security**

- authentication, authorization, validation, secrets, API access और database rules audit।

- sensitive keys frontend/public repository में न हों।

- user/order data और permissions सुरक्षित हों।

- backup/restore strategy जाँचें; बिना test के backup को recoverable न बताएं।

**Task 17: Payments and Notifications**

- payment status, order status, settlement और refunds।

- provider terms के अनुसार gateway fees समझें।

- push/in-app notifications और backend integration।

- paid integrations या production activation से पहले अनुमति लें।

### Phase 9 — Testing और Launch

**Task 18: Testing and Bug Fixes**

- customer, seller, restaurant, admin और order workflows test करें।

- UI, navigation, API, database और errors जाँचें।

- fix के बाद retest करें।

- read-only audit के दौरान बिना अनुमति implementation न करें।

**Task 19: Production Build and Launch**

- production readiness, configuration, secrets, backup, monitoring और deployment checklist।

- deployment, paid resources या irreversible actions से पहले मेरी स्पष्ट अनुमति।

- recurring costs पहले बताएँ।

### Phase 10 — Advanced Features

**Task 20: Smart Notification System**

- push और in-app notification center।

- order status, offers/promotions, price changes, restocks और app announcements।

- admin announcement approval/targeting और sensible frequency।

- app बंद होने पर push के लिए provider setup, user permission और backend integration जरूरी।

- test के बिना working न बताएं।

**Task 21: Smart Price Comparison**

- एक ही product की अलग-अलग shops में तुलना।

- सही match: brand, pack size, weight, unit और variant।

- उपलब्ध matching offers में सबसे कम verified price पहले highlight करें; अन्य offers भी दिखाएँ।

- stock, distance/delivery और last-updated time तभी दिखाएँ जब वास्तविक data उपलब्ध हो।

- checkout पर price और stock फिर verify करें।

- local shops के Excel/CSV data का उपयोग।

- third-party retailer live API/feed के लिए अनुमति और वास्तविक access जरूरी है; केवल registration से access न मानें।

- external data sources की licensing/access जाँचें; reference data को actual local shop price न कहें।

**Task 22: Home Services Logo/Icon and Tile Integration**

- Home screen पर Home Services tile/icon को मुख्य theme से match करें।

- पहले जाँचें कि existing Home Services flow/destination है या नहीं।

- working flow हो तो reuse करें; duplicate न बनाएँ।

- flow न हो तो gap बताकर implementation से पहले अनुमति लें।

---

## 4. Approved Subtask: Restaurant Mode और Automatic Branding/Theme Switch

यह अलग 23वाँ main task नहीं है। इसे Tasks 2, 3, 4, 6, 7, 10, 14, 17 और 18 के अंतर्गत tracked subtask रखें।

### Restaurant Mode

Come-In के अंदर proper food-ordering experience हो—restaurant listings, menu, food cart, checkout, food orders और जहाँ supported हो delivery status। यह सिर्फ restaurant list नहीं होना चाहिए।

### Automatic theme switching

**Shopping Mode:** Yellow + Forest Green + Pale Mint — grocery, local shops, daily essentials और Home Services।

**Restaurant Mode:** Creamy Red + White + Cream — restaurant listings, food/menu pages, food cart, checkout और food orders। Header, buttons, icons और relevant interface भी restaurant theme से match करें।

जब user Restaurants पर tap करे:

1. Restaurant Mode खुले।

2. theme अपने आप Creamy Red + White + Cream में बदले।

3. Come-In logo/brand की पहचान और मूल shape consistent रहे, लेकिन matching restaurant-mode color variant दिखे।

4. restaurant experience के लिए स्पष्ट navigation हो।

जब user Restaurant Mode में **Come-In Home** दबाए:

1. सामान्य Come-In Shopping Home खुले।

2. theme/logo variant वापस Yellow + Forest Green + Pale Mint हो।

3. user को केवल back button पर निर्भर न रहना पड़े।

### Cart, login और history

- grocery/shop cart और restaurant food cart अलग रहें।

- mode switch से login, account या order history न खोए।

- cart persistence और mode state architecture audit करें।

- navigation और restart के relevant scenarios test करें।

### Branding safety

- एक Come-In brand identity रखें; unrelated second brand न बनाएँ।

- logo का रंग variant बदले, brand identity बनी रहे।

- theme switching का अर्थ native app icon अपने आप बदलना नहीं है; header logo, splash screen और app icon अलग-अलग assets/behavior हो सकते हैं।

- इन सभी को अलग-अलग verify करें।

- यह planned requirement है; implementation/test के बिना complete न कहें।

### Restaurant details

- nearby restaurants, photos/ratings/open hours केवल verified data होने पर।

- menu, prices, veg/non-veg और cuisine filters।

- food cart, checkout, order status।

- restaurant partner panel।

- delivery arrangements और responsibility स्पष्ट करें।

---

## 5. Home Screen, Categories और Splash Screen

मुख्य shopping Home:

- bright yellow header

- forest-green text/icons

- pale mint background

- rounded pastel-green cards

- subtle yellow borders and soft shadows

- Online Shops, Offline Shops, Restaurants और Home Services tiles

- search, promo area और category browsing

- Home, Categories, Search, Cart, Account navigation मौजूदा architecture के अनुसार

Planned grocery categories:

1. Atta, Rice & Dal

2. Dairy & Breakfast

3. Fruits & Vegetables

4. Snacks & Munchies

5. Personal Care

6. Household Essentials

7. Beverages

8. Bakery

9. Frozen Foods

10. Pet Care

11. Baby Care

12. Stationery & Books

13. Electronics & Gadgets

14. Home Decor

15. Tools & Hardware

Planned splash:

- cold start/restart पर Come-In logo/name और tagline।

- मुख्य branding yellow/forest-green; restaurant launch/mode के behavior को existing architecture देखकर तय करें।

- लगभग 2 seconds केवल अगर उचित हो; duplicate flash या blank screen न बने।

- login, cart और order history सुरक्षित रहें।

- background resume पर अनावश्यक splash न हो।

- implementation/testing अभी verify करना बाकी है।

Suggested copy:

- Come-In

- “Shop Local • Support Local”

- “Local Shops • Home Services & More”

Final use मौजूदा approved design और screen space के अनुसार तय करें।

---

## 6. Backup, GitHub और Project Continuity

- मौजूदा project और backup files की पहचान करें।

- GitHub repo/branch/commit status तभी बताएं जब verify किया हो।

- ZIP backup और repository backup अलग हैं।

- दूसरे Emergent/Replit/account में ले जाने से पहले project files, environment variables, secrets, database, assets और integrations की dependencies सूचीबद्ध करें।

- secrets को ZIP, public GitHub या prompt में न डालें।

- restore test के बिना backup को fully recoverable न कहें।

- credits खत्म हों तो नए बदलाव रोककर सुरक्षित स्थिति, किए गए काम और अगला कदम लिखें।

- development credits, hosting, APIs, payment fees और deployment costs अलग हो सकते हैं।

---

## 7. Ideas Not Approved for Main Roadmap

इनको अपने-आप मुख्य roadmap में न जोड़ें; पहले founder की अनुमति लें:

- multi-shop combined order और अलग delivery fees/times

- direct shop contact/call/WhatsApp

- “Find this for me” photo/text request

- elder-friendly UI और voice search

- cross-shop loyalty/rewards

- scheduled delivery/pickup

- shop business dashboard

- city/local market hub

- Verified Local Shop badge

Shop Call Assistance Task 11 का planned subtask है; operations validate करना बाकी है।

---

## 8. Business Model और Rough Monthly Cost Context

संभावित earning options—पहले economics और feasibility जाँचें:

- optional shop subscriptions

- clearly labelled sponsored promotions

- delivery fee/partnership

- Home Services commission

पहले एक locality में reliable service, repeat orders और fulfilment पर ध्यान दें।

पहले चर्चा में 500 active users, 1,000 orders/month, और shops/restaurants द्वारा अपनी delivery संभालने की assumption पर rough estimate:

- technical running costs: ₹2,000–₹7,000/month

- अगर ₹300 average order × 1,000 orders = ₹3,00,000 gateway से process हों और illustrative 2% fee लगे, तो ₹6,000 fee + 18% GST ₹1,080 = ₹7,080; उस assumption पर rough total ₹9,000–₹15,000/month।

- safe planning estimate के रूप में ₹15,000/month कहा गया था।

ये पुराने rough estimates हैं, guaranteed cost या provider quote नहीं। Actual hosting, OTP/SMS, API usage, GST, payment method/contract, delivery और traffic से cost बदलेगी। जरूरत हो तो current provider pricing verify करें। Shop/restaurant की own delivery होने पर भी operational agreement और responsibility स्पष्ट होनी चाहिए।

---

## 9. Test Catalog Files

पहले synthetic demo files बनाए गए थे:

- ComeIn_Test_Catalog_2000_Items.xlsx

- ComeIn_Test_Catalog_2000_Items.csv

- ComeIn_Price_Comparison_Test_15_Offers.csv

- ComeIn_Test_Catalog_README.txt

इनमें demo/synthetic data है, वास्तविक retailer prices नहीं। अगली बातचीत में files तभी उपलब्ध मानें जब वे attach हों या accessible Library में मिलें। पुराने download paths verify किए बिना न बनाएँ।

Importer/price comparison tests:

1. successful import और row count

2. stable product_id पर update, duplicates नहीं

3. stock/status update और out-of-stock behavior

4. same product के multi-shop offers में cheapest available offer पहले

5. duplicate IDs, blank names, negative prices, invalid stock और wrong columns validation

6. last-updated time, अगर supported हो

Test चलाए बिना test result का दावा न करें।

---

## 10. अगली बार काम कैसे शुरू करना है?

जब founder Come-In पर काम फिर शुरू करे:

1. current project location और available access पहचानें।

2. files/ZIP/repository उपलब्ध हों तो Task 1 का read-only audit करें।

3. screens, buttons, online/offline shops, restaurants, Home Services, carts, account, backend/API/database और current errors जाँचें।

4. concise report दें: verified working, broken, missing, duplicate और uncertain।

5. approval के बिना code changes न करें।

6. audit के बाद priority-based plan दें और approval लें।

7. छोटे changes करें, relevant tests चलाएँ, results और limitations बताएं।

8. credits/cost risks और external dependencies पहले समझाएँ।

9. missing context पर अनुमान न लगाएँ; जरूरत हो तो एक सीधा सवाल पूछें।

---

## 11. Special Trigger Phrase

जब मैं यह exact phrase लिखूँ:

**“टन टना टन टन टन तारा”**

तो इस prompt और उपलब्ध saved conversation context के आधार पर:

- सभी 22 main tasks की पूरी सूची दिखाएँ।

- हर task के approved subtasks और related requirements भी दिखाएँ।

- Restaurant Mode का automatic logo/theme switching, separate carts, Come-In Home button और unified brand identity शामिल करें।

- Home Services, Smart Notifications, Smart Price Comparison, security, backups और अन्य saved project requirements शामिल करें।

- status केवल evidence के आधार पर बताएं; अज्ञात status को unknown/pending कहें।

- implementation, test, backup या document update का दावा verify किए बिना न करें।

यह phrase roadmap/context सामने लाने का trigger है, automatic code modification या deployment की अनुमति नहीं।

---

## 12. Final Working Principle

**पहले समझो और audit करो → फिर plan बताओ → मेरी approval लो → छोटे बदलाव करो → test करो → परिणाम बताओ → backup और continuity सुरक्षित रखो।**

Come-In की existing functionality और data की सुरक्षा, स्पष्ट communication और verified results सबसे महत्वपूर्ण हैं।

## Evidence-backed candidate-source audit — 18 October 2026

This note records checks against the candidate archive `COME-IN-FINAL-PREVIEW-READINESS-2026-10-18.zip` extracted to `/mnt/data/come-in-candidate-audit-20261018/come-in-phase2-work/`. It does **not** assert that this is the latest Emergent/Codex working copy. The main roadmap remains 22 tasks; no new main task was added.

- **Task 13 — Login and Account: PARTIAL.** Candidate source wraps the app in one `AuthProvider` (`frontend/app/_layout.tsx`), and Restaurant screens call the same `useAuth()`; runtime cross-mode session continuity was not browser/device tested.
- **Task 7 — Cart and Checkout: PARTIAL.** Candidate has distinct shopping and restaurant cart storage keys (`frontend/src/store/cart.tsx`, `frontend/src/restaurant/cart.ts`) and explicit checkout routes. This matches the existing roadmap's requirement to prevent grocery/food cart mixing; it is not evidence of a single shared cart data store. Backend contract tests pass, but end-to-end checkout was not run.
- **Task 10 — Live Tracking: BLOCKED for live rider tracking.** `backend/integrations/delivery_provider.py` deliberately returns unavailable without a configured provider; restaurant order UI explicitly says live delivery-partner location is not connected. Contract tests cover fail-closed behavior, not live GPS delivery.
- **Task 17 / Task 20 — Payments and Notifications: PARTIAL/BLOCKED.** Candidate grocery checkout supports COD and rejects unavailable online methods (`backend/server.py`, `frontend/app/checkout.tsx`). Restaurant checkout exposes COD/pay-at-pickup; Razorpay server endpoints exist, but the customer-facing Razorpay checkout is not integrated (`frontend/app/restaurant/checkout.tsx`). `backend/integrations/order_notifications.py` is a fail-closed unconfigured provider, and no notification/push-token API route exists in `backend/server.py`. Provider delivery is not verified.
- **Task 11 — Order Help and Refund Status: PARTIAL.** Restaurant support endpoints exist (`backend/server.py`, `/restaurant/support` and `/restaurant/support/mine`); `frontend/app/chand.tsx` documents that linked order validation is restaurant-only and no customer-facing refund request API exists.
- **Task 18 — Testing and Bug Fixes: PARTIAL.** Backend suite result for this candidate after the navigation fixes: recorded in the accompanying candidate audit report. Frontend typecheck/build could not be considered verified because frontend dependencies are not installed in this working copy.
- **Navigation defect fixed in candidate copy:** the Shopping Account rows for Notifications, Payment Methods and Help & Support previously had no `onPress` handlers. They now navigate to `/notifications`, `/payment-methods`, and the existing `/chand` support screen. The new Notifications and Payment Methods screens state the candidate's actual capability limits; they do not fake provider delivery, saved payment methods, or payment success.

No credentials were added, no payment/notification was initiated, no preview was launched, and no production deployment occurred.


### 2026-10-18 — Functional Blockers Phase evidence update

Candidate working-copy follow-up is documented in `COME-IN-FUNCTIONAL-BLOCKERS-REPORT-2026-10-18.md`. Main roadmap remains **22 tasks**; no new main task added.
- **Task 7 / 13 — PARTIAL:** shared auth/address infrastructure exists; separate shopping and restaurant cart persistence is intentional and retained. Cross-mode continuity still needs runtime verification.
- **Task 10 — BLOCKED for live tracking:** one-time user-triggered GPS path is present, but device permissions were not tested; no configured delivery provider/live rider updates.
- **Task 11 — PARTIAL:** CHAND can list grocery and restaurant orders, but the existing support API only validates restaurant order linkage; grocery linkage and customer-facing refund request remain incomplete.
- **Task 17 / 20 — PARTIAL/BLOCKED:** shopping COD and restaurant COD/pay-at-pickup paths exist; Razorpay server architecture exists but customer checkout is not integrated and sandbox was not run. Notification provider protocol is fail-closed; token endpoint/provider delivery absent.
- **Task 18 — PARTIAL/BLOCKED:** backend tests 94 passed / 23 skipped and Python syntax passed. Frontend typecheck/lint/build blocked because dependencies are absent and npm registry lookup failed with `EAI_AGAIN`; no false frontend PASS claimed.
- No preview or production deployment, real payment, or external notification was initiated.

### 2026-10-18 — Network-independent functional blocker regression pass
- **22-task structure preserved.** No new main roadmap task added; this note records only verified source contracts and tests.
- **Task 7 — PARTIAL, stronger regression coverage:** added `backend/tests/test_functional_blockers_regression.py` covering Grocery quote/idempotency/COD-only fail-closed contract, Restaurant payment-method/fulfillment rules, duplicate Restaurant order retry and unique-index declaration, Razorpay intent/verification/webhook/retry guards, and separate Shopping/Restaurant cart persistence. Backend suite now reports **104 passed, 23 skipped, 0 failed**. This is source-contract/unit evidence, not live DB/payment end-to-end proof.
- **Task 11 — PARTIAL/BLOCKED for Grocery ticket linkage:** regression test confirms `/restaurant/support` validates that linked orders belong to the authenticated customer. No generic/Grocery support order-link route exists in this candidate; no unsupported route was invented.
- **Task 13 — PARTIAL, stronger regression coverage:** tests verify one root `AuthProvider`, shared auth token key, and owner-scoped address list/update/delete contract. Cross-mode browser/device session remains UNVERIFIED.
- **Task 10 — PARTIAL/BLOCKED for live rider tracking:** tests verify one-shot GPS permission-denied/timeout messaging, no `watchPosition` background tracking, and fail-closed provider-unavailable state. Device permission, rider assignment, provider location stream remain UNVERIFIED/BLOCKED.
- **Task 17 / Task 20 — PARTIAL/BLOCKED:** regression tests protect payment method constraints, Razorpay captured-state/currency/order checks, duplicate webhook and cancelled-order reconciliation guards. Notification provider remains fail-closed; no push-token registration/refresh or notification event API exists. No credentials or live external calls added.
- **Task 18 — PARTIAL:** `PYTHONPATH=. python -m pytest -c /dev/null -q tests` => **104 passed, 23 skipped, 0 failed**. Python `py_compile` passed. Frontend checks remain BLOCKED: Node v22.16.0 and npm 10.9.2 are available, Yarn 1.22.22 is specified by `packageManager` but executable is absent, no frontend lockfile/node_modules were found, npm cache contained no useful cached packages, and `npm ping --fetch-retries=0 --fetch-timeout=8000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`. No speculative lockfile generated or dependency versions changed.
- No Replit/browser/device preview, real payment, external notification, or production deployment was run.

### 2026-10-18 — Restaurant Account shared-route fix
- **Task 13 — PARTIAL (source-level route fix; runtime verification pending).** `frontend/app/restaurant/account.tsx` is now a compatibility redirect to `/(tabs)/account`, eliminating the separate Restaurant Account/login UI and reusing the single Shopping Account screen. Existing Restaurant navigation and order-confirmation links remain valid and flow through this alias.
- The app still has one root `AuthProvider` in `frontend/app/_layout.tsx`; both Shopping Account and Restaurant consumers use the shared auth/token implementation (`frontend/src/store/auth.tsx`, `frontend/src/lib/api.ts`, `TOKEN_KEY`). Both address screens call the same `/addresses` API. Shopping and Restaurant carts remain separate by design.
- Added static regression contracts for shared Account routing, auth token set/clear, saved-address API reuse, and existing Restaurant links. These do not substitute for browser/device verification; frontend dependencies remain unavailable, so runtime navigation and session-expiry UX are **UNVERIFIED**.
- No new main task added; roadmap remains 22 tasks.


### 2026-10-18 — Shared systems / pre-preview implementation pass (evidence-backed)
- **Task 7 — PARTIAL:** added a shared account-owned address book at `frontend/app/addresses.tsx`; `/restaurant/addresses` is now a compatibility redirect. Shopping Account opens the shared saved-address route. Restaurant checkout selects the default/first saved address, requires a saved address for delivery, and routes missing/invalid saved address cases to the shared address book. Shopping and Restaurant carts remain separate by design. Restaurant order creation remains on its own backend contract because its item pricing, restaurant identity, fulfilment and idempotency are domain-specific; this is shared infrastructure, not a merged grocery cart. Runtime checkout remains UNVERIFIED.
- **Task 11 — PARTIAL:** `/restaurant/support` now redirects into shared CHAND Help & Support with optional order context. The existing authenticated support API accepts explicit `order_kind` (`grocery` or `restaurant`) and verifies the order belongs to the authenticated customer before storing its ID/reference in the ticket. Backend support collection/status workflow is reused. Customer-triggered refund execution remains unavailable; admin refund flow was not called.
- **Task 13 — PARTIAL (source-level):** Restaurant Account and saved-address routes are compatibility redirects to the shared Shopping Account/address book. Root AuthProvider and token store are unchanged and shared. Browser/device login, logout and expiry continuity remain UNVERIFIED.
- **Task 17 — PARTIAL/BLOCKED:** Payment Methods screen now routes users to supported Shopping COD or Restaurant COD/pay-at-pickup checkout instead of implying saved payment methods. Customer-facing Razorpay checkout remains absent; no online payment was initiated.
- **Task 10 / Task 20 — BLOCKED for live integrations:** no provider/token-registration/refresh route exists for push notifications and no configured delivery provider exists for live rider updates. These were not fabricated; provider/device testing remains blocked.
- **Task 18 — PARTIAL:** backend test suite `PYTHONPATH=. python -m pytest -c /dev/null -q tests` passed **112 passed, 23 skipped, 0 failed**; backend `py_compile` passed. Frontend TypeScript exited 2 due missing Expo base config/dependencies; lint and web build exited 127 (`expo: not found`). npm cache listed no useful packages and `npm ping --fetch-retries=0 --fetch-timeout=8000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`. No lockfile was created and pinned package versions were not changed. No browser/device preview was launched.

### 2026-10-18 — Shared Restaurant delivery-address guard (follow-up)
- **Task 7 — PARTIAL:** Restaurant checkout no longer offers free-text address entry as a delivery bypass. Delivery uses the shared account-owned `/addresses` record, and serviceability pincode is sourced only from the selected saved-address record. The unsupported `delivery_address` fallback was removed from the Restaurant order payload; missing selection routes to the shared address book.
- Added a regression contract in `backend/tests/test_functional_blockers_regression.py`; full backend suite: **113 passed, 23 skipped, 0 failed**. This is source/backend test evidence, not browser/device E2E. Frontend TypeScript/lint/build remain blocked by missing Expo dependencies and registry DNS (`EAI_AGAIN`).
- No new main roadmap task added; roadmap remains 22 tasks. No Preview, production deploy, real payment, or external notification was run.
