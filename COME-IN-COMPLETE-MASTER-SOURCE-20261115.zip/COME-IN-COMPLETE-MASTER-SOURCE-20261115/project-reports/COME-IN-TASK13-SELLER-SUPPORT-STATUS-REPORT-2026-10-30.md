# COME-IN Task 13 — Seller Support Status Update

## Audit findings
- Task 12 implemented authenticated seller read-only support listing at `GET /seller/support`, scoped through the seller's owned shop/restaurant orders.
- No seller status mutation route or seller ticket status-update UI was present.
- Existing statuses are `open`, `in_progress`, `resolved`, and `closed`; the admin route can update all four.
- Seller status changes must not be allowed to close tickets or run refunds/cancellations.

## Implementation
- Added `PATCH /seller/support/{ticket_id}` to `backend/server.py`.
- Requires the existing `shopkeeper` or `restaurant` role.
- Resolves the ticket's linked Grocery or Restaurant order and verifies the linked shop/restaurant `owner_id` against the authenticated seller.
- Seller transition policy is intentionally limited to `open -> in_progress -> resolved`; `closed` remains an admin-level status.
- Requires `expected_status` and uses a conditional update on the stored current status. Invalid, stale, or concurrent transitions return a conflict instead of overwriting another update.
- Appends actor identity/role and timestamp to support history. Does not touch payment/refund/cancellation/order status.
- No seller UI was added: no seller support-ticket screen exists in the current frontend. The endpoint is the minimum safe backend capability; UI integration remains pending.

## Changed files
- `backend/server.py`
- `backend/tests/test_task13_seller_support_status_contract.py`
- `project-reports/COME-IN-TASK13-SELLER-SUPPORT-STATUS-REPORT-2026-10-30.md`

## Tests
- `python -m py_compile backend/server.py` — PASS.
- `PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests/test_task13_seller_support_status_contract.py backend/tests/test_task12_customer_support_contract.py backend/tests/test_task10_payment_refund_notification_contract.py` — 18 passed.
- These are source-contract/regression tests; no live database/API integration was exercised.

## Verification limitations and blockers
- Live MongoDB: NOT VERIFIED.
- Backend server / authenticated API calls: NOT VERIFIED.
- Preview: NOT VERIFIED.
- Android and iPhone: NOT VERIFIED.
- Seller-facing UI controls: NOT IMPLEMENTED; endpoint is available for future UI wiring.
- Notifications: no confirmed delivery provider; no delivery claim is made.
- Payment/refund integration blockers from Task 10 remain; seller support status does not trigger refund/cancellation.

## Backup
- Pre-change ZIP: `COME-IN-TASK13-PRE-CHANGE-20261030T070033Z.zip`.
- Pre-change SHA-256: `6e8fa763150ceafff0d7231172ff227234ae2031bd0f5b18537a24c7df67b96c`.
- Post-change ZIP and SHA-256 are recorded in the final execution report.
