# COME-IN — Final Preview Readiness Report

Date: 2026-10-18
Source archive: `/mnt/data/COME-IN-FINAL-CONSOLIDATED-MASTER.zip`
Source archive SHA-256: `74e759eccd4c0b7ff238b0b5de75165f462c179728369c0244f51d6925be2857`

## Scope and preservation

- Worked in a separate copy of the existing project. The original master ZIP, previous project copies, and rollback backups were not overwritten or deleted.
- No new app was created; the existing Expo Router frontend, FastAPI backend, Shopping Mode, Restaurant Mode, and CHAND route were retained.
- No Replit, Emergent, browser preview, production deployment, paid service, database migration, real payment, or real notification was started.
- No real secrets were added. No package manager was switched and no lockfile was fabricated.

## Changes made

1. Added `scripts/preview.sh` as a single-command, frontend-only preview launcher. It checks Node and the project root, installs dependencies only if Expo is missing (using the declared Yarn/Corepack manager), stops with actionable diagnostics on failure, and starts the existing Expo Web app on `PORT` (default 3000).
2. Added the `preview` script to `frontend/package.json` without changing the existing `main`, `start`, or other app scripts.
3. Updated `README.md` with the portable preview command, routes, frontend-only/demo limitations, and a warning not to assume Emergent supports undocumented auto-start settings.
4. Preserved the existing `.replit` configuration and Replit startup script. No visual redesign or Restaurant Mode UI changes were made in this preview-preparation pass.

## Verification results

| Check | Status | Evidence / limitation |
|---|---|---|
| Original master ZIP SHA-256 | PASS | Matched the expected source hash above. |
| Original master ZIP integrity | PASS | Python `zipfile.testzip()` returned `None`; 153 entries. |
| Package JSON parse and Expo Router entry | PASS | `frontend/package.json` parses; `main` remains `expo-router/entry`. |
| App configuration referenced assets | PASS | icon, favicon, and splash-image paths exist. |
| Route source presence | PASS (static only) | `/` → `frontend/app/index.tsx`; `/restaurant` → `frontend/app/restaurant/index.tsx`; `/chand` → `frontend/app/chand.tsx`. This does not prove browser rendering. |
| Startup shell syntax | PASS | `bash -n scripts/preview.sh scripts/replit-install.sh scripts/replit-run.sh`. |
| Command guard | PASS | `node frontend/scripts/cmd-guard.js --preinstall` exited 0. |
| Backend Python syntax | PASS | `py_compile` passed for `server.py`, `restaurant_pricing.py`, and `restaurant_serviceability.py`. |
| Backend local tests | PASS | `93 passed, 23 skipped in 1.06s`. |
| Remote integration tests | BLOCKED / SKIPPED | 23 tests require `COMEIN_TEST_BASE_URL` pointing to an isolated disposable test deployment; no remote endpoint was contacted. |
| Frontend dependency resolution | BLOCKED | `frontend/node_modules` is absent; no lockfile exists; Yarn is absent and npm cache is empty. No install was attempted because this environment previously reported registry DNS failure and automatic retries are avoided. |
| TypeScript check | BLOCKED | TypeScript dependencies are not installed; `tsc --noEmit` could not be truthfully reported as run. |
| Expo web export/build | BLOCKED | Expo dependencies are not installed; no build was run. |
| App process startup / HTTP route availability | NOT TESTED | Preview execution is deliberately deferred; no local server or browser was started. |
| Browser console/runtime / screenshot checks | NOT TESTED | No browser automation session was started. |
| Emergent-specific auto-start behavior | BLOCKED / UNVERIFIED | No authenticated Emergent workspace access or verified platform-specific startup schema was available. The portable command is provided without inventing a platform feature. |
| Real backend, checkout/payment, GPS/live tracking, CHAND live AI | NOT VERIFIED | These require actual configured services/credentials. Preview script does not fake or enable them. CHAND UI explicitly contains Demo Mode guidance. |

## Remaining blockers

- Install frontend dependencies in the target Emergent workspace where the configured package registry is reachable. The project declares Yarn 1.22.22 but ships no Yarn/npm lockfile; a lockfile should be generated only after a successful, intentional dependency resolution in that environment.
- Run TypeScript checks and Expo web build after install.
- Start the preview in Emergent and verify the actual rendered `/`, `/restaurant`, and `/chand` routes, browser console, assets, and network failures.
- Configure a browser-reachable backend URL and backend/database secrets only if API-backed features are to be tested. Never use sample secrets from `.env.example` as real credentials.

## How to open the preview in Emergent

1. Import `COME-IN-FINAL-PREVIEW-READINESS-2026-10-18.zip` and open the extracted project root (the directory containing `frontend/`, `backend/`, and `scripts/`).
2. Run one command in the workspace terminal:

   ```bash
   bash ./scripts/preview.sh
   ```

3. Open the workspace Preview for port `3000` (or the port printed/configured via `PORT`).
4. Check `/`, `/restaurant`, and `/chand` in the browser. A successful static route listing is not a substitute for this real browser check.

## Conclusion

The project is **launch-prepared, not confirmed launched**. The portable startup script and documentation are in place, and local backend/static checks passed. Because frontend dependencies could not be installed in this environment and no browser preview was started, it would be inaccurate to claim that the app currently renders successfully in Emergent.
