# COME IN — Complete Master Project (Preview Setup)

Archive date: 2026-10-18

## What this is

This is a consolidated copy of the latest available working project, based on `COME-IN-MASTER-BUSINESS-FEATURES-2026-10-18.zip`. It preserves the source tree, frontend, FastAPI backend, existing routes and components, test files, scripts, preview design assets, and prior implementation/readiness reports. Previous ZIP archives were not overwritten or deleted.

This package is **prepared for Replit setup, not certified as already Preview-ready**. Expo dependencies are not vendored. Frontend typecheck/build and a live Replit Preview were not verified in this environment. Some APIs require configured MongoDB and external credentials.

## Replit setup

1. Upload/extract this ZIP into a new Replit project; the project root is the directory containing `.replit`, `frontend/`, `backend/`, and `scripts/`.
2. Install dependencies in Replit Shell with `bash ./scripts/replit-install.sh` (requires Node.js, Corepack/Yarn registry access, Python and package-index access).
3. Add Replit Secrets as appropriate:
   - `MONGO_URL` — real MongoDB connection string
   - `DB_NAME` — database name
   - `JWT_SECRET` — unique, random secret (at least 32 characters; never use the placeholder)
   - `EXPO_PUBLIC_BACKEND_URL` — externally reachable backend URL used by browser API calls; set according to the deployment/network layout
   - `CORS_ORIGINS` — explicit browser origin(s) for the deployed frontend
   - Add payment/storage/provider credentials only if the corresponding integrations are intended and configured.
4. Run the configured Replit command (`bash ./scripts/replit-run.sh`) or press Run. `.replit` maps Expo Web port 3000 to external 80 and backend port 8000 to external 8000.
5. If MongoDB/JWT configuration is missing, the current script intentionally starts only the frontend and logs that backend/API functionality is unavailable. A visible UI in this mode is not proof that backend workflows work.

## Local checks

Backend tests:

```bash
PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests
```

Frontend checks after dependency installation:

```bash
cd frontend
yarn typecheck
yarn build:web
```

## Verified in packaging pass

- ZIP archive integrity checked.
- Python backend regression tests: 145 passed, 23 skipped, 0 failed.
- Node.js 22.16.0 and Corepack are present in the packaging environment.

## Not verified in packaging pass

- Frontend dependencies were not installed (`frontend/node_modules` absent); typecheck, web export/build and Expo startup were not run.
- Replit Preview and external port accessibility were not run.
- Live MongoDB persistence, registration-to-approval-to-public-listing workflows, image storage, concurrent booking against a live database, and payment gateway flows were not end-to-end tested.
- The 23 skipped backend tests require `COMEIN_TEST_BASE_URL` for remote integration testing.

See the included `COME-IN-MASTER-BUSINESS-FEATURES-IMPLEMENTATION-REPORT-2026-10-18.md`, `COME-IN-MASTER-BUSINESS-FEATURES-TEST-REPORT-2026-10-18.md`, and existing readiness/blocker reports for known gaps. Features described only as planned or unverified should not be treated as complete.

## Security and data

No `.env` secrets, real credentials, `node_modules`, build output, or Python bytecode caches are packaged. Keep real secrets in Replit Secrets, not in this archive. This ZIP contains project code and reference catalog assets, not a copy of any live MongoDB user/business data.

## Real services work — Phase 1 (2026-10-19)

CHAND now supports an optional native Ollama local-model adapter as well as the existing OpenAI-compatible provider. See `docs/COME-IN-REAL-SERVICES-PHASE-1-REPORT-2026-10-19.md` and `docs/COME-IN-CHAND-SETUP-2026-10-19.md`. This is source-level integration only: Ollama was not installed or live-tested in this workspace. Payment gateway, GPS device, SMS/OTP and live database services remain subject to separate configuration and tests. No APK was built and Replit was not launched.
