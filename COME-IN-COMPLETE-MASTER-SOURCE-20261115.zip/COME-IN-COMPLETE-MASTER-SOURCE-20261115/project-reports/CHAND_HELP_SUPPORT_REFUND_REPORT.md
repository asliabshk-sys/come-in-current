# CHAND by COME-IN — Help & Support / Refund Assistance Implementation Report

Date: 2026-10-17

## Implemented in the existing project
- Added a Help & Support panel inside `frontend/app/chand.tsx`; the existing CHAND screen, COME-IN routes, Shopping theme and Restaurant theme remain in place.
- Signed-in customers can request their own grocery/shop orders (`GET /orders/mine`), restaurant orders (`GET /restaurant/orders/mine`), and existing support tickets (`GET /restaurant/support/mine`) through the existing authenticated API client.
- Shows order, payment and refund statuses only when returned by the backend. If no refund status is present, the UI says it was not reported.
- Adds order, payment, refund-help, restaurant and other complaint categories; the customer must review and explicitly confirm before submission.
- Submits through existing `POST /restaurant/support` and displays the returned reference and status. Refreshes tickets through `GET /restaurant/support/mine`.
- The backend validates authenticated customer identity and ownership for a linked restaurant order. CHAND sends `order_id` only for a selected restaurant order. Grocery order references may be included in the message, but cannot be linked structurally using the current support endpoint.
- CHAND never calls the admin refund endpoint. Existing actual refund execution remains admin-only and separate from a customer support request.
- No passwords, OTPs, card numbers, CVVs or payment credentials are requested.

## Existing backend capability assessment
- Existing support routes: `POST /restaurant/support`, `GET /restaurant/support/mine`, and admin-only list/status routes.
- Existing actual refund route: `POST /admin/restaurant/orders/{order_id}/refund`, protected by admin role. It checks verified paid status, linked payment, existing pending/completed refund state and gateway configuration.
- No customer-facing refund-request API was found. Therefore CHAND provides **Refund Help / support-case submission**, not refund eligibility decisions, refund approval, or real refund processing.
- Restaurant order records may return `refund_status`; grocery orders do not expose a dedicated refund status in the inspected code.
- The support endpoint has no confirmed idempotency mechanism. The UI disables concurrent submission while a request is in flight, but that is not a server-side duplicate-prevention guarantee.
- The current support API is restaurant-namespaced. Its optional linked order ID is validated only against restaurant orders; a grocery-wide support linkage is not present. This limitation remains unchanged; grocery order references are included in support message text only.
- Role chips in CHAND are preview modes, not authorization. Backend permissions remain authoritative.

## Remaining-work update (2026-10-17; preview intentionally deferred)
- Updated only the existing `demoReply()` in `frontend/app/chand.tsx`: added deterministic safe guidance for payment deducted/no order, duplicate payment, missing item, delayed order, wrong/damaged item, cancellation and refund-status questions. Unknown requests now explicitly direct users to existing screens/support and state that unavailable facts will not be invented. No AI/API call was added.
- Added a contract test in `backend/tests/test_chand_demo_contract.py` to assert these support-topic disclosures and safety warnings. This is a source-contract test, not a browser interaction test.
- No new roadmap was created; this remains a subtask of master roadmap Task 11 (Order Help and Refund Status), with related Task 16/18 security/testing implications.
- Preview, Codespaces, Replit, paid/credit-based environments, and browser launch were not attempted, per the current instruction.

## Verification results
- Backend tests: **69 passed, 23 skipped, 0 failed**.
  Command: `cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q -rs tests`
  The 23 skipped tests require `COMEIN_TEST_BASE_URL` pointed at an isolated disposable test deployment.
- Python syntax: **PASS** — `python -m py_compile backend/server.py backend/restaurant_pricing.py`.
- Frontend typecheck: **BLOCKED** — `npm run typecheck` exited 2. `frontend/node_modules`, `yarn.lock` and `package-lock.json` are absent; the compiler cannot resolve `expo/tsconfig.base`, React, React Native, Expo Router and other declared packages. The additional JSX/lib diagnostics cascade from the missing project dependencies/configuration; this is not a successful source typecheck.
- Expo web build, lint, browser launch, mobile rendering and screenshot verification: **NOT RUN / UNVERIFIED**, because frontend dependencies are unavailable.
- Network: npm registry DNS failures were already checked during the prior dependency-resolution task. No repeated registry or alternate-host network attempts were made in this pass.
- Git: the working directory has no `.git` repository, so Git status/diff could not be recorded. A file-based backup was created instead.

## Feature status
- **Available in code:** CHAND screen and four role-preview modes; deterministic no-cost Demo Mode; Help & Support UI; authenticated order/ticket fetch calls; explicit support submission confirmation; actual returned support reference/status display; navigation links to existing categories, restaurant, services and orders screens.
- **Live only when configured:** private order and support data; requires a reachable configured backend and a valid signed-in session.
- **Demo-only / not integrated:** AI language model, live catalog recommendations, live restaurant/menu discovery through chat, seller analytics through chat, live home-service provider search, voice input/output.
- **Not supported by existing backend:** customer-facing refund request/eligibility API, customer refund processing, grocery order-to-ticket linkage, support-ticket idempotency guarantee.
- **Unverified:** frontend typecheck after installing dependencies, web build, lint, browser/mobile runtime and visual regression.

## Preview instructions (not runtime-verified here)
1. Restore internet/DNS access on a machine where the configured npm registry resolves.
2. From `frontend`, run `corepack prepare yarn@1.22.22 --activate`, then `yarn --version` and `yarn install`. Do not bypass `scripts/cmd-guard.js`.
3. Run `yarn typecheck`, `yarn build:web`, then `yarn start`.
4. Open `/chand` or tap **Meet CHAND** on Shopping home. Sign in and open **Help & Support** to load private order/support data.
5. Configure `EXPO_PUBLIC_BACKEND_URL` in local `frontend/.env` if needed. Do not put secrets in frontend environment variables.

## Cost and safety
- Demo Mode and the support UI use no AI provider and have no AI-provider cost.
- No paid API calls, billing activation, production deployment, production database changes, actual refund calls, order changes or payment mutations were performed.
- A submitted support request is not a refund approval or payment. No refund dates, eligibility decisions or case statuses are invented.

## Backups and rollback
- Original project ZIP preserved: `/mnt/data/COME-IN-COMPLETE-PREVIEW-READY-2026-10-17.zip`.
  SHA-256: `0e5e93b275a3f981d2e00f243f9a55f08f0b450fa76983a3baad096d9eb6148a`.
- Pre-CHAND implementation backup: `/mnt/data/come-in-backups/come-in-before-chand-support-20261017T164332Z.tar.gz`.
  SHA-256: `02d87d265a89e64139f6f83beb0a01fd498c960e1cd7059779825ad28ee804a4`.
- Pre-review safety backup of the current working tree: `/mnt/data/come-in-chand-backups/come-in-before-chand-review-20261017T164606Z.tar.gz`.
  SHA-256: `67fcc8d8e291f40e21919a3cb15fc19d0aba66c809f6f8440d3b363d6b29f028`.
- Previous ZIPs were not overwritten. To roll back, extract a backup into a separate directory and selectively restore files; do not overwrite the original ZIP or current tree wholesale.

## Changed files in the cumulative CHAND work
- `frontend/app/chand.tsx` — existing Help & Support panel plus issue-specific deterministic Demo Mode guidance and safe unknown-request fallback.
- `backend/tests/test_chand_demo_contract.py` — CHAND and support/refund safety contract tests, including the new guidance assertions.
- `CHAND_IMPLEMENTATION_STATUS.md` — implementation status and limitations.
- `CHAND_HELP_SUPPORT_REFUND_REPORT.md` — cumulative report updated with this remaining-work pass.
