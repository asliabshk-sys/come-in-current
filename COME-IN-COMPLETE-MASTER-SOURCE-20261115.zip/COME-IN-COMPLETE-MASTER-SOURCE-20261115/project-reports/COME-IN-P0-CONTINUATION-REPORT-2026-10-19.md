# COME-IN P0 Continuation — Consolidated Current Status

This file replaces the root-level status summary for the consolidated master. The original reports from earlier snapshots are preserved under `docs/history/` and must be read as historical reports for their named candidates, not as claims about the current consolidated source.

## Consolidated source-level changes

- Removed the visible Delivery Area / saved-address panel from Restaurant search and cuisine discovery while retaining restaurant search, cuisine filters and delivery-eligibility checks.
- Restored the distinct variant-aware Buy Now action alongside Add to Cart; Buy Now is restricted to a live, in-stock product and a single product/variant cart.
- Enforced non-empty shop payment configuration and server-side validation against the resolved shop's current methods.
- Added per-shop COD, UPI intent and cash-at-shop/pickup options where configured. UPI orders remain `awaiting_upi_payment` / `pending_payment` until an authenticated shop owner or admin manually confirms receipt after checking the bank statement. Opening a UPI app is not proof of payment.
- Grocery Stripe/Razorpay checkout remains disabled until a real customer-facing gateway integration is configured. Restaurant Razorpay is only available through its existing configured flow; no new gateway credentials are bundled.
- Kept the current referral, earnings/ledger, retail-price import, product-listing and CHAND AI changes from the newest candidate.

## Verification status

- Backend tests after real-services Phase 1: 213 passed, 23 skipped, 0 failed.
- Python syntax: PASS.
- Frontend TypeScript/TSX transpile syntax check: 78/78 files passed; this is not a full typecheck. After Phase 1, full typecheck/lint/build remain blocked by missing Expo dependencies.
- Full frontend typecheck/lint/build and live backend import remain blocked by missing dependencies. Live MongoDB, real payment, browser UI and end-to-end flows were not run.
- No APK was built and Replit was not launched.

See `docs/COME-IN-ULTIMATE-CONSOLIDATION-INVENTORY-2026-10-19.md` and the external verification report for the full source archive inventory and limitations.
