# COME IN — Business Onboarding Implementation Report

Date: 2026-10-18

## Existing architecture reused
- Existing `/api/shops` registration and owner/admin checks cover online/offline shop registration; existing shop types include the specialty Offline Shop types.
- Existing restaurant registration, owner menu management, order lifecycle and Razorpay configuration/verification routes were preserved.
- Existing agent-assistance requests are persisted in `agent_assist` and admin-managed; no call-routing provider was configured or represented as connected.
- Added home-service provider and appointment workflows in the existing FastAPI/Mongo architecture and changed the existing Home Services screen to use them rather than displaying static mock services and a fake success toast.

## Implemented
- Authenticated provider registration, one profile per account, pending approval by default, owner-only profile edits, public listing limited to approved and active profiles, and admin approval/activation endpoints.
- Provider fields include category, declared tasks/specializations, experience, description, service area, slots, optional service charge, visit fee, additional-charge disclosure and quotation-required flag.
- Appointment requests persist to Mongo, require a future timezone-aware date/time, store the configured fee snapshot and quotation state, and reject a listed slot if unavailable or already booked. Customer can cancel their own appointment; provider can accept/reject/reschedule; admin can manage statuses.
- Home Services UI lists only real approved/active API profiles, offers provider registration and appointment request forms, clearly states that registration is pending review, and never fabricates provider profiles or payment confirmation.

## Not completed / blockers
- The home-services feature has API and UI code but was not exercised against a live MongoDB or in a browser/device Preview. Concurrent booking safety is a read-before-insert check and should be strengthened with a unique reservation/slot-lock strategy before relying on it at scale.
- Provider profile photo upload, provider appointment dashboard controls, automated notifications, routing/distance estimates and fee policy configuration are not implemented in this pass.
- Call Shop uses the saved phone number in the existing shop flow; platform-level call routing for agents is not configured. Existing agent-assistance requests remain the fallback; no agent availability is fabricated.
- Existing Online Shop and Restaurant flows were preserved, not comprehensively re-run in an end-to-end environment. Existing online payment integrations remain conditional on backend credentials and gateway configuration.
- No destructive migration, deployment, paid integration, or public release was performed.
