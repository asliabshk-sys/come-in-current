# COME-IN — Shop Registration Entry Point Removal Report
Date: 2026-10-19

## Candidate integrity and preservation
- Input candidate: `COME-IN-Role-Security-Retail-Price-Import-Pre-APK-2026-10-19.zip`
- Input SHA-256: `f78d07a87dc733e1ef1728a59621982c989f7e076c40086f678cc92bebc867dd`
- Input ZIP integrity test: passed before editing.
- Work was performed in a separate extracted copy. The original input ZIP was not overwritten.
- Restaurant Mode theme/branding files were not edited.

## Changes made
1. Removed the Add Your Shop / Register Your Shop button from the shared Online/Offline Shops browsing screen (`frontend/app/shops.tsx`). Removed the browse screen's navigation to `/become-seller`; this was a real component removal, not CSS hiding.
2. Added `Add Your Shop` to Account. Selecting it opens four modes: Online Shop, Offline Shop, Restaurant, and Home Services.
3. Online Shop and Offline Shop selections route to the existing shop registration flow with the corresponding `type`.
4. Restaurant selection routes to the existing restaurant dashboard/registration flow.
5. Home Services selection routes to the existing Services page with `openRegistration=1`, which opens the provider registration form.
6. Removed duplicate “Open your shop” registration links from the empty Shop Products and Shop Orders screens. Those screens now direct the user to Account > Add Your Shop using text only.
7. Preserved the existing shop-list API call, shop list, search, tabs, category filters and shop detail navigation. No backend approval logic was changed.

## Automated source-contract tests
Command:
`cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests`

Result: **166 passed, 23 skipped, 0 failed**.

The tests verify the browse component has no registration UI/navigation, shop browsing code remains connected to `/shops` and shop details, Account has all four registration modes, and registration/approval API handlers use authenticated/admin dependencies.

## Requested checks — actual rendered/live status
The frontend could not be launched in this environment because `frontend/node_modules` is absent and `expo/tsconfig.base` is missing. `npm run typecheck` exited 2 with missing Expo/React Native modules and TypeScript base config. No browser automation session was available, and no live backend/database API session was run. Therefore these are **not claimed as rendered/runtime PASS**:

| Check | Source-contract result | Actual rendered/live result |
|---|---|---|
| Registration option removed from Online Shops | PASS — shared browse component has no registration entry point | FAIL / NOT VERIFIED — rendered screen test could not run |
| Registration option removed from Offline Shops | PASS — same shared component has no registration entry point | FAIL / NOT VERIFIED — rendered screen test could not run |
| Existing approved shops still visible | PASS — `/shops` fetch, list and shop detail navigation remain in source | FAIL / NOT VERIFIED — live approved shop records were not loaded in a running app |
| Registration accessible from Account | PASS — four mode routes and Home Services registration-open parameter are present in source | FAIL / NOT VERIFIED — rendered tap-through test could not run |
| Unauthorized registration or approval access prevented | PASS — shop/restaurant creation requires `get_current_user`; shop/restaurant approval routes require `require_role("admin")` in source | FAIL / NOT VERIFIED — live unauthorized requests and HTTP status codes were not exercised |

## Remaining verification
- Install the project's intended frontend dependencies and restore `expo/tsconfig.base`, then run typecheck/build.
- Run browser/device tests for Online Shops, Offline Shops, Account modal and all four destination routes.
- With a test backend and test accounts, verify anonymous registration returns 401, disallowed-role/ownership requests return 403, and non-admin approval requests return 403.
- Verify actual approved shops load and remain visible in both tabs against test data.

No APK was built. No production database was changed.
