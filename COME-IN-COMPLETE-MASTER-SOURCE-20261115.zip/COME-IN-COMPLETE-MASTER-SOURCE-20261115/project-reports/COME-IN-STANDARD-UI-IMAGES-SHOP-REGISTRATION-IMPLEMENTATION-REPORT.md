# COME-IN — Standard UI, Product Images & Shop Registration Implementation Report

Date: 2026-10-19

## Candidate verification
- Selected candidate: `COME-IN-Compact-UI-Product-Checkout-Shopkeeper-Payments-Verified.zip`
- Expected SHA-256 from the recorded candidate: `0115041fd07520d73e63948c3d85e568f6396d1986f4af49dcf27737256e39e3`
- Recomputed SHA-256: `0115041fd07520d73e63948c3d85e568f6396d1986f4af49dcf27737256e39e3` — PASS
- ZIP size: 3,962,995 bytes
- `unzip -t`: PASS, no errors detected.
- Working copy: `/mnt/data/comein-standard-work/COME-IN-COMPLETE-MASTER-PREVIEW-READY-2026-10-18/`
- Original candidate and all Library backups preserved.
- Screen recording inspected from the user-provided MP4. Sampled screens show a 2x2 home shortcut grid and generic/placeholder imagery on some catalog product details.

## Changes made in the separate working copy
1. `frontend/app/(tabs)/index.tsx`
   - Reduced home mode-card minimum height from 98 to 88 and artwork from 48x54 to 40x44.
   - Slightly compacted arrow and title dimensions; kept accessible card press surfaces and existing route handlers.
2. `frontend/src/data/catalog.ts`
   - Added a product-name keyword image mapper for browse-only catalog references (rice, pulses/dal, flour/atta, sugar, dairy, spices/oils, bakery, fruits and vegetables).
   - Uses existing project image URLs already referenced by the catalog; falls back to the category image. Images are illustrative only and do not assert a live offer, brand, price or stock.
   - Catalog reference items remain `source: "catalog"` with price 0 and remain non-orderable until a shop publishes a real listing.
3. `frontend/app/shops.tsx`
   - Added a visible “Add Your Shop / Register Your Shop” action linking to the existing authenticated `/become-seller` registration/profile flow.
4. `backend/tests/test_catalog_reference_minimum.py`
   - Updated a source-contract assertion to reflect that browse-only references now receive presentation imagery while still carrying no invented price.
5. `backend/tests/test_standard_ui_image_shop_cta_contract.py` (new)
   - Added source-contract tests for compact card dimensions, registration CTA routing, and browse-only catalog image mapping/no fake price.

## Verification
- PASS: `python -m py_compile backend/server.py backend/restaurant_pricing.py backend/restaurant_serviceability.py`
- PASS: `PYTHONPATH=. python -m pytest -c /dev/null -q tests` from `backend/` — **148 passed, 23 skipped, 0 failed**.
- PASS: Original input ZIP integrity (`unzip -t`).
- BLOCKED: Frontend typecheck, lint, and web build because `frontend/node_modules` is absent. No dependency install was attempted; this environment has previously recorded package registry DNS/network failure.
- NOT RUN: Replit, Preview, app launch, browser/device UI test, real image URL fetch verification, live database persistence, and payment transaction tests.

## Requirement status / important limitations
- Standard-size home cards and smaller prominent card artwork: implemented at source level; no rendered responsive visual comparison was possible because Preview was intentionally not launched.
- Product images: browse-only catalog items now resolve to product-keyword/category image URLs. Real network image loads were not verified in this pass; deployed availability and category/product/cart rendering still need runtime verification. Existing image fallback handlers remain in place.
- Quantity selector: existing shared `QuantityStepper`, cart state, variant-keyed cart identity and subtotal calculations were inspected and retained. This pass did not alter quantity/cart code. Existing selector increments whole cart units; fractional-weight purchasing is not implemented/verified.
- Offline shop registration: backend `POST /shops`, `GET /shops/mine`, and owner-checked `PATCH /shops/{id}` plus the existing `/become-seller` form were found in the candidate. This pass added a direct visible entry point. Database persistence cannot be verified without DB connectivity.
- Shop payments: existing shop registration supports payment method preferences and a public UPI handle. This pass did **not** implement secure bank-account storage, QR-specific upload/preview/replace, dedicated private payment-settings APIs, or customer checkout instructions for shop-level UPI/QR/bank transfer. These remain incomplete; do not treat a UPI handle as proof of payment.
- Restaurant Mode: no Restaurant Mode source files or restaurant theme styles were changed. Backend suite passed; runtime visual regression remains unverified.
- Database inventory and live API checks: BLOCKED; no live DB credentials/configuration were used. No migration or production write was performed.
- No new verified product records or live catalog counts were fabricated.
- No Replit launch, deployment, or real payment occurred.

## Final package
- New ZIP: `COME-IN-Standard-UI-Product-Images-Quantity-Offline-Shop-Payments-Verified.zip`
- Package is a new archive; original ZIP remains untouched.
