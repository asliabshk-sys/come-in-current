# COME-IN — Grocery Payment Sandbox Infrastructure Readiness

**Date:** 2026-10-30  
**Scope:** Read-only configuration/infrastructure audit, Pay-at-Shop regression verification, and targeted source-contract tests.  
**Explicit exclusions:** No Grocery Razorpay integration, no payment intent/capture/refund, no webhook integration, no Task 25 Order Replacement, no database mutation/migration, no dependency installation, no Preview/mobile testing.

## 1. Executive result

**Sandbox readiness: BLOCKED.**

The active working copy is present at `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`. No `.git` directory is present; Git status/history is therefore not claimed.

All four requested runtime configuration variables are absent from the current process environment. `.env`, `backend/.env`, and `frontend/.env` are absent. MongoDB client initialization in `backend/server.py` requires `MONGO_URL`, so the application cannot establish its configured database connection in this environment. No local `mongod`/`mongosh` executable or local TCP listener on port 27017 was detected. No connection or transaction capability was demonstrated.

No source-code files were changed in this audit. Only this report was added.

## 2. Configuration audit

Availability was checked as a boolean only; no environment variable values were read, printed, logged, or copied.

| Variable | Runtime environment | Source/template finding | Assessment |
|---|---|---|---|
| `GROCERY_RAZORPAY_KEY_ID` | NOT SET | Not present in backend code or `.env.example`; name appears only in the previous readiness report | Not configured or wired |
| `GROCERY_RAZORPAY_KEY_SECRET` | NOT SET | Not present in backend code or `.env.example`; name appears only in the previous readiness report | Not configured or wired |
| `GROCERY_RAZORPAY_WEBHOOK_SECRET` | NOT SET | Not present in backend code or `.env.example`; name appears only in the previous readiness report | Not configured or wired |
| `MONGO_URL` | NOT SET | Referenced by `backend/server.py` and listed in `backend/.env.example` | Name/template exists; no usable runtime connection |

The backend template also contains the existing shared `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET` names. Existing uses are part of the Restaurant payment integration. They are not Grocery-specific credentials and must not be reused for Grocery. The frontend template contains only the public backend URL variable; payment secrets must never be placed in frontend configuration.

`backend/.env.example` shows a sample MongoDB URI with `replicaSet=rs0`. This is a template example only, not evidence that a replica set exists or that the current environment is connected to one.

## 3. MongoDB transaction readiness

- `MONGO_URL` is not set in the current process environment.
- No root, backend, or frontend `.env` file is present.
- No `mongod` or `mongosh` executable was found on PATH.
- No local TCP listener on port 27017 was detected.
- No MongoDB connection was attempted because no configured connection string is available.
- No replica-set status, server topology, transaction start, commit, or rollback was tested.

**Result: NOT VERIFIED / BLOCKED.** Do not describe the database as installed, connected, replica-set-enabled, or transaction-capable based on the template alone.

The existing FastAPI/Motor code uses `client.start_session()` and `session.start_transaction()` in Grocery checkout and cancellation paths. Existing code paths are designed to fail closed when transactional operations fail; there must be no non-transactional fallback for stock/order/payment state that could leave partial writes. Before payment work, a dedicated non-production MongoDB replica-set or transaction-capable sharded sandbox must be configured and its topology and a harmless transaction commit/rollback test demonstrated.

## 4. Razorpay sandbox setup checklist

The merchant/account owner must perform the dashboard-side setup:

1. Sign in to the authorized Razorpay account (or create/complete the account onboarding if no account exists).
2. Switch the Dashboard to **Test Mode**. Do not select Live Mode or use live credentials for this exercise.
3. In the Test Mode API Keys settings, generate the Test Key ID and Test Key Secret. Store them directly in the backend hosting/runtime secret manager; do not send them in chat, commit them, put them in ZIP files, or put them in frontend environment variables.
4. In the Dashboard Webhooks settings, add the eventual public HTTPS Grocery webhook endpoint, configure a separately generated webhook signing secret, and subscribe only to the required payment/refund events after the Grocery handler has been implemented and tested. Use the Test Mode webhook configuration. Do not send webhooks to the Restaurant route.
5. Ensure the webhook endpoint is reachable from Razorpay's test environment. A localhost-only URL is not externally reachable; use an approved staging endpoint or a controlled secure tunnel for development only.
6. Verify Test Mode credentials, webhook delivery, event signatures, captured-payment status, and refund status against the provider's sandbox records before marking any behavior verified.

Proposed backend-only environment variable names for a future Grocery implementation:

- `GROCERY_RAZORPAY_KEY_ID`
- `GROCERY_RAZORPAY_KEY_SECRET`
- `GROCERY_RAZORPAY_WEBHOOK_SECRET`
- `MONGO_URL`

These Grocery-specific names are proposed configuration contracts only; they are not currently wired into source code or present in `.env.example`. They must be added deliberately as part of a separately approved implementation step. Use the platform's encrypted backend secret store/environment configuration. If a local `.env` is used for development, keep it backend-only, ignored by version control, excluded from ZIPs/backups, and restrict file permissions. Never expose a secret to Expo/public `EXPO_PUBLIC_*` variables.

Official reference links:
- Razorpay Python integration/testing and Test Mode guidance: https://razorpay.com/docs/server-integration/python/test-app/
- Razorpay dashboard payment/webhook actions: https://razorpay.com/docs/payments/payments/dashboard/
- Razorpay webhook setup guidance: https://razorpay.com/blog/how-to-use-razorpay-webhooks/

## 5. Future Grocery/Restaurant separation and security gates

A future Grocery implementation must use dedicated Grocery records and endpoints, for example `grocery_payments` and `grocery_payment_events`, with unique indexes for order/attempt/provider identifiers and idempotency keys. It must not read/write `restaurant_payments` or `restaurant_payment_events`, nor reuse `/restaurant/...` payment, verify, webhook, or refund routes.

Before accepting a Grocery payment as paid, the backend must independently validate the expected order/customer, server-calculated amount in integer paise, INR currency, Razorpay order/payment IDs, provider-retrieved payment state `captured`, and a valid payment signature. The frontend callback alone is not proof of capture.

Webhook processing must validate the HMAC signature against the exact raw request body using the Grocery webhook secret, persist/deduplicate provider event IDs, be safe for retries and out-of-order/late events, and apply order/payment transitions atomically. Duplicate create/verify/refund requests must be idempotent.

Refund state must distinguish a customer/admin refund request from a provider-accepted/pending refund and from a provider-confirmed processed refund. A timeout or ambiguous provider response must enter an uncertain/reconciliation state; it must not be reported as refunded or automatically retried in a way that can double-refund. Only provider-confirmed refund completion may update refunded totals and ledger reversal.

Any future additional payment for an Order Replacement proposal must be a separate payment attempt explicitly bound to the exact order ID, proposal ID, customer, currency, and difference amount. Accepting a proposal must not itself imply payment. This stage does not implement any of this behavior.

MongoDB transaction support is a precondition for coordinated payment/order/stock/ledger state changes. If transactions are unavailable, fail closed with no partial state transition and no fallback that marks an order paid or refunded.

## 6. Pay-at-Shop fix verification and newly found regression

Confirmed in the active source:

- New Grocery `cash_shop` / `pickup` order creation sets `payment_status` to `pay_at_pickup_pending`.
- `cod` continues to use the distinct `cod_pending` state.
- `confirm_manual_cash_collection()` accepts the canonical `pay_at_pickup_pending` state and, for Grocery only, the legacy `pay_at_shop_pending` state.
- Seller Earnings exposes the cash confirmation action for `cod_pending`, `pay_at_pickup_pending`, and legacy `pay_at_shop_pending` when fulfillment is `delivered` or `picked_up`.
- The confirmation endpoint requires `confirmed=true`, current shopkeeper role/ownership, and completed fulfillment, then records `cash_collected` plus actor/time audit fields. It does not set the order to `paid`.

**Newly found regression:** `_cancel_grocery_order()` still allows `pay_at_shop_pending` but does not allow the new canonical `pay_at_pickup_pending`. New unpaid Pay-at-Shop orders in a cancellable status may therefore be rejected by the existing cancellation payment-state guard. This was not changed in this audit, per the no-unnecessary-source-change instruction. It should be fixed with a narrowly scoped change and a regression test before treating the Pay-at-Shop lifecycle as fully corrected.

The existing `test_task9_order_actions_contract.py` still asserts the legacy-only cancellation state and passes; it does not detect this new canonical-state gap. A new assertion should cover both canonical and legacy values while preserving COD and unpaid UPI handling.

## 7. Targeted tests executed

Command 1:

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_grocery_pay_at_shop_status_contract.py \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_task10_payment_refund_notification_contract.py \
  tests/test_financial_security_contract.py \
  tests/test_task22_checkout_audit_contract.py
```

Result: **35 passed in 0.37s**.

Command 2:

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q tests/test_task9_order_actions_contract.py
```

Result: **9 passed in 0.13s**. This existing test suite still encodes the legacy-only cancellation status and therefore does not prove the new canonical cancellation state works.

No full-app tests, Preview, mobile tests, live API, MongoDB, or Razorpay sandbox tests were run.

The previously recorded Task 23 tracking assertion failure remains a separate known test issue from the earlier broader test run. It was not run or modified as part of this focused infrastructure audit.

## 8. Task 21–24 and backup preservation evidence

- Task 24 baseline ZIP exists: `COME-IN-TASK24-POST-CHANGE-20261030T082300Z.zip`; size 4,132,820 bytes; SHA-256 `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`; ZIP integrity PASS.
- Recent Pay-at-Shop post-change ZIP exists: `COME-IN-GROCERY-PAYAT-SHOP-POST-CHANGE-20261030T093000Z.zip`; size 4,187,245 bytes; SHA-256 `1b37dd9b338d1b908ddb8ee41d0f50bf241a00cdc7095a9378ea4a635cc72b69`; ZIP integrity PASS.
- Comparing the two ZIPs: 305 common files, **2 differing common files**, precisely the intended Pay-at-Shop source files (`backend/server.py` and `frontend/app/seller-earnings.tsx`); the Pay-at-Shop ZIP adds the dedicated source-contract test and reports. The five removed entries from the Task 24 ZIP are only `.pytest_cache` artifacts.
- The active working copy's `backend/server.py`, `frontend/app/seller-earnings.tsx`, and `backend/tests/test_grocery_pay_at_shop_status_contract.py` match the recent Pay-at-Shop ZIP byte-for-byte.
- The Task 21, Task 22, Task 23, and Task 24 report files are present in the active working copy and match their copies in the recent Pay-at-Shop ZIP byte-for-byte.
- ZIP packaging excludes `.env.example` templates; those remain present in the active working copy. No ZIP was extracted over the active source.
- Test execution created ordinary Python cache artifacts only; no application source files were changed by this audit.

## 9. Final status and next smallest safe step

**Overall Grocery Payment Sandbox: BLOCKED.**

Blocking prerequisites:
1. Merchant owner creates/uses a Razorpay account and generates Test Mode API credentials plus a distinct Test Mode webhook secret.
2. Authorized project operator configures those secrets in the backend secret store under the proposed Grocery-specific names.
3. A non-production MongoDB replica-set/transaction-capable environment is provided through `MONGO_URL` and its topology/transaction behavior is proven.
4. A public HTTPS test webhook endpoint can be configured in the Razorpay Test Mode Dashboard.
5. Before Payment/Refund implementation, fix and test the newly identified Pay-at-Shop cancellation status mismatch.

**Next smallest safe step:** user/operator provisions a non-production MongoDB replica-set and Razorpay Test Mode account credentials through secure secret management; do not share secret values in chat. Then perform a configuration-presence and harmless transaction-readiness check before authorizing any Grocery payment code changes.

No Grocery payment/refund integration or Task 25 Order Replacement was implemented.
