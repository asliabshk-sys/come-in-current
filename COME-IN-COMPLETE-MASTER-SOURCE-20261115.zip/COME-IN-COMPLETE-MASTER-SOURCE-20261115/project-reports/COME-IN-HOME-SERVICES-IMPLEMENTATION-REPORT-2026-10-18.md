# COME-IN — Remaining Home Services Implementation Report

Date: 2026-10-18

## Source and backup safety

- Continued from `COME-IN-BUSINESS-ONBOARDING-2026-10-18.zip` working copy.
- Created a new archive: `COME-IN-HOME-SERVICES-COMPLETE-2026-10-18.zip`.
- Original and earlier ZIP backups were not overwritten.
- Final ZIP SHA-256 is provided in the handoff message; it is not embedded here to avoid a self-referential archive hash.
- ZIP integrity: PASS; 198 entries.

## Files changed in this phase

1. `backend/server.py`
   - Added a MongoDB unique compound index for home-service provider/time-slot reservations.
   - Appointment creation now reserves a slot with an atomic unique insert, rejects duplicate concurrent reservations with HTTP 409, and removes the reservation if appointment insertion fails.
   - Added a compatibility guard for active appointments created before reservation records existed.
   - Rescheduling reserves the destination slot first, validates timezone/future time, uses compare-and-set status update, and releases the previous reservation only after the change succeeds. Rejected/cancelled appointments release their reservation.
   - Added admin-configurable visit fee policy: provider-configured, platform fixed fee, or waived. Fee policy is snapshotted on new appointments; existing appointments retain their recorded fee.
   - Added a provider-photo update endpoint that checks provider ownership and that the uploaded image belongs to the signed-in user, using the existing object-storage upload flow.
   - Provider appointment list now returns an empty list for an account without a provider profile instead of preventing customers from loading their own appointment list.
   - Existing approval, ownership, and customer cancellation permission checks remain in place.
2. `frontend/app/services.tsx`
   - Added customer appointment list with request/accepted/closed status, visit fee, service-charge/quotation state, payment status, and customer cancellation for eligible appointments.
   - Added provider dashboard for incoming requests with accept, reject, reschedule, status notes, and fee/payment information.
   - Added web profile-photo upload using the existing shared image-upload API; it does not reset approval status.
   - Refreshes appointment views after create/update actions.
3. `frontend/app/admin.tsx`
   - Added Home-service fees admin tab with provider/fixed/waived modes and validated INR fixed fee setting.
4. `backend/tests/test_home_services_remaining_contract.py`
   - Added focused contract checks for reservations, rescheduling, fee policy, photo ownership, status/payment UI, and approval/permission guards.

## Verification

- Python compile (`backend/server.py`, `backend/restaurant_pricing.py`, `backend/restaurant_serviceability.py`): PASS.
- Backend regression suite: **142 passed, 23 skipped, 0 failed**.
- Skipped tests are existing remote integration tests requiring `COMEIN_TEST_BASE_URL`.
- ZIP archive integrity: PASS.
- Original prior archive SHA-256 check should be compared against its previously recorded value if needed; no command in this phase wrote to the original archive.

## Not verified / constraints

- Replit Preview was not started, as requested.
- No live MongoDB concurrency race test was run; atomicity is implemented through a MongoDB unique compound index and insert conflict handling, but deployment startup/index creation and behavior against the configured live database remain unverified.
- Frontend typecheck/build was not run because frontend dependencies are not installed in this working copy; no browser/device test was run.
- Provider photo selection is wired for web (matching the existing shop-logo upload pattern). Native mobile image-picker UI is not wired because the project does not currently include an image-picker dependency.
- Object-storage upload still requires `EMERGENT_LLM_KEY` and a reachable configured object-storage service. If unavailable, the existing upload endpoint returns a service-unavailable error.
- Appointment notifications, payment collection for home services, and live end-to-end verification remain outside this phase; appointment acceptance does not indicate payment success.
