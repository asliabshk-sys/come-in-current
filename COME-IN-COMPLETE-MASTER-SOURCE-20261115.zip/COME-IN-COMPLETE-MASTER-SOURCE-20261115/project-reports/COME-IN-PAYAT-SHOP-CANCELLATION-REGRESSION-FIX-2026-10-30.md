# COME-IN — Pay-at-Shop Grocery Cancellation Regression Fix

Date: 2026-10-30  
Status: **COMPLETE — source-contract level**

## Scope

Fix only the Grocery cancellation guard for canonical Pay-at-Shop status `pay_at_pickup_pending`. No Grocery Razorpay integration, refund implementation, additional payment, Task 25 Order Replacement, Restaurant payment change, database migration, dependency installation, network retry, Preview launch, or mobile test was performed.

## Defect confirmed

The prior Pay-at-Shop baseline ZIP (`COME-IN-GROCERY-PAYAT-SHOP-POST-CHANGE-20261030T093000Z.zip`, SHA-256 `1b37dd9b338d1b908ddb8ee41d0f50bf241a00cdc7095a9378ea4a635cc72b69`) allowed only `cod_pending`, `awaiting_upi_payment`, and legacy `pay_at_shop_pending` in `_cancel_grocery_order()`. New Grocery `cash_shop` / `pickup` orders use canonical `pay_at_pickup_pending`, so eligible unaccepted orders failed the payment-state guard with HTTP 409 before stock restoration.

## Minimal correction

`backend/server.py` now includes `pay_at_pickup_pending` in the explicit unpaid cancellation allow-list, while retaining `cod_pending`, `awaiting_upi_payment`, and legacy `pay_at_shop_pending`.

The existing order-status guard (`pending` / `pending_payment` only), transactional stock restoration, compare-and-set update, `modified_count` check, and cancellation result (`status=cancelled`, `payment_status=cancelled`) are unchanged. Paid, cash-collected, refund-related, and unknown states remain outside the allow-list. This path never marks an order `paid`.

Existing cash confirmation remains separate: seller authorization, explicit `confirmed=true`, and completed fulfillment (`delivered` / `picked_up`) are required; confirmation records `cash_collected`, not `paid`.

## Files changed relative to the prior Pay-at-Shop ZIP

1. `backend/server.py` — one canonical status added to cancellation allow-list.
2. `backend/tests/test_task9_order_actions_contract.py` — Task 9 assertion updated and an additional protected-state regression assertion added.
3. `backend/tests/test_grocery_pay_at_shop_status_contract.py` — added cancellation assertions for canonical and legacy states, COD separation, and protected states.

No frontend file changed in this cancellation task. `frontend/app/seller-earnings.tsx` remains as in the preceding Pay-at-Shop update. No Restaurant route was changed.

## Tests actually run

Focused source-contract command:

```bash
cd backend
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_task9_order_actions_contract.py \
  tests/test_grocery_pay_at_shop_status_contract.py \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_functional_blockers_regression.py \
  tests/test_financial_security_contract.py
```

Result: **50 passed in 0.80s**.

Separate Task 23 legacy assertion check:

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_shared_system_integration_contract.py::test_shared_tracking_endpoint_supports_restaurant_orders_without_fake_coordinates
```

Result: **1 failed in 0.15s**. The assertion expects the old direct `restaurant_owner_id` comparison, while current Task 23 code checks current role and live Restaurant shop ownership. It is unrelated to this Grocery cancellation fix and was not changed or hidden.

`python -m py_compile backend/server.py`: PASS. All tests are source-contract/unit-level; they do not prove live API/database behavior.

## Backup and preservation evidence

- The prior Pay-at-Shop ZIP above was retained unchanged and used as the pre-fix source baseline.
- Task 24 ZIP retained unchanged: `COME-IN-TASK24-POST-CHANGE-20261030T082300Z.zip`, SHA-256 `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`.
- Comparing Task 24 archive files against current source showed only the expected subsequent Pay-at-Shop differences in `backend/server.py`, `frontend/app/seller-earnings.tsx`, and `backend/tests/test_task9_order_actions_contract.py`; remaining common archived files matched. The Pay-at-Shop status contract test was added after Task 24.
- A timestamped working snapshot was also created during this run, but inspection showed it already contained the canonical cancellation allow-list change; it is therefore not treated as the pre-fix baseline. The prior Pay-at-Shop ZIP is the actual pre-fix comparison baseline.
- No `.git` directory was present; no Git status/history is claimed.
- ZIP packaging excludes `.env` secrets, dependency directories, caches, and bytecode.

## Not verified / remaining blockers

No live FastAPI request, MongoDB transaction, inventory mutation, Preview, Android/iOS device, Razorpay sandbox, payment, or refund test was performed. Grocery payment/refund and Task 25 Order Replacement remain BLOCKED and were not implemented.

## Completion

The cancellation regression is fixed at source level with a minimal allow-list change. Canonical Pay-at-Shop, legacy Pay-at-Shop, and COD cancellation eligibility are covered by targeted source-contract tests; protected payment states remain fail-closed. Runtime/database behavior remains unverified.
