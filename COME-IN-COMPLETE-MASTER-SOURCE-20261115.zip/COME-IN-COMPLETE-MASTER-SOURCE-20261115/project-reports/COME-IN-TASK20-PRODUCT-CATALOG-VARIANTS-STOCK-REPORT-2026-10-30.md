# COME-IN — Task 20: Product Catalog, Variants, Quantity & Stock Audit

Date: 30 October 2026  
Active working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
Result: **Two schema-boundary validation gaps fixed; targeted source-contract tests passed. Runtime verification remains unperformed.**

## 1. Active project and prior evidence

The active source was identified from the working-copy root marker `COME-IN-WORKING-COPY-RECOVERED-V1.md` and the expected `backend/` and `frontend/` paths. No ZIP or older extracted directory was substituted as the active project.

Read the Task 18 and Task 19 reports before editing. Also reviewed the Task 10 payment/security report and the older `COME-IN-ROLE-SECURITY-RETAIL-PRICE-IMPORT-REPORT-2026-10-19.md`. There is no separate Task 07 or Task 08 report in the active `project-reports/` folder; those findings were cross-checked against current source, Task 18's historical notes, and the checkout/import contract tests. The relevant Task 07/08 backup archives were checksum-checked without modification.

Task 18 pre/post archives and Task 19 pre/post archives were re-hashed and ZIP-integrity checked before work. All four matched their previously recorded SHA-256 values and passed `unzip -t`.

No `.env` values, credentials, or secret files were opened or printed.

## 2. Actual source and workflows inspected

Backend:
- `backend/server.py`: `ProductVariantIn`, `ProductIn`, `MasterLinkIn`, product create/update/link routes, seller CSV/XLSX import preview/apply, `/catalog/products`, `_price_for`, `_aggregate_grocery_quote_lines`, `_resolve_grocery_lines`, `_quote_totals`, `_atomic_decrement_line`, and `create_order`.
- `backend/tests/test_grocery_checkout_security_contract.py`
- `backend/tests/test_catalog_import_security_contract.py`
- `backend/tests/test_shopping_cart_variants_contract.py`
- `backend/tests/test_task19_seller_admin_workflows_contract.py`

Frontend:
- `frontend/src/data/useCatalogProducts.ts`
- `frontend/src/store/cart.tsx`
- `frontend/app/product/[id].tsx`
- `frontend/app/(tabs)/cart.tsx`
- `frontend/app/checkout.tsx`
- `frontend/app/seller/products.tsx`

## 3. Existing protections confirmed

### Product identity, variants and catalog

- Product variants have stable IDs with a restricted identifier format; duplicate variant IDs within one product are rejected.
- Variant selection carries the selected `variant.id` through product detail, cart line keys, quote request and order line.
- Cart keys are product ID plus variant ID; different packs of the same product remain distinct. Unknown saved variant IDs are unresolved rather than silently falling back to base-product price.
- The public catalog endpoint selects products from approved shops, requires product availability, and includes either positive-stock base products or products with at least one available positive-stock variant. It returns the product's actual stored price/stock/variants and shop display information; the frontend maps those returned values rather than using catalog-reference/demo prices for checkout.
- The product detail UI displays the selected variant's price/unit and disables variants marked unavailable or with no stock. The frontend mapper excludes unavailable and zero-stock variants from the live purchasable variant list.

### Quantity, quote and checkout

- Cart quantity is an integer count of selected packs/units. The cart prevents incrementing beyond its current stock snapshot; this is only a UI guard, not the authority.
- Variant `unit` is a descriptive string, so labels such as `1 kg`, `5 kg`, `250 ml` or `600 ml` can be represented without adding hardcoded products. Quantity counts whole selected packs; no kg/ml conversion or fractional-measure calculation is implemented by this cart schema. No new sample products or variants were created in this audit, and no live inventory records were available to verify which pack sizes are currently populated.
- Quote/order schemas require quantity >= 1 and <= 1,000. Task 18 aggregates duplicate rows by product ID + variant ID before quote-time stock validation and keeps distinct variants separate.
- `_price_for` resolves the selected variant ID and obtains its unit, price and stock from the stored product. Missing, unknown or unavailable variants are rejected.
- `_resolve_grocery_lines` checks product availability, approved shop, directory-only restrictions, one-shop-per-checkout, and current stock.
- Quote totals are calculated server-side. Checkout ignores client-submitted item prices and fees; order creation reloads current product/variant data and compares it with the stored quote snapshot.
- Order creation requires a scoped quote token and idempotency key, claims the quote once, uses a unique idempotency scope, and handles duplicate-key retries by looking up the already-created order.
- Conditional stock decrement targets the exact base product or exact selected variant and requires `stock >= qty`. Stock decrement, quote consumption and order insert remain in the same MongoDB transaction. Unsupported transactions fail closed; no non-transactional fallback was introduced.

### Seller update and import

- Seller product create/update resolves the actual shop and verifies current owner/role. Product update additionally checks the stored product `owner_id` against the authenticated seller. Legacy updates omitting variants preserve existing variant data.
- CSV/XLSX import validates file size/type, headers, row count, price/stock, IDs/SKUs, duplicate rows and product identity. Matching is scoped to the requested shop. Preview performs no writes; apply rechecks rows and performs product, price-audit and import-history writes in a transaction, failing closed if the transaction cannot complete.
- Task 19's current-role + shop-ownership check for Grocery order status updates remains in `backend/server.py`; no Task 19 logic was changed.

## 4. Verified defects and limited fixes

### Finding A — variant MRP and stock had no upper bound

`ProductVariantIn.price` already had the shared upper bound of 100,000,000, but `mrp` and `stock` only had lower bounds. This differed from base `ProductIn` values and seller import validation, which cap both at 100,000,000. A request could therefore submit arbitrarily large variant stock or MRP values, including values beyond a safe BSON integer range, and fail later during persistence rather than being rejected as invalid input at the API schema boundary.

**Fix:** `ProductVariantIn.mrp` and `ProductVariantIn.stock` now both enforce `<= 100000000`, retaining their existing lower bounds and the MRP >= selling-price validator.

### Finding B — master-product linking bypassed the same upper bounds

`MasterLinkIn` accepted unbounded price, MRP and stock, while ordinary seller-created products, product variants and CSV/XLSX import used bounded values. The master-link route creates a purchasable shop product directly from this model, so this was another product creation path with inconsistent numeric validation.

**Fix:** `MasterLinkIn.price`, `mrp` and `stock` now enforce an upper bound of 100,000,000. The existing `price >= 0` rule is deliberately retained (not changed to `> 0`) to avoid silently changing the existing master-link pricing contract. Existing MRP >= price validation is retained.

No other verified product/variant/quantity/catalog defect requiring a source change was found in the inspected scope.

## 5. Exact changed files

1. `backend/server.py`
   - Added upper bounds to variant MRP and stock.
   - Added upper bounds to master-linked product price, MRP and stock.
2. `backend/tests/test_task20_product_catalog_variants_stock_contract.py` (new)
   - Added focused source-contract regressions for numeric bounds, catalog availability/price data, variant identity, server-authoritative quote pricing, transactional stock decrement, seller import scope and seller product ownership.

No frontend file, checkout/payment code, authentication logic, database schema/index, navigation, or Restaurant Mode file was changed. No dependency was installed.

## 6. Targeted tests and exact results

Commands run from `backend/`:

```bash
python -m py_compile server.py tests/test_task20_product_catalog_variants_stock_contract.py
```

Result: **PASS**.

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_task20_product_catalog_variants_stock_contract.py \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_shopping_cart_variants_contract.py \
  tests/test_catalog_import_security_contract.py \
  tests/test_task19_seller_admin_workflows_contract.py \
  tests/test_task5_task7_ui_implementation_contract.py \
  tests/test_online_shop_product_listing_contract.py \
  tests/test_master_catalog_seller_ui_contract.py
```

Actual result: **52 passed in 0.85s**.

These tests are source-contract/AST and isolated helper checks. They do not call a live authenticated API, persist product documents, or exercise MongoDB transactions.

## 7. Backup records and integrity

### Pre-change archive

- Filename: `COME-IN-TASK20-PRE-CHANGE-20261030T073334Z.zip`
- Path: `/mnt/data/COME-IN-TASK20-PRE-CHANGE-20261030T073334Z.zip`
- Size: `4,099,175` bytes
- SHA-256: `c4dd26c9eb6d05026e65f983b825e0b926d0e289373a16a940defbe2e9a47a93`
- ZIP integrity (`unzip -t`): **PASS**.

### Post-change archive

- Filename: `COME-IN-TASK20-POST-CHANGE-20261030T073603Z.zip`
- Path: `/mnt/data/COME-IN-TASK20-POST-CHANGE-20261030T073603Z.zip`
- Size: `4,100,706` bytes
- SHA-256: `596dc11288b7d3487e111b5898f6692788df94a1e9cef2730f613ade4792a73d`
- ZIP integrity (`unzip -t`): **PASS**.
- All 297 archived files compared byte-for-byte against the active working copy: **PASS**.
- Pre/post archive comparison found only the two intended differences: `backend/server.py` (modified) and `backend/tests/test_task20_product_catalog_variants_stock_contract.py` (added). The report is stored separately and excluded from the archive to avoid a self-referential checksum.

Both archives exclude `.env`/`.env.*`, secrets/key material, `node_modules`, `.git`, virtual environments, Python/pytest caches, Expo caches, build/dist/coverage directories and logs.

### Prior backup preservation

The following prior archives were SHA-256 checked during this task; each matched the previously recorded value. Their `unzip -t` checks passed for Task 18/19 archives. No prior archive was overwritten or regenerated.

```text
31cbf1f71ce18151fa325342405a0ed1c8e601be65f0d28347a15958a53caff0  COME-IN-TASK07-PRE-CHECKOUT-STOCK-20261030T062624Z.zip
8a2cb348505313fa4fac22093153919df8e17af4f3b4e47f2dd096cf5446870d  COME-IN-TASK07-CHECKOUT-STOCK-POSTFIX-20261030T062813Z.zip
8a2cb348505313fa4fac22093153919df8e17af4f3b4e47f2dd096cf5446870d  COME-IN-TASK08-PRE-SELLER-IMPORT-20261030T063053Z.zip
65115b092b3ca9f422226bec095fbc233cc2feeae2ff0d2f36193102daac18bb  COME-IN-TASK08-SELLER-IMPORT-POSTFIX-20261030T063326Z.zip
0ea04f65a46d10aad672ded487fdf69e6a845b1b5a29868c8f7e386bf64c1670  COME-IN-TASK18-PRE-CHANGE-20261030T072246Z.zip
db3602bc2e6b986d5a78e59326347acf12660bc16b50e07b81b23dbf1e2eaccc  COME-IN-TASK18-POST-CHANGE-20261030T072454Z.zip
fe7a627973a21e8946c5e548ba14cde959a88e9b7105c62ed67f8d613936de54  COME-IN-TASK19-PRE-CHANGE-20261030T072756Z.zip
3f92c8804e7c20c7c6b4801edf5876a0e66f585aeab388283bd23fc4d0b70ef2  COME-IN-TASK19-POST-CHANGE-20261030T073100Z.zip
```

## 8. Runtime verification and remaining blockers

| Verification | Actual status |
|---|---|
| Source compilation and targeted tests | **PASS** |
| Live MongoDB / replica-set transactions | **NOT TESTED** |
| Running backend API / live product CRUD | **NOT TESTED** |
| Live seller CSV/XLSX import apply | **NOT TESTED** |
| Expo Preview | **NOT TESTED** |
| Android device/emulator | **NOT TESTED** |
| iPhone/iOS runtime | **NOT TESTED** |
| Production environment | **NOT TESTED** |

No live order, inventory mutation, payment or refund was executed. Razorpay remains blocked under Task 17 and Grocery online gateway payments remain disabled. Task 10's payment/order cross-document consistency and `refund_uncertain` reconciliation blockers remain unresolved and were not changed.

## 9. Final assessment

**TASK 20 COMPLETE — source changes made; runtime verification pending.**

Two inconsistent numeric validation gaps were closed at the product-variant and master-link schema boundaries. Existing product/variant identity, seller ownership, import transaction, server-authoritative price/stock, duplicate cart aggregation, quote idempotency and conditional transactional stock protections remain intact at source level. This is not a production-readiness claim. Live database, API, Preview and device testing remain necessary.

Task 20 stops here. Task 21 has not been started.
