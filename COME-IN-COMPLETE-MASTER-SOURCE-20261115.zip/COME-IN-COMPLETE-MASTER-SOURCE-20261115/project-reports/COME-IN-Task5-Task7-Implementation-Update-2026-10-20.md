# COME-IN — Task 5 + Task 7 Implementation Update

Date: 2026-10-20

## Candidate and preservation

- Starting archive: `COME-IN-Ultimate-Consolidated-Master-Pre-APK-2026-10-19.zip`
- Starting archive size: 3,892,905 bytes
- Starting archive SHA-256: `977ddc5bbaf213fa7be9dcf28334b48cf9286ab8aed0608386532650200d2e5a`
- Starting ZIP integrity: PASS (307 entries; `ZipFile.testzip()` returned no corrupt entry)
- Work was performed in a separate extracted working copy. The original archive in the Library was not modified.

## Audit findings

The candidate already contained substantial purchase logic: product detail variant selection, a quantity stepper, Add to Cart, a Buy Now action on the detail page, cart variant-specific keys, server-authoritative grocery quotes, stock checks and idempotent order creation. It also contained server-side referral attribution, admin review, a ₹500 total reward workflow after 10 qualified referrals, and a referral dashboard.

The bundled prior report explicitly marked checkout shopping redemption as not implemented, real bank payout provider as unavailable, and live UI/API runtime checks as blocked by missing frontend/backend dependencies and external services.

## Changes made in this update

1. `frontend/src/components/ProductCard.tsx`
   - Added a visible Buy Now action for live purchasable product cards.
   - For products with variants, the action routes to product details so the customer must select an available variant before purchase.
   - For non-variant live products, Buy Now checks the single-shop cart constraint and hands off to the existing checkout route.
   - Existing product details, Add/quantity stepper, catalog/reference labels and preview-only restrictions are preserved.

2. `frontend/src/store/auth.tsx`
   - New-account registration records a one-time local marker for the first Home visit.
   - Normal login does not mark an existing customer as new.

3. `frontend/app/(tabs)/index.tsx`
   - Added a prominent Referral & Earn banner on the first Home visit after in-app registration.
   - Subsequent Home visits show a smaller banner for customer accounts.
   - Both actions open the existing referral dashboard.
   - Copy states are scoped to the customer ID. No Restaurant Mode or Home Services theme changes were intentionally made.

4. `backend/tests/test_task5_task7_ui_implementation_contract.py` (new)
   - Added source-contract regression tests for the Buy Now and referral banner paths.

## Verification actually performed

- ZIP integrity: PASS.
- Python syntax: PASS — `python -m py_compile backend/server.py backend/referral_rules.py`.
- Backend regression suite: PASS — `PYTHONPATH=. python -m pytest -c /dev/null -q tests` → **215 passed, 23 skipped, 0 failed**.
- TypeScript/TSX transpile syntax for the 3 changed frontend files: PASS (no transpile diagnostics). This is not a full typecheck.

## Remaining blockers / not claimed as complete

- Full frontend typecheck, lint, web export and running preview: BLOCKED/PENDING because frontend dependencies are absent (`frontend/node_modules` is not installed). Actual preview attempt `npm run preview` exited 127 with `sh: 1: expo: not found`; no preview URL is available.
- Shopping reward redemption in checkout: NOT IMPLEMENTED in this update. It needs a server-authoritative quote/order/ledger integration so reward balances cannot be double-spent or treated as cash incorrectly.
- Real bank withdrawal: NOT AVAILABLE as an actual transfer. Existing workflow supports administrative status/reconciliation fields, but no payout provider is configured. No payout was made or marked paid by this update.
- Live MongoDB transaction/index behavior, authenticated UI, device clipboard/share, OTP provider, payment confirmation and fraud checks: NOT runtime-verified here.
- First-login banner is triggered by accounts registered through the app on this device; registration from another device or externally created accounts cannot be reliably identified as a first app visit with current client-only marker. A server-backed first-visit flag would be needed for cross-device certainty.

## Status summary

- Product detail variants, quantity, Add to Cart and checkout backend: **Existing; source/tests present; live runtime pending**.
- Product-card Buy Now: **Implemented; source-contract tested; running UI pending**.
- Referral dashboard and server-side referral/admin workflow: **Existing; backend tests pass; live DB/provider checks pending**.
- Home referral banner: **Implemented; source-contract tested; running UI pending**.
- Shopping reward redemption: **Pending**.
- Real bank payout: **Blocked pending provider and explicit approval**.
- Original backup: **Preserved**.
