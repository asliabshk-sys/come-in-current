# COME-IN TASK 25 — Replacement Implementation Decision Report

**Date:** 2026-10-30  
**Final status:** TASK 25 INCOMPLETE — PAYMENT/REFUND SAFETY BLOCKER  
**Scope:** Grocery Order Replacement only. No source files changed.

## 1. Active workspace and baseline

- Active workspace confirmed accessible: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`.
- No Git repository detected; no Git status/history is claimed.
- Task 24 report exists and SHA-256 matches the previously recorded value: `8890787e4ddd291e055d420ef38cd30c891456656ac410fb455ba6a701d8019c`.
- Task 24 post-change ZIP exists: `/mnt/data/COME-IN-TASK24-POST-CHANGE-20261030T082300Z.zip`.
  - Size: 4,132,820 bytes.
  - SHA-256: `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`.
  - `unzip -t`: PASS.
  - Earlier Task 25 baseline comparison: 310 archived files matched active source, 0 missing and 0 different.
- Task 25 design review exists and its SHA-256 matches: `0c12216097c95caf811de33d500fbfeb5713eee86d502d3a27478b5e395b0a54`.
- Task 21–24 source baseline preserved. No ZIP was extracted over active source.

## 2. Relevant source evidence

### Grocery order/payment creation — `backend/server.py`

- `OrderIn` accepts Grocery payment methods `cod`, `upi`, `cash_shop`, `pickup`, and legacy online values; lines 519 onward.
- `/orders` explicitly rejects Grocery `online_stripe` and `online_razorpay` with `payment_method_unavailable` (around lines 2275–2311).
- New Grocery orders record payment states:
  - COD: `cod_pending`
  - UPI: `awaiting_upi_payment`, order status `pending_payment`
  - cash_shop/pickup: `pay_at_shop_pending`
  - fully reward-covered orders can become `paid_by_rewards`
  (around lines 2348–2359).
- UPI payment is marked paid by a separate shopkeeper confirmation path (around lines 2443–2451); this is not a verified gateway settlement callback.
- Grocery order creation uses a MongoDB transaction for quote consumption, stock decrement and order insert; unsupported transactions fail closed. This does not provide an external payment/refund settlement mechanism.

### Refund capability

- The existing refund route found in `backend/server.py` is Restaurant-specific and uses `restaurant_orders` / `restaurant_payments` (around lines 4275–4305).
- No Grocery refund route or verified Grocery refund provider/reconciliation flow was found.
- Restaurant refund code must not be reused for Grocery.

### Existing Cart replacement — `frontend/src/store/cart.tsx`, `frontend/app/(tabs)/cart.tsx`

- `replaceLine` is a pre-checkout Cart operation. It checks live product, same shop/category, selected variant and stock, then changes Cart state.
- It does not mutate submitted Grocery orders, track customer approval, adjust paid order totals, or settle payment/refunds.

### Existing order UI — `frontend/app/orders.tsx`

- Grocery order history exposes Repeat Order and Cancel Order where applicable.
- No order-level replacement proposal, customer Accept/Reject, expiry or replacement history UI exists.

### Support

- Existing support flow creates order-linked support tickets and changes ticket status. It is not a replacement approval, payment or refund workflow.

## 3. Approved policy feasibility

The user approved:
- Same shop and same category replacement.
- Current authorized shopkeeper with current shop ownership, or Admin, may propose.
- Customer owner alone may accept/reject.
- Revalidate product, variant, stock, price and order status at decision time.
- COD/pay-at-shop price increases only after explicit customer approval.
- Paid UPI price increases blocked until verified additional-payment flow exists.
- Paid-order price decreases blocked until verified Grocery refund flow exists.
- Reject/expiry removes only unavailable item, recalculates total, and cancels order if no items remain.

## 4. Blocking safety gap

A safe end-to-end implementation cannot currently satisfy the approved rejection/expiry rule for already-paid Grocery UPI orders:

1. Rejecting/expiring a proposal must remove the unavailable line and recalculate the order total.
2. If that order has already been marked `paid`, reducing the payable total creates a customer refund liability.
3. The current Grocery flow has no verified refund API/provider/reconciliation mechanism.
4. The Restaurant refund route is isolated to Restaurant collections and has `refund_uncertain` handling; reusing it would cross business domains and is explicitly prohibited.
5. Merely storing `refund_pending`, changing `order.total`, or marking the line removed would not return funds and could leave payment/order records contradictory.

A related stock issue also needs a transaction design before any order line mutation: original stock was decremented during order creation. Replacement must atomically validate/decrement the proposed item, restore or otherwise reconcile original reserved stock according to current inventory semantics, update order lines/totals, and persist proposal state/history. Existing transaction support in order creation is evidence that transactions are used there, but does not prove a replacement transaction or payment settlement path exists.

Therefore implementation is stopped before source edits. A partial proposal API that permits rejection/expiry but cannot safely settle paid UPI totals would create a misleading, incomplete order state. The system must fail closed rather than pretend the refund happened.

## 5. Files inspected

- `backend/server.py`
- `frontend/app/orders.tsx`
- `frontend/app/(tabs)/cart.tsx`
- `frontend/src/store/cart.tsx`
- `frontend/app/checkout.tsx`
- `frontend/app/order-tracking.tsx`
- `backend/tests/test_grocery_checkout_security_contract.py`
- `backend/tests/test_task24_repeat_order_contract.py`
- `backend/tests/test_task23_order_tracking_authorization_contract.py`
- `backend/tests/test_task22_checkout_audit_contract.py`
- `backend/tests/test_task12_customer_support_contract.py`
- `backend/tests/test_task13_seller_support_status_contract.py`
- `backend/tests/test_task14_seller_support_ui_contract.py`

## 6. Source changes and tests

- Source files changed: NONE.
- API/database schema changes: NONE.
- UI/navigation changes: NONE.
- Restaurant/payment integrations changed: NONE.
- Dependencies installed: NONE.
- Tests run in this implementation attempt: NONE; implementation was blocked before edits because the required paid-order refund behavior cannot be safely delivered by existing Grocery payment capabilities. Existing Task 24 baseline evidence remains as recorded above; it is not represented as a new Task 25 test run.

## 7. Backups and hashes

- No Task 25 pre-change source ZIP created: no source mutation occurred, and the verified Task 24 post-change archive remains the unchanged baseline.
- No Task 25 post-change Master ZIP created: there are no source changes to package.
- Existing Task 24 post-change ZIP remains intact with SHA-256 `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`.
- No prior backups overwritten or deleted.

## 8. Runtime verification

- Live Grocery API: NOT TESTED.
- MongoDB replica-set transaction behavior for a replacement flow: NOT TESTED.
- Grocery payment/refund settlement: BLOCKED / NOT AVAILABLE in current implementation.
- Expo Preview: NOT TESTED.
- Android/iOS device: NOT TESTED.
- No order, stock, payment or refund was mutated.

## 9. Required next safe step

Before implementing order-level replacement, provide a verified Grocery refund/additional-payment capability or explicitly approve a policy that excludes paid UPI orders from all replacement/rejection/expiry mutation until manual refund handling is operational. The latter still requires a clearly owned manual refund process, authoritative refund confirmation record, and a rule for when the order line/total may be finalized. After that, implement the proposal/decision workflow in a MongoDB transaction with CAS/idempotency and targeted tests.

**Final:** TASK 25 INCOMPLETE — PAYMENT/REFUND SAFETY BLOCKER. No source changes were made; Task 21–24 baseline remains preserved.
