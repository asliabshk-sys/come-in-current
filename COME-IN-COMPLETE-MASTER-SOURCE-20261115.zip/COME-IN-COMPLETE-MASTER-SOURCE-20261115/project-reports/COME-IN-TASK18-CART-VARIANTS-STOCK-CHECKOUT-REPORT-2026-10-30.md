# COME-IN Task 18 — Cart, Variants, Stock and Checkout Gap Audit

Date: 30 October 2026  
Working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
Result: **One verified backend input-validation gap fixed; focused source-contract tests pass. Runtime/database verification remains blocked/unavailable.**

## 1. Scope, evidence and preservation

Reviewed the actual working-copy source and available reports for Tasks 07–10 and 15–17.

Available reports read:
- `project-reports/COME-IN-TASK10-PAYMENTS-REFUNDS-NOTIFICATIONS-REPORT-2026-10-30.md`
- `project-reports/COME-IN-TASK15-RAZORPAY-CHECKOUT-REPORT-2026-10-30.md`
- `project-reports/COME-IN-TASK16-RAZORPAY-NATIVE-INTEGRATION-PLAN-2026-10-30.md`
- `project-reports/COME-IN-TASK17-RAZORPAY-NATIVE-BUILD-FEASIBILITY-REPORT-2026-10-30.md`

No separate Task 07, Task 08 or Task 09 narrative report was present in `project-reports/` or elsewhere in the working copy. For those tasks, inspected the actual implementation and relevant tests, including:
- `backend/tests/test_grocery_checkout_security_contract.py`
- `backend/tests/test_shopping_cart_variants_contract.py`
- `backend/tests/test_task5_task7_ui_implementation_contract.py`
- `backend/tests/test_task9_order_actions_contract.py`
- `backend/tests/test_targeted_tasks_9_12_15_18_21.py`

No secrets or `.env` values were opened or printed. No payment, refund, order, inventory or customer database operation was performed.

## 2. Existing cart and variant findings

### Frontend cart identity and quantity

- `frontend/src/store/cart.tsx` uses `productId::variant::variantId` as a distinct cart key for each selected variant; legacy product-only cart keys remain supported.
- A selected variant's unit, price and MRP are used for that cart line. Unknown saved variant IDs are not silently priced as the base product; they become unresolved cart entries that the customer must remove.
- Quantity is an integer count of the selected pack/unit. For example, a selected `1 kg` variant with quantity `2` means two 1 kg packs; fractional weights are not represented by the current cart schema.
- Cart increment checks the product/variant stock snapshot where present. The backend remains authoritative because the snapshot can become stale.
- `frontend/app/product/[id].tsx` carries the selected `variant.id` into add/increment and Buy Now. Sold-out/unavailable variants are disabled in the selector.
- `frontend/app/(tabs)/cart.tsx` renders separate rows by variant key and preserves the selected variant during quantity changes and replacement.

### Checkout and authoritative pricing

- `frontend/app/checkout.tsx` sends `product_id`, `variant_id` and integer `qty` to `POST /grocery/quotes`.
- The quote endpoint resolves current product and variant data from MongoDB. Client-provided price/name/fee values are not authoritative.
- Server-side totals are calculated from resolved prices and the delivery-fee threshold/rule. The quote expires after 10 minutes.
- Order creation derives lines from the stored quote rather than trusting the client's submitted item prices.
- The frontend requires the customer to review the server quote before submitting the order. Stock/quote errors clear the stale quote while preserving the cart for review.

## 3. Existing backend stock and order protections

Inspected `backend/server.py`:

- `ProductVariantIn` requires a stable variant ID, unit, positive price, non-negative integer stock and availability flag; duplicate variant IDs within a product are rejected.
- `_price_for` requires a valid selected variant when a product has variants and rejects missing, unavailable or nonexistent variants. A variant ID cannot be used to buy a non-variant product.
- `_resolve_grocery_lines` verifies product existence/availability, shop approval, directory-only restrictions, selected variant and stock, and one-shop-per-checkout.
- `_atomic_decrement_line` uses a conditional MongoDB update (`stock >= qty`) and decrements the exact base product or exact variant inside the transaction.
- `create_order` requires a scoped quote token and idempotency key, re-resolves server-side product data, checks price/stock snapshots and fulfillment/payment method, claims the quote once, then decrements stock and inserts the order in the same transaction.
- The unique `grocery_idempotency_scope` index protects duplicate submissions. Duplicate-key recovery returns the existing committed order where found.
- Unsupported transactions fail closed; there is no non-transactional stock-decrement fallback.
- Task 09 cancellation restores the exact base/variant stock in a transaction and uses conditional order-state updates to prevent repeat restoration.
- Grocery `online_razorpay` and `online_stripe` remain explicitly rejected by the backend. No payment or checkout payment behavior was changed.

These are source-level findings. The configured live MongoDB replica-set transaction behavior was not exercised in this task.

## 4. Verified gap and source fix

### Finding

The API accepted a list of cart rows without aggregating repeated rows for the same `(product_id, variant_id)`. The frontend's keyed cart normally emits one row per product/variant, but an API caller could submit repeated rows. `_resolve_grocery_lines` checked stock against each row independently. For example, two rows of quantity 6 against stock 10 could each pass the quote-time per-row check even though the combined requested quantity was 12.

The later conditional stock decrements inside the transaction prevented overselling: the second decrement would fail and the transaction would abort. However, the quote endpoint could issue a quote for a combined quantity that could never be fulfilled, leading to a predictable checkout failure. This is an input-validation/quote correctness gap, not evidence that stock could be oversold.

### Fix

Added `_aggregate_grocery_quote_lines` in `backend/server.py` and call it at the start of `_resolve_grocery_lines`:

- Canonicalizes product IDs and normalizes empty variant IDs to `None`.
- Combines duplicate rows for the same product and selected variant.
- Keeps different variant IDs separate.
- Rejects a combined quantity above 1,000 with `quantity_limit_exceeded`.
- Preserves the existing invalid-product error for malformed product IDs.

This causes quote-time stock validation to compare the aggregate quantity against the selected variant/base stock. The transactional conditional stock decrement remains unchanged as the final concurrency guard.

### Exact changed files

1. `backend/server.py` — added duplicate-line aggregation and wired it into Grocery line resolution.
2. `backend/tests/test_grocery_checkout_security_contract.py` — added source-contract and isolated helper tests for aggregation, variant separation and the combined quantity limit.

No frontend file, Restaurant file, payment/refund route, authentication, navigation, database schema/index, or package/dependency file was changed.

## 5. Targeted tests and actual results

Commands run from `backend/`:

```bash
python -m py_compile server.py
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_shopping_cart_variants_contract.py \
  tests/test_task9_order_actions_contract.py \
  tests/test_task5_task7_ui_implementation_contract.py \
  tests/test_p0_payment_checkout_completion.py
```

Actual results:
- `python -m py_compile server.py` — **PASS**.
- Pytest — **37 passed in 0.27s**.

The new aggregation behavior was executed in an isolated helper test using test doubles; the remaining tests are source-contract/regression tests. These results do **not** establish live MongoDB transaction behavior, API runtime behavior or device UI behavior.

## 6. Backups and integrity

### Pre-change archive

- File: `COME-IN-TASK18-PRE-CHANGE-20261030T072246Z.zip`
- Path: `/mnt/data/COME-IN-TASK18-PRE-CHANGE-20261030T072246Z.zip`
- Size: `4,111,196` bytes
- SHA-256: `0ea04f65a46d10aad672ded487fdf69e6a845b1b5a29868c8f7e386bf64c1670`
- `unzip -t`: **PASS** (no compressed-data errors)

### Post-change archive

The post-change archive includes the report and the exact working-copy files. Its size, SHA-256 and ZIP-integrity result are supplied in the Task 18 final delivery message to avoid a self-referential checksum inside the archive itself.

Archive exclusions applied to both ZIPs: `.env`/`.env.*`, secrets/key material, `node_modules`, `.git`, virtual environments, Python caches, pytest/mypy/ruff caches, Expo caches, build/dist/coverage directories and logs.

### Existing backup preservation

The following existing Task 07–10 and Task 15 backup archives were SHA-256 checked during Task 18 and their hashes matched the previously recorded values; none was overwritten or regenerated:

```text
31cbf1f71ce18151fa325342405a0ed1c8e601be65f0d28347a15958a53caff0  COME-IN-TASK07-PRE-CHECKOUT-STOCK-20261030T062624Z.zip
8a2cb348505313fa4fac22093153919df8e17af4f3b4e47f2dd096cf5446870d  COME-IN-TASK07-CHECKOUT-STOCK-POSTFIX-20261030T062813Z.zip
8a2cb348505313fa4fac22093153919df8e17af4f3b4e47f2dd096cf5446870d  COME-IN-TASK08-PRE-SELLER-IMPORT-20261030T063053Z.zip
65115b092b3ca9f422226bec095fbc233cc2feeae2ff0d2f36193102daac18bb  COME-IN-TASK08-SELLER-IMPORT-POSTFIX-20261030T063326Z.zip
0d6bd8dcfbbf547bfc161321523c8039b4bb9fad473a7c2d2705e7f18d17a77c  COME-IN-TASK09-PRE-CHANGE-20261030T063719Z.zip
914a1fd095b5f6eb345360101e05e3000eb849f695b29acaebab1055a5d13125  COME-IN-TASK09-POST-CHANGE-20261030T064437Z.zip
ee72d34081151a73b39f9d598bc0390f92b014b83862f6fc73eb4e4da1442c1d  COME-IN-TASK10-PRE-CHANGE-20261030T064654Z.zip
16e61d11f5e7f8c9feb5d8aceeb94f0dbbfba6363c3e5a09070d45b242d4c83d  COME-IN-TASK10-POST-CHANGE-20261030T065100Z.zip
6789ca0360e3451b70c1d5a856fc934762cb274869adbd324bbf5af021a02c97  COME-IN-TASK15-PRE-CHANGE-20261030T071134Z.zip
471ca816fad3a717772478ce14644dab3fc44890a04241874ad5e37d5bbb7659  COME-IN-TASK15-POST-CHANGE-20261030T071305Z.zip
```

## 7. Remaining blockers and verification matrix

- Live MongoDB / replica-set transactions and concurrent stock/order tests: **NOT TESTED**.
- Backend API against a running MongoDB instance: **NOT TESTED**.
- Expo/browser Preview: **NOT TESTED**.
- Android device/emulator: **NOT TESTED**.
- iPhone/iOS runtime: **NOT TESTED**.
- Razorpay sandbox/live provider: **NOT TESTED**; Task 17 remains blocked by native build environment. No payment was performed.
- No real payment, refund, customer transaction or production inventory mutation was performed.
- Task 10 payment/order cross-document consistency and `refund_uncertain` reconciliation remain unresolved and were not changed.
- Grocery Razorpay remains disabled.

## 8. Final assessment

**Source-level gap fixed and targeted tests passed.** Cart variant identity, integer pack quantity, server-authoritative pricing, quote checks, conditional stock decrement, transaction-only order creation and duplicate-order protections remain in place. The verified gap fixed here concerns repeated API rows for the same product/variant and quote-time aggregate stock validation.

This is not a production-readiness claim. Live MongoDB, API, Preview and device verification are still required. Task 18 stops here; no Task 19 work was started.
