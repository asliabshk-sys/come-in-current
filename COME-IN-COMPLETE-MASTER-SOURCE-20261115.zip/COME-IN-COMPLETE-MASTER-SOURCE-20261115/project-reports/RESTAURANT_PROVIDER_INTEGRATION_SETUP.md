# Restaurant shared-provider integration setup (pre-preview)

This document describes configuration required before enabling provider-dependent features. It does not activate a provider or claim runtime verification.

## Delivery serviceability

Restaurant delivery is now fail-closed unless the restaurant has an explicit `delivery_serviceable_pincodes` list. This uses verified postal coverage configured by the restaurant owner; it does not infer a radius, geocode an address, or treat GPS coordinates as proof of coverage.

- Configure through the existing authenticated `PATCH /api/restaurants/{restaurant_id}` contract, as the restaurant owner/admin, including the existing required restaurant fields and `delivery_serviceable_pincodes`, for example `['110001', '110002']`.
- Only valid six-digit Indian pincodes are accepted; empty/unconfigured coverage blocks delivery checkout.
- `GET /api/restaurants/{restaurant_id}/serviceability?pincode=110001` returns `serviceable`, `unconfigured`, `invalid_address`, `outside_configured_area`, or `unavailable`.
- `GET /api/restaurants?pincode=110001` filters discovery results to approved, available restaurants with an explicit matching coverage entry. Restaurant Home, Search, and Categories now load the shared saved-address list, validate the selected pincode, pass it into discovery, and refresh when the selection changes. The shared location text is used only as a fallback when the selected saved address has no valid pincode. A discovery match remains advisory; checkout and order creation revalidate.
- Delivery order creation independently repeats the serviceability check on the server. Client results are advisory only.
- This pincode allowlist is not a geospatial radius or distance-based provider. Restaurants must configure coverage only where they have verified their actual service.

## Razorpay checkout

Server intent/verification/webhook routes remain guarded and use server-side `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET`. Do not expose the secret or activate a live gateway. Customer-facing checkout remains disabled until the official SDK is added through the approved package workflow and a disposable Razorpay test-mode account/configuration is supplied. No credentials are committed in this project. Required isolated tests include success, failure, pending, cancellation, retry, duplicate submission/webhook, amount/currency/order mismatch, and delayed capture after cancellation.

## Rider tracking

The existing `/api/orders/{order_id}/tracking?kind=restaurant` endpoint returns status and an authorized last location if one has been submitted by an authorized operator. It does not constitute rider assignment or a delivery-partner integration. A `DeliveryProvider` protocol and `UnconfiguredDeliveryProvider` fail-closed adapter boundary are present in `backend/integrations/delivery_provider.py`; the location freshness helper rejects missing, malformed, naive, future, and stale timestamps. To complete live tracking, select a delivery partner and implement authenticated assignment, stable rider/order IDs, signed location updates, revocation, and verified ETA/map contracts. The default adapter returns unavailable with no coordinates or ETA.

## Notifications

No shared order-notification provider/event-delivery contract is present. Do not reuse password-reset email as an order-notification provider. A `OrderNotificationProvider` protocol and `UnconfiguredOrderNotificationProvider` fail-closed adapter boundary are present in `backend/integrations/order_notifications.py`; the default result is `not_sent`. Before enabling notifications, define authorized order events, opt-in/permission rules, recipient mapping, provider credentials in environment/secret storage, durable idempotency, retry/backoff and dead-letter handling. Use a test sink or provider sandbox before any real messages; no messages are sent by this source-only implementation.

## Frontend dependency setup

The frontend uses Yarn 1.22.22 pinned in `frontend/package.json`; the repository currently has no lockfile and no `node_modules`. Run the existing `scripts/cmd-guard.js --preinstall` guard and use the approved registry/network once available. Do not bypass the guard, disable TLS, or switch to an unverified mirror. Frontend typecheck/lint/build and browser runtime checks remain blocked until dependencies are installed safely.
