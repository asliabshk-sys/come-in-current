# COME-IN Task 25 — Out-of-Stock Replacement Audit Report

**Date:** 2026-10-30  
**Final status:** **TASK 25 INCOMPLETE — ISSUES REMAIN**

## 1. Active workspace and baseline

- Active workspace exists and is accessible: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`.
- No `.git` directory was present; Git status/history was not claimed.
- Task 24 report exists: `project-reports/COME-IN-TASK24-REPEAT-ORDER-REPORT-2026-10-30.md`.
  - SHA-256: `8890787e4ddd291e055d420ef38cd30c891456656ac410fb455ba6a701d8019c`.
- Task 24 post-change ZIP exists: `/mnt/data/COME-IN-TASK24-POST-CHANGE-20261030T082300Z.zip`.
  - Size: 4,132,820 bytes.
  - SHA-256: `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`.
  - `unzip -t`: PASS.
  - All 310 archived files compared byte-for-byte with the active workspace: 0 missing, 0 different.
- Task 23 post-change ZIP exists and passes integrity:
  - `/mnt/data/COME-IN-TASK23-POST-CHANGE-20261030T081012Z.zip`
  - Size: 4,122,279 bytes; SHA-256 `f1ada6d418a63d982db55adadc6778cf6d3fe306375947e5f2af090a8ae2a5b8`.
  - Compared against current source, 303 archived files: 0 missing; two expected differences in `frontend/app/orders.tsx` and `backend/tests/test_task9_order_actions_contract.py`, which Task 24 report identifies as Task 24 changes. The Task 24 archive matches the current workspace exactly.
- Task 23 report exists: `project-reports/COME-IN-TASK23-ORDER-TRACKING-REPORT-2026-10-30.md`.
- Task 21/22/23/24 source changes were not overwritten. No source files were modified in Task 25.

## 2. Existing replacement implementation audit

### Cart-level replacement exists

`frontend/app/(tabs)/cart.tsx` lines 160–171:
- When a live Cart item or selected pack is no longer present in the live catalog, the UI displays an unavailable notice.
- It offers up to three alternatives from the same shop and category, provided current stock is sufficient.
- It displays the current replacement price and quantity.
- Selecting an option calls `replaceLine(...)`.

`frontend/src/store/cart.tsx` lines 166–188:
- `replaceLine` accepts only a live replacement product.
- It requires same shop and category as the original Cart item.
- It checks replacement variant availability and stock, including existing replacement quantity.
- It replaces the Cart line; it does not update an already-created order.

### Order-level replacement does not exist

`frontend/app/orders.tsx`:
- Customer order history exposes order tracking/help and Grocery Repeat Order / eligible cancellation actions.
- No order-item replacement proposal, approve, reject, or confirm action exists.

`frontend/app/chand.tsx` lines 47–60:
- Wrong/damaged/missing-item guidance directs the customer to Help & Support.
- It explicitly says replacement/refund is not approved by the helper and depends on the support team's backend status.

`backend/server.py` lines 4143–4178:
- `/restaurant/support` creates a customer support ticket linked to an order only after checking that the order belongs to the authenticated customer.
- It records a category/message/request ID, not a proposed replacement product, variant, quantity, price delta, or customer decision.

`backend/server.py` lines 4184–4255:
- Seller support listing is scoped to current shop/restaurant ownership and current seller role.
- Seller ticket actions only transition support status (`open` → `in_progress` → `resolved`) using expected-status compare-and-set.
- No replacement proposal or order-item mutation is present.

`backend/server.py` lines 4258–4269:
- Admin support routes update support ticket status only; they do not create or confirm an order replacement.

Search of frontend/backend source and existing tests found no order replacement request/response model, order-item replacement API, customer approval/rejection endpoint, price-difference quote, or replacement-specific notification workflow.

## 3. Findings

| Area | Result | Evidence / limitation |
|---|---|---|
| Pre-checkout Cart replacement | PASS | Same-shop/category live catalog choice; current variant/stock checks. |
| Order-level replacement UI | FAIL | No customer proposal/approval/rejection workflow in order screens. |
| Customer order ownership for support ticket | PASS | Support creation checks `customer_id` against authenticated user. |
| Current seller ownership for support | PASS at source | Seller support routes require current seller role and current shop/restaurant owner match. |
| Admin support workflow | PASS for ticket status only | Admin can update support status; no replacement decision model. |
| Proposed replacement product/variant identity | FAIL | No order replacement entity or endpoint. |
| Current replacement price and price difference | FAIL | Cart UI displays current price only; no order-level repricing/quote for substitution. |
| Customer explicit approval/rejection | FAIL | No such API or UI action. |
| Duplicate replacement action protection | NOT IMPLEMENTED | No replacement action or idempotency contract exists. |
| Order/stock atomicity for replacement | BLOCKED | No replacement transaction exists to inspect or verify. Existing checkout transaction does not itself provide an order replacement operation. |
| Notifications | BLOCKED | Existing notification integration is not a confirmed delivered provider and has no replacement event workflow. |
| Restaurant order replacement | NOT IMPLEMENTED | Restaurant orders use a separate order/menu flow; no replacement workflow found. |
| Live API / MongoDB / device behavior | NOT TESTED | No runtime environment exercised. |

## 4. Why no source changes were made

The requested order-level workflow needs more than a UI button or reuse of Cart `replaceLine`. At minimum, it needs an explicit persisted replacement proposal tied to a specific order item, current product/variant identity, proposed quantity, current server-validated price and price delta, expiry/staleness rules, customer approve/reject decision, seller/admin authority, duplicate-action protection, and a safe order/stock/payment consistency strategy.

The current support-ticket schema and status-only endpoints do not represent those facts. Implementing this safely would require a new data/API contract and likely a transaction design for order items, stock reservation/decrement, total changes, and payment/refund consequences. The user explicitly instructed not to make broad schema/API/architecture changes without a safe basis. Therefore Task 25 stops at the audit and records the blocker rather than creating a misleading partial workflow.

No frontend, backend, schema, authentication, seller/admin, Restaurant Mode, payment, Cart, Checkout, Buy Now, Repeat Order, or Tracking source files were changed.

## 5. Targeted regression tests

Command (from `backend/`):

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_task9_order_actions_contract.py \
  tests/test_task12_customer_support_contract.py \
  tests/test_task13_seller_support_status_contract.py \
  tests/test_task14_seller_support_ui_contract.py \
  tests/test_task23_order_tracking_authorization_contract.py \
  tests/test_task24_repeat_order_contract.py \
  tests/test_task21_customer_shopping_workflow_contract.py \
  tests/test_task22_checkout_audit_contract.py
```

Result: **46 passed in 0.66s**.

These are existing source-contract tests; they do not prove live API/database behavior or that order-level replacement exists. No dependencies were installed. No live API, MongoDB, Expo Preview, Android, or iPhone test was run.

## 6. Backups and source changes

- No Task 25 source changes were made, so no Task 25 pre-change or post-change source ZIP was generated.
- The verified Task 24 post-change ZIP above remains the unchanged baseline/rollback artifact.
- No older backups were overwritten or deleted.
- This report is a new audit artifact only.

## 7. Runtime status and remaining blockers

| Environment / capability | Status |
|---|---|
| Source inspection and targeted tests | PASS |
| Live MongoDB / transaction behavior | NOT TESTED |
| Authenticated running backend API | NOT TESTED |
| Expo Preview | NOT TESTED |
| Android / iPhone | NOT TESTED |
| Order-level replacement workflow | NOT IMPLEMENTED |
| Replacement price-difference payment/refund handling | BLOCKED — no approved contract/transaction design |
| Replacement notifications | BLOCKED — no configured delivery provider/event workflow |

## 8. Next safe step

Before implementation, the product owner must decide the replacement policy: who may propose (seller, admin, or both); whether only same-shop/same-category substitutions are allowed; whether customer approval is mandatory for every price change and equal/lower price; what happens on rejection (keep original item, cancel that line, or support review); how paid orders handle additional charges/refunds; and whether replacement is limited to Grocery or also applies to Restaurant orders. Once these policy choices are explicit, design the smallest API/data contract and transaction plan before changing source.

**Final status: TASK 25 INCOMPLETE — ISSUES REMAIN.**
