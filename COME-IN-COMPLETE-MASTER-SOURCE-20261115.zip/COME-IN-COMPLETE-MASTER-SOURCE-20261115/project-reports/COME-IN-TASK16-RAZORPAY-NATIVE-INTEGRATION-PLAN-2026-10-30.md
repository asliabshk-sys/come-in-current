# COME-IN — Task 16: Native Razorpay Integration Feasibility Audit

Date: 30 October 2026  
Working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
Status: **AUDIT COMPLETE — implementation not started**

## 1. Scope and preservation

Read the Task 10 and Task 15 reports and inspected the current Expo configuration, package manifest and lockfile, Replit/preview scripts, Restaurant checkout and confirmation screens, API helper, and the existing Restaurant payment/order routes in `backend/server.py`.

This was a read-only application audit. The only file created/changed for this task is this report. No application source, package manifest, lockfile, app configuration, native configuration, backend route, database or existing backup was changed. No package was installed and no dependency/network/DNS retry was attempted. No credentials or `.env` values were read or printed.

## 2. Actual Expo and build configuration found

| Item | Evidence in working copy | Finding |
|---|---|---|
| Expo SDK | `frontend/package.json`: `expo` `57.0.25` | Expo SDK 57 |
| React Native | `frontend/package.json`: `react-native` `0.86.3` | RN 0.86.3 |
| React | `frontend/package.json`: `react` `19.2.3` | React 19.2.3 |
| Package manager | `packageManager`: `yarn@1.22.22...` | Yarn Classic 1.22.22 |
| Lockfile | `frontend/yarn.lock` | Present; Yarn v1 lockfile |
| Expo config | `frontend/app.json` | Static Expo config; iOS and Android identifiers and standard plugins exist |
| Dynamic Expo config | No `app.config.js`, `.ts`, etc. found | Not present |
| EAS config | No `frontend/eas.json` | No checked-in EAS build profiles |
| Native projects | No `frontend/android/` or `frontend/ios/` | No generated/committed native project in this working copy |
| Dev client | `expo-dev-client` absent from dependencies and lockfile | No development-client dependency configured |
| Razorpay SDK | `react-native-razorpay` absent from dependencies and lockfile | Not installed/configured |
| Native build scripts | `android`/`ios` scripts call `expo start --android` / `expo start --ios`; `start`, `web`, `preview` run Expo web | These are start/launch scripts, not an explicit native build pipeline |
| Workspace workflow | Root `.replit` runs `scripts/replit-run.sh`; `scripts/preview.sh` and README describe browser Preview | Existing documented workflow is Replit/Emergent web Preview, not a verified mobile build workflow |

### Expo Go vs Development Build vs EAS Build

**The actual installed runtime/workflow cannot be established from this source tree.** The project does not contain an EAS profile, `expo-dev-client`, native platform folders, or a recorded build artifact/configuration proving Expo Go, a custom development build, or EAS Build was used. The starter `frontend/README.md` lists Expo Go, emulators and development builds as possible ways to open an Expo app; that is generic guidance, not evidence of which client was actually used.

Therefore:

- Expo Go use: **NOT CONFIRMED**.
- Custom development build use: **NOT CONFIRMED / not configured in this source tree**.
- EAS Build use: **NOT CONFIRMED / no `eas.json` found**.
- Existing verified workflow: **web Preview scripts only**.

The Razorpay native module cannot be added to the existing browser Preview and expected to work in an unmodified Expo Go client. A custom native app binary (development build or production build) is required.

## 3. Official documentation consulted

1. Razorpay React Native Standard prerequisites and supported markets:  
   https://tfs.np.razorpay.in/docs/payments/payment-gateway/react-native-integration/standard
2. Razorpay React Native Android integration, including Expo prebuild instructions, server-created Orders API requirement and Android build notes:  
   https://tfs.np.razorpay.in/docs/payments/payment-gateway/react-native-integration/standard/integration-steps-android
3. Razorpay React Native iOS integration, including Expo prebuild, CocoaPods and iOS UPI Intent scheme configuration:  
   https://tfs.np.razorpay.in/docs/payments/payment-gateway/react-native-integration/standard/integration-steps-ios
4. Razorpay-maintained React Native SDK repository and README:  
   https://github.com/razorpay/react-native-razorpay
5. Razorpay-maintained SDK `package.json` (repository master currently declares version `3.0.0`, React Native peer dependency `>=0.66.0`, and a Codegen module configuration):  
   https://github.com/razorpay/react-native-razorpay/blob/master/package.json
6. Expo development builds:  
   https://docs.expo.dev/develop/development-builds/introduction/
7. Expo development build FAQ / Expo Go native-module limitations:  
   https://docs.expo.dev/develop/development-builds/faq/
8. Expo custom native code and config plugin workflow:  
   https://docs.expo.dev/workflow/customizing/
9. Expo SDK 57 release notes (SDK 57 includes React Native 0.86):  
   https://expo.dev/changelog/sdk-57
10. React Native version compatibility matrix:  
    https://react-native.dev/

## 4. SDK and compatibility findings

### Native SDK package

The official Razorpay React Native wrapper is `react-native-razorpay`. It wraps Razorpay's native Android and iOS Standard Checkout SDKs. Razorpay's current React Native integration pages explicitly show installation with Expo and say to run `expo prebuild` before building/running the native app. The package is therefore a plausible integration route for an Expo prebuild/development-build project; it is not an Expo Go-only JavaScript package.

The current repository `package.json` on the Razorpay-maintained repository reports version `3.0.0`, peer dependency `react-native >=0.66.0`, and a React Native Codegen module declaration. This is encouraging for a modern React Native app, but **it is not a published compatibility guarantee for this exact Come-In combination (Expo 57.0.25 / RN 0.86.3)**. The public docs do not provide an Expo SDK 57 / RN 0.86.3 compatibility matrix or a verified Come-In build. There is also an older Expo-related GitHub issue reporting New Architecture compatibility concerns for SDK 54+; it is not proof that current package 3.0.0 fails, but it reinforces the need for an isolated compile test before touching the main app:

https://github.com/razorpay/react-native-razorpay/issues/510

**Compatibility verdict:** Android and iOS are officially supported platforms for the Razorpay React Native wrapper, and Razorpay documents Expo prebuild. Compatibility with Come-In's exact SDK 57 / RN 0.86.3 / New Architecture combination remains **UNVERIFIED** until the exact package release is built and tested on both platforms. Do not assume peer-dependency range alone proves binary compatibility.

### Android

- Razorpay's Android instructions explicitly support the React Native wrapper and Expo prebuild.
- The native dependency must be autolinked/compiled into the Android application; adding only a JS import is insufficient.
- Razorpay's Android page mentions a minimum Android `minSdkVersion` of 19 for its integration. Come-In's Expo SDK 57 / RN 0.86.3 generated native defaults may impose a higher floor. Preserve the Expo/RN-generated value; do not lower it to 19 just to match older Razorpay guidance.
- If R8/ProGuard minification is enabled in the eventual release build, review and apply the keep rules documented by Razorpay to the generated Android build configuration.
- After adding the native dependency or changing app config, generate/update native project files and rebuild the Android binary. A Metro reload or browser Preview is not enough.

### iOS

- Razorpay's iOS React Native wrapper is supported and its current integration instructions include Expo prebuild.
- CocoaPods installation is part of the iOS native build. The iOS build requires macOS/Xcode (local build) or a supported cloud native builder such as EAS Build.
- Razorpay documents iOS UPI Intent as optional and requires `LSApplicationQueriesSchemes` in `Info.plist`. For an Expo CNG project, configure this in `frontend/app.json` under `expo.ios.infoPlist`, rather than hand-editing generated `ios/Info.plist`. Use the current official list appropriate to the required UPI apps, not just an old abbreviated list copied blindly.
- Razorpay's older iOS page says iOS 10 / Xcode 11 / Swift 5.1, but these are old minimums and do not establish compatibility with the current Expo/RN/Xcode toolchain. Keep Expo SDK 57's supported iOS deployment target and validate CocoaPods/Xcode compilation.
- Build and test on a real iPhone for app-switch return/UPI Intent behavior; simulator success alone is not sufficient for app-to-app UPI behavior.

### Expo / native build requirements

- Razorpay's official Android and iOS pages explicitly instruct Expo users to run `expo prebuild`, then build/run the native app.
- Expo documents that libraries with custom native code require a development build or production native build; Expo Go only includes its fixed native modules and cannot dynamically acquire a new native SDK.
- The Razorpay repository README does not identify a dedicated Expo config plugin for this SDK. The documented Expo path is prebuild plus native autolinking, with the optional iOS UPI schemes configured in app config. This must be checked against the exact package release selected for implementation.
- Any native dependency or app config change requires a new native build for each platform. Existing installed APK/IPA/dev-client binaries will not acquire the SDK through a JS-only refresh.

## 5. Existing Come-In backend payment flow — reuse, do not duplicate

The existing Restaurant flow already has the server-side pieces required for a native checkout:

1. `POST /restaurant/orders` (`backend/server.py`, around line 3745) validates the authenticated customer, restaurant support for the selected method, delivery/pickup rules, menu item/variant/add-on availability and server-side prices, computes the INR total, and saves a Restaurant order as `pending_payment` when `payment_method="razorpay"`.
2. `GET /restaurant/payments/config` (around line 3869) exposes whether Razorpay is configured and the **public** key ID only.
3. `POST /restaurant/orders/{order_id}/payment-intent` (around line 3874) scopes the order to the signed-in customer, checks the pending Razorpay order, creates/reuses the Razorpay gateway order server-to-server, and returns the gateway order ID, amount, currency and public key ID.
4. `POST /restaurant/payments/verify` (around line 3916) validates customer/order/payment linkage, HMAC signature, and then queries Razorpay server-to-server to confirm captured status, exact order ID, INR currency and exact amount before marking the Come-In order paid.
5. `POST /restaurant/payments/razorpay-webhook` (around line 3993) validates the webhook signature and provider event/payment details; this remains the asynchronous provider notification path.
6. `POST /restaurant/orders/{order_id}/payment-retry` (around line 3904) exists for eligible pending/failed orders.

The future mobile checkout should call these existing endpoints and should not create a second payment/order backend. The native SDK success callback is only input to the existing server verification endpoint; it must never directly mark an order paid in the app. Cancellation, SDK errors, app termination, delayed capture and webhook arrival must be handled as pending/failed/uncertain until the backend/provider confirms the final state.

### Important backend blocker before activation

Task 10 documents that verification and webhook processing update payment/order documents using separate database writes, and atomic cross-document consistency has not been demonstrated. The native UI must not be enabled for real customers until this is resolved or a documented reconciliation design is proven, including races between the SDK callback, webhook, retry and repeated verification. This is a prerequisite, not a reason to create a parallel payment service.

### Grocery remains disabled

`backend/server.py` rejects Grocery `online_razorpay` checkout with `payment_method_unavailable`. The native integration plan is **Restaurant Mode only**. Do not expose Razorpay in `frontend/app/checkout.tsx` or enable Grocery online payments unless a separately audited and tested backend design supports Grocery payment intents, verification, webhook reconciliation, stock/order atomicity, refunds and idempotency.

## 6. Sandbox credentials and isolated database requirements

### Razorpay sandbox

For an isolated test environment, obtain disposable Razorpay **Test Mode** credentials from the account dashboard:

- Test Key ID — public identifier; passed to the native SDK only after the backend returns it.
- Test Key Secret — backend-only; used for server-side Orders API and provider payment lookup.
- Test Webhook Secret — backend-only; used to validate test webhook signatures.
- A reachable test webhook URL configured in Razorpay Test Mode, with the exact existing webhook route and subscribed events.
- Razorpay test payment instruments/scenarios from the official dashboard/docs; no live payment method or Live Mode keys.

Keep secrets in the backend secret manager/environment only. Do not put the Key Secret or Webhook Secret in `frontend/.env`, `EXPO_PUBLIC_*`, app config, source code, logs, ZIP reports or the app binary. Do not print them during verification. The backend `.env.example` documents the variable names `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET`; this audit did not inspect any real `.env` values.

### MongoDB

Use a separate disposable test database on a MongoDB **replica set** (single-node replica set is acceptable for isolated integration testing if configured correctly). Do not point payment tests at production or the user's real app database. Supply test-only `MONGO_URL`, `DB_NAME`, and a unique test `JWT_SECRET`; keep database data disposable and isolated. Verify transactions, indexes, duplicate idempotency submissions, callback/webhook races, payment retry, refund uncertainty and order/payment reconciliation. A standalone MongoDB server without replica-set transaction support is not an adequate substitute for these tests.

## 7. Recommended minimal implementation plan (future task only)

1. **Compatibility spike in a disposable branch/copy:** pin and inspect the exact published `react-native-razorpay` release; confirm its native Android/iOS source, Codegen/New Architecture support, autolinking and Expo prebuild behavior against SDK 57 / RN 0.86.3. Do not upgrade Expo/RN as a first reaction.
2. **Build baseline before UI work:** add only the selected native SDK dependency using the declared Yarn manager; update `frontend/yarn.lock`; apply only the native app-config changes actually required. Generate native projects in the isolated copy and compile Android and iOS. If SDK 57 incompatibility is found, stop and report it rather than patching around it or downgrading Expo/RN without approval.
3. **Choose a real build route:** either local Expo prebuild + `expo run:android` / `expo run:ios` with Android Studio/JDK/SDK and macOS/Xcode, or explicitly configure EAS Build with a checked-in `eas.json` and the required account/build credentials. This repository currently documents neither route as configured. For iOS from a non-Mac environment, a supported cloud builder is required.
4. **Close backend atomicity/reconciliation gap:** test and harden existing verify/webhook state transitions on the isolated replica set; preserve the current server-side amount/currency/capture checks, ownership checks and idempotency. No parallel payment backend.
5. **Restaurant-only customer UI:** add the Razorpay option only when the backend config and selected restaurant support it. Create the Come-In Restaurant order first, request its payment intent, launch native checkout using the returned public key ID + gateway order ID + server amount/currency, then submit the SDK callback values to the existing `/restaurant/payments/verify` endpoint. Show success only from the backend's verified response/order state.
6. **Failure/recovery:** handle customer cancellation, SDK errors, duplicate callbacks, app background/termination, delayed capture, webhook-before-callback, callback-before-webhook, retry and uncertain network outcomes. Refresh order status from the backend before allowing another attempt.
7. **iOS UPI Intent:** if included in the required payment methods, add the documented `LSApplicationQueriesSchemes` to Expo iOS config and test installed UPI app discovery and return-to-Come-In on physical devices.
8. **Verification gate:** run targeted backend tests, frontend typecheck, native Android debug/release builds, iOS simulator/device builds, sandbox test payments and webhook replay/concurrency tests. Only after all pass should the customer-facing Razorpay choice be enabled. Keep Grocery online payments disabled.

## 8. Exact files likely to change in a future implementation task

| File | Why it may need a change | Status in this audit |
|---|---|---|
| `frontend/package.json` | Add the approved exact `react-native-razorpay` dependency; optionally `expo-dev-client` if the chosen dev-build workflow requires it | Not changed |
| `frontend/yarn.lock` | Lock the selected SDK and transitive native dependencies | Not changed |
| `frontend/app.json` | Add only required iOS UPI `infoPlist.LSApplicationQueriesSchemes` and/or verified config-plugin settings | Not changed |
| `frontend/eas.json` | Only if EAS Build is selected; define dev/preview/production profiles | Does not exist; not created |
| `frontend/app/restaurant/checkout.tsx` | Restaurant-only Razorpay selection, payment-intent call, native SDK launch, callback submission and safe failure/retry UI | Not changed |
| `frontend/app/restaurant/order-confirmation.tsx` | Display verified payment state separately from order creation/restaurant acceptance | Not changed |
| `frontend/src/restaurant/api.ts` | Add typed wrappers for existing payment config/intent/verify/retry endpoints if useful; do not duplicate backend routes | Not changed |
| `backend/server.py` | Only if isolated tests require targeted atomicity/idempotency/reconciliation hardening of existing Restaurant verify/webhook flows | Not changed |
| `backend/tests/test_task16_razorpay_native_payment_contract.py` (new) | Contract tests for native payment flow assumptions, server verification, callback/webhook idempotency and Grocery separation | Not created |
| `backend/tests/` (new focused replica-set integration test, if infrastructure supports it) | Verify transaction and callback/webhook concurrency on isolated replica set | Not created |
| `project-reports/COME-IN-TASK16-RAZORPAY-NATIVE-INTEGRATION-PLAN-2026-10-30.md` | This feasibility and implementation plan | **Created** |

Generated `frontend/android/` and `frontend/ios/` directories may appear during a future prebuild/build task. They are not present now. If the project continues using Expo Continuous Native Generation, prefer app config/config plugins over hand-editing generated native files; if native folders are intentionally committed, preserve and review those files as source changes.

## 9. Verification matrix for this audit

| Check | Result |
|---|---|
| Task 10 and Task 15 reports read | YES |
| Actual Expo/package/build configuration inspected | YES |
| Official Razorpay and Expo docs researched | YES |
| Application source modified | NO |
| Package installed / lockfile changed | NO |
| Native configuration changed / prebuild run | NO |
| Preview tested | NO |
| Android build/device tested | NO |
| iPhone/iOS build/device tested | NO |
| Razorpay sandbox tested | NO |
| Live MongoDB tested | NO |
| Replica-set payment integration tested | NO |
| Real payment performed | NO |

## 10. Final decision

**Feasibility: conditionally feasible, but exact SDK 57 / React Native 0.86.3 compatibility is not yet proven.** The smallest supported direction is the official `react-native-razorpay` native wrapper plus Expo prebuild and a custom development/production native build, while reusing the existing Restaurant payment-intent, verification and webhook backend. Expo Go and web Preview alone are insufficient.

Do not begin implementation until the selected SDK release has passed a clean Android and iOS compile spike, the actual native build route is chosen, disposable Test Mode credentials and an isolated replica-set database are available, and the Task 10 payment/order consistency gap has a tested resolution.

No packages were installed. No application source or configuration was changed. No Preview, Android, iPhone, sandbox or live MongoDB test was performed. No real payment was performed. Task 16 is an audit/plan only; implementation has not started.
