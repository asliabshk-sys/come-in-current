# COME-IN — Grocery Payment & Refund Infrastructure Audit / Design

**Date:** 2026-10-30  
**Scope:** Audit Grocery UPI, COD, Pay-at-Shop, gateway payment, refunds, additional payments, webhook security and the implications for Task 25 Order Replacement.  
**Final decision:** **BLOCKED — no safe Grocery gateway/refund implementation can be enabled from the current workspace configuration.**  
**Source changes:** None. No payment/refund was executed.

## 1. Workspace and baseline

- Active working copy exists and is accessible at `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`.
- No `.git` directory exists; no Git status/history is claimed.
- Task 24 post-change archive exists at `/mnt/data/COME-IN-TASK24-POST-CHANGE-20261030T082300Z.zip`.
- ZIP integrity: `unzip -t` PASS.
- ZIP size: 4,132,820 bytes.
- SHA-256: `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`.
- Archive/source comparison after stripping the archive's top-level folder prefix: 310 archived files, 0 missing, 0 different.
- Task 21–24 source files were not modified. No archive was extracted over the active workspace.
- `backend/.env` and `frontend/.env` are absent. Runtime environment variables `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, `MONGO_URL`, and `BANK_DATA_ENCRYPTION_KEY` are absent. Only presence/absence was checked; no secret values were read or disclosed.

## 2. Existing Grocery payment flows

### 2.1 UPI — manual receipt confirmation, not gateway verification

**Source:** `backend/server.py`

- `OrderIn` accepts `upi` as a Grocery payment method (around line 527).
- `create_order` (around lines 2275 onward) checks that the Shop enables UPI and has `public_upi`; it creates an `upi://pay` URI for the current server-quoted amount (around lines 2359–2361).
- The Grocery order is stored with `payment_status="awaiting_upi_payment"` and `status="pending_payment"` (around lines 2348–2351).
- `confirm_grocery_upi_payment` at `POST /orders/{order_id}/confirm-upi-payment` (around lines 2430–2454) explicitly says the UPI deep link cannot prove capture. A current Shop owner or Admin manually confirms after checking their bank/UPI statement. The route then changes the Grocery order's `payment_status` to `paid` and status to `pending`.
- This route does not verify a provider payment ID, gateway order ID, captured status, currency or exact captured amount; it does not create a separate Grocery payment record or persist a bank transaction reference/receipt evidence.
- The compare-and-set filter limits the transition to `awaiting_upi_payment` + `pending_payment`, but the route does not inspect `modified_count` or write a dedicated payment audit event.
- The Shop page UI (`frontend/app/shop/[id].tsx`, around lines 233–240) warns that showing the UPI handle does not verify payment.

**Finding:** PASS — the code does not trust the customer's UPI callback as proof. FAIL for automated/provider-verified Grocery settlement and for a complete auditable payment record. A Shopkeeper's manual bank-statement attestation is not a gateway capture verification.

### 2.2 COD and Pay-at-Shop

**Source:** `backend/server.py`, `frontend/app/seller-earnings.tsx`.

- `create_order` records `cod_pending` for `cod`; other supported manual methods (`cash_shop` / `pickup`) are recorded as `pay_at_shop_pending` (around lines 2348–2351).
- `confirm_manual_cash_collection` at `POST /earnings/orders/{kind}/{order_id}/cash-collected` (around lines 3008–3045) requires current `shopkeeper` role, validates current Grocery Shop ownership using `_assert_shop_owner`, requires explicit `confirmed=true`, and only accepts `cod_pending` or `pay_at_pickup_pending`. It only permits confirmation after order status is `delivered` or `picked_up`; then it writes `cash_collected`, actor/time/note and a financial audit entry.
- `frontend/app/seller-earnings.tsx` (around line 30) only renders the cash confirmation action for `cod_pending` or `pay_at_pickup_pending`.
- **Existing mismatch:** Grocery `cash_shop` / `pickup` creation stores `pay_at_shop_pending`, but cash collection endpoint and UI expect `pay_at_pickup_pending`. The current Pay-at-Shop payment state therefore cannot use that cash collection action as written. This audit did not change it.
- COD confirmation is a manual physical cash attestation after delivery/pickup; it is not a payment-provider settlement.

**Finding:** PASS — COD cash confirmation has role, ownership, delivery/pickup and conditional update checks. FAIL — Pay-at-Shop status mismatch prevents the expected confirmation workflow. NOT TESTED — live database concurrency and ledger writes.

### 2.3 Grocery gateway restrictions

**Source:** `backend/server.py`, `create_order` around lines 2275–2311.

- Grocery checkout explicitly rejects `online_razorpay` and `online_stripe` with `payment_method_unavailable`.
- No Grocery payment-intent, payment-verification, payment-retry or gateway webhook route exists.
- Grocery orders are stored in `db.orders`; there is no Grocery-specific gateway payment collection in the inspected payment flows.

**Finding:** PASS — unsupported online gateway methods fail closed. FAIL — no enabled Grocery gateway payment infrastructure exists.

## 3. Existing Restaurant-only gateway/refund implementation (not reusable as Grocery)

**Source:** `backend/server.py`.

- `restaurant_payment_config` at `GET /restaurant/payments/config` (around lines 3906–3909) exposes only the public Razorpay key when both server key ID and secret are configured.
- `create_restaurant_payment_intent` at `POST /restaurant/orders/{order_id}/payment-intent` (around lines 3911–3940) creates a Razorpay order and persists a `db.restaurant_payments` record.
- `verify_restaurant_payment` at `POST /restaurant/payments/verify` (around lines 3953–4008) validates HMAC signature, looks up the provider payment server-side, and checks exact gateway order ID, captured status, INR currency and amount before marking the Restaurant order paid.
- `razorpay_webhook` at the Razorpay webhook route (around lines 4030 onward) validates the raw-body HMAC signature, handles event IDs/duplicates through `db.restaurant_payment_events`, checks payment/order amount and currency, and handles late payment capture after cancellation as a reconciliation case.
- `admin_refund_restaurant_order` at `POST /admin/restaurant/orders/{order_id}/refund` (around lines 4271–4312) only reads `db.restaurant_orders` and `db.restaurant_payments`. It requires a paid order with a linked gateway payment ID, claims refund state before provider call, blocks ambiguous/concurrent retries, stores `refund_uncertain` on ambiguous provider outcomes, and only writes a financial reversal when provider status is `processed` or `refunded`.
- `test_task10_payment_refund_notification_contract.py` checks these Restaurant-specific protections.

**Finding:** PASS — Restaurant gateway/refund source has signature, amount/currency, idempotency/duplicate-event and uncertainty protections at source level. NOT TESTED — provider sandbox, live credentials or webhook delivery. **This integration is scoped to Restaurant collections and routes and is not used for Grocery.**

## 4. Shared financial records and support

- `confirm_manual_cash_collection` writes a manual cash audit event to `db.financial_audit` and invokes `_record_finalized_order_ledger` after successful manual cash confirmation.
- `_record_finalized_order_ledger(order, kind)` around lines 2924–2955 supports a `grocery` kind for Grocery Shop financial snapshots.
- `_record_refund_reversal(order, kind, refund_id)` around lines 2958–2980 is parameterized by order kind, but the only refund route/caller found is the Restaurant refund route. There is no Grocery refund request, provider call, status reconciliation or Grocery caller.
- Existing `/restaurant/support` can create order-linked support tickets for `order_kind="grocery"` after customer ownership validation. This creates a support ticket only; it is not a refund approval, refund request or payment action. The frontend `chand.tsx` also explicitly describes support as not being refund approval/payment.

**Finding:** PASS — a generic financial ledger/reversal helper and Grocery financial snapshots exist. FAIL — no Grocery provider refund orchestration or reconciliation path calls the reversal helper.

## 5. Environment and provider configuration

- `backend/.env.example` documents `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` and `RAZORPAY_WEBHOOK_SECRET`, but an example variable name is not evidence of configured credentials.
- Actual `backend/.env` and `frontend/.env` files are absent.
- Runtime environment presence checks found all of `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`, `MONGO_URL`, and `BANK_DATA_ENCRYPTION_KEY` absent.
- No provider sandbox credentials, test webhook secret, sandbox webhook URL or sandbox confirmation evidence was available.
- No network calls, provider requests, production payment account, customer funds or real refunds were used.

**Finding:** BLOCKED — provider configuration and sandbox environment are unavailable. No sandbox verification was attempted.

## 6. Recommended Grocery-only design (not implemented)

The existing FastAPI/MongoDB architecture can be extended without reusing Restaurant routes or collections. The following is a proposed design only; implementation must wait for provider configuration and sandbox verification.

### 6.1 Separate Grocery payment domain

- Keep Grocery orders in `db.orders`.
- Add a Grocery-scoped payment collection, e.g. `db.grocery_payments`, with unique indexes on `order_id`/payment attempt and provider IDs; store customer ID, order ID, amount in paise, currency `INR`, provider, provider order/payment IDs, status, refund totals/status, timestamps and idempotency keys.
- Add a separate Grocery webhook-event collection with a unique provider event ID. Do not point Grocery routes at `restaurant_payments` or `restaurant_payment_events`.
- Use Decimal/paise integer arithmetic for all payment/refund amount comparisons; do not accept client-supplied totals.

### 6.2 Grocery API surface

Candidate routes, subject to existing route naming conventions:

- `GET /grocery/payments/config` — expose only public key and enabled status; never expose secrets.
- `POST /grocery/orders/{order_id}/payment-intent` — authenticated customer ownership, only eligible unpaid Grocery order, server-derived exact amount, stable idempotency key, and one active intent per order/amount.
- `POST /grocery/payments/verify` — customer ownership plus HMAC signature and server-side provider lookup; require exact provider order/payment IDs, captured status, INR currency and exact paise amount before a transactional payment/order state update.
- `POST /grocery/payments/webhook` — raw-body signature verification, unique event ID, payload/order/payment/amount validation, replay-safe processing, late capture after cancellation routed to reconciliation rather than silently reviving the order.
- `POST /admin/grocery/orders/{order_id}/refund` — Admin-only; only a captured/verified Grocery payment; bounded amount no greater than captured less prior confirmed refunds; claim with compare-and-set/idempotency before provider call; store provider refund ID/status; ambiguous timeout becomes `refund_uncertain` and must not be retried until provider reconciliation.
- `POST /admin/grocery/payments/{payment_id}/reconcile` (or equivalent controlled reconciliation workflow) — only after a provider dashboard/API evidence check; immutable actor, reference, timestamp and evidence metadata; no manual status flip without provider confirmation.

### 6.3 Refund state model

Distinguish internal request state from provider settlement:

`not_requested → refund_requested → pending → processed/refunded` or `refund_failed`; ambiguous timeout becomes `refund_uncertain`.

- `refund_requested` means the application claimed/submitted a request; it is not a successful refund.
- `pending` means provider accepted but has not confirmed completion; it is not successful.
- Only provider-confirmed `processed`/`refunded` can set the confirmed refunded amount and trigger the idempotent Grocery financial-ledger reversal.
- Never update an order total or replacement line as if funds were returned before the required provider confirmation.

### 6.4 Additional payment for replacement

- Create a distinct Grocery replacement-difference payment attempt tied to `order_id`, `replacement_proposal_id`, exact difference amount and customer; never reuse an old payment intent for a different amount.
- Proposal acceptance alone does not settle the difference. Final replacement transition must wait for a provider-confirmed captured payment of the exact difference, or be blocked if no verified Grocery gateway exists.
- Enforce unique idempotency scope per proposal/difference attempt and provider payment ID; duplicate callbacks must be no-ops.

### 6.5 Atomic order/stock/payment invariants

- Use MongoDB transaction and compare-and-set state transitions for payment record, order status/total, replacement proposal, inventory reservation/decrement/restore and audit history wherever those records are in the same MongoDB transaction.
- External provider calls cannot be part of a MongoDB transaction. Use an explicit claimed/pending state before calling provider; persist provider identifiers/results; treat timeouts as uncertain and reconcile before retry.
- If transaction support is unavailable, fail closed. Do not perform a non-transactional stock/order/payment fallback.
- Verify the existing Grocery inventory reservation semantics before implementing replacement: order creation decrements stock transactionally, so replacement must atomically reserve replacement stock and restore/reconcile the original reservation.

### 6.6 Manual UPI treatment

- Until a verified provider/bank integration exists, retain the current UPI flow only as a clearly labelled manual bank-statement attestation.
- Before treating such a payment as refundable for replacement, persist the authorized actor, confirmation time, exact amount, UPI/bank transaction reference and an auditable confirmation event; require an explicit policy for duplicate/reversed/incorrect manual attestations.
- A manual attestation without a transaction reference is insufficient for automated refund execution.

### 6.7 COD / Pay-at-Shop

- Preserve COD as manual cash collection after delivery/pickup with current Shop ownership checks.
- Fix the existing `pay_at_shop_pending` versus `pay_at_pickup_pending` contract mismatch in a separately targeted change after confirming the intended status naming; update creation, endpoint, UI and tests together.
- Do not mark cash collected based only on a customer or seller UI click without the existing explicit seller attestation and audit trail.

## 7. Security risks and mitigations

| Risk | Required mitigation |
|---|---|
| Customer claims payment via UPI callback | Never trust callback; provider capture lookup/webhook or documented manual bank attestation only |
| Duplicate payment intent/refund | Unique idempotency keys, unique provider IDs, CAS claim and replay-safe webhook events |
| Wrong amount/currency | Server-derived paise amount and exact INR/provider verification |
| Forged webhook | HMAC over raw body with secret; constant-time comparison; event ID deduplication |
| Provider timeout after request accepted | `refund_uncertain`/payment uncertain state; reconcile before retry |
| Customer accesses another order | Authenticated `customer_id` ownership on every Grocery payment route |
| Demoted seller accesses order | Current role plus live Shop ownership check on every seller action |
| Payment/order/stock disagreement | MongoDB transaction for internal state; external provider operations use pending/claim state and reconciliation |
| Restaurant/Grocery cross-domain leakage | Dedicated Grocery routes, collections, indexes and tests; no Restaurant collection reuse |
| Secret exposure | Server-only credentials; only public key ID returned to app; never log or return secrets |

## 8. Targeted tests required before enabling Grocery payments

1. Grocery customer order ownership and unauthorized customer rejection.
2. Current Shopkeeper role and live Shop ownership; demoted former owner rejected.
3. Payment intent only for eligible unpaid Grocery orders; exact current amount and INR.
4. Duplicate intent request returns same active intent; no duplicate payable gateway order.
5. Signature failure, wrong provider order ID, wrong payment ID, wrong amount, wrong currency and non-captured payment rejected.
6. Duplicate webhook event is a no-op; invalid signature rejected; late capture after cancellation enters reconciliation.
7. Refund only for verified captured Grocery payment; maximum refundable balance enforced.
8. Duplicate refund claim blocked; timeout enters uncertain state and cannot be retried until reconciliation.
9. Provider refund `pending` is not displayed as successful; only confirmed `processed`/`refunded` updates refunded amount and ledger reversal.
10. Partial refund arithmetic and repeated partial-refund cumulative cap.
11. Additional-payment attempt bound to exact replacement proposal and difference; approval alone cannot finalize replacement.
12. Transaction failure rolls back order, stock, payment and replacement state; unsupported transactions fail closed.
13. Pay-at-Shop status consistency across order creation, seller earnings UI, collection route and cancellation policy.
14. Regression checks for Task 21 Buy Now isolation, Task 22 Checkout blur cleanup, Task 23 tracking authorization and Task 24 Repeat Order quantity/stock behavior.
15. Separate provider sandbox tests for payment capture, refund pending/processed/failed, duplicate webhook and timeout/reconciliation; these must use sandbox credentials only.

## 9. Test execution in this audit

No source files were changed and no live services were started.

- Targeted source-contract tests:
  `PYTHONPATH=. python -m pytest -c /dev/null -q tests/test_task10_payment_refund_notification_contract.py tests/test_grocery_checkout_security_contract.py tests/test_financial_security_contract.py`
  **26 passed in 0.25s.**
- Broader combined check adding `tests/test_shared_system_integration_contract.py`:
  **41 passed, 1 failed in 0.63s.** The single failure is `test_shared_tracking_endpoint_supports_restaurant_orders_without_fake_coordinates`, whose assertion expects the old direct `restaurant_owner_id` expression in `_tracking_can_read`; the current Task 23 implementation checks current role and live Restaurant ownership. This appears to be a stale source-contract expectation, not a payment failure. It is reported, not changed, because this audit is payment-only.
- No provider sandbox tests were run.
- Live API/MongoDB: NOT TESTED (no `MONGO_URL`).
- Expo Preview, Android and iOS: NOT TESTED.
- No real payment, refund, stock mutation or order mutation was performed.

## 10. Changed files and backups

- Source files changed: **NONE**.
- Tests added/modified: **NONE**.
- Dependencies installed: **NONE**.
- Network/provider requests: **NONE**.
- No new Master ZIP created because no source changes occurred. Existing Task 24 ZIP remains the verified baseline; older backups were not overwritten or deleted.
- This audit report is a new documentation artifact only.

## 11. Blockers and required inputs

1. Select and authorize a Grocery payment provider and a dedicated Grocery merchant/configuration approach. Restaurant routes must remain isolated.
2. Supply provider sandbox key ID, sandbox secret and sandbox webhook secret through the deployment's secure secret manager/environment (not chat, source files or ZIP).
3. Configure the provider sandbox webhook URL and events; prove signature verification and event delivery in sandbox.
4. Confirm whether manual UPI bank-statement attestation remains supported alongside the gateway, and what transaction reference/evidence is mandatory.
5. Confirm the Pay-at-Shop status naming contract (`pay_at_shop_pending` vs `pay_at_pickup_pending`) before fixing all call sites.
6. Ensure a MongoDB replica set/transaction-capable sandbox is available for atomic payment/order/stock tests.
7. Define an operational owner and evidence-based reconciliation process for `refund_uncertain` cases.

## 12. Task 25 impact

**Task 25 Payment/Refund blocker: NOT REMOVED.** There is still no verified Grocery gateway payment, additional-payment or refund/reconciliation implementation, and no sandbox verification. Grocery Order Replacement must remain blocked for paid UPI orders and for any price change requiring an unverified payment/refund. No replacement API or UI has been implemented.

**Final:** Grocery payment/refund infrastructure audit and design report completed; implementation blocked by missing provider configuration, sandbox evidence and operational payment decisions. No real or production payment/refund was used.
