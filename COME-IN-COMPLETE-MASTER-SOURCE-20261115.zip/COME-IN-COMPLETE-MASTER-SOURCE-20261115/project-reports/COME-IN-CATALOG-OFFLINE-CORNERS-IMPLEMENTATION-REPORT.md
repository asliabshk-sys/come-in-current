# COME IN — Catalog, Checkout and Offline Corner Follow-up

**Date:** 2026-10-18  
**Status:** Source changes and focused local checks completed in a new working copy. Live API/database/browser verification remains blocked.

## Input and backup safety

- Working baseline: `COME-IN-MASTER-FINAL.zip`
- Baseline SHA-256: `b39917e8505131e2964b465f63cefdfd5f1cf946fbbc718869089d82ae8cfc99`
- Work was extracted into a separate directory and packaged under a new filename. The input archive and earlier recovery archive were not overwritten.
- No database writes/migrations, deployment, payment, paid service, or Replit/Preview launch was performed.

## Task 1 — Catalog and product imagery

- Added **101 seller-side common-item starting suggestions** across the current supported categories (staples, oils/spices, snacks/namkeen, bakery, beverages, dairy, produce, personal care and household). These are name/category suggestions only; they do not create fake shop listings, prices, stock, brands, pack sizes, or availability. Seller must enter actual details before saving.
- Preserved the existing 20 demo preview products. Their current category counts are: Atta/Rice/Dal 3; Dairy/Breakfast 3; Masalas/Oils 3; Fruits/Vegetables 3; Snacks 2; Beverages 2; Household/Cleaning 2; Personal Care 2. Bakery currently has no demo product record.
- **No verified real shop product records were added** because no connected live catalog/database or reliable licensed catalog feed was available. The 101 suggestions are not customer-sellable inventory; the existing demo products remain explicitly preview-only.
- Added 9 small bundled category illustrations and wired product cards and product detail images to use them when a remote image fails. These are clearly generic category placeholders, not branded package photos.
- Verified branded product-package images: **0 confirmed**. Existing demo image URLs are remote generic/stock-style imagery and have not been verified as the exact brand package; the Coca-Cola demo record therefore must not be treated as having a verified Coca-Cola product photo. Live seller uploads remain the path for actual listing photos.

## Task 2 — Variants, cart, checkout and imports

- Preserved the existing seller UI for configuring variants with stable IDs, units/pack sizes, shop-specific prices, MRP, stock and availability.
- Preserved the existing variant-aware cart and server quote/order flow, including server-side price/stock revalidation and single-shop checkout restrictions.
- Extended the existing grocery checkout to support **shop-configured pickup or delivery**. Checkout fetches the selected shop's real flags, only offers supported fulfillment options, permits no delivery address for pickup, requests a quote for the selected fulfillment, and displays pickup payment wording accurately.
- Backend quote/order paths validate that the shop still supports the selected fulfillment; pickup does not add a delivery fee. Existing COD-only grocery payment behavior remains unchanged. No payment is claimed as completed.
- Existing CSV/XLSX import preview/apply workflow remains in place. Blank required price/stock fields fail validation rather than being applied; import retry and live transaction behavior were not exercised against MongoDB.

## Task 3 — Offline shops and food corners

- Added backward-compatible `offline_shop_type` to the existing shop profile model, separate from `shop_type` (`online`/`offline`/`both`). Existing records remain readable and omitted new fields receive a default.
- Shop registration/profile UI now allows one of 10 types: Grocery/Kirana, Chicken, Meat, Fish, Momos, Burger, Pizza, Chinese Food, Chaat/Golgappa, and Other Food Corner.
- Added matching type filters inside the existing Offline Shops tab only; no new home-screen tiles, parallel app, or separate ordering system was created.
- Food-corner menus can use the existing seller product/variant/availability management and the existing cart/quote/order flow. Pickup is supported only when the shop profile says pickup is available. No vendor registrations, menu availability, food certifications, or delivery capabilities were fabricated.

## Verification

- Backend syntax compile: PASS (`python -m py_compile backend/server.py backend/restaurant_pricing.py backend/restaurant_serviceability.py`).
- Backend test suite: **131 passed, 23 skipped, 0 failed**. The 23 skipped tests require `COMEIN_TEST_BASE_URL` for an isolated disposable remote test deployment.
- TypeScript compiler API syntax parsing of 6 affected TS/TSX files: PASS (0 parser diagnostics). This is syntax parsing, **not** a full typecheck.
- Preview/Replit shell scripts: PASS (`bash -n scripts/preview.sh scripts/replit-run.sh scripts/replit-install.sh`).
- Frontend full typecheck/build/lint: NOT RUN successfully; frontend dependencies are not installed and registry access was previously blocked. No install guard was bypassed.
- Live API/MongoDB checkout, import transaction, shop registration, real image fetches, and browser/device UI: NOT RUN. Frontend Preview was **not started or visually verified**.

## Final package

- Archive: `COME-IN-CATALOG-OFFLINE-CORNERS-FINAL.zip` (217 entries; ZIP integrity passed).
- Packaged as a new archive; prior project and recovery ZIPs remain untouched.

## Remaining blockers / limitations

1. There is no connected live catalog/database in this execution, so actual shop inventory, prices, stock, variants, images and new shop-type persistence were not round-trip tested.
2. There is no verified/licensed product catalog feed. The project has 20 preview-only demo products plus 101 seller entry suggestions, not a 500-products-per-category live catalog. No unverified brand images or prices were invented to inflate counts.
3. Full frontend typecheck/build and visual Preview verification remain blocked by missing dependencies/network access.
4. Existing remote integration tests remain skipped until a disposable `COMEIN_TEST_BASE_URL` is configured.
