# COME-IN — Secure Earnings Dashboards Implementation Report

Date: 19 October 2026  
Status: Implemented in the existing project; pre-APK; runtime verification blocked by missing dependencies/configuration.

## Source preservation and scope

- Source candidate: `COME-IN-Referral-Earn-Implementation-Pre-APK-2026-10-19-v2.zip`
- Expected and verified source SHA-256: `5e02b6283a3ac7841eea3c4a0d38a245318f4f76a0ccda7a9eda73f5fb935db4`
- Source size: 4,068,057 bytes; ZIP integrity passed before extraction.
- Original source ZIP was not modified. Work was performed in a separate extraction directory.
- No APK was built.
- Restaurant Mode theme/branding and Shopping Mode theme assets were not edited.

## Implemented

### Owner/Admin earnings

- Added an Admin-only Owner Earnings entry and dedicated screen.
- Added backend-protected date-range summary, paginated transaction history, paginated persisted-ledger history, settlement history, referral-reward liability summary, shop/restaurant registration counts, and active-user unavailability explanation.
- Separates gross order sales/merchandise from platform income. Commission is calculated only from the explicit admin-configured rate; service fees and delivery-fee beneficiary are explicit settings. Taxes are not counted as platform income.
- Adds an Admin-only per-shop/per-restaurant financial policy editor. A policy is not applied retroactively: orders created before its recorded timestamp remain financially unavailable until a supported historical snapshot exists.
- Adds platform bank destination management with masked responses and encrypted account-number/IFSC storage when the backend encryption key is configured.
- Displays Referral & Earn reward liabilities separately from order commission revenue.

### Shopkeeper earnings

- Added a dedicated My Shop Earnings screen and Account entry.
- Backend derives authorized shops/restaurants from the authenticated user’s ownership records. A requested shop ID is checked against that server-derived set.
- Displays today/this-week/this-month gross order values, selected-range metrics, completed product/variant sales, current stock/low-stock/out-of-stock indicators, authorized order details, settlement records, and own bank destination.
- Gross order values, completed sales, estimated payable, recorded settlement amounts, and marked-paid amounts are distinct. An order is not financially finalized solely because it was delivered.
- Added an audited manual cash-collection attestation for delivered/picked-up COD orders. It requires the authenticated shopkeeper to own the relevant shop/restaurant. This is an owner attestation, not independent payment verification.

### Financial ledger, refunds and settlements

- Added `backend/financial_rules.py` using `Decimal` money handling and timezone-aware inclusive-start/exclusive-end date boundaries.
- Added idempotent `financial_ledger` snapshots for supported orders only after completion/payment confirmation and when a timestamped admin policy is available.
- Added a unique idempotency key for ledger events and indexes for ledger history, bank beneficiaries, settlements, settlement order allocations, and financial audit events.
- Added provider-confirmed full-refund reversal entries for the existing Restaurant Razorpay refund/webhook path when the provider reports `processed`/`refunded`.
- Added settlement request states, admin review transitions, auditable manual payment confirmation, required payout reference, and unique order allocation keys. Settlement requests and status/audit updates use MongoDB transactions and fail closed if atomic commits cannot be completed.
- A `paid` settlement means an authorized Admin attested that a real manual transfer occurred and recorded its reference; it is not provider-verified because no payout provider is configured.

### Bank-account handling

- Platform account and shop/restaurant beneficiary accounts use separate records and beneficiary keys.
- Account number and IFSC are encrypted with Fernet using `BANK_DATA_ENCRYPTION_KEY`; full account number and IFSC are never returned by these endpoints.
- The app refuses to save bank details when the encryption key is absent or invalid. The key must be managed outside source control (deployment secret manager recommended).
- Verification status remains `unverified`. No bank-account ownership/IFSC verification provider is integrated.

## Files changed or added

Changed:
- `backend/server.py`
- `backend/.env.example`
- `frontend/app/admin.tsx`
- `frontend/app/(tabs)/account.tsx`

Added:
- `backend/financial_rules.py`
- `backend/tests/test_financial_rules.py`
- `backend/tests/test_financial_security_contract.py`
- `frontend/app/admin-earnings.tsx`
- `frontend/app/seller-earnings.tsx`
- This report.

No theme asset or Restaurant Mode theme file was changed.

## Test results

- `python -m py_compile backend/server.py backend/financial_rules.py`: PASS.
- `PYTHONPATH=. python -m pytest -c /dev/null -q tests`: **189 passed, 23 skipped, 0 failed**.
- Global TypeScript `transpileModule` syntax/transpile checks on `admin-earnings.tsx`, `seller-earnings.tsx`, `admin.tsx`, and `(tabs)/account.tsx`: **4 PASS, 0 syntax/transpile diagnostics**.
- Source candidate SHA-256 and ZIP integrity: PASS before editing.

## Runtime verification blockers

- Frontend dependencies are absent (`frontend/node_modules` is absent), and there is no `yarn.lock`, `package-lock.json`, or `pnpm-lock.yaml` in the candidate.
- `npm run typecheck`: BLOCKED (exit 2); `expo/tsconfig.base` is missing and Expo/React typings/modules are unavailable. The resulting compiler output includes missing Promise/JSX/module diagnostics; it is not a valid full typecheck.
- `npm run lint`: BLOCKED (exit 127), `expo: not found`.
- `npm run build:web`: BLOCKED (exit 127), `expo: not found`.
- `python -c 'import server'`: BLOCKED, `ModuleNotFoundError: No module named 'bcrypt'`.
- No live MongoDB instance/credentials or safe replica-set test database were configured. Therefore protected API behavior, MongoDB transaction execution, database indexes, UI rendering, bank encryption/decryption round trips, provider webhook processing, and settlement end-to-end behavior were not live-tested.
- Dependency installation was not attempted because the candidate has no lockfile/node_modules and the previously observed package registry access failure (`EAI_AGAIN registry.yarnpkg.com`) remains a blocker; no arbitrary dependency upgrades were made.

## Known limitations — do not treat as verified/complete

1. The current project does not persist immutable historical fee terms per order. This implementation intentionally marks pre-policy or missing-policy orders unavailable instead of applying a current rate retroactively. Commission policy is per shop/restaurant, not category-specific.
2. Historical orders are not backfilled into `financial_ledger`. Persisted ledger summaries are explicitly marked as limited to recorded events; they are not a complete historical general ledger.
3. Provider-confirmed reversal support currently covers the existing Restaurant Razorpay full-refund path. Grocery refund lifecycle, partial refunds, general adjustments, expense entry, tax remittance accounting, and other income categories are not implemented because their authoritative source/workflow is absent.
4. There is no payout provider. Settlements are an auditable manual review/reconciliation workflow. Manual “paid” status requires an Admin confirmation and reference but cannot independently prove the bank transfer.
5. No bank verification provider exists. Account status remains `unverified`; formatting does not prove ownership.
6. Bank writes require a valid deployment secret `BANK_DATA_ENCRYPTION_KEY`. Do not enter real bank details until that key is configured and backed up securely.
7. Active-user counts are unavailable because reliable activity tracking is not configured.
8. Dashboard source-order queries have a 10,000-order-per-mode safety cap and report a warning if reached. For a larger deployment, use database-side aggregation and more granular pagination.
9. Cross-shop authorization is covered by source-contract tests, not live API integration tests. Do not describe it as live-verified until dependencies and a safe MongoDB test environment are restored.

## Required next actions before production use

1. Restore dependencies using the project’s intended Yarn version once registry/cache access is available; then run full typecheck, lint and web build.
2. Install backend requirements in an isolated environment and configure a safe MongoDB replica-set test database; run API authorization, transaction, index, and concurrency tests.
3. Configure and protect `BANK_DATA_ENCRYPTION_KEY` and `FINANCIAL_TIMEZONE` in deployment secrets. Do not commit the real key.
4. Configure each shop/restaurant’s actual commission, service fee and delivery-fee beneficiary from an approved agreement before relying on future payable calculations.
5. Add immutable order-level fee snapshots, full Grocery refund lifecycle and provider/manual settlement reconciliation before treating the dashboards as production accounting.
6. Manually verify actual transfers before Admin records a settlement as paid. No APK was created.

The companion external verification report contains the final output ZIP size and SHA-256 because an archive cannot meaningfully embed its own final checksum without changing that checksum.
