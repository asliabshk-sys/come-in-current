# COME IN — Business Onboarding Test Report

- `python -m py_compile backend/server.py backend/restaurant_pricing.py backend/restaurant_serviceability.py`: PASS.
- `PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests`: **136 passed, 23 skipped, 0 failed**.
- The 23 skipped tests are existing remote integration tests requiring `COMEIN_TEST_BASE_URL` to an isolated test deployment.
- Frontend semantic TypeScript typecheck/build: NOT RUN in this pass; installed frontend dependencies were not confirmed.
- Preview/Replit startup and visual verification: NOT RUN.
- Mongo-backed provider registration/booking, auth role checks, live shop/restaurant checkout, call routing and payment gateway behavior: NOT runtime-tested here.
- No tests are claimed for behaviors that were not executed.
