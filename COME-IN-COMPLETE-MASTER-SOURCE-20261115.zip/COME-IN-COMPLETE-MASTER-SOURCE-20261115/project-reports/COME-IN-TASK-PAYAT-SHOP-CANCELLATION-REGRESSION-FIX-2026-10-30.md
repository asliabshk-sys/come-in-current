# COME-IN — Pay-at-Shop Cancellation Regression Fix

**Date:** 2026-10-30  
**Task status:** COMPLETE (source-level fix and targeted contract tests)  
**Scope:** Grocery order cancellation handling only. No Grocery Razorpay integration, refund implementation, additional payment, or Task 25 Order Replacement.

## 1. Baseline and safety

- Active workspace: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`
- No `.git` directory was present; no Git status/history is claimed.
- No prior ZIP was extracted over the active workspace.
- Pre-change snapshot created before editing: `COME-IN-PAYAT-SHOP-CANCELLATION-PRE-CHANGE-20261030T100000Z.zip`.
- No dependency installation, network retry, live API, MongoDB, Preview, or mobile test was performed.
- No payment, refund, cash collection, order, inventory, or database mutation was performed.

## 2. Defect confirmation

`backend/server.py`, `_cancel_grocery_order()` accepted this payment-state allowlist:

`{"cod_pending", "awaiting_upi_payment", "pay_at_shop_pending"}`

New Grocery `cash_shop` / `pickup` orders are created with canonical `pay_at_pickup_pending`. Since cancellation uses a fail-closed allowlist, the new status did not match and cancellation returned HTTP 409 before inventory restoration. Legacy `pay_at_shop_pending` orders continued to match.

## 3. Minimal fix

Updated the allowlist to:

`{"cod_pending", "awaiting_upi_payment", "pay_at_pickup_pending", "pay_at_shop_pending"}`

Consequences:
- New canonical Pay-at-Shop orders are eligible for the same existing unaccepted/unpaid cancellation path.
- Legacy Pay-at-Shop orders remain compatible.
- COD remains separately represented by `cod_pending` and is not conflated with Pay-at-Shop.
- Other states (including `paid`, `cash_collected`, captured/settled or unknown states) remain outside the allowlist and fail closed.
- Existing order status guard (`pending` / `pending_payment` only), stock restoration transaction, compare-and-set update, and `modified_count` check remain unchanged.
- Cancellation sets order/payment status to `cancelled`; it does not set `paid` or `cash_collected`.
- Existing cash confirmation remains separate: explicit `confirmed=true`, completed fulfillment (`delivered` / `picked_up`), and seller authorization are required; the result is `cash_collected`, not `paid`.

## 4. Files changed

1. `backend/server.py` — added canonical `pay_at_pickup_pending` to Grocery cancellation allowlist; retained legacy and COD values.
2. `backend/tests/test_task9_order_actions_contract.py` — updated the Task 9 source-contract expectation to include canonical status.
3. `backend/tests/test_grocery_pay_at_shop_status_contract.py` — added regression assertions for canonical + legacy status acceptance, COD separation, fail-closed protected states, and no `paid`/`cash_collected` mutation in cancellation.

No frontend file changed. No Restaurant route or payment/refund logic changed.

## 5. Tests

Targeted command:

```bash
cd backend
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_task9_order_actions_contract.py \
  tests/test_grocery_pay_at_shop_status_contract.py \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_functional_blockers_regression.py \
  tests/test_financial_security_contract.py
```

**Final repeat result: 50 passed in 0.83s.** A prior run immediately after the edit reported 49 passed; the final collection showed 50 tests, and the repeated full targeted command passed all 50.

Additional syntax check:
- Python `compile()` of `backend/server.py`: PASS.

### Separate pre-existing Task 23 assertion

Ran separately:

`tests/test_shared_system_integration_contract.py::test_shared_tracking_endpoint_supports_restaurant_orders_without_fake_coordinates`

**Result: 1 failed.** It expects the old direct `order.get("restaurant_owner_id") == user.get("id")` check, while current Task 23 code checks current role and live Restaurant ownership. This unrelated assertion was not changed or hidden.

All tests above are source-contract/unit-level checks. They do not prove live FastAPI/MongoDB behavior.

## 6. Backup and archive verification

Pre-change snapshot:
- File: `COME-IN-PAYAT-SHOP-CANCELLATION-PRE-CHANGE-20261030T100000Z.zip`
- ZIP integrity: PASS (`testzip() == None`)
- Size: 4,177,065 bytes
- SHA-256: `fd72aec98a37508f588c2381ff3a7886b755769263685211afe2246fde362525`

Post-change Master ZIP:
- File: `COME-IN-PAYAT-SHOP-CANCELLATION-POST-CHANGE-20261030T103000Z.zip`
- ZIP integrity: PASS
- Archive-to-active-source comparison: exact match for all included files; 0 missing, 0 different.
- Earlier Pay-at-Shop ZIP was retained unchanged.
- Task 21–24 application code remains as in the prior Pay-at-Shop baseline except the one intended Grocery cancellation allowlist change in `backend/server.py`; no Task 21–24 files were edited.

## 7. Remaining blockers / limits

- No live MongoDB or transaction test.
- No API/Preview/device test.
- Grocery Razorpay sandbox credentials/configuration remain absent/unverified as previously reported.
- Grocery payment/refund and Task 25 Order Replacement remain BLOCKED and were not implemented.
- The previously reported Task 23 stale assertion remains separate and unresolved.

## 8. Completion statement

The cancellation regression is fixed at source level with a minimal allowlist change, preserving legacy Pay-at-Shop and COD behavior. Targeted tests pass. Runtime/database behavior remains unverified.
