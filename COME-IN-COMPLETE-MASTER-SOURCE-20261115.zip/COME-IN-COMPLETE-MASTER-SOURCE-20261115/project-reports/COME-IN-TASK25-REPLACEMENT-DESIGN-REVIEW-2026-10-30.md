# COME-IN Task 25 — Customer-approved Order Replacement Design Review

**Date:** 2026-10-30  
**Status:** DESIGN REVIEW READY — IMPLEMENTATION PAUSED FOR BUSINESS/PAYMENT DECISIONS  
**Scope:** Grocery orders only. No source files changed in this review.

## 1. Active workspace and baseline

- Active workspace exists and is accessible: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`.
- No `.git` directory/repository is present; no Git status/history is claimed.
- Task 24 report exists and SHA-256 matches: `8890787e4ddd291e055d420ef38cd30c891456656ac410fb455ba6a701d8019c`.
- Task 24 post-change ZIP exists: `/mnt/data/COME-IN-TASK24-POST-CHANGE-20261030T082300Z.zip`.
  - Size: 4,132,820 bytes.
  - SHA-256: `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`.
  - `unzip -t`: PASS.
  - 310 archived files compared against active source after removing archive root prefix: 0 missing, 0 different.
- The Task 24 source baseline is therefore consistent. No old archive was extracted over the active source.
- Task 21–24 changes remain in the active source. No source file was modified for this design review; no Task 25 pre/post source ZIP was created.

## 2. Existing implementation and relevant files

### Frontend

- `frontend/app/orders.tsx`
  - Loads authenticated Grocery `/orders/mine` and Restaurant `/restaurant/orders/mine` history.
  - Existing Repeat Order is Grocery-only and resolves old product/variant IDs against the live catalog.
  - No existing order-item replacement proposal, customer Accept/Reject, or replacement status UI was found.
- `frontend/app/(tabs)/cart.tsx`
  - Existing pre-checkout Cart replacement UI offers available alternatives from the same shop/category and displays current price/quantity.
  - This only replaces a Cart line; it does not mutate a submitted order.
- `frontend/src/store/cart.tsx`
  - `replaceLine` checks live product, same shop/category, selected variant, and current stock before replacing the Cart line.
  - This function must remain Cart-only and must not be reused as an order mutation API.
- `frontend/app/chand.tsx`
  - Help & Support can create a customer-owned order-linked ticket.
  - UI explicitly describes this as a support case, not replacement approval or refund execution.

### Backend

- `backend/server.py`
  - `OrderIn`, `QuoteLineIn`, and `GroceryQuoteIn` define current Grocery order/quote contracts.
  - `POST /orders` requires a fresh server-side quote and scoped idempotency key; re-resolves current product/variant prices and stock; compares quote snapshots; consumes quote, decrements stock and inserts the order in one MongoDB transaction. Unsupported transaction errors fail closed.
  - `GET /orders/mine` scopes orders to authenticated `customer_id`.
  - `GET /orders/{order_id}` and seller/admin order routes are existing order access surfaces; seller status updates check current role and current shop ownership.
  - `PATCH /orders/{order_id}/status` permits only current `shopkeeper` role with current shop ownership, or admin, and uses compare-and-set status transitions.
  - `POST /restaurant/support` validates linked order ownership and creates an idempotent support ticket; seller support actions only progress ticket status; admin support actions only change ticket status.
  - Restaurant refund route is separate and admin-only. It calls Razorpay and has `refund_uncertain` safeguards; it is not a Grocery refund API.
  - Grocery `online_razorpay` and `online_stripe` are explicitly rejected as unavailable. Existing Grocery payment choices include COD, UPI/manual confirmation and pickup/pay-at-shop variants. No customer-facing Grocery gateway refund or incremental payment API was found.

## 3. Reuse vs missing functionality

| Capability | Finding |
|---|---|
| Cart-level same-shop/category replacement | EXISTS; reuse as a reference for product/variant validation only |
| Existing Grocery order item identity | EXISTS; order items carry product/variant identifiers and quantity |
| Customer order ownership | EXISTS in order/support read paths; new routes must repeat strict customer ownership checks |
| Current seller role + shop ownership | EXISTS in seller order workflows; replacement proposal routes must enforce both at action time |
| Admin authorization | EXISTS through `require_role("admin")` |
| Order-level replacement proposal | MISSING |
| Customer Accept/Reject | MISSING |
| Proposal expiry/cancellation and history | MISSING |
| Replacement price-difference quote | MISSING |
| Grocery additional payment/refund settlement | MISSING / BLOCKED by current payment capability |
| Replacement idempotency | MISSING |
| Replacement notifications | MISSING; existing notification provider is not confirmed delivered |

## 4. Proposed minimal API/data design (not implemented)

### Data record

Recommended one MongoDB collection, e.g. `grocery_replacement_proposals`, not a new database/service. Each immutable proposal/action history record should include:

- `proposal_id`, `order_id`, `customer_id`, `shop_id`, `original_order_item_key` (stable order-line identifier or a server-generated line reference),
- original `product_id`, `variant_id`, `qty`, original order unit price/snapshot,
- proposed `product_id`, `variant_id`, `qty`, server-resolved current unit price, unit, stock snapshot, subtotal and signed price delta,
- `status` (`pending_customer`, `accepted`, `rejected`, `expired`, `cancelled`, `stale`, `settlement_pending`, `completed`, `failed`),
- `created_by`, `actor_role`, timestamps, `expires_at`, `expected_order_status`, `idempotency_key`, customer decision timestamp, and append-only history.

Never trust client-supplied product names, prices, stock, totals, shop ID, customer ID, or actor role. Resolve them from current DB state. A unique index should protect `(order_id, original_order_item_key, idempotency_key)` or a suitable scoped request key. A separate active-proposal constraint/conditional update is needed so two open proposals cannot target the same order line concurrently.

### Proposed endpoints

- `POST /orders/{order_id}/replacement-proposals` — current admin or current shopkeeper who owns the order's current shop may propose. Validate Grocery order only, allowed order state, exact original line, replacement live/approved product, same shop/category policy (unless explicitly changed), valid variant, stock, quantity, price, and expiry. Return server-calculated before/after totals and delta.
- `GET /orders/{order_id}/replacement-proposals` — customer sees only own order proposals; seller sees only current owned shop order; admin can inspect.
- `POST /orders/{order_id}/replacement-proposals/{proposal_id}/decision` — customer owner only; accepts `accept` or `reject`, expected proposal status/version, and idempotency key. Revalidate order state, proposal expiry, product/variant, stock and price before any commit.
- Optional admin/seller cancellation endpoint only if business policy requires it; expiry can be lazily marked expired on read/decision or by existing scheduled infrastructure (do not add a worker/dependency just for this).

### Atomicity and order mutation

- Proposal creation does not reserve/decrement stock and does not change the order. It is a pending offer only; this avoids silently holding inventory.
- Acceptance must re-read and revalidate all current state.
- Final order-line replacement, stock decrement for the new item, restoration of old reserved stock where applicable, order total update, proposal terminal state, and audit history must commit in one MongoDB transaction with conditional stock guards and compare-and-set checks. If Mongo transactions are unavailable, fail closed; no non-transactional fallback.
- Must define whether stock for the original item was already reserved/decremented and exactly when it is restored. Existing order creation decrements stock transactionally; cancellation restores it. Replacement must follow equivalent transaction safety.
- If payment settlement cannot be confirmed, do not mark the proposal/order line as replaced or payment as settled. Use explicit pending/uncertain state and reconciliation; never retry an ambiguous external payment/refund automatically.

## 5. Suggested state transitions

Proposal: `pending_customer` → `accepted` / `rejected` / `expired` / `cancelled` / `stale`.

If accepted and price settlement is needed: `pending_customer` → `settlement_pending` → `completed` only after authoritative settlement confirmation; failure/uncertainty remains explicitly unresolved and blocks duplicate actions.

Order status should not be advanced to `delivered`, `cancelled`, or another fulfilment state by the proposal itself. The original line must not continue to appear as available if seller has declared it unavailable. Until customer decision, represent it as `replacement_pending`/`unavailable` in the replacement substate while preserving the overall order status. Final item/order totals and fulfilment state update only after the approved decision and settlement policy.

## 6. Security and race-condition controls

- Customer endpoints query by both order ID and authenticated `customer_id`; return 404 for another customer's order.
- Seller endpoints require current `shopkeeper` role plus current shop `owner_id` match on every action; historical owner ID alone is insufficient.
- Admin endpoints require current admin role.
- Restrict this implementation to `db.orders` Grocery orders. Reject Restaurant order IDs/kinds; do not touch Restaurant Mode.
- Use expected status/version CAS, unique idempotency keys, unique indexes, and transaction-scoped stock guards.
- Validate exact original line belongs to the target order and cannot be substituted by arbitrary client line data.
- Expired/stale proposal cannot be accepted. A changed price or stock produces a fresh proposal/review, not silent acceptance.
- Never expose seller/customer private data across order boundaries.

## 7. Payment/refund risks — implementation blocker

Current Grocery payment capabilities do not provide a safe automatic way to collect a replacement price increase or return a replacement price decrease. Grocery online Razorpay/Stripe are explicitly disabled. UPI confirmation is a manual state transition, not a verified payment gateway settlement callback. Existing Razorpay refund logic is Restaurant-specific/admin-only and may become `refund_uncertain`; it cannot be repurposed as Grocery replacement settlement.

Therefore an order-level replacement that changes the amount must not be finalized by simply changing `order.total` or pretending a payment/refund occurred. A safe implementation needs a business-approved policy and a real supported settlement/reconciliation route. No payment code should be changed until this is decided.

## 8. Targeted tests required after decisions

- Customer can only read/decide on own Grocery order; cross-customer 404.
- Current shopkeeper role + current shop ownership required; demoted/stale owner denied; unrelated seller denied; admin permitted.
- Restaurant order rejected by Grocery replacement endpoints.
- Original line must belong to order; wrong product/variant/line rejected.
- Live product/variant, approval, shop/category, stock and quantity validation.
- Changed price/stock/expiry blocks acceptance and requires review.
- Accept/reject exactly once; repeated idempotent request returns same result; conflicting second action gets 409.
- Rejection/expiry leaves original item explicitly unavailable and applies the chosen order policy.
- Transaction rollback protects order line, stock, total, proposal status and audit history together.
- Payment increase/decrease success/failure/timeout/uncertain paths, only after a supported settlement design exists.
- Regression: Task 21 Buy Now isolation; Task 22 blur cleanup; Task 23 tracking authorization; Task 24 repeat-order aggregation; existing Cart replacement; support; Grocery checkout; Restaurant flows unchanged.

## 9. Decisions required before implementation

The following business decisions are not safely inferable from the current code:

1. **Customer rejects or does not respond before expiry:** recommended default is to cancel/remove only the unavailable order line, mark it explicitly unavailable/cancelled, recalculate the remaining order total, and keep other available lines. If the order becomes empty, cancel the order. For prepaid orders, this still requires a separately approved refund policy before any refund is claimed complete. Alternative: cancel the entire order.
2. **Replacement price increases:** current Grocery flow cannot collect an incremental online payment. Recommended safe default: do not offer/allow higher-priced replacement for prepaid UPI orders until a real additional-payment route exists. For COD/pay-at-shop, permit only if the customer explicitly accepts the revised payable total and the revised amount is clearly collected at delivery/pickup; confirm if this is acceptable.
3. **Replacement price decreases:** current Grocery refund capability is absent. Recommended safe default: do not finalize a lower-priced replacement for already-paid orders until a verified Grocery refund route exists. For unpaid COD/pay-at-shop, reduce the amount due after explicit customer acceptance. Confirm whether a future verified refund or a clearly labeled manual refund-pending process is required for prepaid orders.
4. **Same shop/category rule:** recommended default is to preserve the existing Cart replacement rule (same shop and category). Confirm whether seller/admin may propose a different category within the same shop.
5. **Proposal authority:** recommended default is current shopkeeper who owns the order's shop, or admin. Customer only accepts/rejects. Confirm whether Admin should also be able to propose for any Grocery shop.

## 10. Current completion state

- Workspace and Task 24 baseline: VERIFIED.
- Existing Cart replacement: VERIFIED AT SOURCE LEVEL.
- Existing order-level replacement: NOT IMPLEMENTED.
- Design/API proposal: PREPARED.
- Source changes: NONE.
- Runtime/API/MongoDB/Preview/device verification: NOT TESTED.
- Implementation: PAUSED pending the decisions above. No dependencies installed; no network retries; no Task 21–24 source changed.
