# COME-IN — Master Catalog Recovered Baseline & Verification Report

## Candidate identity / provenance
- Verified source ZIP: `COME-IN-Shopping-Home-Reference-Theme-Implementation-Followup-2026-10-18.zip`
- Source SHA-256: `a03d1cfe282fccf483e4d9306a1136df64ae1660b58baa18f9cc29b3fd900d64`
- Source ZIP integrity: PASS (`unzip -t`; 225 entries, no compressed-data errors).
- The separate expected hash `fac922b78ece62b72157cabcdf7e4f322da086f7658f4deb085a31fbc1c8f677` was not found in a ZIP or authoritative manifest. Prior reports mention it as a requested candidate identity, but do not establish it as the hash of the recovered source. The two hashes are not treated as equivalent.
- Working copy extracted separately to `/mnt/data/come-in-master-catalog-recovery-work-20261018/come-in-master-task-work-20261018/`. Source ZIP remains unchanged.

## Implemented Master Catalog areas present in the verified source
1. Admin-only master product creation with normalized-name duplicate preflight and unique canonical variant IDs.
2. Authenticated active master product search with bounded result limits and optional category filter.
3. Shop-owner-authorized linking of a canonical product variant to an existing shop, with per-shop price/MRP/stock/availability.
4. Validation for active master product, valid variant, MRP >= price, duplicate-link conflicts, and directory-only Medical/Pharmacy and Stationery/Books restrictions.
5. Seller-panel search/select/link workflow with loading, empty, authorization, expired-session, invalid-input, duplicate, missing-record, and network error messages; regression tests cover the backend and UI contracts.

## Change in this pass
- Fixed one stale source-contract assertion in `backend/tests/test_frontend_contracts.py`: the test expected an old hard-coded category-strip expression, while the current Home screen correctly renders the existing category data through `CATEGORIES.map(...)`. No product data, UI behavior, backend route, database, or migration was changed by this test fix.

## Verification
- Backend tests: `122 passed, 23 skipped, 0 failed` using `PYTHONPATH=. python -m pytest -c /dev/null -q -rs tests` from `backend/`.
- Python syntax compilation: PASS for `server.py`, `restaurant_pricing.py`, `restaurant_serviceability.py`.
- Frontend typecheck/lint/build: BLOCKED/not run because `frontend/node_modules` is absent; dependencies were not installed and package-manager safeguards were not bypassed.
- Live database inventory and HTTP integration: BLOCKED/not run; no isolated test DB or read-only DB credentials available. Live master/listing/variant/duplicate counts remain UNKNOWN.
- No DB read/write, migration, index creation, Preview, Replit launch, deployment, payment, or external notification was performed.

## Remaining limitations
- Application-level duplicate preflight is not a concurrency-safe guarantee without a unique index; no index was created without a live-record audit and approval.
- No verified product-source dataset was available, so no master products were seeded and no 500-item catalog claim is made.
- Twenty-three existing tests are skipped because they require `COMEIN_TEST_BASE_URL` pointing to an isolated disposable deployment.
