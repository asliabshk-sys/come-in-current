# COME-IN Task 24 — Repeat Order Audit & Targeted Fix Report

Date: 2026-10-30  
Active working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`

## Final status

**TASK 24 COMPLETE — REORDER VERIFIED AT SOURCE LEVEL**

The existing Grocery Repeat Order action was already present. Audit identified a quantity-validation gap: historical orders can contain duplicate rows for the same product/variant, and the UI checked each row separately. It could therefore under-check combined stock/quantity and then silently stop adding units at the cart's per-line 1,000 limit. The smallest safe fix aggregates rows before validation, enforces the existing 1,000-item cap including quantities already in the cart, and reports the specific unavailable items. No backend API, schema, checkout, or payment changes were needed.

Live database/API, Preview, Android and iPhone verification remain NOT TESTED.

## 1. Active workspace and baseline

- The requested workspace exists and is readable/writable: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`.
- This directory is **not a Git repository**. Git status/history are unavailable; no Git claim is made.
- Task 23 report exists and was read: `project-reports/COME-IN-TASK23-ORDER-TRACKING-REPORT-2026-10-30.md`.
- Task 23 post-change ZIP exists, passes `unzip -t`, and has SHA-256 `f1ada6d418a63d982db55adadc6778cf6d3fe306375947e5f2af090a8ae2a5b8` (4,122,279 bytes). Before Task 24 edits, all 303 archived files were compared byte-for-byte with the active workspace: no missing files or mismatches.
- Task 21/22/23 changes were therefore present in the active baseline. Task 22's `frontend/app/checkout.tsx` still contains `useFocusEffect(useCallback(() => () => clearBuyNow(), [clearBuyNow]))`, preserving Buy Now cleanup on Checkout blur/unmount.
- No source was restored or overwritten from an old ZIP.
- Pre-change backup was created before editing (details below).

## 2. Existing Repeat Order audit

### Frontend files inspected

- `frontend/app/orders.tsx`
- `frontend/src/store/cart.tsx`
- `frontend/src/data/useCatalogProducts.ts`
- `frontend/src/data/catalog.ts`
- `frontend/app/checkout.tsx`
- `frontend/app/(tabs)/cart.tsx`
- `frontend/app/order-tracking.tsx`
- `frontend/app/restaurant/orders/[id].tsx`
- `frontend/app/restaurant/cart.tsx`
- `frontend/app/restaurant/checkout.tsx`

### Backend and tests inspected

- `backend/server.py` — `GET /orders/mine`, `GET /restaurant/orders/mine`, grocery quote resolution, order creation and ownership scoping.
- `backend/tests/test_task9_order_actions_contract.py`
- `backend/tests/test_shopping_cart_variants_contract.py`
- `backend/tests/test_grocery_checkout_security_contract.py`
- Task 21/22/23 and Task 11 tracking source-contract tests.

### Findings

| Area | Status | Evidence / explanation |
|---|---|---|
| Grocery customer order history | PASS | `/orders/mine` queries `customer_id` from the authenticated user; `frontend/app/orders.tsx` loads this history. |
| Restaurant customer order history | PASS | `/restaurant/orders/mine` is authenticated and queries the current user's `customer_id`. |
| Existing Repeat Order action | PASS | `frontend/app/orders.tsx` has `testID={repeat-order-${item.id}}`; action is shown only for Grocery history rows. |
| Order item identity | PASS | Reorder reads saved `product_id` and `variant_id`, then resolves the current live catalog item and exact variant. |
| Current catalog / shop matching | PASS | Product must still exist in `liveProducts`, have `source === "live"`, and match the old order's `shop_id`. |
| Variant availability | PASS after targeted hardening | Missing/unavailable saved variants are rejected; products with variants require a saved variant ID. |
| Historical price reuse | PASS | Old `line.price` is not used to build the cart. Current catalog product snapshots are added instead. Checkout obtains a fresh `/grocery/quotes` quote. |
| Current stock check | FAIL before fix; PASS after fix | Before fix, duplicate rows for the same product/variant were checked independently. Now rows are aggregated and checked against current stock plus existing cart quantity. |
| Quantity limit | FAIL before fix; PASS after fix | Existing CartProvider caps each line at 1,000, but Repeat Order did not preflight the aggregate quantity against that limit. Now both combined historical quantity and existing-cart-plus-reorder quantity are checked. |
| Unavailable-item feedback | PASS after targeted hardening | The action reports up to three specific item names/reasons and leaves the cart unchanged if any item is unavailable. |
| Mixed-shop cart protection | PASS | Existing cart from another shop prevents the reorder; no mixed-shop items are added. |
| Direct order/payment execution | PASS | Repeat Order only adds to normal cart and navigates to cart. It does not call order creation or payment endpoints. |
| Checkout quote / price and stock revalidation | PASS at source | Checkout requests `/grocery/quotes`; backend `_resolve_grocery_lines` re-reads current product/variant, availability, shop, price and stock. Order creation rechecks within its transaction. |
| Buy Now isolation and cleanup | PASS at source | Checkout uses `[buyNowLine]` when active; otherwise normal `cartLines`. Task 22 focus cleanup remains present. |
| Restaurant Repeat Order | NOT IMPLEMENTED | No Repeat Order button exists for Restaurant orders. Restaurant orders use a separate menu/cart/checkout model, not the Grocery Product/variant CartProvider. No unsafe cross-mode conversion was added. |
| Cancelled / rejected / delivered Grocery orders | PASS for cart-only behavior | The action remains a cart-only repeat action regardless of historical status; it does not re-open or mutate the old order. Current item availability is revalidated. |
| Runtime/API/database/device behavior | NOT TESTED | No live backend, MongoDB, Preview or device was run. |

## 3. Defect and targeted changes

### Defect

The prior UI mapped each saved order line separately and compared that line's quantity against current stock. If the saved order contained repeated rows for the same `product_id + variant_id`, each row could pass separately although their combined quantity exceeded available stock. CartProvider then adds one unit at a time and stops at stock / 1,000, potentially resulting in fewer units than the success message implied.

### Changes

1. `frontend/app/orders.tsx`
   - Aggregate historical rows by product ID + variant ID before checking.
   - Reject invalid saved rows and combined quantities above 1,000.
   - Require the exact current variant when the product currently has variants.
   - Check current stock against aggregate reorder quantity plus quantity already in cart.
   - Check the CartProvider 1,000-item cap before adding.
   - If any item cannot be fulfilled, add nothing and show specific unavailable item names/reasons.
   - Add only current live catalog product/variant snapshots; never copy historical prices.
   - Keep the existing normal-cart navigation and fresh server quote workflow.
2. `backend/tests/test_task24_repeat_order_contract.py` — new source-contract regression tests.
3. `backend/tests/test_task9_order_actions_contract.py` — updated the existing source assertion to match the new aggregated current-catalog validation implementation.

No backend source, API contract, database schema, auth/role rules, CartProvider, Checkout, Buy Now logic, Restaurant Mode, Seller/Admin workflow, or payment/Razorpay code changed.

## 4. Targeted tests and checks

Final targeted command (from `backend/`):

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_task24_repeat_order_contract.py \
  tests/test_task21_customer_shopping_workflow_contract.py \
  tests/test_task22_checkout_audit_contract.py \
  tests/test_task23_order_tracking_authorization_contract.py \
  tests/test_task11_live_order_tracking_contract.py \
  tests/test_delivery_tracking_contract.py \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_shopping_cart_variants_contract.py \
  tests/test_task9_order_actions_contract.py
```

Result: **66 passed in 0.60s**.

- The first post-edit run had one failure in an older Task 9 source assertion that expected the previous inline lookup expression. The assertion was updated to check the new aggregate/current-catalog expression; no production code was changed to satisfy the stale assertion. Final focused run: 66 passed.
- TypeScript TSX syntax transpilation for `frontend/app/orders.tsx` using global TypeScript 5.8.3: **PASS**.
- Python `py_compile` for the new Task 24 test and updated Task 9 test: **PASS**.
- Full frontend TypeScript project typecheck: **NOT TESTED / BLOCKED** because `frontend/node_modules` is absent. No dependencies were installed.
- No full test suite, live API, or database tests were run.

These tests are source-contract regressions, not live runtime verification.

## 5. Backups and integrity

### Pre-change

- File: `/mnt/data/COME-IN-TASK24-PRE-CHANGE-20261030T082000Z.zip`
- Size: **4,130,811 bytes**
- SHA-256: `6db9090f7c1123e5b14d0a4838b8845669be8ca5e4ad6d73309157c7a13251ed`
- ZIP integrity: **PASS**
- Archived files: 309

### Post-change

- File: `/mnt/data/COME-IN-TASK24-POST-CHANGE-20261030T082300Z.zip`
- Size: **4,132,820 bytes**
- SHA-256: `95ff21fc79742836cc4eb67a7751fb26eecb7b8b1580d658099a0004cebc68bd`
- ZIP integrity: **PASS**
- Archived files: 310
- Every archived file was compared byte-for-byte with the active working copy: **PASS**, no missing or mismatched files.
- Pre/post ZIP diff: only `frontend/app/orders.tsx` and `backend/tests/test_task9_order_actions_contract.py` changed; `backend/tests/test_task24_repeat_order_contract.py` was added; no files removed.
- Report is delivered separately and excluded from post ZIP to avoid a self-referential archive checksum.
- Old Task 23 backup was not modified.

## 6. Runtime verification

| Environment | Status |
|---|---|
| Live MongoDB / replica set | NOT TESTED |
| Running authenticated backend API | NOT TESTED |
| Real order quote / order creation | NOT TESTED |
| Expo Preview | NOT TESTED |
| Android device / emulator | NOT TESTED |
| iPhone / iOS | NOT TESTED |
| Restaurant reorder runtime | NOT TESTED; feature not implemented in separate Restaurant cart flow |
| Production | NOT TESTED |

No order, payment, stock mutation, refund, or external service call was performed.

## 7. Remaining blockers and next safe step

- Run Repeat Order against an isolated staging backend and database with: duplicate saved rows, variant changed/removed, insufficient stock, existing cart quantity, price changes, and mixed-shop cart cases.
- Verify the customer-facing message and cart contents in Expo Preview / Android / iOS when the existing runtime becomes available.
- Restaurant Repeat Order remains outside the existing Grocery Product/variant cart model; it should not be added by converting Restaurant menu lines into Grocery products.
- No dependency installation or network retry was performed.

**Task 24 is complete at source level only. No Task 25 or other feature was started.**
