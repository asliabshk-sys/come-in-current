# Remaining Blockers List

1. **Registry DNS/network — BLOCKED:** cannot resolve `registry.npmjs.org` or `registry.yarnpkg.com`; Corepack cannot fetch pinned Yarn 1.22.22.
2. **Offline dependency cache — BLOCKED:** no cached Yarn distribution, project Yarn cache, `node_modules`, or usable npm cache was found.
3. **Lockfile — PARTIAL:** manifest declares `expo-image-picker ~58.0.10` and `expo-audio ~58.0.12`, but lockfile lacks their entries; do not hand-edit. Run genuine Yarn/Expo resolution once network returns.
4. **Frontend verification — BLOCKED:** full semantic TypeScript, Expo config/doctor, dependency compatibility, lint, bundling/export and native module validation.
5. **Android — BLOCKED / NOT RUN:** Android SDK/ADB unavailable; no build or device E2E.
6. **iOS — BLOCKED / NOT RUN:** macOS/Xcode unavailable; no build or device E2E.
7. **AI provider — BLOCKED:** backend-only provider secrets and reachable endpoint absent; no real chat/vision/STT calls.
8. **MongoDB — BLOCKED:** no non-production replica-set URI/runtime or drivers; feedback persistence, RBAC, dedupe, rate limits and transaction tests not executed.
9. **Full backend test suite — BLOCKED:** configured pytest requires missing `pytest-xdist`; selected focused tests passed.
10. **Photo/voice customer workflow — NOT RUN:** native permissions, real codec, secure uploads, vision/STT responses and customer confirmation must be exercised on actual devices with a reachable backend.
11. **Release gate — NOT READY:** Cart/Checkout and Task 5 focused contracts passed, but live customer workflow, native runtime, provider, database and complete security gates are not established. No deployment attempted.
