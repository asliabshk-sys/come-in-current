# Native Build Report

| Gate | Status | Evidence |
|---|---|---|
| Android SDK / ADB availability | BLOCKED | `adb` not installed / not on PATH |
| Android native build | NOT RUN | No Android SDK/ADB or installed frontend dependencies |
| iOS build toolchain | BLOCKED | `xcodebuild` unavailable; current host is not a macOS/Xcode build host |
| iOS native build | NOT RUN | No Xcode toolchain |
| Camera permission / gallery permission runtime | NOT RUN | No native app build or device |
| Audio recording / codec compatibility | NOT RUN | No native app build or device; source labels recording `.m4a` / `audio/mp4`, but actual device output/provider acceptance has not been tested |
| Voice permission and Hindi/English transcription E2E | NOT RUN | No native device or live STT provider |
| CHAND navigation / Cart transfer / Checkout device E2E | NOT RUN | No native build or device |

`app.json` contains existing `expo-image-picker` and `expo-audio` plugin configuration. This is source inspection only and is not reported as Expo configuration validation or a successful native build.
