# COME-IN Task 12 — Customer Support & Order Help

## Scope and audit
- Existing customer support UI is the shared CHAND Help & Support panel; Restaurant order detail links to it through `/restaurant/support` alias.
- Existing `POST /restaurant/support` authenticates the customer and validates a linked Grocery or Restaurant order against `customer_id`.
- Existing `GET /restaurant/support/mine` is scoped to the authenticated user; Admin list/update routes are admin-only.
- Existing support creation does not execute cancellation or refunds. Refund execution remains separate and admin-only.
- Gaps found: issue categories were too generic; duplicate submissions were not idempotent; seller access to their own order-linked cases was absent.

## Changes
- `backend/server.py`: expanded issue categories; added optional per-customer `request_id` idempotency with a partial unique index and duplicate-key recovery; added role-gated `/seller/support`, scoped through the seller's owned shops/restaurants and their order IDs.
- `frontend/app/orders.tsx`: added a per-order Help link carrying the exact order ID and Grocery/Restaurant kind into the shared support screen.
- `frontend/app/chand.tsx`: added customer-facing late/wrong-or-missing/damaged/cancellation/payment/refund issue choices; generates and retains a request ID across retry until successful response; keeps success message tied to API response and displays actual reference/status.
- `backend/tests/test_task12_customer_support_contract.py`: source-contract regressions for ownership, idempotency, categories, seller scope, and separation from refund/cancellation execution.

## Tests
`python -m py_compile backend/server.py` — PASS.
`PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests/test_task12_customer_support_contract.py backend/tests/test_task10_payment_refund_notification_contract.py backend/tests/test_task11_live_order_tracking_contract.py backend/tests/test_task9_order_actions_contract.py backend/tests/test_grocery_checkout_security_contract.py` — 38 passed.

These are source-contract/regression tests; no live MongoDB, Preview, device, notification provider, payment provider, or refund transaction was exercised.

## Limitations
- Seller access is read-only; no seller ticket status mutation endpoint was added.
- Support requests are stored in the existing `restaurant_support` collection for compatibility.
- Notifications are not delivered; no configured provider/receipt mechanism is present.
- Support case creation is not a refund request, cancellation, refund approval, or payment state change.
- Existing Task 10 payment/refund configuration blockers remain.
