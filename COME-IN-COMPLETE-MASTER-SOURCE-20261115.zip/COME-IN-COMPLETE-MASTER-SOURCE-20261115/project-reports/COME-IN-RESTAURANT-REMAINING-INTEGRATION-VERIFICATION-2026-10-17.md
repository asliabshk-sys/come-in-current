# COME-IN — Restaurant Mode Remaining Integration & Verification

**Date:** 17 October 2026  
**Working directory:** `/mnt/data/come-in-phase2-work/`  
**Scope:** Existing COME-IN app only. This is within the existing 22-task roadmap (related backend/security and testing tasks). No browser preview, Replit, Codespaces, paid environment, production deployment, real payment, external notification, or real rider action was run.

## Current copy and preservation

- Current source working copy: `/mnt/data/come-in-phase2-work/`
- Previous integration ZIP retained unchanged: `/mnt/data/COME-IN-Restaurant-Shared-System-Integration-Pre-Preview.zip`  
  SHA-256: `396b5a3d9faf55091910e223a9a633b2a9eb9fdb57542f5ee92130b18b23d29c`
- Previous CHAND ZIP retained unchanged: `/mnt/data/COME-IN-CHAND-Remaining-Work-Completed-Pre-Preview.zip`  
  SHA-256: `46a0ac82851603e1972a6e045f0ce56a9a2c41095d58e063ed1df0b7700228e5`
- Pre-change rollback backup: `/mnt/data/come-in-backups/come-in-before-remaining-integration-20261017T172139Z.tar.gz`  
  SHA-256: `4fa721a29203986c38835b116ca64b160fa9d996b3e6b7dab4f88789495dfcb5`
- No Git repository is present in the working directory; rollback uses the preserved tar.gz or prior ZIP.

## Implementation changes in this pass

1. `backend/server.py`
   - Restaurant payment-intent retries reuse an existing created Razorpay order for the same COME-IN order rather than deliberately creating another gateway order on each retry.
   - Existing payment intent is checked against the server-calculated order amount and INR currency before reuse.
   - New gateway order responses are checked for a valid gateway order ID, expected amount in paise, and INR currency before persistence/return.
   - Payment intent, retry, and verification reject orders that are no longer in `pending_payment`, reducing the risk of paying/capturing against a cancelled or otherwise transitioned order. The signed webhook now transitions to `placed` only from a guarded `pending_payment` state; a valid capture arriving after cancellation preserves `cancelled` and sets `payment_reconciliation_required` for authorized manual follow-up rather than resurrecting the order.
   - Payment verification still checks the server-stored gateway order, signature, amount, and customer ownership, and now additionally retrieves the payment entity from Razorpay using server-only credentials. It requires matching payment ID, gateway order ID, `captured` status, INR currency, and exact server-calculated amount before marking the order paid.
   - If the gateway status lookup fails, the API returns a failure and does not claim payment success.
2. `frontend/app/restaurant/checkout.tsx`
   - Clarifies that the current backend only checks restaurant-level `delivery_available`; it does **not** validate that a specific address lies inside a service radius. It warns customers not to treat saved-address selection or GPS coordinates as proof of delivery coverage.
3. `backend/tests/test_shared_system_integration_contract.py`
   - Added source-contract tests for payment-intent reuse and amount/currency checks, closed-order payment guards, gateway-captured payment lookup, late-capture/cancelled-order reconciliation, and the explicit address-level serviceability limitation.

## Feature-by-feature status

| Feature | Status | Evidence / remaining gap |
|---|---|---|
| Shared account/session and saved addresses | **PASS — source contract only** | Shared root auth provider/token store and account-scoped `/addresses` APIs; cross-mode runtime session continuity is not tested in a browser. |
| GPS permission | **UNVERIFIED — source only** | Existing location screen requests location after user action; no browser/device permission prompt was exercised. |
| Address-level delivery serviceability | **BLOCKED** | Backend has restaurant-level `delivery_available`, delivery fee, minimum order, and saved-address ownership checks, but no verified restaurant geospatial/radius serviceability contract or geocoding provider. No fake radius/availability was added. Required: trusted restaurant coordinates/coverage definition plus a server-side serviceability contract/provider and tests. |
| Restaurant totals and order creation | **PASS — source-contract/backend unit coverage** | Server resolves live menu prices, add-ons/variants, minimum order and authoritative tax/delivery totals; order uses category-specific cart/order contract and idempotency key. No live database order was created. |
| Razorpay intent/verification hardening | **PASS — source contract and tests only** | Added intent reuse/amount/currency checks, closed-order guards, and server-side payment lookup requiring captured status, order/payment ID, INR and exact amount. |
| Customer-facing online payment checkout | **BLOCKED** | No installed customer-facing Razorpay SDK/checkout UI or available isolated test credentials/configuration. UI remains disabled; no payment intent or real transaction was initiated. Backend payment endpoints being present does not mean customer checkout is complete. |
| Payment failure/retry runtime behavior | **UNVERIFIED** | Source guards exist; no live Razorpay or mocked endpoint-level integration test was possible with current dependencies/configuration. Do not use production gateway for testing. |
| Real delivery-partner assignment/live GPS/ETA | **BLOCKED** | Shared tracking API supports restaurant orders and access checks, but no verified rider assignment/provider feed or ETA/map service was found. Existing owner/admin location updates are not proof of a delivery-partner integration. UI must continue to state location/ETA unavailable when no authorized point exists. |
| Order status tracking authorization | **PASS — source contract only** | Customer, associated restaurant owner and admin access rules exist; location updates require authorized operator/admin and an active delivery status. No live tracking provider tested. |
| Order notifications (push/SMS/email) | **BLOCKED** | No shared order-notification event/provider route was found. SMTP code is for password-reset email only, not order notifications. No paid provider was activated and no messages sent. Required: approved provider/event contract, user opt-in/permission where applicable, recipient authorization and deduplication tests. |
| Grocery/Restaurant cart isolation | **PASS — source contract only** | Separate category-specific carts/orders remain; no duplicate shared cart was introduced. Runtime regression not run. |
| Logout and role authorization | **PASS — source contract only** | Shared token cleared by logout; existing customer/shopkeeper/admin role checks and restaurant ownership checks remain. Home Services-specific role runtime test remains unverified. |
| CHAND Help & Support/refund guidance | **PASS — existing source regression contract** | Existing support routes and safe demo guidance remain in source; no live support ticket or refund was created. |
| Shopping green/yellow and Restaurant pink/rose themes/branding | **PASS — source files untouched** | This pass changed only restaurant checkout copy, backend payment logic, integration tests, and this report. No browser visual regression was run. |

## Verification results

- Backend/source-contract suite: **82 passed, 23 skipped** (`PYTHONPATH=. python -m pytest -c /dev/null -q -rs tests`, run from `backend/`).
- Skipped tests: 23 remote integration tests require `COMEIN_TEST_BASE_URL` for an isolated disposable deployment. No remote backend was contacted.
- Python syntax: **PASS** (`python -m py_compile backend/server.py backend/restaurant_pricing.py`).
- Security preinstall guard: **PASS** (`node frontend/scripts/cmd-guard.js --preinstall`, exit 0; not bypassed).
- Frontend typecheck: **BLOCKED**. `frontend/node_modules` and Yarn are absent. Global `tsc --noEmit -p frontend/tsconfig.json` cannot resolve Expo/React Native dependencies and reports missing libs/types; no unsafe install or network retry was attempted.
- Frontend lint/build: **BLOCKED** (Expo CLI/dependencies not installed).
- ZIP integrity: **PASS** for the previous integration ZIP before this pass. The new ZIP is separately tested after packaging.
- Browser preview/CHAND/Restaurant preview: **DEFERRED**, not run. No Replit, Codespaces, paid environment, or preview server was started.

## Remaining gaps before full integration can be claimed

1. Add/choose a trusted address geocoding and restaurant serviceability contract using verified restaurant coordinates and configured coverage; otherwise continue to disclose that address-level coverage is unknown.
2. Add the customer-facing Razorpay SDK/checkout flow only with the official SDK and isolated test-mode credentials/configuration. Test success, failure, cancel, retry, duplicate submissions, and gateway/order mismatches with mocks or test mode. No production payment.
3. Integrate a verified delivery-partner assignment/location API and mapping/ETA service if/when a real provider contract and credentials are available.
4. Add an approved order-event and notification provider contract, delivery idempotency, recipient/role isolation, and isolated mocks.
5. Run API integration tests against a disposable test deployment, then after the user's Replit credits refresh perform the explicitly deferred runtime/visual regression pass.

## Rollback instructions

Do not overwrite the original or previous ZIPs. To restore the exact pre-change working directory, extract the preserved tarball into a separate directory first, inspect it, and then selectively replace the working copy only if desired:

```bash
mkdir -p /mnt/data/come-in-rollback-review
 tar -xzf /mnt/data/come-in-backups/come-in-before-remaining-integration-20261017T172139Z.tar.gz -C /mnt/data/come-in-rollback-review
```

The archive contains `come-in-phase2-work/`. Review before restoring. Do not delete the current working copy or backup.

## FINAL PREVIEW — REPLIT CREDITS REFRESH के बाद

**Not performed now.** Only after credits refresh, run browser/device preview and verify all four CHAND modes, Shopping and Restaurant Mode, shared account/login/logout, location permission and address selection, checkout and payment test-mode, tracking, order notifications if configured, role isolation, and Help & Support. No production payment or real customer/rider data should be used. Any unsupported provider feature must remain clearly unavailable rather than simulated.
