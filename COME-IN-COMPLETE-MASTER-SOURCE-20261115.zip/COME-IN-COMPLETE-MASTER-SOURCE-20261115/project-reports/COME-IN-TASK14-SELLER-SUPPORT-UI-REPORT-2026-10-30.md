# COME-IN Task 14 — Seller Support UI Integration

## Audit
- Read Task 12 and Task 13 reports and inspected `backend/server.py`, the seller routes, Account navigation, and the shared API client.
- `GET /seller/support` returns an array of `doc_out` support ticket documents. `doc_out` serializes Mongo `_id` to `id`; available ticket fields include `ref`, `order_id`, `order_kind`, `order_ref`, `category`, `message`, `status`, `created_at`, `updated_at`, and `history` when stored.
- `PATCH /seller/support/{ticket_id}` accepts `{status, expected_status}` and returns the updated `doc_out` ticket. Seller transitions are `open -> in_progress` and `in_progress -> resolved`; `closed` is not seller-selectable. The backend validates seller role and linked order ownership, and uses conditional status compare-and-set; stale transitions return 409.
- No seller support screen or navigation entry existed. The authenticated API client already exposes typed `get` and `patch` methods.

## Implementation
- Added `frontend/app/seller/support.tsx` using existing API client, auth store, theme tokens, React Native components, and existing seller account route conventions.
- Added Seller Support entry to Account for `shopkeeper` and `restaurant` roles.
- Screen shows ticket reference, related order reference/type, category, details, current status and update timestamp where returned.
- Seller controls expose only `open -> in_progress` and `in_progress -> resolved`. PATCH sends the ticket's current status as `expected_status`.
- While any update is in progress, controls are disabled. Displayed status changes only after successful PATCH response. 401/403, 404, 409 and network/API errors are handled; 409 refreshes the list before another action can be attempted.
- No refund, cancellation, payment, notification, or backend endpoint was added or invoked.

## Changed files
- `frontend/app/seller/support.tsx` (new)
- `frontend/app/(tabs)/account.tsx`
- `backend/tests/test_task14_seller_support_ui_contract.py` (new)
- `project-reports/COME-IN-TASK14-SELLER-SUPPORT-UI-REPORT-2026-10-30.md` (new)

## Targeted checks
- `python -m py_compile backend/server.py` — PASS.
- `PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests/test_task14_seller_support_ui_contract.py backend/tests/test_task13_seller_support_status_contract.py backend/tests/test_task12_customer_support_contract.py` — 18 passed.
- Frontend typecheck was not run: `frontend/node_modules/.bin/tsc` is absent. Dependencies were not installed.
- Tests are source-contract tests; they do not call live APIs or MongoDB.

## Runtime verification and limitations
- Live MongoDB: NOT VERIFIED.
- Backend authenticated API / seller session: NOT VERIFIED.
- Preview: NOT VERIFIED.
- Android: NOT VERIFIED.
- iPhone: NOT VERIFIED.
- UI integration is source-level only until frontend dependencies and a runnable Preview/device environment are available.
- Existing backend authorization remains the security boundary; UI role checks are not a substitute for backend authorization.
- No SMS, email, or push delivery is claimed.

## Backups
- Pre-change ZIP: `COME-IN-TASK14-PRE-CHANGE-20261030T070324Z.zip`
- Pre-change size: 4,045,628 bytes
- Pre-change SHA-256: `ea740295a4f9ce3270c203db121d25fbeb1fba5d24d26104cd7c4bc1a3386458`
- Post-change ZIP filename, size, SHA-256 and byte-comparison results are provided in the accompanying final execution report. (The archive contains this report; its own checksum is therefore recorded externally to avoid a self-referential hash.)
