# COME IN — 100-Per-Category Catalog Expansion Report

**Date:** 18 October 2026  
**Base archive:** `COME-IN-CATALOG-OFFLINE-CORNERS-FINAL.zip`  
**Scope:** Frontend reference catalog and category/product browsing; no database migration or live inventory writes were performed.

## What changed

- Expanded customer-visible categories from 9 to **17** while reusing the existing category screen and stable IDs where practical.
- Added **1,628 new unique reference-catalog item names** to the existing 20-item local demo catalog. The 20 original demo records were preserved; two produce/category placements were corrected (Tata Salt under Grocery & Staples; Shimla Apple under Fruits).
- Added a bundled, category-appropriate placeholder image for each new category that needed one. The full local browse catalog uses placeholders rather than unverified packaging images. There are **0 verified product/brand photos** in this package and **17 bundled placeholder illustration assets** in total.
- Reference entries have no real brand, pack size, price, stock, or availability claim. The internal `price: 0` value is a non-display sentinel; the UI says “Price set by shop” / “Shop price needed.” Existing demo prices are now explicitly labelled preview-only and are not displayed as live prices.
- Catalog references cannot be added to the cart. If an exact-name, same-category live listing exists, product detail offers a link to that real shop listing; otherwise it explains that a seller must list the item first. Existing live listing variant, quantity, cart, and checkout code paths were retained.
- Existing seller product management and Excel/CSV import were not replaced or duplicated. Reference items are not automatically inserted as a seller's stock.

## Category counts

“Existing” means unique names in the previous bundled demo catalog, reclassified into the canonical categories below. “New” counts only reference names not already present under the same category. “Final” is the bundled browse-catalog count (existing demo names plus new references), not a count of live inventory in MongoDB. Image counts are **verified product photos / local category placeholders**.

| Category | Existing unique | New unique added | Final unique | Verified photos / placeholders | Variants, cart & checkout runtime verified? | Gap to 100 |
|---|---:|---:|---:|---:|---|---:|
| Grocery & Staples | 4 | 99 | 103 | 0 / 103 | No — source-level only | 0 |
| Cooking Essentials | 2 | 100 | 102 | 0 / 102 | No — source-level only | 0 |
| Snacks & Namkeen | 2 | 100 | 102 | 0 / 102 | No — source-level only | 0 |
| Biscuits, Cookies & Bakery | 0 | 100 | 100 | 0 / 100 | No — source-level only | 0 |
| Cold Drinks & Beverages | 2 | 98 | 100 | 0 / 100 | No — source-level only | 0 |
| Tea & Coffee | 0 | 100 | 100 | 0 / 100 | No — source-level only | 0 |
| Dairy Products | 3 | 100 | 103 | 0 / 103 | No — source-level only | 0 |
| Fruits | 1 | 100 | 101 | 0 / 101 | No — source-level only | 0 |
| Vegetables | 2 | 100 | 102 | 0 / 102 | No — source-level only | 0 |
| Personal Care | 2 | 100 | 102 | 0 / 102 | No — source-level only | 0 |
| Cleaning & Household | 2 | 100 | 102 | 0 / 102 | No — source-level only | 0 |
| Frozen Foods & Ice Cream | 0 | 100 | 100 | 0 / 100 | No — source-level only | 0 |
| Packaged Foods | 0 | 100 | 100 | 0 / 100 | No — source-level only | 0 |
| Eggs | 0 | 31 | 31 | 0 / 31 | No — source-level only | **69** |
| Stationery | 0 | 100 | 100 | 0 / 100 | No — source-level only | 0 |
| Baby Care | 0 | 100 | 100 | 0 / 100 | No — source-level only | 0 |
| Pet Supplies | 0 | 100 | 100 | 0 / 100 | No — source-level only | 0 |
| **Total** | **20** | **1,628** | **1,648** | **0 / 1,648** | **Preview not launched** | **69** |

## Important accuracy and availability limits

- The 1,648 figure is the bundled customer-facing browse catalog, not a claim that 1,648 items are stocked by any real shop. Reference entries are browseable but intentionally **not orderable** until an approved shopkeeper publishes a live listing with its own price, variants, and stock.
- The Eggs category has **31 defensible reference entries**. It remains 69 below the requested target rather than inventing 69 purportedly distinct egg products. Several egg-production attributes are catalog suggestions only, not verified claims about a seller or farm.
- Product images are category placeholders, not real package photos. No Coca-Cola or other branded package photo was independently verified.
- The reference catalog is bundled in frontend source; it was not seeded into the live `master_products` database because no database connection or authorization to create live catalog records was available in this run.

## Files changed

- `frontend/src/data/catalog-reference.ts` — new 1,631-name category reference dataset.
- `frontend/src/data/catalog.ts` — 17 categories, reference product mapping, stable browse IDs, placeholder mappings.
- `frontend/src/components/ProductCard.tsx` — local placeholders and no fabricated live price for reference/demo entries.
- `frontend/app/product/[id].tsx` — reference-item messaging and links to exact matching live shop listings.
- `frontend/app/category/[slug].tsx` — truthful catalog count/availability wording.
- `frontend/src/store/cart.tsx` and `frontend/app/(tabs)/cart.tsx` — non-live catalog/preview items blocked from cart/checkout.
- `frontend/assets/images/placeholders/*.png` — 8 new original category illustrations; 17 placeholder assets total.
- `backend/tests/test_catalog_reference_minimum.py` — focused catalog/category/image/cart guard contract tests.
