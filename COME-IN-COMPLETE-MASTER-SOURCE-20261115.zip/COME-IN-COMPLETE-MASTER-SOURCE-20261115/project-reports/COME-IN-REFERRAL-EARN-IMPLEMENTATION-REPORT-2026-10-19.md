# COME-IN — Referral & Earn Implementation Report

Date: 19 October 2026

## Starting candidate integrity

- Candidate: `COME-IN-Shop-Registration-Account-Only-Pre-APK-2026-10-19.zip`
- Expected and observed SHA-256: `f9a7557143e19f9a680a1f1fbae20a5ee1a4d9f52a2ef17be3c6f87464500936`
- Source ZIP size: 3,911,318 bytes
- `unzip -t`: PASS, no compressed-data errors.
- Extracted to a separate working directory. Original candidate and other backups were not edited or overwritten.

## Changes made

### Backend

- Added `backend/referral_rules.py` with dependency-free policy helpers for random referral-code generation, format validation, ₹100 minimum order, blocked refund/return/dispute states, and 10-customer / ₹500 constants.
- Customer registration now creates a random public referral code and accepts only a validated referral code (never a client-supplied referrer ID). Referral attribution is recorded once per referred customer.
- Added unique/sparse/partial indexes for referral codes, one attribution per referred user, one qualifying order, one target reward per referrer, and idempotent reward ledger entries.
- Added `/api/referrals/me`, `/api/referral/validate`, `/api/referral`, `/api/admin/referrals`, `/api/admin/referrals/{id}/review`, and `/api/admin/referral-rewards/{id}`.
- Delivered Grocery and Restaurant orders can create a **pending review candidate** only when the order is at least ₹100 and the order/refund/return/dispute fields do not show a blocked state. Delivery alone never automatically pays or qualifies a referral.
- Admin review requires explicit contact verification method, payment confirmation, and refund/return checks. Review decisions and reward transitions are recorded in `referral_audit`.
- The 10-qualified-customer threshold creates one `pending_verification` ₹500 reward workflow per referrer. The unique reward key prevents duplicate threshold workflows. Before approving a reward, the backend rechecks all ten associated orders.
- Reward credits and status changes are represented in a ledger with idempotency keys. Marking a bank payout paid requires an admin-supplied payout reference.

### Frontend

- Added `frontend/app/referral-dashboard.tsx` and `frontend/app/referral.tsx`.
- Added Referral & Earn to Account for signed-in customer-role accounts.
- Dashboard shows code, link, Copy Link, native Share, WhatsApp, attributed registration counts, link-open count (explicitly not unique people), purchase-pending/review/qualified counts, progress, reward status, available ledger balance and transaction history.
- Incoming referral code is validated and kept in app storage while a new customer registers; registration sends the code to the backend. Signing into an existing account clears the pending code so an existing account cannot be retroactively attributed.
- Added an Admin Dashboard Referral & Rewards tab for reviewing qualification records and managing reward status with audited backend endpoints.

### Changed/new files

- `backend/server.py`
- `backend/referral_rules.py` (new)
- `backend/tests/test_referral_rules.py` (new)
- `backend/tests/test_referral_implementation_contract.py` (new)
- `frontend/src/store/auth.tsx`
- `frontend/app/auth.tsx`
- `frontend/app/(tabs)/account.tsx`
- `frontend/app/referral.tsx` (new)
- `frontend/app/referral-dashboard.tsx` (new)
- `frontend/app/admin.tsx`

No Restaurant Mode theme/branding files were intentionally changed. No APK was built.

## Verification results

| Check | Status | Evidence / limitation |
|---|---|---|
| Source candidate checksum | PASS | Exact SHA-256 matched before editing |
| Source ZIP integrity | PASS | `unzip -t`; no errors |
| Python syntax | PASS | `python -m py_compile server.py restaurant_pricing.py restaurant_serviceability.py referral_rules.py` |
| Backend tests | PASS | `PYTHONPATH=. python -m pytest -c /dev/null -q tests` → **175 passed, 23 skipped, 0 failed** |
| Referral policy unit tests | PASS | Included in suite: 1,000 generated codes sampled, format/invalid code, ₹100 boundary, delivery/status/refund flags, 10-customer threshold |
| Frontend changed-file syntax/transpile | PASS | Global TypeScript `transpileModule` run against six changed TS/TSX files; no syntax diagnostics |
| Frontend dependency installation | BLOCKED | `frontend/node_modules` absent; no `yarn.lock`, `package-lock.json`, or `pnpm-lock.yaml` in candidate. Project declares Yarn 1.22.22. `corepack yarn --version` failed fetching `https://registry.yarnpkg.com/yarn/-/yarn-1.22.22.tgz` with `getaddrinfo EAI_AGAIN registry.yarnpkg.com`. No arbitrary package versions or lockfile were added. |
| Frontend typecheck | BLOCKED | `npm run typecheck` exit 2; `tsconfig.json` cannot find `expo/tsconfig.base`; React/Expo modules missing and TypeScript reports missing Promise/JSX libs because dependencies/config are absent. |
| Frontend lint | BLOCKED | `npm run lint` exit 127: `sh: 1: expo: not found` |
| Web build | BLOCKED | `npm run build:web` exit 127: `sh: 1: expo: not found` |
| Backend import/startup | BLOCKED | `python -c 'import server'` fails at `import bcrypt`: `ModuleNotFoundError: No module named 'bcrypt'` |
| Live MongoDB/API authorization tests | NOT RUN | Server cannot import in this environment; no authenticated test accounts or live DB session available. Index creation and HTTP status behaviour are not runtime-verified. |
| Browser UI / actual Copy, Share, WhatsApp | NOT RUN | No runnable Expo frontend/dependencies or browser session. Source wiring and TypeScript transpilation only were checked. |
| Native clipboard | BLOCKED / partial | Web Copy Link uses `navigator.clipboard` when available. No native clipboard package exists in the project; native Copy Link currently explains the limitation and directs users to Share Link. Native clipboard copy is not claimed complete. |
| Universal/deferred deep links | PARTIAL | The app has Expo scheme `frontend`; installed-app scheme links are generated when `PUBLIC_APP_URL`/`EXPO_PUBLIC_APP_URL` is not configured. A production customer-facing URL and Android/iOS associated-domain configuration or deferred-link provider are not present. Pre-install attribution is therefore not guaranteed. |
| Bank payout | PARTIAL | Admin can record a verified payout reference and ledger status, but no payout provider credentials/API or secure bank-account vault was available. No bank transfer was executed and no bank details are collected/stored by this implementation. |
| COME-IN purchase redemption | NOT IMPLEMENTED | Existing checkout does not support referral reward balance as a payment/discount method. No fake redemption was added. |
| Contact verification / refund lifecycle | PARTIAL | Admin must attest to an authorized contact-verification method and confirm payment/refund/return checks. Automated OTP/email verification and a unified refund/return/dispute event integration are not available here. |
| Home-page new-customer referral promo banner | NOT VERIFIED / NOT ADDED | The starting source did not contain a Referral & Earn implementation or an identifiable referral-banner eligibility rule. No arbitrary first-use window was invented. Existing general home UI was left alone. |

## Important limitations

- Referral qualification is deliberately **pending manual Admin review** after a qualifying delivered order; it is not awarded based on frontend clicks.
- Link-open metrics count validation requests and are **not unique people**. Registered/qualified counts come from backend attribution records.
- Without a configured `PUBLIC_APP_URL` or `EXPO_PUBLIC_APP_URL`, the generated `frontend://referral?code=...` link only works where the COME-IN app scheme is installed/configured. It is not a universal web link and does not provide deferred deep linking after installation.
- No live database, API, native sharing, WhatsApp, payout, or browser end-to-end result is claimed.
- Original ZIPs/backups were preserved; this working copy and output archive use separate paths/names.
