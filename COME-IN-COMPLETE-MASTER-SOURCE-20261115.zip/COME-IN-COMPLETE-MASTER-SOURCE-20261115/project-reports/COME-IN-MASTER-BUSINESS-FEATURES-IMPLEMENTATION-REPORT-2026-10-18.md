# COME-IN — Master Business Features Implementation Report

Date: 2026-10-18

## Source and preservation

- Continued from the current `COME-IN-HOME-SERVICES-COMPLETE-2026-10-18.zip` working copy.
- Created a new separately named ZIP; earlier source and backup ZIPs were not overwritten.
- Replit Preview, browser flows, live database, and payment gateway were not started or claimed as verified.

## Files changed in this phase

1. `backend/server.py`
   - Validates shop payment-method identifiers against the currently recognized options and validates a configured public UPI handle format.
   - Adds provider payment preferences limited to the currently supported informational options (`cash_after_service`, `cash_visit_fee`) and snapshots them into new appointment records. These preferences do not charge a customer or claim payment success.
2. `frontend/app/become-seller.tsx`
   - Adds a Cash at Shop / Pickup preference; clarifies COD and public UPI behavior and that a UPI handle is not payment verification.
3. `frontend/app/shop/[id].tsx`
   - Displays only payment options configured on a live shop. Public call, WhatsApp, directions and Come In Agent contact controls are restricted to offline-only shops; Call Shop is disabled when no shop phone exists.
4. `frontend/app/services.tsx`
   - Adds a provider profile edit path using the existing owner-protected API, shows configured cash payment preferences, and adds an explicit call-provider action using the saved phone number. Appointment payment remains `not_charged` unless a separate verified payment flow exists.
5. `frontend/app/restaurant/dashboard.tsx`
   - Extends restaurant registration/profile editing with description, cuisine categories, and restaurant image upload using the existing upload API. Profile edits reuse the owner-protected endpoint and correctly explain that material edits return the profile to pending review. Existing menu/order controls remain in place.
6. `backend/tests/test_home_services_remaining_contract.py`
   - Adds contract tests for shop payment configuration and display, provider payment preferences/calling, and restaurant profile editing/image upload.

## Tests and checks

- Python syntax compilation: PASS (`backend/server.py`, `backend/restaurant_pricing.py`, `backend/restaurant_serviceability.py`).
- Backend regression suite: **145 passed, 23 skipped, 0 failed** using `PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests`.
- Skips: existing remote integration tests requiring `COMEIN_TEST_BASE_URL`.
- Frontend typecheck: BLOCKED / not validly completed. `frontend/node_modules` is absent; globally installed `tsc` cannot resolve Expo/React Native types and the Expo base tsconfig. Full typecheck/build needs project dependencies installed.
- ZIP integrity: checked separately after packaging.

## Scope and limitations

- Shop `upi` is a public handle only; no QR-generation/payment verification was added. Online gateway methods are displayed only as configured options and still require supported checkout wiring/credentials. The app does not claim payment success based on a UPI app launch or screenshot.
- Home-service payment preferences are informational cash preferences only. No new home-service payment collection/gateway was added; appointment status and payment status remain separate.
- Existing restaurant menu/cart/checkout/order and configured Razorpay verification code was preserved; this phase did not execute a live payment.
- Native mobile photo-picker support is not added; restaurant/provider/shop upload UI uses the existing web upload flow. Upload depends on existing storage configuration and credentials.
- Offline shop call actions use `tel:` and depend on the device supporting phone links. No calls are initiated silently.
- Live MongoDB reservation concurrency, index creation against deployment data, object-storage upload, browser/mobile rendering, and full end-to-end workflows remain unverified.
- Existing Online Shops, product catalog, cart, checkout, authentication, Restaurant Mode, approval/ownership checks and prior project assets were retained; regression contract tests passed, but this is not a substitute for live E2E verification.
