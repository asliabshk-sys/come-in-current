# COME-IN — Restaurant Mode Shared-System Integration Report

**Date:** 17 October 2026  
**Scope:** Existing COME-IN project only. No new app, duplicate backend, production deployment, paid service, real payment, or CHAND browser preview.

## Summary

The audit confirmed that Shopping and Restaurant Mode already share the root `AuthProvider`, persisted bearer-token storage, `/auth/me`, and authenticated user identity. Restaurant addresses use the same authenticated `/addresses` API as the rest of the app. Restaurant orders retain their own category-specific cart/order contract while using the same signed-in user. This separation is intentional and was not replaced with a duplicate or mixed cart.

This update improves Restaurant checkout continuity by prefilling contact details from the shared signed-in profile, selecting the saved default address (or first saved address) when addresses load, allowing saved-address management, and linking to the existing one-shot current-location screen. The checkout continues to submit a selected `address_id` so the backend re-resolves it against the signed-in user's own address record; manually edited text drops the saved ID and is sent as manual delivery-address text.

## Files changed

1. `frontend/app/restaurant/checkout.tsx`
   - Reformatted into maintainable component logic.
   - Uses the existing shared `useAuth()` session/profile; no separate restaurant login or token was introduced.
   - Prefills contact name and phone from the shared user profile.
   - Loads the existing authenticated `/addresses` records and selects the default address, falling back to the first saved address.
   - Provides links to the existing Restaurant saved-address management screen and shared `/delivery-address` screen.
   - Explicitly explains that current location is optional, GPS permission is requested only when the user chooses the existing location screen, and GPS coordinates are not themselves a postal delivery address.
   - Keeps existing live-menu-only order validation, one-restaurant-per-cart isolation, backend order submission, idempotency key, and no-local-demo-order behavior.
   - Keeps online payment unavailable in this UI because a customer-facing Razorpay SDK/checkout flow is not present. Does not claim payment success or call payment APIs.
2. `backend/tests/test_frontend_contracts.py`
   - Adjusted the one-restaurant-per-cart contract assertion to match the newly formatted equivalent expression.
3. `backend/tests/test_shared_system_integration_contract.py` (new)
   - Adds source-contract checks for shared authentication, address ownership, saved-address selection, authoritative restaurant totals, order idempotency, shared restaurant tracking, payment confirmation safeguards, shared logout/roles, and the absence of a notification-provider claim.

## Existing architecture findings and gaps

### Account/authentication — PASS (source contract)
- One root `AuthProvider` and shared `TOKEN_KEY` bearer-token store serve both modes.
- Existing roles remain `customer`, `shopkeeper`, and `admin`; restaurant ownership is checked using `owner_id`, not a new role.
- Logout clears the shared token. Cross-mode browser/session behavior still requires runtime verification.

### Location and addresses — PARTIAL
- Existing Shopping location screen requests browser/device geolocation only after a button press, uses one-shot `getCurrentPosition`, reports denied/unavailable/timeout states, and does not background-track. Coordinates are not reverse-geocoded into a postal address.
- Saved addresses are account-scoped in `/addresses`; Restaurant checkout now preselects the default/first saved address and submits `address_id` where selected.
- **Gap:** no verified geocoding/address-validation provider or restaurant delivery-radius/serviceability lookup by coordinates exists in the inspected contract. The backend checks whether a restaurant offers delivery, but does not establish that a specific address is inside its delivery radius. Manual text is not a geocoded address.

### Cart and order flow — PARTIAL
- Grocery and Restaurant carts/order APIs remain separate, preserving category isolation. Restaurant order creation resolves menu prices/add-ons/variants server-side, checks availability and minimum order, applies `calculate_restaurant_totals`, validates delivery/pickup availability and supported payment method, and has an idempotency key.
- Live Restaurant order history and cancellation APIs exist. Checkout clears the Restaurant cart only after the order request returns successfully.
- No live database-backed end-to-end order was created in this task.

### Payments — BLOCKED for customer online checkout
- Backend Razorpay intent, verification, retry, webhook, amount/currency checks and admin-only refund endpoint exist in source.
- Frontend has no installed Razorpay checkout SDK or customer payment UI/flow. Online payment remains disabled; no gateway credentials were read or used, no payment intent was created, and no real transaction was attempted.
- Checkout currently submits COD for delivery or pay-at-pickup for pickup, with backend validation of restaurant-supported methods. Payment gateway readiness is not equivalent to a working customer checkout.

### Tracking — PARTIAL
- The existing shared `GET /orders/{order_id}/tracking?kind=restaurant` contract resolves Restaurant orders and enforces customer/restaurant-owner/admin access. Location updates require an authorized operator and `out_for_delivery` status; coordinates are not fabricated, and terminal states stop exposing location.
- **Gap:** no delivery-partner assignment/provider integration or mapping/ETA provider was found. Restaurant owner/admin location submission is not a substitute for a verified delivery-partner integration. Live rider tracking and ETA are therefore not claimed.

### Notifications — UNVERIFIED / GAP
- No shared push/SMS/email notification route/provider was found in the inspected backend API routes. Order status history is available, but it is not the same as delivered notifications. No notification provider was configured or activated.

### Theme/navigation — PASS (files untouched)
- Shopping theme, Restaurant pink/rose theme, branding assets, cart screens, order tracking screen, and root navigation/theme files were not changed by this integration patch.

## Verification results

| Check | Result | Evidence / limitation |
|---|---|---|
| Backend/source contract suite | **PASS** | `PYTHONPATH=. python -m pytest -c /dev/null -q -rs tests` → **78 passed, 23 skipped** |
| Remote integration tests | **SKIPPED** | 23 tests require `COMEIN_TEST_BASE_URL` for an isolated disposable deployment; no remote backend was contacted. |
| Python syntax | **PASS** | `python -m py_compile server.py restaurant_pricing.py` |
| Command safety guard | **PASS** | `node frontend/scripts/cmd-guard.js --preinstall` exited 0; guard was not bypassed. |
| Frontend typecheck | **BLOCKED** | `frontend/node_modules` and Yarn executable/lockfile are absent. Available global `tsc` cannot resolve Expo/React Native modules and project base config. No dependency installation or network retry was attempted. |
| Frontend lint/build | **BLOCKED** | Expo CLI and project dependencies are not installed locally. |
| Browser preview / visual regression | **DEFERRED** | Intentionally not run; wait until Replit credits refresh. |
| Real GPS device permission | **UNVERIFIED** | Source contract only; no browser/device permission prompt was exercised. |
| Live restaurant order/payment/tracking/notification provider | **UNVERIFIED** | No live order, payment, delivery partner, or notification provider was contacted. |

## Safety and preservation

- No production deployment, destructive migration, credential change, paid-service activation, real payment, or external provider call occurred.
- No new backend endpoint or database migration was introduced.
- The previous source ZIP `COME-IN-CHAND-Remaining-Work-Completed-Pre-Preview.zip` was retained as the rollback/source reference; it was not overwritten.
- CHAND browser preview remains deferred until Replit credits refresh.

## Remaining work before declaring full integration complete

1. Install dependencies in an authorized environment without bypassing `scripts/cmd-guard.js --preinstall`, then run Expo typecheck/lint/build.
2. After the user's Replit-credit refresh, visually test Shopping ↔ Restaurant navigation, shared login/logout, saved default address selection, and checkout error handling.
3. Add/verify a real address validation and restaurant serviceability contract before claiming address-level delivery availability.
4. Integrate a delivery partner assignment/location provider and mapping/ETA service only when a real supported contract and credentials are available; otherwise continue to show “not available”.
5. Add a customer-facing Razorpay SDK/checkout and retry flow only after the supported gateway configuration and isolated test setup are available; verify only through test credentials, never a real transaction.
6. Select and configure an approved notification provider/API before claiming push/SMS/email notifications work.
7. Run isolated backend integration tests for customer/shopkeeper/restaurant-owner authorization, address ownership, cancellation eligibility, payment failure/retry, and tracking access.
