# COME-IN — Functional Blockers, Network-Independent Pass (2026-10-18 v2)

## Scope and safety
Continued in the existing candidate working copy. No new app or roadmap was created. Original ZIPs and prior versioned ZIPs were not overwritten. No Replit/browser/device preview, production deployment, real payment, or external notification was initiated. No credentials were fabricated.

## Source changes
- Added `backend/tests/test_functional_blockers_regression.py` with 9 source-contract regression tests covering Grocery checkout quote/idempotency/COD fail-closed behavior; Restaurant payment methods and fulfillment rules; duplicate Restaurant order retry/unique-index declaration; Razorpay intent, verification, webhook and retry guards; Restaurant support ownership linkage and missing Grocery linkage; shared auth/address owner scoping; separate cart persistence; GPS permission/timeout and no background `watchPosition`; tracking-provider unavailable and terminal-state behavior.
- Updated `memory/COME-IN-MASTER-ROADMAP.md` with an evidence-based dated note. Existing 22 main tasks retained.
- No application runtime/payment/notification/provider behavior was changed because available evidence did not prove a safe functional integration path without credentials/provider/registry.

## Verification results

| Task | Status | Evidence / blocker |
|---|---|---|
| Backend regression suite | PASS | `PYTHONPATH=. python -m pytest -c /dev/null -q tests` → **104 passed, 23 skipped, 0 failed** |
| Python syntax | PASS | `python -m py_compile server.py restaurant_pricing.py restaurant_serviceability.py integrations/order_notifications.py integrations/delivery_provider.py` from `backend/` completed successfully |
| Frontend dependency install | BLOCKED | `npm ping --fetch-retries=0 --fetch-timeout=8000` → `EAI_AGAIN` resolving `registry.npmjs.org`; no useful npm cache, no `node_modules`, no `yarn` executable, and no `yarn.lock`, `package-lock.json`, or `pnpm-lock.yaml` found |
| TypeScript | BLOCKED | Dependencies absent; `expo/tsconfig.base` cannot resolve. No claim of typecheck pass. |
| Lint | BLOCKED | Expo CLI unavailable because dependencies absent. |
| Web build | BLOCKED | Expo CLI/dependencies absent; build not run successfully. |
| Expo compatibility | PARTIAL | `frontend/package.json` pins Expo `57.0.25`, React `19.2.3`, React Native `0.86.3`, TypeScript `6.0.3`, and related Expo modules to exact versions. `packageManager` specifies Yarn 1.22.22 with integrity suffix, but Yarn binary and lockfile are absent. Network unavailable so registry metadata/official compatibility validation could not be completed. No versions changed. |
| Shared auth/address | PARTIAL | Static regression contracts pass for root AuthProvider, shared token key, and authenticated owner-scoped address list/update/delete. Cross-mode runtime session not tested. |
| Shopping/Restaurant carts | PASS for intended separation | Regression test confirms distinct storage keys remain separate. Checkout end-to-end is UNVERIFIED. |
| Payment contracts | PARTIAL | Tests protect Grocery COD-only fail-closed behavior, quote/idempotency requirements, Restaurant COD/pay-at-pickup/Razorpay configuration and fulfillment rules, duplicate retry behavior, captured-payment/currency/order checks, webhook duplicate/cancelled-order guards. Razorpay sandbox credentials and gateway test not available; customer-facing online checkout remains not integrated. No real transaction. |
| Notifications | BLOCKED for delivery | Fail-closed provider interface exists and test confirms no token registration/refresh or notification API route. No provider credentials/configuration or event-delivery evidence. |
| Help & Support | PARTIAL/BLOCKED for Grocery linkage | Restaurant support endpoint validates order ownership. No generic/Grocery support order-link endpoint exists; not fabricated. |
| GPS/live tracking | PARTIAL/BLOCKED | Tests confirm permission denied, timeout messaging, one-shot current location and absence of background watch; unconfigured provider returns unavailable without fake coordinates/ETA. Device permission, rider assignment and live location stream unverified/unavailable. |

## Dependency/network evidence
- Node: `v22.16.0`
- npm: `10.9.2`
- Yarn: `yarn: command not found`
- Registry check: `npm ping --fetch-retries=0 --fetch-timeout=8000` failed with `EAI_AGAIN` / `getaddrinfo` for `registry.npmjs.org`.
- No lockfile was generated and dependency versions were not upgraded.

## Roadmap
The existing `memory/COME-IN-MASTER-ROADMAP.md` remains the only main roadmap and still has **22 main tasks**. The new dated note updates only evidence-supported status for Tasks 7, 10, 11, 13, 17, 18 and 20.
