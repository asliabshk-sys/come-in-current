# Come-In — Pay-at-Shop Compatibility Fix & Grocery Payment Sandbox Readiness

Date: 2026-10-30
Scope: Minimal Grocery Pay-at-Shop state correction and payment/refund sandbox readiness audit. Grocery gateway integration and Order Replacement were explicitly out of scope and were not implemented.

## 1. Baseline and preservation

- Active workspace: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`.
- Task 21–24 source was retained in place. No Task 24 ZIP was extracted over the workspace.
- Pre-change archive: `COME-IN-PAYAT-SHOP-PRE-CHANGE-20261030T090000Z.zip`.
- Pre-change archive size: 4,180,416 bytes.
- Pre-change SHA-256: `130bdd649cbec8a723a6ef6e53cb6fb1508a3c4144b47a8d7276602dd1eb2c30`.
- Pre-change ZIP integrity: PASS (`unzip -t`).
- No Git repository is present in this workspace; no Git commit/status is claimed.
- No dependency was installed. No gateway/network call, real payment, refund, production account, or customer-fund operation was performed.

## 2. Pay-at-Shop status decision

### Business meaning

Grocery `cash_shop` and `pickup` are accepted only when `fulfillment == "pickup"` (otherwise the API rejects the request). Therefore `pay_at_pickup_pending` is the semantically accurate canonical pending state. `cod_pending` remains the distinct Cash on Delivery state. Restaurant orders already use `pay_at_pickup_pending` for their non-COD pickup payment method; this was used only as a naming consistency reference, not by reusing Restaurant payment routes.

### Defect and minimal correction

Before the change:
- Grocery `create_order()` wrote `pay_at_shop_pending` for both `cash_shop` and `pickup`.
- `confirm_manual_cash_collection()` accepted `cod_pending` and `pay_at_pickup_pending`, but not `pay_at_shop_pending`.
- Seller Earnings displayed the cash-confirmation action for `cod_pending` and `pay_at_pickup_pending`, but not `pay_at_shop_pending`.

Changes made:
1. `backend/server.py`: new Grocery cash-at-pickup orders now receive `pay_at_pickup_pending`; COD remains `cod_pending` and UPI remains `awaiting_upi_payment`.
2. `backend/server.py`: cash collection confirmation accepts the legacy `pay_at_shop_pending` state for Grocery only, in addition to canonical `pay_at_pickup_pending` and `cod_pending`. Restaurant accepted states were not broadened.
3. `frontend/app/seller-earnings.tsx`: the cash-confirmation action is also shown for legacy `pay_at_shop_pending` records.
4. Added `backend/tests/test_grocery_pay_at_shop_status_contract.py` to protect canonical creation, legacy Grocery compatibility, explicit collection confirmation, and separation of COD / Restaurant states.

### Existing order compatibility and safety

- No stored order was migrated or bulk-updated.
- Existing Grocery records with `pay_at_shop_pending` remain eligible for the same confirmation action after fulfillment reaches `delivered` or `picked_up`.
- The endpoint still requires an authenticated current shopkeeper, live shop ownership, `confirmed=true`, and a completed delivery/pickup state.
- Confirmation writes `cash_collected`, actor, timestamp and audit record. It does not write `paid`.
- The endpoint remains compare-and-set guarded on the order's current payment and fulfillment status; duplicate confirmation returns the already `cash_collected` order.
- The old status remains in the existing Grocery cancellation allowlist; no cancellation rule was removed.
- Actual stored records were not enumerated because no live MongoDB connection was available. Compatibility is source-level, not a live-database migration test.

## 3. Grocery payment sandbox readiness audit

### Current state

- Grocery orders are stored in `db.orders`.
- Grocery checkout has quote validation, retry idempotency key, server-side price/stock resolution, and a MongoDB transaction for quote consumption and stock reservation.
- Grocery `online_razorpay` and `online_stripe` currently fail closed with `payment_method_unavailable`.
- Grocery UPI is a manual bank/UPI statement attestation flow. A UPI deep link or customer callback is not proof of payment capture. Current manual confirmation does not provide a gateway-captured payment record suitable for an automated refund workflow.
- There are no Grocery-specific payment-intent, payment-verification, webhook, refund, or provider reconciliation routes/collections in the audited source.
- Existing Razorpay intent/verify/webhook/refund routes and `restaurant_payments` / `restaurant_payment_events` are Restaurant-specific. They must not be reused or pointed at Grocery orders.

### Required Grocery-only design (not implemented)

Dedicated collections:
- `grocery_payments`: one record per payment attempt, linked to Grocery `order_id`, customer, provider, provider order/payment IDs, amount in integer paise, currency, status, idempotency key, timestamps, and refund state.
- `grocery_payment_events`: immutable/deduplicated provider webhook event records, unique by provider event ID.
- Add unique indexes for provider order/payment identifiers and scoped idempotency keys; define whether one order can have multiple sequential attempts and enforce only one active attempt.

Grocery-only routes to consider:
- `GET /grocery/payments/config` — return only the public key ID and enabled state.
- `POST /grocery/orders/{order_id}/payment-intent` — customer ownership check; eligible unpaid Grocery order only; calculate amount from the server-side order; create/reuse one idempotent attempt.
- `POST /grocery/payments/verify` — validate signature, exact provider order/payment IDs, captured status, INR currency and exact amount; then CAS-update the Grocery payment and `db.orders`.
- `POST /grocery/payments/webhook` — verify HMAC against the raw request body, deduplicate provider event ID, validate payment/order/amount/currency, and handle late capture safely.
- Admin-only Grocery refund and reconciliation endpoints, separate from Restaurant paths.

Amount and currency:
- Never trust client-supplied amount, currency, order total or provider IDs as authoritative.
- Store/compare money in integer paise (or exact Decimal); reject booleans, floats where exact integer paise is expected, negative/over-order amounts, non-INR currency and mismatched order totals.
- Bind each payment attempt to one specific Grocery order and customer. Additional replacement payment (future Task 25 only) must also bind to the exact order-replacement proposal ID and exact difference amount; customer acceptance alone is not payment.

Signatures and webhooks:
- Verify checkout signature using constant-time HMAC comparison and then verify the payment with the provider server-to-server before marking captured/paid.
- Verify webhook signature over the unmodified raw body before parsing; use a dedicated Grocery webhook secret; persist provider event IDs under a unique index.
- Duplicate request keys and duplicate provider events must return a safe idempotent result without creating a second charge or applying a second state transition.
- A signed event is authentic but still must match the persisted attempt, order, customer, amount, currency and allowed order state.
- Handle delayed/late captures after cancellation or expiry as reconciliation cases; never silently reopen or mark an invalid order paid.

Refund lifecycle:
- Separate `refund_requested` (local claim/request initiated), provider `pending`, provider-confirmed `processed`/`refunded`, provider `failed`, and ambiguous `refund_uncertain` states.
- A successful HTTP response or accepted refund request is not proof that money reached the customer. Only provider-confirmed processed/refunded status may update refunded totals and create a ledger reversal.
- On timeout/ambiguous response, set `refund_uncertain`, block automatic retries, and reconcile using provider refund/payment lookup or dashboard evidence before retrying or finalizing.
- Enforce refund amount <= verified captured amount minus prior successful refunds; record refund ID, amount, currency, provider status, actor, timestamps and audit evidence.

MongoDB transaction/fail-closed behavior:
- Use transactions/CAS for local multi-document transitions involving Grocery order, payment attempt, event, stock/replacement linkage and audit/ledger records.
- MongoDB transactions require a transaction-capable replica set or sharded deployment. The example Mongo URL uses a replica-set parameter, but actual deployment capability has not been tested.
- Do not fall back to non-transactional multi-write behavior if transactions are unsupported. Return a safe 503/409 and leave the order unpaid/unrefunded until reconciliation; external provider calls require a claimed/pending state because provider calls cannot participate in Mongo transactions.

### Sandbox configuration and secret handling

Recommended separate backend-only names for a future Grocery Razorpay sandbox:
- `GROCERY_RAZORPAY_KEY_ID`
- `GROCERY_RAZORPAY_KEY_SECRET`
- `GROCERY_RAZORPAY_WEBHOOK_SECRET`
- `MONGO_URL` (sandbox replica-set connection string; no production DB)

Existing Restaurant names `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` must remain scoped to Restaurant until a deliberate separate migration is approved. Do not copy Restaurant credentials into Grocery configuration implicitly.

Store secrets only in the backend hosting platform's encrypted environment/secret manager, or in a local `backend/.env` file that is gitignored and excluded from ZIPs. Do not put secrets in frontend `EXPO_PUBLIC_*`, source code, screenshots, reports, chat, or ZIP files. The public key ID may be returned to the client by a Grocery config endpoint; private key and webhook secret must remain backend-only. Use provider sandbox credentials and a sandbox webhook URL, never production credentials.

### Readiness blockers

- No Grocery sandbox credentials or Grocery webhook secret were configured/verified in this workspace.
- No `.env` files were present; the runtime environment was checked for presence only (secret values were not read or printed). `MONGO_URL` and the existing Razorpay variables were not configured in this execution environment.
- No provider sandbox request or webhook delivery was attempted.
- No live MongoDB connection/replica-set transaction test was possible.
- Therefore Grocery gateway integration remains NOT READY TO IMPLEMENT/VERIFY in this environment. This stage only records the safe design; no Grocery gateway code was added.

## 4. Tests and results

Command executed from `backend/`:

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_grocery_pay_at_shop_status_contract.py \
  tests/test_task9_order_actions_contract.py \
  tests/test_functional_blockers_regression.py \
  tests/test_financial_security_contract.py \
  tests/test_task10_payment_refund_notification_contract.py
```

Result: **37 passed in 0.71s**.

Separate known stale Task 23 tracking test was run independently:

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_shared_system_integration_contract.py::test_shared_tracking_endpoint_supports_restaurant_orders_without_fake_coordinates
```

Result: **1 failed**. Its assertion expects the old direct `order.get("restaurant_owner_id") == user.get("id")` check. Current Task 23 implementation checks the current role and live Restaurant ownership. This unrelated stale assertion was not edited or counted as a passing test.

These are source-contract tests only. No live FastAPI API, MongoDB, Expo Preview, Android/iOS device, provider sandbox, payment, refund or real cash collection was tested.

## 5. Changed files

- `backend/server.py`
- `frontend/app/seller-earnings.tsx`
- `backend/tests/test_grocery_pay_at_shop_status_contract.py` (new)
- `project-reports/COME-IN-PAYAT-SHOP-AND-GROCERY-SANDBOX-READINESS-2026-10-30.md` (this report)

No Grocery gateway routes/collections, Order Replacement logic, Restaurant payment/refund changes, dependency changes, database migrations or payment credentials were added.

## 6. Completion status

- Pay-at-Shop mismatch: **Implemented at source level; 37 targeted source tests passed.** Live UI/API/database verification remains pending.
- Legacy `pay_at_shop_pending` compatibility: **Implemented at source level; no DB migration.**
- COD separation and physical cash confirmation guard: **Preserved and covered by source tests.**
- Grocery payment sandbox readiness design: **Documented; sandbox not configured or tested.**
- Grocery Razorpay integration: **Not implemented.**
- Task 25 Payment/Refund blocker: **Still BLOCKED** for verified paid Grocery UPI/gateway orders, refunds, and additional payment. The Pay-at-Shop correction does not remove that blocker.
- Task 25 Order Replacement: **Not implemented and remains blocked** pending a separately approved, verified Grocery payment/refund foundation.
