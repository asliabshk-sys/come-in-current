# COME-IN Task 15 — Razorpay Checkout Audit and Completion

Date: 30 October 2026  
Working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
Status: **BLOCKED — customer-facing Razorpay checkout was not safely implementable in this environment; no payment source files changed.**

## Working copy and preservation

- Working copy exists, source files are readable, and the directory is writable.
- Task 10 payment/refund report was read. A separate Task 07 narrative report was not present in `project-reports`; the current checkout/security implementation and focused Task 07-era regression tests were inspected instead.
- No source file was edited. No credentials or `.env` contents were read or printed.

## Audit findings

### Existing backend — Restaurant payments

- `POST /restaurant/orders` creates the Restaurant order from server-side menu prices, variants, add-ons, delivery fee and tax. Razorpay orders start as `pending_payment` / `payment_status=pending` and use a customer-scoped idempotency key.
- `GET /restaurant/payments/config` returns whether server-side Razorpay keys are configured and only exposes the public key ID.
- `POST /restaurant/orders/{order_id}/payment-intent` authenticates and scopes the order to the current customer, checks pending state and server total, reuses an existing created intent, and creates the Razorpay order server-to-server.
- `POST /restaurant/payments/verify` checks customer ownership, payment/order linkage, signature, and then calls Razorpay server-to-server to verify captured status, amount and currency before marking paid.
- `POST /restaurant/payments/razorpay-webhook` validates the webhook HMAC, validates captured amount/currency/order, and handles duplicate event IDs when supplied.
- Task 10 report documents that payment/order writes are not proven atomic across MongoDB documents and require replica-set concurrency/reconciliation testing.

### Existing frontend — customer checkout

- `frontend/app/restaurant/checkout.tsx` offers COD and Pay at Pickup only. It creates Restaurant orders through the existing API and intentionally states that Razorpay customer checkout is not connected.
- `frontend/app/restaurant/order-confirmation.tsx` reports order persistence, not payment success.
- Grocery checkout `frontend/app/checkout.tsx` only offers shop-supported COD/UPI/cash/pickup options. Backend `/orders` explicitly rejects `online_razorpay` for Grocery checkout with `payment_method_unavailable`. No Grocery Razorpay flow was invented.

### Concrete missing capability and blocker

- `frontend/package.json` does not include `react-native-razorpay` or another Razorpay native SDK.
- The frontend project has no checked-in `android/` or `ios/` native projects in this working copy. Adding the official React Native native SDK therefore requires a native dependency/prebuild/build workflow that is not currently present or verified.
- `react-native-webview` is declared, but using Razorpay Standard Checkout inside a WebView is not a safe substitute for this app's production customer payment flow: Razorpay's documentation warns that WebView checkout has popup/UPI-intent/download limitations and recommends native SDK integration. The app's core market is India, where UPI intent compatibility is material.
- No sandbox credentials/configuration or sandbox runtime was supplied. No actual provider checkout can be validated here.

For these reasons, no improvised WebView checkout, frontend-only success callback, fake callback URL, or unsupported SDK import was added. The existing backend verification remains authoritative and unchanged.

Official Razorpay references inspected:
- WebView mobile integration: https://d6xcmfyh68wv8.cloudfront.net/docs/payments/payment-gateway/web-integration/standard/webview/
- React Native Android standard integration: https://d6xcmfyh68wv8.cloudfront.net/docs/payments/payment-gateway/react-native-integration/standard/build-integration-android/

## Files changed

- `project-reports/COME-IN-TASK15-RAZORPAY-CHECKOUT-REPORT-2026-10-30.md` — this audit/blocker report only.
- No application source, API, checkout UI, payment, order, stock, refund or navigation files were changed.

## Targeted checks

Commands:

```bash
python -m py_compile backend/server.py
PYTHONPATH=backend python -m pytest -c /dev/null -q backend/tests/test_task10_payment_refund_notification_contract.py backend/tests/test_p0_payment_checkout_completion.py backend/tests/test_grocery_checkout_security_contract.py
```

Actual results:
- Python syntax check: PASS.
- Pytest: **22 passed in 0.22s**.
- These are source-contract/regression tests, not Razorpay sandbox, live database or device integration tests.

## Backups

Pre-change:
- File: `COME-IN-TASK15-PRE-CHANGE-20261030T071134Z.zip`
- Path: `/mnt/data/COME-IN-TASK15-PRE-CHANGE-20261030T071134Z.zip`
- Size: `4,051,702` bytes
- SHA-256: `6789ca0360e3451b70c1d5a856fc934762cb274869adbd324bbf5af021a02c97`
- ZIP integrity: PASS.

Post-change:
- File: `COME-IN-TASK15-POST-CHANGE-20261030T071305Z.zip`
- Path: `/mnt/data/COME-IN-TASK15-POST-CHANGE-20261030T071305Z.zip`
- ZIP integrity, SHA-256, byte comparison and exclusion results are recorded in the final delivery report. The archive contains this report; its own checksum is therefore reported outside the archive to avoid a self-referential checksum.

The pre-change archive checksum was rechecked after post-backup creation. Existing task backups were not overwritten. Backup exclusions: `.env`/`.env.*`, secrets, dependency directories, virtual environments, build outputs, caches and `.git`.

## Verification limitations and remaining risks

- Razorpay sandbox: NOT VERIFIED; no sandbox credentials or runtime.
- Live MongoDB / replica-set transactions and concurrency: NOT VERIFIED.
- App Preview: NOT VERIFIED.
- Android device: NOT VERIFIED.
- iPhone device: NOT VERIFIED.
- No real payment, refund, customer transaction or production mutation was performed.
- Task 10's payment/refund reconciliation and notification-provider blockers remain.
- Production activation requires an approved native Razorpay SDK integration, native build configuration, sandbox credentials, callback/webhook configuration and isolated replica-set verification of payment/order consistency.

**Task 15 result: BLOCKED, not completed. Task 16 was not started.**
