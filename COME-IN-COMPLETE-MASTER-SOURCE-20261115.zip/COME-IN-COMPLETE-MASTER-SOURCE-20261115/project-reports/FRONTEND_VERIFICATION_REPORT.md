# COME-IN — CHAND Frontend Verification & Preview Report

Verification date: 2026-10-17

## Scope and protection
- Continued the existing working tree: `/mnt/data/come-in-phase2-work`. No new application was created.
- Existing latest CHAND ZIP was checked against the supplied SHA-256 and matched exactly: `9d3f581fee74a735c19d265ff09eb798e8938f5412e5c0e3b43cd7fbfd646828`.
- ZIP integrity/CRC check: PASS.
- Original project ZIP preserved: `/mnt/data/files/COME-IN-COMPLETE-PREVIEW-READY-2026-10-17.zip` — SHA-256 `0e5e93b275a3f981d2e00f243f9a55f08f0b450fa76983a3baad096d9eb6148a`.
- Pre-verification working-tree backup: `/mnt/data/come-in-backups/come-in-before-frontend-verification-20261017T164944Z.tar.gz` — SHA-256 `77cae32f134ea3fb376e956cd2046d16bdb44c72f29a8d02cec325f7195e0af3`.
- Git status: unavailable because the working directory is not a Git repository.
- No application source/config changes were made during this verification pass. This report records verification outcomes only.

## Architecture/source inspection
- Expo Router route file exists: `frontend/app/chand.tsx` (route `/chand`).
- Four role preview modes and role-specific prompt sets are present: Customer, Shopkeeper, Restaurant, Home services.
- Deterministic Demo Mode explicitly says it does not access real private data or claim live catalog/provider availability.
- Help & Support reads `/orders/mine`, `/restaurant/orders/mine`, and `/restaurant/support/mine` for signed-in users.
- Support submission uses the existing authenticated `POST /restaurant/support` endpoint after a review/confirmation step; UI shows the returned support reference and status.
- Backend support API checks linked restaurant order ownership against the authenticated user. Grocery order IDs are not passed as linked restaurant-order IDs; grocery references are only included in complaint text.
- No customer-facing refund-request endpoint was found. Refund assistance remains support-case-only; actual refund execution endpoint is admin-only. No refund API/payment was called.
- Shopping and Restaurant themes were not modified.

## Exact verification results

| Check | Result | Evidence / limitation |
|---|---|---|
| Latest CHAND ZIP hash | PASS | Actual SHA-256 matches supplied hash exactly |
| ZIP integrity | PASS | `unzip -t`: no errors in compressed data |
| Backend tests | PASS | `68 passed, 23 skipped, 0 failed` in `0.27s`; exit code `0` |
| Python syntax | PASS | `python -m py_compile server.py restaurant_pricing.py`; exit code `0` |
| Frontend typecheck | BLOCKED | `npm run typecheck` exit code `2`; no installed dependencies and no `expo/tsconfig.base`, causing missing React/Expo modules and cascading compiler diagnostics |
| Web build | BLOCKED | `npm run build:web` exit code `127`; `expo: not found` |
| Frontend lint | BLOCKED | `npm run lint` exit code `127`; `expo: not found` |
| Browser preview `/chand` | NOT RUN / UNVERIFIED | Expo CLI/dependencies absent; no app server could be started |
| Browser automation/screenshot | NOT RUN | Python Playwright package and Chromium binary are present, but there is no running web app to navigate; no screenshot fabricated |

### Backend skipped tests
The 23 skipped remote integration tests require `COMEIN_TEST_BASE_URL` to point at an isolated disposable test deployment. They were not run against production.

## Dependency and network blocker
- Node: `v22.16.0`
- npm: `10.9.2`
- Corepack: `0.32.0`
- Yarn executable: unavailable (`yarn: command not found`)
- `frontend/package.json` pins `yarn@1.22.22` through `packageManager` and defines a `preinstall` security guard script.
- No `yarn.lock`, `package-lock.json`, or `pnpm-lock.yaml` exists in `frontend`.
- `frontend/node_modules` is absent; npm cache has no useful package entries.
- A single DNS lookup for `registry.npmjs.org` returned no address. To avoid repeating a known failure, no further registry/alternate-host retries were made and dependencies were not installed. The project preinstall guard was not bypassed.

## Preview instructions once registry DNS works
From `frontend` on a machine/environment with working npm registry DNS:

```bash
corepack prepare yarn@1.22.22 --activate
yarn --version
yarn install
yarn typecheck
yarn build:web
yarn start
```

Keep the existing `scripts/cmd-guard.js --preinstall` behavior intact. When Expo reports its local server URL, open that host and navigate to `/chand`. Sign in only against a safe local/test backend to test real order/support data. Demo Mode should be usable without a provider API key. Do not configure paid AI or production services.

## Rollback
The pre-verification backup is separate and was created before this verification pass. To inspect it without overwriting the working tree:

```bash
mkdir -p /mnt/data/come-in-rollback-inspect
 tar -xzf '/mnt/data/come-in-backups/come-in-before-frontend-verification-20261017T164944Z.tar.gz' -C /mnt/data/come-in-rollback-inspect
```

Restore selected files from the extracted `come-in-phase2-work/` tree only if necessary; do not replace the current project wholesale. Preserve all earlier archives and the original ZIP.

## Cost and safety
- Demo Mode: no AI-provider key or paid AI call required.
- No deployment, billing activation, production database change, real refund/payment action, or order mutation was performed.
- The support submission API can create support cases but no server-side idempotency guarantee was confirmed. Customer refund eligibility/processing is not implemented as a customer API.

## Remaining work
1. Restore registry DNS/network access or use a trusted, pre-populated environment with the pinned package manager/dependencies.
2. Install through the project guard and run typecheck, web build and lint.
3. Start Expo, open `/chand`, verify mobile and desktop layouts and the support flow in browser automation, and capture a real screenshot if the app launches.
4. Use a disposable backend/test deployment to run the 23 remote integration tests.
