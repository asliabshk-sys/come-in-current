# COME-IN — Task 19: Seller & Admin Workflows Audit Report

Date: 30 October 2026  
Working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
Result: **One verified seller authorization gap fixed; targeted source-contract tests passed. Runtime verification remains unperformed.**

## 1. Active working-copy identification and preservation

The active working copy was identified from its root marker `COME-IN-WORKING-COPY-RECOVERED-V1.md`, which names this recovered V1 project and its frontend/backend live paths. No alternate ZIP or older folder was treated as the active source.

Task 18 evidence was read first. Its pre-change and post-change ZIPs were re-hashed and their ZIP integrity was checked before Task 19 work:

- Task 18 pre-change: `COME-IN-TASK18-PRE-CHANGE-20261030T072246Z.zip`, 4,111,196 bytes, SHA-256 `0ea04f65a46d10aad672ded487fdf69e6a845b1b5a29868c8f7e386bf64c1670`, `unzip -t` PASS.
- Task 18 post-change: `COME-IN-TASK18-POST-CHANGE-20261030T072454Z.zip`, 4,117,206 bytes, SHA-256 `db3602bc2e6b986d5a78e59326347acf12660bc16b50e07b81b23dbf1e2eaccc`, `unzip -t` PASS.

Also read Task 10, Task 12, Task 13, Task 14, Task 15, Task 16, Task 17 and Task 18 reports, plus the older `COME-IN-ROLE-SECURITY-RETAIL-PRICE-IMPORT-REPORT-2026-10-19.md` and `COME-IN-Execution-Report-Excel-Import-UI-2026-10-19.md`.

No standalone Task 07 or Task 09 narrative report was present in the active `project-reports` directory. Task 07/09 implementation details were therefore cross-checked against the current `backend/server.py` and the existing Task 07 checkout-security and Task 09 order-action contract tests. Task 08 was cross-checked against the older role-security/import report, current import implementation and import security tests. No secrets or `.env` contents were opened.

## 2. Workflows and source inspected

Backend:
- `backend/server.py`: shop owner helpers, product create/update/delete, master-product linking, seller CSV/XLSX import preview/apply, import history and audit routes, Grocery shop order listing/status/UPI confirmation, Admin route handlers, seller support listing/status update, Restaurant order/support ownership paths.
- `backend/tests/test_catalog_import_security_contract.py`
- `backend/tests/test_role_security_retail_import_contract.py`
- `backend/tests/test_task9_order_actions_contract.py`
- `backend/tests/test_task13_seller_support_status_contract.py`
- `backend/tests/test_task14_seller_support_ui_contract.py`
- `backend/tests/test_grocery_checkout_security_contract.py`

Frontend:
- `frontend/app/seller/products.tsx`
- `frontend/app/seller/orders.tsx`
- `frontend/app/seller/support.tsx`
- `frontend/app/admin.tsx`
- `frontend/app/admin-earnings.tsx`
- `frontend/src/lib/api.ts`
- `frontend/src/store/auth.tsx`

## 3. Audit findings — existing protections confirmed

### Seller Products

- Product create resolves the shop from the path ID and calls `_assert_shop_owner`; it writes the authenticated user as `owner_id` and checks duplicate SKU within that shop.
- Product update/delete require the current `shopkeeper` role for non-admin users, resolve the product's actual shop, check shop ownership and check the product's stored `owner_id` against the authenticated user.
- `ProductIn` validates positive bounded price, non-negative bounded integer stock, text lengths/nonblank required fields, MRP not below selling price, and unique variant IDs. Variant models validate stable IDs, positive prices, non-negative stock and MRP bounds.
- Update preserves existing variant/SKU fields when legacy clients omit them; it does not silently erase the selected variant inventory identity.
- Admin override remains explicit. No product CRUD defect was established in this audit.

### Bulk Import

- Import is authenticated and calls `_assert_shop_owner` for the requested shop; client-supplied `shop_id` is not treated as proof of ownership.
- CSV/XLSX headers are normalized and checked for blanks/duplicates; row count and file size are bounded; invalid numeric/formula-like fields, invalid prices/stock, malformed product IDs, duplicate IDs/SKUs and duplicate target rows are rejected.
- Update matching is scoped to the authenticated shop; unknown product IDs/SKUs and product identity conflicts stop the import before writes.
- Preview does not write. Apply requires explicit `apply=true` and uses one MongoDB transaction for product writes, price audit and import history; transaction failure returns unavailable instead of falling back to partial non-transactional writes.
- No additional import defect was established from the inspected source/contracts. Live transaction behavior remains unverified.

### Seller Orders

- `GET /shops/{shop_id}/orders` resolves the shop and uses `_assert_shop_owner`, which allows only the owning current shopkeeper or admin.
- Grocery order transitions already use an explicit transition map and conditional update on the previous status; invalid/stale transitions return conflict. Cancellation reuses the transaction-based cancellation/stock restoration path.
- UPI confirmation uses `_assert_shop_owner`; it does not trust a client payment callback and is restricted to the order's actual shop owner/admin.
- Restaurant order status handling already requires shopkeeper/admin, verifies restaurant ownership and `restaurant_owner_id`, and uses compare-and-set status updates.

### Seller Support

- `GET /seller/support` and `PATCH /seller/support/{ticket_id}` require `shopkeeper` or `restaurant` role.
- The listing derives owned shop/restaurant IDs from the authenticated user and returns only tickets linked to those orders.
- Status update loads the linked order, verifies actual shop/restaurant `owner_id`, checks the permitted `open -> in_progress -> resolved` transition and uses expected-status compare-and-set. Seller cannot set `closed` or trigger refund/cancellation.
- Task 14 UI uses the existing authenticated API client and does not replace backend authorization.

### Admin and ID/ownership security

- An AST-based route scan of all `/admin/` API routes found explicit `Depends(require_role("admin"))` dependencies. The new regression contract checks this for every discovered Admin route.
- Product, shop, order and support paths resolve IDs against stored records and check ownership rather than trusting a client-provided owner/user ID.
- No missing Admin role dependency or Seller Support ownership bypass was found in the inspected routes.

## 4. Verified defect and fix

### Defect

`PATCH /orders/{order_id}/status` previously checked whether a non-admin user's ID matched the shop's stored `owner_id`, but did not require that user's *current* role still be `shopkeeper`. The Admin role-management endpoint permits an authorized Admin to demote a former shopkeeper to `customer`; the historical shop can retain the former owner's ID. In that state, the demoted customer could still pass the old owner-ID-only check and update Grocery order status, even though other shop-management routes reject non-shopkeeper roles.

### Fix

In `backend/server.py`, `update_order_status` now:
- permits the explicit Admin override;
- otherwise requires `user.role == "shopkeeper"`;
- resolves the order's shop through `_get_shop_or_404` and calls `_assert_shop_owner` to verify current role and actual ownership;
- retains the existing allowed-transition map and conditional compare-and-set update unchanged.

This is a narrow backend authorization fix. It does not change UI, APIs, database schema, order transitions, stock, cancellation, payment or Restaurant Mode.

## 5. Exact changed files

1. `backend/server.py` — enforce current shopkeeper role plus actual shop ownership before a non-admin can update Grocery order status.
2. `backend/tests/test_task19_seller_admin_workflows_contract.py` — new source-contract regression tests for the role gate, all Admin route role dependencies, product/import scope and seller-support ownership.

No frontend files, package/dependency files, database schema/indexes, payment/refund code or Restaurant Mode files were changed.

## 6. Targeted verification and actual results

Commands run:

```bash
python -m py_compile /mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/backend/server.py /mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/backend/tests/test_task19_seller_admin_workflows_contract.py
```

Result: **PASS**.

```bash
cd /mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/backend
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_task19_seller_admin_workflows_contract.py \
  tests/test_task9_order_actions_contract.py \
  tests/test_catalog_import_security_contract.py \
  tests/test_role_security_retail_import_contract.py \
  tests/test_task13_seller_support_status_contract.py \
  tests/test_task14_seller_support_ui_contract.py
```

Result: **40 passed in 0.91s**.

These are source-contract/AST and focused regression tests. They do not exercise a running authenticated API or real database records.

## 7. Backup records and preservation

### Pre-change ZIP

- Filename: `COME-IN-TASK19-PRE-CHANGE-20261030T072756Z.zip`
- Path: `/mnt/data/COME-IN-TASK19-PRE-CHANGE-20261030T072756Z.zip`
- Size: 4,117,206 bytes
- SHA-256: `fe7a627973a21e8946c5e548ba14cde959a88e9b7105c62ed67f8d613936de54`
- ZIP integrity (`unzip -t`): PASS.

### Post-change ZIP

- Filename: `COME-IN-TASK19-POST-CHANGE-20261030T073100Z.zip`
- Path: `/mnt/data/COME-IN-TASK19-POST-CHANGE-20261030T073100Z.zip`
- Size: 4,118,648 bytes
- SHA-256: `3f92c8804e7c20c7c6b4801edf5876a0e66f585aeab388283bd23fc4d0b70ef2`
- ZIP integrity (`unzip -t`): PASS.
- All 295 archived files were compared byte-for-byte against the working copy: PASS.
- Compared against the pre-change archive, the only source/test file differences are `backend/server.py` (modified) and `backend/tests/test_task19_seller_admin_workflows_contract.py` (added). No other existing file was changed.
- The Task 19 report is stored separately in `project-reports/` and is intentionally not embedded in the post-change ZIP, so the recorded ZIP checksum remains independently verifiable without a self-referential archive hash.

Archive exclusions: `.env`/`.env.*`, secrets/key material, `node_modules`, `.git`, virtual environments, Python bytecode/caches, pytest/mypy/ruff caches, Expo caches, build/dist/coverage and logs.

### Earlier backup preservation

Task 18 pre/post ZIP hashes still match their recorded values (see Section 1). The earlier Task 07, Task 08, Task 09, Task 10 and Task 15 backup archives were also re-hashed; every hash matched the previously recorded values. No previous backup was overwritten, deleted or regenerated.

## 8. Remaining blockers and runtime verification

| Environment/check | Status |
|---|---|
| Live MongoDB / replica-set transaction and authorization tests | NOT TESTED |
| Running backend API with seller/admin/customer sessions | NOT TESTED |
| Expo Preview / browser runtime | NOT TESTED |
| Android emulator/device | NOT TESTED |
| iPhone/iOS device | NOT TESTED |
| Production access | NOT TESTED |
| Razorpay sandbox / real payment / refund | NOT TESTED / NOT PERFORMED |

Task 10 payment/order cross-document consistency and `refund_uncertain` provider reconciliation remain unresolved. Task 17 native Razorpay feasibility remains blocked by the native build environment. Grocery Razorpay remains disabled. No real payment, refund, customer transaction or production data mutation was performed.

## 9. Final assessment

**One verified seller authorization gap was fixed; targeted source-contract tests passed.** Seller Products, bulk import, Seller Support and Admin role dependencies had the expected source-level ownership/role protections in the inspected implementation. The Grocery seller order-status route now also requires the user's current `shopkeeper` role as well as actual shop ownership.

This is not a production-readiness claim. Live MongoDB, authenticated API, Preview and device verification remain outstanding. Task 19 stops here; Task 20 has not been started.
