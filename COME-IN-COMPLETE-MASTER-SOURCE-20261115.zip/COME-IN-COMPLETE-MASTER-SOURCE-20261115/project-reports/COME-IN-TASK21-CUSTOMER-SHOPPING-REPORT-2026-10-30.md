# COME-IN — TASK 21: Customer Shopping Workflow Completion

Date: 30 October 2026  
Active working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
Result: **Customer Product → Variant → Quantity → Add to Cart / Buy Now → Checkout source workflow improved. Targeted source tests pass; runtime verification remains pending.**

## 1. Previous evidence read

Read the available reports:
- `project-reports/COME-IN-TASK18-CART-VARIANTS-STOCK-CHECKOUT-REPORT-2026-10-30.md`
- `project-reports/COME-IN-TASK19-SELLER-ADMIN-WORKFLOWS-REPORT-2026-10-30.md`
- `project-reports/COME-IN-TASK20-PRODUCT-CATALOG-VARIANTS-STOCK-REPORT-2026-10-30.md`

The Task 18, 19 and 20 pre/post archives were also checked by SHA-256 and `unzip -t` before work. Their recorded checksums remained unchanged at final verification; none was overwritten or regenerated.

## 2. Screens and source inspected

Frontend:
- `frontend/app/(tabs)/index.tsx` — Home product sections use the shared `ProductCard`.
- `frontend/app/(tabs)/categories.tsx` — category navigation.
- `frontend/app/category/[slug].tsx` — category product list uses the shared `ProductCard`.
- `frontend/src/components/ProductCard.tsx` — product card, add stepper, options navigation and Buy Now.
- `frontend/app/product/[id].tsx` — product detail, variant selector, quantity stepper, add action and Buy Now.
- `frontend/src/components/QuantityStepper.tsx` — shared add/increment/decrement control.
- `frontend/src/store/cart.tsx` — variant-keyed cart state, product snapshots, stock cap and totals.
- `frontend/app/(tabs)/cart.tsx` — cart lines, variant-specific display, quantity changes, remove/replacement and checkout gating.
- `frontend/app/checkout.tsx` — shop/fulfillment/payment options, quote request, quote review, idempotency and order submission.
- `frontend/src/data/useCatalogProducts.ts` and `frontend/src/data/catalog.ts` — live catalog mapping and product/variant model.

Backend:
- `backend/server.py` — `GET /catalog/products`, `POST /grocery/quotes`, `_aggregate_grocery_quote_lines`, `_resolve_grocery_lines`, `_price_for`, `_quote_totals`, `_atomic_decrement_line`, and `POST /orders`.
- Related source-contract tests for cart variants, checkout security, Task 18 aggregation and Task 20 catalog/stock validation.

No `.env`, credentials or secret values were opened or printed.

## 3. Existing functionality and protections confirmed

- Home and category screens share `ProductCard`; catalog-only and demo products are not orderable. Variant products route to Product Detail so a specific pack must be selected.
- Product Detail already had a variant selector and selected-variant unit/price display. Its quantity stepper already called the shared cart store.
- Cart identity is `productId::variant::variantId`; separate variants remain separate lines. Cart rows show selected variant unit, price and quantity.
- Backend catalog output is limited to available products from approved shops. The client maps variant ID, unit, price, stock and availability into the live catalog.
- `/grocery/quotes` resolves current product and selected variant from MongoDB, validates availability/shop/stock, and calculates server-side prices and totals. Client-submitted item prices are not used to create the quote.
- `/orders` requires a quote token and idempotency key, re-resolves current server values, compares quote snapshots, claims the quote once, conditionally decrements stock and inserts the order in the transaction. Unsupported transactions fail closed; no non-transactional stock fallback exists.
- Task 18 duplicate `(product_id, variant_id)` cart rows are aggregated before quote-time stock validation.
- Task 20 numeric bounds and Task 19 authorization fixes were left unchanged.
- Grocery `online_razorpay` / `online_stripe` remain rejected by the backend. No payment integration was introduced.

## 4. Verified customer-workflow gaps

### A. Buy Now did not consistently isolate the selected item

The Product Detail Buy Now action previously added the selected product to the ordinary persistent cart and navigated to `/checkout`. It also disabled Buy Now whenever any other cart line existed, even if the selected item itself was valid.

The ProductCard Buy Now action also added to the ordinary cart before navigating. When other products from the same shop were already in the cart, the checkout therefore used the full cart rather than just the item on which Buy Now was pressed. This made Buy Now semantics inconsistent between ProductCard and Product Detail and could include unrelated same-shop cart lines.

### B. Quantity cap feedback

The shared cart add handler stopped incrementing at stock, but had no common per-line cap of 1,000. Product Detail and Cart quantity controls did not consistently explain when stock or the per-line quantity limit had been reached.

### C. Pickup preview total

Before a server quote was returned, Checkout's fallback total included the delivery fee even when Pickup was selected, although the fulfillment line was labelled “At shop”. The server quote correctly waives delivery fee for pickup; the pre-quote display could be misleading.

## 5. Changes made

### Isolated Buy Now selection

`frontend/src/store/cart.tsx`:
- Added an in-memory `buyNowLine` selection, separate from the persisted cart map.
- Added `startBuyNow(product, variantId, qty)`, which accepts only a live product with a shop ID, an integer quantity from 1 through 1,000, a valid selected variant when the product has variants, an available variant and sufficient known stock.
- Uses the selected variant's own unit/price/MRP in the temporary checkout line.
- Added `clearBuyNow()`; it clears only the temporary Buy Now selection. The normal persisted cart is not replaced or overwritten.
- Added a 1,000-unit per-line cap to ordinary cart increments. Existing stock cap remains in place.

`frontend/src/components/ProductCard.tsx`:
- Non-variant live products use the isolated Buy Now selection and then navigate to Checkout.
- Products with variants continue to route to Product Detail for explicit option selection.
- The Buy Now control shows unavailable state when a non-variant product cannot satisfy the local stock check.

`frontend/app/product/[id].tsx`:
- Keeps variant selection and quantity keyed to the selected variant.
- Defaults to the first available/in-stock variant where possible and resets the selection/message when the product changes.
- Add-to-cart and increment handlers now surface stock and 1,000-unit limit messages rather than silently doing nothing.
- Buy Now sends only the selected live product, selected variant ID and selected quantity into the temporary checkout line. It no longer adds a duplicate line to the normal cart or blocks merely because other cart lines exist.

`frontend/app/checkout.tsx`:
- Uses exactly `[buyNowLine]` when Buy Now is active; otherwise it continues to use ordinary `cartLines`.
- Shop selection, cart fingerprint, quote request, quote display and order submission all use the effective checkout lines.
- Still requests `/grocery/quotes` with only product ID, variant ID and quantity; server quote prices/totals remain authoritative.
- Retains quote expiry, changed-price/stock error handling, quote token and idempotency key.
- On successful Buy Now order, clears only the temporary Buy Now line and preserves all previously saved cart items. Normal cart checkout continues to clear the cart after success.
- Back navigation clears a pending Buy Now selection.
- Uses the same delivery-fee constants as the cart store and previews pickup with zero delivery fee.

`frontend/app/(tabs)/cart.tsx`:
- Preserves existing variant-specific cart rows and checkout gating.
- Adds clear inline feedback when a cart line reaches available stock or the 1,000-unit cap.

### Tests

- Added `backend/tests/test_task21_customer_shopping_workflow_contract.py` for isolated Buy Now line selection, variant identity, checkout quote inputs, cart preservation, quantity limits and existing stock-error handling.
- Updated the historical assertion in `backend/tests/test_task5_task7_ui_implementation_contract.py` to match the new extracted Product Detail increment handler while still asserting that it calls the selected-variant increment path.

No backend application source was changed. No database schema/index, API contract, authentication, navigation structure, theme, Restaurant Mode or payment behavior was changed.

## 6. Exact changed files

1. `frontend/src/store/cart.tsx`
2. `frontend/src/components/ProductCard.tsx`
3. `frontend/app/product/[id].tsx`
4. `frontend/app/(tabs)/cart.tsx`
5. `frontend/app/checkout.tsx`
6. `backend/tests/test_task21_customer_shopping_workflow_contract.py` (new)
7. `backend/tests/test_task5_task7_ui_implementation_contract.py` (updated assertion)

## 7. Targeted verification and actual results

### Source-contract tests

Command run from `backend/`:

```bash
PYTHONPATH=. python -m pytest -c /dev/null -q \
  tests/test_task21_customer_shopping_workflow_contract.py \
  tests/test_shopping_cart_variants_contract.py \
  tests/test_task5_task7_ui_implementation_contract.py \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_task20_product_catalog_variants_stock_contract.py
```

Actual final result: **36 passed in 0.41s**.

An earlier first attempt at the new test file had a quoting typo in one test assertion and failed during collection. That test assertion was corrected; the final command above passed. No application code was rolled back as a result of that test-authoring typo.

### TypeScript / JSX syntax transpilation

Used the globally available TypeScript compiler API `transpileModule` with JSX enabled (no module resolution or project type checking) against the five changed frontend source files. Actual result: **PASS for all five files**.

### Full frontend typecheck attempt

Command: `cd frontend && tsc --noEmit --pretty false`

Result: **BLOCKED / NOT A VALID PROJECT TYPECHECK**. `frontend/node_modules` is absent and `tsconfig.json` extends `expo/tsconfig.base`, which is unavailable without installed Expo dependencies. The command emitted unresolved Expo/React Native modules and missing JSX/lib configuration errors. No dependencies were installed and no network/DNS retry was attempted. The syntax transpilation above is not a substitute for the project's full TypeScript typecheck.

## 8. Backups and integrity

### Pre-change archive

- Filename: `COME-IN-TASK21-PRE-CHANGE-20261030T074012Z.zip`
- Path: `/mnt/data/COME-IN-TASK21-PRE-CHANGE-20261030T074012Z.zip`
- Size: `4,085,988` bytes
- SHA-256: `62a68a1e72bf722b81f766b34c17f9317ed71649b158fbd825859afb3cca2985`
- ZIP integrity (`unzip -t`): **PASS**
- Included files: 298

### Final post-change archive

- Filename: `COME-IN-TASK21-POST-CHANGE-FINAL-20261030T075412Z.zip`
- Path: `/mnt/data/COME-IN-TASK21-POST-CHANGE-FINAL-20261030T075412Z.zip`
- Size: `4,088,274` bytes
- SHA-256: `8c3ec687debba8688f54acd4d29e8f5382c14978aa485fd9091666be4e1356d0`
- ZIP integrity (`unzip -t`): **PASS**
- Included files: 299
- All 299 archived files compared byte-for-byte against the active working copy: **PASS**.
- The Task 21 report itself is intentionally excluded from this archive to avoid a self-referential archive hash; it is saved separately in `project-reports/`.

Both archives exclude `.env`/`.env.*`, secrets/key material, `node_modules`, `.git`, virtual environments, Python/pytest caches, Expo caches, build/dist/coverage directories and logs.

### Prior backup preservation

The following Task 18–20 archives were SHA-256 checked again and each matched its previously recorded hash. All six also passed `unzip -t`; none was overwritten, deleted or regenerated.

```text
0ea04f65a46d10aad672ded487fdf69e6a845b1b5a29868c8f7e386bf64c1670  COME-IN-TASK18-PRE-CHANGE-20261030T072246Z.zip
db3602bc2e6b986d5a78e59326347acf12660bc16b50e07b81b23dbf1e2eaccc  COME-IN-TASK18-POST-CHANGE-20261030T072454Z.zip
fe7a627973a21e8946c5e548ba14cde959a88e9b7105c62ed67f8d613936de54  COME-IN-TASK19-PRE-CHANGE-20261030T072756Z.zip
3f92c8804e7c20c7c6b4801edf5876a0e66f585aeab388283bd23fc4d0b70ef2  COME-IN-TASK19-POST-CHANGE-20261030T073100Z.zip
c4dd26c9eb6d05026e65f983b825e0b926d0e289373a16a940defbe2e9a47a93  COME-IN-TASK20-PRE-CHANGE-20261030T073334Z.zip
596dc11288b7d3487e111b5898f6692788df94a1e9cef2730f613ade4792a73d  COME-IN-TASK20-POST-CHANGE-20261030T073603Z.zip
```

## 9. Runtime status and remaining blockers

| Verification | Actual status |
|---|---|
| Focused source-contract tests | **PASS — 36 passed** |
| TypeScript/JSX syntax transpilation | **PASS — five changed files** |
| Full frontend TypeScript project check | **BLOCKED — Expo/React Native dependencies and `expo/tsconfig.base` absent** |
| Live MongoDB / replica-set | **NOT TESTED** |
| Running authenticated backend API | **NOT TESTED** |
| Live catalog / quote / order flow | **NOT TESTED** |
| Expo Preview | **NOT TESTED** |
| Android device/emulator | **NOT TESTED** |
| iPhone/iOS runtime | **NOT TESTED** |
| Production | **NOT TESTED** |

No real order, inventory mutation, payment or refund was performed. No dependency was installed. Task 17 Razorpay native-build feasibility remains blocked; Grocery online Razorpay payments remain disabled. Task 10 payment/order consistency and `refund_uncertain` refund reconciliation blockers remain unresolved.

## 10. Final assessment

**TASK 21 COMPLETE — source workflow changes made; runtime verification pending.**

The customer flow now has a consistent isolated Buy Now path that carries the selected product/variant/quantity into the existing server-quoted checkout without replacing or accidentally including unrelated saved cart lines. Existing Add to Cart, variant-keyed cart, one-shop checkout, server-authoritative quote, stock transaction, quote consumption and idempotency protections remain in place at source level. Pickup's pre-quote total preview no longer includes a delivery fee.

This is not a production-readiness claim. Full TypeScript project checking, live MongoDB/API verification, Expo Preview and Android/iPhone testing remain necessary.

Task 21 stops here. Task 22 has not been started.
