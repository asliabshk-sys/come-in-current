# COME-IN Setup Guide

This is the existing Expo Router / React Native Web frontend plus FastAPI/MongoDB backend. It is a source archive, not a compiled app. External payment, push, geocoding and delivery-provider services remain configuration-dependent.

## 1. Prerequisites

- Node.js compatible with the versions pinned in `frontend/package.json` (the project declares Yarn 1.22.22 via Corepack).
- Python compatible with `backend/requirements.txt`.
- MongoDB for API-backed features.
- Network access to npm/Yarn and Python package registries for first-time dependency installation.

## 2. Install dependencies

From the extracted project root (the directory containing `frontend/`, `backend/`, and `scripts/`):

```bash
bash ./scripts/replit-install.sh
```

The script uses the declared Yarn package manager and installs backend requirements. It does not create a database or configure secrets. If registry DNS/network access fails, resolve that in the target workspace rather than bypassing the project's command guard.

## 3. Configure the backend

Copy `backend/.env.example` to `backend/.env` for local development and edit the values locally. Do not put real credentials into the ZIP or commit them.

Required values:

- `MONGO_URL` — MongoDB connection string.
- `DB_NAME` — development database name.
- `JWT_SECRET` — unique, long random secret (not the example placeholder).

Optional values include `ADMIN_EMAIL` and `ADMIN_PASSWORD` for deliberate admin bootstrap; the server requires a sufficiently long admin password. Configure any external provider keys only when you intend to test that integration.

Start the backend from the project root:

```bash
cd backend
python -m uvicorn server:app --host 0.0.0.0 --port 8000
```

The server loads `backend/.env` automatically. MongoDB must be reachable. Do not point development tests at production data.

## 4. Configure the frontend

Copy `frontend/.env.example` to `frontend/.env` and set `EXPO_PUBLIC_BACKEND_URL` to a backend origin reachable from the browser.

- On the same local machine, `http://localhost:8000` may work.
- On a phone or remote workspace Preview, use the development machine's reachable LAN/workspace backend URL instead of `localhost`.
- Set this value before starting Expo; restart Expo after changing it.

Start the frontend Preview:

```bash
bash ./scripts/preview.sh
```

The existing Preview defaults to port **3000**. This script starts the frontend only; it does not invent a backend, fake successful checkout, or simulate GPS/tracking. The script may install declared dependencies if Expo is missing and the package registry is reachable.

## 5. Replit Run configuration

The existing `.replit` configuration is preserved and runs:

```bash
bash ./scripts/replit-run.sh
```

Use Replit Secrets for `MONGO_URL`, `DB_NAME`, `JWT_SECRET`, and `EXPO_PUBLIC_BACKEND_URL` when running the combined workflow. Frontend Preview uses port 3000; the API uses port 8000. Replit's Preview is a development workspace Preview, not a production deployment.

## 6. Run tests

Backend/source-contract suite:

```bash
cd backend
PYTHONPATH=. python -m pytest -c /dev/null -q -rs tests
python -m py_compile server.py restaurant_pricing.py restaurant_serviceability.py
```

The current report records 127 passing tests and 23 skipped remote integration tests. Those skipped tests require an isolated disposable deployment via `COMEIN_TEST_BASE_URL`. Do not point them at production.

Frontend checks after dependencies are installed:

```bash
cd frontend
yarn typecheck
yarn lint
yarn build:web
```

These frontend commands were not verified in the current environment because dependencies are missing and npm registry DNS failed. Do not interpret the setup commands as evidence that they passed here.

## 7. Catalog CSV/XLSX import

In the seller Products screen on web, choose **Import**, select `.csv` or `.xlsx`, inspect the validation preview, and explicitly choose **Apply validated import** only after reviewing the result.

Required columns:

```csv
name,brand,sku,action,unit,price,mrp,stock,category_id,description,available
Example Product,Example Brand,SKU-001,create,1 piece,10,12,25,household,Sample row,true
```

- New rows require `action=create`, a stable SKU, and a category ID.
- Update rows should use `product_id` or an existing SKU and `action=update` (the action defaults to update when an ID/SKU is supplied).
- `price` and `stock` are required; stock must be a non-negative whole number. MRP, when supplied, must be at least the selling price.
- A preview does not write to the database. Apply rechecks ownership/matches and uses a Mongo transaction; if transactions are unavailable, it fails closed.
- The import does not create verified market prices or invent stock. Each listing remains shop-specific.
- `.xlsx` parsing requires pandas and openpyxl, declared in `backend/requirements.txt`.
- Medical/Pharmacy and Stationery categories are restricted to directory-only listings by the existing backend rule.

## 8. Known limitations

- The current local environment did not have frontend dependencies installed; registry DNS lookup failed. Frontend typecheck/lint/build and browser Preview remain unverified.
- No database credentials were supplied to this pass. No live catalog counts, real prices, seller permissions, transaction behavior, announcement persistence or price-comparison offers were verified.
- Real push delivery, live rider tracking, reverse geocoding, payment settlement and provider-backed refunds require their own configured providers, credentials, permissions and testing.
- Do not claim a feature is production-ready based on source-contract tests alone.
