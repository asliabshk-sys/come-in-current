# COME-IN — Role Security + Retail Price Import Report

Date: 2026-10-19

## Base candidate preservation

- Continued from `COME-IN-Excel-Import-UI-and-Regression-Fixes-Pre-APK-2026-10-19.zip`.
- Expected/base SHA-256: `c0d7c26fcaa32661079c0a7db97057e2bc6b7eb40ebfa05029922b804e2779ee`.
- Base ZIP integrity passed before editing. Work was extracted to a separate working directory. The source ZIP was not overwritten.
- No APK was built. Restaurant Mode theme/branding files were not intentionally edited.

## Implemented in this working copy

### Role and ownership authorization

- Public registration always creates a `customer`; role is not accepted from the registration payload.
- Shop and restaurant onboarding may transition a customer to `shopkeeper`; there is no client-controlled path to grant `admin`.
- Shop-scoped management/import/template endpoints use the current database role plus shop owner ID checks. A non-admin must have `shopkeeper` role and own the target shop.
- Product update/delete checks now require shopkeeper role, the actual product shop's ownership, and matching product owner; admins retain their admin path.
- Restaurant management checks require shopkeeper role plus restaurant ownership; admin role remains the explicit override.
- Public shop/product and retail offer serializers remove internal owner/uploader identifiers.
- Added admin-only user listing and role management endpoints. Role changes cannot remove the current admin's own admin role or demote the last admin.
- Admin dashboard now has a Users tab and role-change actions. Existing account UI continues to show the Admin dashboard only for admin and shop-management links for shopkeepers.

### Retail Price Import

- Added Admin Dashboard tab: **Retail Price Import**.
- Added CSV template download and CSV/XLSX/XLS upload endpoints (Excel needs `pandas` + `openpyxl`/`xlrd`; CSV remains available without them).
- Import supports a preview phase and requires explicit `apply=true` to write.
- Required columns: `retailer`, `retailer_shop_id`, `name`, `price`. Supported/recommended columns: `sku`, `category_id`, `brand`, `pack_size`, `unit`, `stock`, `last_updated`, `source_url`.
- Validates required fields, finite non-negative price, non-negative whole-number stock, file type/size, and duplicate product identity keys within the same retailer/store file.
- Offers are stored separately by retailer + retailer shop ID + SKU (or name + unit when SKU is absent). This prevents retailer A's prices from overwriting retailer B's prices or COME-IN shop checkout prices.
- Successful imports record source retailer(s), filename, row counts, importer, import timestamp, and price audit history.
- Added admin-only import history endpoint and public `/catalog/retail-prices` feed. Added customer-facing `Retail Price Compare` screen linked from the Shops screen; it shows source retailer/store, reported retailer timestamp, import time, and stock snapshot.
- UI explicitly describes imported data as snapshots, not guaranteed live prices.

## Verification

- `python -m py_compile server.py restaurant_pricing.py restaurant_serviceability.py`: PASS.
- Backend tests: **162 passed, 23 skipped, 0 failed**.
- Base ZIP checksum/integrity were verified before editing; final ZIP verification is reported separately after packaging.
- Backend startup is blocked in this environment: `ModuleNotFoundError: No module named 'bcrypt'`.
- Frontend `npm run typecheck` is blocked by absent frontend dependencies and missing `expo/tsconfig.base`; `npm run lint` and `npm run build:web` are blocked because `expo` is not installed (`expo: not found`).
- No live MongoDB transaction/import run, live API authorization test, browser test, or end-to-end test was possible in this environment. Contract/unit tests do not substitute for these live tests.

## Still pending / important limitations

- No authorized retailer API or feed credentials/configuration were provided. Automatic/scheduled retailer sync and import-failure notifications are **not implemented**; retailer data updates only when an authorized fresh file is imported.
- The retail importer uses a defined template/column schema; a flexible interactive field-mapping wizard is not implemented.
- Imported retailer offers are kept separate from COME-IN shop listings and are visible on the Retail Price Compare screen/feed. They do not become purchasable COME-IN checkout inventory automatically. Checkout continues to use its own shop's backend-verified price/stock.
- Frontend build and live database authorization/transaction behavior must be verified in the configured Replit/runtime environment before treating the app as production-ready.
