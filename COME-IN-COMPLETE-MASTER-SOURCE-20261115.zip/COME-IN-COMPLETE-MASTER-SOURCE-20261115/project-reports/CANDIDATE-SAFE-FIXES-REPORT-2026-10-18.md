# COME-IN — Candidate Source Audit & Safe Fixes

**Date:** 2026-10-18  
**Source status:** Candidate only; not asserted to be the latest Emergent/Codex working copy.  
**Working copy:** `/mnt/data/come-in-candidate-audit-20261018/come-in-phase2-work/`  
**Original archive:** `/mnt/data/COME-IN-FINAL-PREVIEW-READINESS-2026-10-18.zip`  
**Original archive SHA-256:** `8262e53685bc83a82b4d3e43e11c513c915ee5b1ade2fb879ad0c57c74ceff00`  
**Integrity:** `unzip -t` passed; no corrupt entries found. Original archive was not modified.

## Changes made in this working copy

1. `frontend/app/(tabs)/account.tsx`
   - Added handlers for the previously inert Notifications, Payment Methods, and Help & Support rows.
   - Destinations: `/notifications`, `/payment-methods`, and existing `/chand` support/help screen.
2. `frontend/app/notifications.tsx` (new)
   - Honest capability status: candidate has no push-token registration/refresh endpoint and no configured push provider. No push prompt, test notification, or delivery claim.
3. `frontend/app/payment-methods.tsx` (new)
   - Documents candidate checkout capabilities only: grocery COD; restaurant COD for delivery or pay-at-pickup where backend/restaurant allows it; customer-facing online gateway checkout is not integrated. Does not save payment details or simulate payment.
4. `backend/tests/test_frontend_contracts.py`
   - Added a regression contract test verifying account navigation destinations and that new screens disclose missing integrations rather than claiming success.
5. `memory/COME-IN-MASTER-ROADMAP.md`
   - Added an evidence-backed dated audit note under the existing 22-task roadmap. No main task was added and no unrelated task was marked complete.

## Candidate feature audit

| Area | Status | Evidence and limits |
|---|---|---|
| Shared account/auth | PARTIAL | `frontend/app/_layout.tsx` has one `AuthProvider`; Restaurant pages use `useAuth()`. Static contract tests pass. Cross-mode runtime session continuity not browser/device-tested. |
| Saved addresses | PARTIAL | Authenticated `/addresses` backend routes and Restaurant address hook exist; backend contract tests pass. No runtime API/database session test was run. |
| Cart | PARTIAL | Existing Shopping and Restaurant cart stores use different storage keys (`frontend/src/store/cart.tsx`, `frontend/src/restaurant/cart.ts`). This is consistent with the roadmap's explicit instruction not to mix grocery/shop and restaurant items; they share app-level patterns but not one cart state. No architecture rewrite made. |
| Checkout/order creation | PARTIAL | Grocery uses quote + idempotency flow; Restaurant order creation has customer ownership/idempotency checks. Backend tests pass; no live database order was created. |
| Payment options | PARTIAL | Grocery UI/backend support COD; non-COD grocery methods are rejected with `payment_method_unavailable` (`frontend/app/checkout.tsx`, `backend/server.py:993-1005`). Restaurant UI submits COD for delivery or pickup pay-at-pickup (`frontend/app/restaurant/checkout.tsx:123-129`). Backend has Razorpay intent/verify/webhook routes (`backend/server.py:1771-1893`), including server-side checks, but the customer-facing Razorpay checkout SDK/flow is absent from the UI. No payment was initiated. |
| Duplicate order/payment protection | PARTIAL | Grocery order requires quote and idempotency key; Restaurant order contract uses idempotency key. Restaurant Razorpay intent reuses existing created intent and verifies captured payment server-side. Tests are source-contract/unit level, not gateway end-to-end. |
| GPS/current location | PARTIAL | `frontend/app/delivery-address.tsx` requests one-time browser/device location only after user action and explains permission errors. It does not implement background GPS tracking. Device permission flow not exercised. |
| Delivery/live tracking | BLOCKED for live rider GPS | Shared tracking route and UI exist, but `backend/integrations/delivery_provider.py` returns unavailable when no verified provider is configured. Existing order screen says live delivery-partner location is not connected. Contract tests confirm fail-closed behavior only. |
| Notifications/push tokens | BLOCKED for delivery | `backend/integrations/order_notifications.py` returns `not_sent` when provider is unconfigured. No notification or push-token API route was found in `backend/server.py`. No token registration/refresh or provider delivery test exists in this candidate. |
| Help & Support | PARTIAL | Existing `/chand` has support UI and attempts to use `/restaurant/support` APIs. Backend endpoints are restaurant support scoped; `frontend/app/chand.tsx:253` explicitly notes grocery complaints are not linked to grocery orders and there is no customer-facing refund request API. Account navigation defect fixed; no shared support backend was invented. |
| Order history | PARTIAL | Shopping `/orders` and Restaurant `/restaurant/orders/mine`/account history are separate routes. Restaurant order history is account-scoped, but a unified cross-mode history screen is not evidenced. |
| 22-task roadmap | UPDATED | Existing `memory/COME-IN-MASTER-ROADMAP.md` retained and appended a dated evidence note; still exactly 22 main tasks. |

## Actual checks

- Candidate archive integrity: **PASS** — `unzip -t /mnt/data/COME-IN-FINAL-PREVIEW-READINESS-2026-10-18.zip`.
- Source archive SHA-256: **PASS** — `8262e53685bc83a82b4d3e43e11c513c915ee5b1ade2fb879ad0c57c74ceff00`.
- Backend tests after edits: **94 passed, 23 skipped, 0 failed** — `cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests`.
- Python syntax: **PASS** — `python -m py_compile backend/server.py backend/restaurant_pricing.py backend/restaurant_serviceability.py backend/integrations/order_notifications.py backend/integrations/delivery_provider.py`.
- TypeScript: **BLOCKED** — `cd frontend && npm run typecheck` exits 2 because `frontend/node_modules` is absent and `expo/tsconfig.base`, React/Expo modules and type declarations cannot be resolved. The resulting diagnostics are not a valid clean TypeScript result.
- Frontend lint: **BLOCKED** — `npm run lint` exits 127 because `expo` is not installed in this working copy.
- Runtime/browser/device, backend database integration, Razorpay sandbox, notification provider delivery, GPS permission, rider tracking: **NOT RUN**. No Preview/Replit launch, paid service, real payment, external notification, or production deployment.

## Remaining blockers

- Latest Emergent/Codex source is still not established; this archive remains a candidate snapshot.
- Safe dependency installation is needed before a meaningful TypeScript/lint/build check. No package install was attempted.
- Razorpay customer checkout needs an integrated customer-facing SDK/flow and sandbox configuration before a sandbox end-to-end test.
- Push-token registration and a verified push provider/test sink are missing.
- Live rider GPS requires a verified delivery partner/provider and fresh authenticated location updates.
- Support API needs a shared customer-support contract if grocery order IDs are to be linked to tickets and a real customer refund request flow is desired.

No credentials were added, no production data was changed, no real payment/notification was initiated, and no preview was launched.
