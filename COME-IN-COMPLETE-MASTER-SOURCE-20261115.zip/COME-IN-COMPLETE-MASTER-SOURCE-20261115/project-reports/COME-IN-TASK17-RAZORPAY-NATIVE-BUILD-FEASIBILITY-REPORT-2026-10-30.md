# COME-IN — Task 17: Razorpay Native Build Feasibility Report

Date: 30 October 2026  
Working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
**Final status: BLOCKED — ENVIRONMENT**  
Scope: documentation and environment audit only; no payment integration implemented.

## 1. Executive result

The documentation review gives a **plausible native integration route**, but this environment cannot perform the required native builds. The official Razorpay React Native package is `react-native-razorpay`; the current official repository identifies version `3.0.0`, React Native peer dependency `>=0.66.0`, and a React Native Codegen module. Razorpay's official repository documents Expo installation and identifies Android and iOS native SDKs. Razorpay's 26 October 2026 article describes the current React Native Standard package as supporting New Architecture as well as the old architecture.

Come-In declares Expo `57.0.25` and React Native `0.86.3`, so the package's published peer range does not rule it out. However, **no source evidence or successful compile establishes that package 3.0.0 builds against this exact Expo SDK 57 / RN 0.86.3 app**. A native compile is the required proof and was impossible here because Yarn is not installed/activated, frontend dependencies are absent, Android SDK/Gradle/ADB are absent, and this host is Linux without Xcode/CocoaPods.

No separate experimental copy was created and no installation/build experiment was attempted. The stop condition was applied before any package, configuration, or source modification.

## 2. Existing evidence read

Read:

- `project-reports/COME-IN-TASK15-RAZORPAY-CHECKOUT-REPORT-2026-10-30.md`
- `project-reports/COME-IN-TASK16-RAZORPAY-NATIVE-INTEGRATION-PLAN-2026-10-30.md`
- `project-reports/COME-IN-TASK10-PAYMENTS-REFUNDS-NOTIFICATIONS-REPORT-2026-10-30.md`
- `backend/tests/test_grocery_checkout_security_contract.py` (Task 07-era source-contract tests; no standalone Task 07 narrative report was found under `project-reports/`)
- Actual source: `frontend/package.json`, `frontend/yarn.lock`, `frontend/app.json`, `frontend/app/restaurant/checkout.tsx`, `frontend/app/restaurant/order-confirmation.tsx`, `frontend/app/checkout.tsx`, and relevant routes/helpers in `backend/server.py`.

Task 15 records that the customer-facing Razorpay checkout is not implemented and no application source was changed. Task 16 records that no EAS profile, development-client dependency, or checked-in native project exists.

## 3. Actual project and host environment

### Project configuration

| Item | Observed value / evidence |
|---|---|
| Expo | `57.0.25` in `frontend/package.json` |
| React Native | `0.86.3` in `frontend/package.json` |
| React | `19.2.3` in `frontend/package.json` |
| Package manager declaration | `yarn@1.22.22` in `packageManager` |
| Lockfile | `frontend/yarn.lock`, Yarn v1 format |
| Static Expo config | `frontend/app.json` |
| Dynamic Expo config | No `app.config.js`, `.ts`, `.mjs`, or equivalent found in frontend root |
| EAS config | `frontend/eas.json` absent |
| Native project folders | `frontend/android/` and `frontend/ios/` absent |
| Development client | `expo-dev-client` absent from package manifest and lockfile |
| Razorpay SDK | `react-native-razorpay` absent from package manifest and lockfile |
| Installed JS dependencies | `frontend/node_modules/` absent |
| Existing workflow | `.replit` starts `scripts/replit-run.sh`; that script starts Expo Web (`npx expo start --web`). `scripts/preview.sh` also launches web Preview. |
| Existing platform scripts | `android` and `ios` scripts are `expo start --android` and `expo start --ios`; they are launch commands, not native build commands. |

The project tree does **not** prove whether a user previously opened it in Expo Go, installed a custom development build, or used EAS Build. The README lists these as possible development choices only. Therefore Expo Go use, a development build, and EAS Build use are all **NOT CONFIRMED**. The verified workflow represented by the checked-in scripts is web Preview.

### Host tools checked

| Command/check | Actual result |
|---|---|
| `node --version` | `v22.16.0` |
| `npm --version` | `10.9.2` |
| `yarn --version` | Failed: `bash: yarn: command not found` |
| `corepack` | Executable exists at `/opt/nvm/versions/node/v22.16.0/bin/corepack`; Corepack-managed Yarn was not activated or downloaded |
| `java -version` | OpenJDK `21.0.12.1` |
| `gradle` | Not found |
| `adb` | Not found |
| `javac` | Not found |
| `ANDROID_HOME`, `ANDROID_SDK_ROOT`, `JAVA_HOME` | Unset |
| `xcodebuild` | Not found |
| `pod` (CocoaPods) | Not found |
| `eas` / `expo` global commands | Not found |
| `node_modules` | Absent in project and parent |
| Host OS | Debian GNU/Linux 13, Linux x86_64 |

Node 22.16.0 meets the current React Native environment guide's Node 22.11+ requirement. The installed JDK is 21; React Native's environment guide recommends JDK 17 and warns that higher JDK versions may cause problems. Android Studio/SDK, platform-tools, Gradle, and an emulator/device bridge are unavailable. iOS local compilation requires macOS/Xcode; this Linux host cannot run `xcodebuild` or CocoaPods. EAS cloud builds can build iOS from another OS in principle, but this project has no `eas.json`, no EAS CLI/login evidence, and no EAS build was requested or run.

## 4. Official documentation consulted

1. Razorpay-maintained React Native SDK README — installation, Expo command, native Android/iOS wrapper, platform requirements, and test-key note:  
   https://github.com/razorpay/react-native-razorpay/blob/master/README.md
2. Razorpay-maintained React Native SDK `package.json` — version `3.0.0`, peer dependency `react-native >=0.66.0`, Codegen configuration:  
   https://github.com/razorpay/react-native-razorpay/blob/master/package.json
3. Razorpay article dated 26 October 2026 — Standard React Native SDK release/architecture notes, including v3.0.0 and New Architecture support:  
   https://razorpay.com/blog/react-native-flutter-payment-gateway-india/
4. Expo development builds — Expo Go vs custom native development build, local/EAS build options, and native module requirements:  
   https://docs.expo.dev/develop/development-builds/introduction/
5. Expo SDK 57 release notes — SDK 57 uses React Native 0.86; `expo@57.0.17` and later update RN to 0.86.3:  
   https://expo.dev/changelog/sdk-57
6. Expo SDK reference — SDK 57 platform baseline (Android compile/target SDK 36; iOS 16.4+ and Xcode 26.4+ in the current reference table):  
   https://docs.expo.dev/versions/latest/
7. Expo SDK 57 Build Properties reference — native build properties are generated through Expo prebuild; example Android compile/target 36 and iOS deployment target 16.4:  
   https://docs.expo.dev/versions/v57.0.0/sdk/build-properties/
8. React Native environment setup — Node 22.11+, JDK 17 recommendation, Android Studio/SDK prerequisites:  
   https://reactnative.dev/docs/next/set-up-your-environment
9. Razorpay React Native Android/iOS integration guides previously consulted and recorded in Task 16:  
   https://tfs.np.razorpay.in/docs/payments/payment-gateway/react-native-integration/standard/integration-steps-android  
   https://tfs.np.razorpay.in/docs/payments/payment-gateway/react-native-integration/standard/integration-steps-ios

The Razorpay repository README still lists old minimum iOS/Xcode/Swift versions. Those are not sufficient to establish compatibility with Expo SDK 57. The Expo SDK 57 toolchain/deployment baseline is the newer constraint for this app.

## 5. SDK compatibility findings

### Documentation-level support

- Candidate: official `react-native-razorpay` Standard Checkout wrapper.
- Current official repository version observed: `3.0.0`.
- Peer dependency: React Native `>=0.66.0`; Come-In's RN `0.86.3` satisfies this declared lower bound.
- Package includes a React Native Codegen module declaration.
- Razorpay's current article describes the Standard React Native v3.0.0 line as supporting old and New Architecture. This is positive documentation evidence for the architecture concern recorded in Task 16.
- Razorpay's README explicitly provides an Expo installation command and describes the package as a wrapper around native Android and iOS SDKs.
- Expo documentation explains that native modules require a custom development/production binary; Expo Go and web Preview cannot load arbitrary native modules.

### What remains unverified

- No official compatibility matrix explicitly certifies the exact combination Expo `57.0.25` + React Native `0.86.3` + `react-native-razorpay@3.0.0`.
- No dependency resolution was run, so the exact published package contents and native transitive dependency versions were not installed/resolved in this project.
- No Android Gradle compile or iOS CocoaPods/Xcode compile was run.
- The repository's peer dependency range is not proof that native code compiles against every later React Native release.

**Conclusion:** documentation support is encouraging, but exact project compatibility is **not verified**. A successful isolated Android and iOS build is still required before integration is approved.

## 6. Android and iOS native requirements

### Android

- Add the pinned, verified Razorpay React Native package only in a future isolated implementation/test copy first.
- Use Expo prebuild/Continuous Native Generation (CNG) so React Native autolinking can include the native module; a JavaScript-only web preview is not sufficient.
- Compile against the Expo SDK 57 generated Android configuration (current Expo reference: compile SDK 36 / target SDK 36). Do not lower the app's generated minimum SDK to match older Razorpay documentation.
- Required host tooling includes Android Studio/Android SDK platform and build tools, platform-tools/ADB, Gradle wrapper/native build, and a supported JDK. React Native currently recommends JDK 17; this host only has JDK 21.
- Build a fresh native development binary after adding the native package. Test app launch, checkout open/cancel/error/success callbacks and UPI app switching on a physical Android device; emulator-only success is not enough for external UPI app behavior.

### iOS

- Use the same pinned native React Native package and Expo prebuild/CNG.
- iOS native dependencies are resolved through CocoaPods in the documented repository flow; compile with a macOS/Xcode environment supported by Expo SDK 57. Current Expo SDK 57 reference specifies iOS 16.4+ and Xcode 26.4+.
- If UPI Intent app detection is required, configure the documented `LSApplicationQueriesSchemes` entries through Expo app config (`ios.infoPlist`) rather than manually editing generated files. Confirm the current official list and the business-required UPI apps before adding it.
- Build a new iOS binary after native dependency/config changes. Test on a real iPhone for app-switch return and UPI behavior; simulator compile alone cannot establish app-to-app UPI behavior.
- This Linux host cannot perform local iOS compilation. EAS cloud build is a possible future route, but account, project, profile and build evidence are absent here.

### Expo build workflow

The smallest likely route is an Expo custom development build using CNG/prebuild, then a production build from the same native dependency configuration. EAS Build is an option, not a fact about the current project. Before choosing it, explicitly configure and verify the Expo account/project and `eas.json` profiles. Local Android build is also possible after installing the missing Android toolchain. Do not try to use Expo Go or the existing browser Preview as the Razorpay SDK test environment.

## 7. Separate test copy and commands actually run

**Separate test copy:** NOT CREATED. The experiment was stopped before mutation because the necessary package/build environment is unavailable and the exact package compatibility has not been proven. No test-only dependency or configuration was added anywhere.

Commands/checks executed (read-only unless noted):

```bash
node --version
npm --version
yarn --version
java -version
command -v java javac gradle adb xcodebuild pod eas expo
command -v corepack npx npm python3 git
uname -a
find frontend -maxdepth 2 -type f \
  \( -name 'eas.json' -o -name 'app.config.*' -o -name 'yarn.lock' \
     -o -name 'package-lock.json' -o -name 'pnpm-lock.yaml' \
     -o -name 'Podfile' -o -name 'gradlew' \) -print
```

Actual results:

- Node: `v22.16.0`; npm: `10.9.2`.
- `yarn --version`: failed because `yarn` executable is missing. Corepack executable exists, but `corepack yarn` was not run because it could download a package-manager binary and would cross into network setup.
- Java: OpenJDK `21.0.12.1`.
- Android Gradle/SDK/ADB/Javac tools: not found; Android SDK environment variables unset.
- Xcode/CocoaPods/EAS/Expo global CLI: not found.
- `frontend/node_modules`, `frontend/android`, `frontend/ios`, `frontend/eas.json`: absent.
- No `npx`, `yarn`, `npm install`, `expo install`, `expo prebuild`, Gradle, CocoaPods, EAS or network/DNS retry command was run.
- No Android or iOS build command was run.

## 8. Existing payment flow and safety blockers

The eventual native checkout should reuse the existing Restaurant backend, not create another payment system:

1. `POST /restaurant/orders` creates a Restaurant order using server-side menu/variant/add-on prices and the server-calculated INR total; Razorpay orders begin pending.
2. `GET /restaurant/payments/config` reports whether server credentials are configured and exposes only the public Key ID.
3. `POST /restaurant/orders/{order_id}/payment-intent` creates/reuses the server-side Razorpay Order and returns the public checkout fields.
4. `POST /restaurant/payments/verify` checks authenticated ownership, order/payment linkage, HMAC signature, then verifies captured status, order ID, exact INR amount and currency with Razorpay server-to-server.
5. `POST /restaurant/payments/razorpay-webhook` validates webhook signature and captured payment/order/amount/currency, with event de-duplication when provider event ID is supplied.

The mobile success callback must only submit the returned IDs/signature to the existing backend verification endpoint. It must never mark an order paid locally. The signed webhook remains an independent asynchronous confirmation path.

Unresolved blockers that must remain open:

- Task 10 reports payment/order state transitions written across multiple MongoDB documents without proven atomic transaction/reconciliation behavior. Isolated MongoDB replica-set concurrency and delayed/duplicate webhook tests remain required.
- Task 10 refund route intentionally uses `refund_uncertain` for ambiguous provider outcomes and blocks automatic retries pending provider reconciliation. This remains unresolved; no refund behavior was changed or tested in Task 17.
- Razorpay sandbox credentials and webhook test configuration were not supplied. Do not read, print or commit secrets; use disposable test keys stored only in a secure backend environment when sandbox testing is approved.
- An isolated MongoDB replica-set test database is needed to test transactions, duplicate callbacks, concurrent verification, webhook ordering, delayed capture and cancelled-order reconciliation. No live or isolated database was connected in this task.
- Grocery checkout remains disabled for `online_razorpay`: `backend/server.py` rejects it with `payment_method_unavailable`. Do not enable Grocery Razorpay in the native UI or backend as part of the Restaurant integration.

No sandbox payment, refund, real payment or customer transaction was performed.

## 9. Files that a future implementation task may need to change

This is a planning list only; **none of these files were modified in Task 17**.

| Future file | Reason |
|---|---|
| `frontend/package.json` | Add an explicitly pinned `react-native-razorpay` release (and, only if the selected workflow needs it, `expo-dev-client`). |
| `frontend/yarn.lock` | Resolve and lock the exact SDK/native dependency graph using the project's Yarn package manager. |
| `frontend/app.json` | Add only required Expo native configuration; likely iOS UPI `infoPlist` schemes if UPI Intent is in scope. Do not add unverified plugin names. |
| `frontend/eas.json` | Only if EAS Build is selected; define separate development/preview/production profiles and platform build settings. |
| `frontend/app/restaurant/checkout.tsx` | Add the native checkout launch and callback/error/cancel handling while preserving existing Restaurant UI and authentication. |
| `frontend/app/restaurant/order-confirmation.tsx` | Show a paid state only after backend verification confirms it; otherwise retain pending/failure messaging. |
| Existing API helper used by Restaurant checkout (identify exact import before editing) | Call existing payment-intent and verification routes; do not duplicate endpoint logic. |
| `frontend/android/` generated by Expo prebuild (if native project is committed/needed) | Generated native autolinking/build output; avoid hand edits unless a documented native setting requires it. |
| `frontend/ios/` generated by Expo prebuild (if native project is committed/needed) | Generated CocoaPods/Xcode project; avoid hand edits unless a documented native setting requires it. |
| New focused frontend/backend contract tests under `backend/tests/` and/or frontend test location | Protect callbacks, cancellation, stale/duplicate callback handling, Grocery exclusion and existing backend verification contract. |

`backend/server.py` should be reused as-is for the initial native UI wiring unless a separate, evidence-backed backend task explicitly approves a consistency fix. Do not weaken or bypass the existing signature/capture/amount checks. The Task 10 database consistency issue must be addressed and tested before enabling real customer payments, not silently folded into a UI-only change.

## 10. Verification matrix

| Verification | Task 17 result |
|---|---|
| Documentation review | DONE (documentation evidence only) |
| Separate test copy | NOT CREATED |
| SDK dependency installation | NOT RUN |
| Expo prebuild | NOT RUN |
| Android native build | NOT TESTED — Android toolchain missing |
| iOS native build | NOT TESTED — Linux host; Xcode/CocoaPods missing |
| Expo browser Preview | NOT RUN in Task 17 |
| Android device/emulator | NOT TESTED |
| iPhone/device | NOT TESTED |
| Razorpay sandbox | NOT TESTED — no sandbox credentials/runtime |
| Live MongoDB / isolated replica set | NOT TESTED |
| Real payment/refund/customer transaction | NOT PERFORMED |

## 11. Main working-copy preservation

Only this report was added by Task 17:

`project-reports/COME-IN-TASK17-RAZORPAY-NATIVE-BUILD-FEASIBILITY-REPORT-2026-10-30.md`

No application source, `package.json`, `yarn.lock`, `app.json`, backend payment/refund behavior, checkout UI, navigation, stock, authentication, Restaurant Mode, or existing backup was changed. No package was installed. No secrets were read or printed. No real payment was performed.

SHA-256 fingerprints recorded before the report was written. After report creation, all seven application/dependency file hashes were re-run and matched these values exactly (PASS):

```text
frontend/package.json                                  75793519b2a52debf34678976abf46e7676133e7b69da2ddde07b288c8ac97ef
frontend/yarn.lock                                     66d78c5fdf21fc28b577a4baf54e2114dbe13e0db94a4127b44065bc41fc11ba
frontend/app.json                                      a0d7bf427858fd04593a6157cb11e8228bf090fdb8357b56389e6ed8a408019f
frontend/app/restaurant/checkout.tsx                   08cf5c101ca5091433cd227c76e6116bea9ee72fa2a597b193f6b427999229cf
frontend/app/restaurant/order-confirmation.tsx         0998f7cd47587875248e583bd78946e174f8d698b0ef6d9e65ff42765cec7033
frontend/app/checkout.tsx                               bc1cc9201ecb582280a5fe498dd2060244e3ff7bf2d16fc15cd7b2f8f2a164af
backend/server.py                                      f1544a0fb13deb6fb7c89e6cc084ac11afeb34a3b476144889bccd802e98ad5e
```

No application/dependency file hash changed. No backup archive was created or overwritten for this read-only audit.

## 12. Recommended next step

Do not implement checkout in the current environment. First arrange a disposable isolated build workspace with:

1. Node 22.11+ and Corepack/Yarn 1.22.22 available without changing the main project;
2. Android Studio/SDK (SDK 36/build tools), Gradle wrapper support, ADB/emulator or a test Android phone, and JDK 17;
3. a macOS/Xcode 26.4+ and CocoaPods environment for iOS, or an explicitly configured EAS cloud build account/project/profile;
4. the exact pinned Razorpay Standard React Native SDK release and disposable sandbox keys, stored securely only on the backend;
5. an isolated MongoDB replica-set database for payment/order concurrency and webhook reconciliation tests.

Then make a separate test copy, install the pinned SDK there, run Expo prebuild, and attempt Android and iOS builds independently. Record exact compiler output. Only after both platform builds pass and the Task 10 database consistency/refund reconciliation blockers have an approved test plan should a later task implement Restaurant customer-facing checkout. Keep Grocery Razorpay disabled.

**Task 17 stopped here. Task 18 and customer-facing Razorpay implementation were not started.**
