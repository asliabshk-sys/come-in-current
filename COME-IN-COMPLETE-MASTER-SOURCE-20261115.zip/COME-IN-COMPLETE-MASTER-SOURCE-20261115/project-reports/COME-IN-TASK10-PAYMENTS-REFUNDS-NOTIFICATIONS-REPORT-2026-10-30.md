# COME-IN Task 10 — Payments, Refunds and Order Notifications

Date: 30 October 2026  
Working copy: `/mnt/data/COME-IN-WORKING-COPY-RECOVERED-V1/`  
Status: **Partial source-level hardening; provider/runtime integrations remain blocked or unverified.**

## Scope and preservation

- Continued in the existing working copy; no application rebuild or architecture replacement.
- Preserved the existing frontend/backend/authentication/navigation and Restaurant Mode.
- Preserved Task 06–09 source state. No Task 11 work was started.
- Master v7 original manifest remains in `project-reports/MASTER-v7-ORIGINAL-MANIFEST.sha256`. No separate Master Backup v7 ZIP was present in the inspected `/mnt/data` top-level backup inventory; no v7 file was modified.
- The Task 09 pre-change archive was not modified; its SHA-256 was rechecked before and after this work and remained `0d6bd8dcfbbf547bfc161321523c8039b4bb9fad473a7c2d2705e7f18d17a77c`.

## Audit findings

### Payments

- Restaurant Razorpay payment-intent route creates/reuses a server-side Razorpay order and checks the amount/currency.
- Authenticated payment verification checks the Razorpay signature and then queries Razorpay server-to-server; it only marks paid when the provider payment is captured for the expected Razorpay order, exact INR amount and currency.
- The webhook validates `X-Razorpay-Signature` with the configured webhook secret, checks captured payment amount/currency/order, handles failed/captured/refund events, and records event IDs with a unique index when an event ID is supplied.
- The frontend customer checkout explicitly does not expose Razorpay; it supports COD/pickup only. The existing payment-intent/verify endpoints therefore do not constitute a customer-facing online checkout integration.
- Payment/order persistence across verification and webhook handling is split across multiple database writes, not a demonstrated atomic transaction. This remains a concurrency/reconciliation risk and was not rewritten without a configured replica-set test database and transaction tests.
- Webhook event deduplication depends on the provider event ID being present; the handler does not create a synthetic idempotency key when it is absent.

### Refunds

- Only the Admin-authorized Restaurant Razorpay refund route exists. It requires an order marked paid and a linked payment record with a gateway payment ID.
- No general Grocery refund API/lifecycle, customer refund request/approval workflow, or partial-refund workflow was found.
- The former admin refund handler could label an ambiguous request as failed after a timeout/exception, leaving room for an unsafe duplicate retry.

### Notifications

- `backend/integrations/order_notifications.py` defines a provider protocol and an unconfigured adapter that returns `accepted=False`, `status="not_sent"`.
- No order-notification/push/device-token registration route or verified delivery mechanism was found in the backend route inventory.
- No customer/seller push delivery is claimed. Provider credentials, recipient opt-in/permissions, durable event queue/idempotency, retry/backoff and delivery receipts are not configured.

## Implemented change

Changed `backend/server.py` only in the Admin Restaurant refund handler:

- Claims a refund request using a conditional database update before calling the provider, so concurrent admin requests cannot both proceed from the same unpaid-refund state.
- Treats provider timeout, HTTP error, malformed response, missing refund ID or unknown provider status as `refund_uncertain`, not as a confirmed failure.
- Blocks another refund attempt while the state is `refund_requested`, `refund_uncertain`, legacy `refund_requested_failed`, `pending`, `processed` or `refunded`; these cases require provider-dashboard reconciliation.
- Maps provider-confirmed `failed` to `refund_failed`; provider-confirmed `processed`/`refunded` alone can create the existing financial-ledger reversal.
- Does not invent provider idempotency capabilities or credentials. The local claim reduces concurrent duplicates but is not a substitute for provider-side idempotency or transactionally durable orchestration.

Added `backend/tests/test_task10_payment_refund_notification_contract.py` to protect the refund claim/uncertain state, Admin authorization, provider-confirmed completion, existing payment signature/capture checks and notification fail-closed behavior.

## Focused tests

Command (from `backend/`):

```bash
python -m py_compile server.py
PYTHONPATH=. python -m pytest -c /dev/null -q tests/test_task10_payment_refund_notification_contract.py tests/test_functional_blockers_regression.py tests/test_p0_payment_checkout_completion.py
```

Actual result: **22 passed in 0.39s**; `py_compile` passed. These are source/contract/helper tests, not live provider, database or device tests.

## Configuration and verification blockers

- Razorpay environment variable names documented in `backend/.env.example`: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`. Values were not read, printed or included in the report/archive. No test credentials or public webhook endpoint were supplied for this run.
- Frontend customer-facing Razorpay SDK/checkout is not integrated; Restaurant checkout intentionally offers COD/pickup only.
- No provider sandbox payment, refund, webhook replay, duplicate/concurrency test, or real-money transaction was run.
- No live MongoDB replica-set transaction/concurrency test was run. Database atomicity and event delivery remain unverified.
- Notification provider is unconfigured and fail-closed; no real notification was sent.
- Frontend dependencies/Preview/device runtime were not installed or launched. No dependency/network retry was attempted.

## Remaining risks / next safe prerequisites

1. Before online checkout activation, add the approved customer-facing Razorpay SDK flow and test it with disposable sandbox credentials, including cancellation, delayed capture, retries, duplicate callbacks and amount/currency mismatches.
2. Move payment/order/refund state transitions that require cross-document consistency into verified MongoDB transactions or another proven durable workflow; test on an isolated replica set.
3. Reconcile uncertain refunds against the provider dashboard before any retry. A `refund_uncertain` state is intentionally not auto-retryable.
4. Implement Grocery refund workflow only after the authoritative payment/collection source and customer/admin authorization rules are agreed.
5. Configure a supported notification provider and event delivery/receipt mechanism, opt-in, durable idempotency, retries and dead-letter handling before enabling order notifications.

No live payment, refund, notification, production database mutation, deployment or Task 11 work was performed.
