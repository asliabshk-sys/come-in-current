# COME-IN — Next Steps (after Task 18 QA Iteration 3, 2026-11-11)

1. **Task 18 runtime recovery:** use a workspace where the existing Expo dependencies and CLI are already present; start the existing Preview without installing dependencies; verify checkout/order/admin UI changes at desktop and mobile widths.
2. **Task 18 refund integration:** in an isolated test environment, use a disposable MongoDB replica set and mocked Razorpay HTTP responses to test first refund, duplicate admin request, existing manual full/partial refund, pending provider refund, failed refund retry, webhook duplicate, cumulative partial-to-full refund, and over-cap provider data. Do not use production data or live keys.
3. **Task 18 backend runtime:** install/use an already provisioned test-only environment with compatible Motor/PyMongo; run the relevant API tests against the disposable database. This current environment has no Motor/PyMongo/mongod, so no such tests were run.
4. **Task 5 verification gate:** Seller Measured UI runtime and the seven Phase 2B live transaction tests remain pending. Do not start further Task 5 phases until the existing gate is resolved.
5. **Task 17:** only after owner-approved Razorpay TEST keys are stored securely, run the payment checklist; no keys are currently used.
6. **Task 16:** run restore drill into a disposable DB; restrict production CORS; consider external security audit.
7. **Task 20:** push notifications remain optional and blocked on Firebase configuration + native build.
8. **Task 21:** runtime-test price comparison with linked master variants and distance data.
9. **Task 19:** production build/launch only with explicit owner approval, secrets and cost approval.

## Rules
- Continue from the current source; do not rebuild or repeat completed tasks.
- Preserve Shopping and Restaurant Mode separation, existing theme/navigation, Task 5 business rules, and all historical records.
- Never use production DB/credentials for tests.
- No dependency installation or network retry without explicit approval.
- Keep statuses evidence-based; source implementation is not Runtime Verified.
