# COME-IN — QA Report (Task 18 Iteration 3)

**Date:** 2026-11-11  
**Batch:** Task 18 QA Iteration 3  
**Scope:** Safe source fixes and focused regression only. No MongoDB/provider/UI runtime.

## Current batch test results

| Check | Result | Scope |
|---|---:|---|
| Focused pytest | **43 passed / 0 failed** | 5 selected test files; database-free |
| Python compilation | PASS | `backend/server.py`, `backend/refund_rules.py`, new Task 18 test |
| TypeScript syntax transpilation | **0 diagnostics** | `checkout.tsx`, `orders.tsx`, `admin.tsx`; not full typecheck |
| Expo Preview | NOT RUN | Expo CLI, Yarn and `frontend/node_modules` absent |
| MongoDB runtime | NOT RUN | Motor/PyMongo/mongod/mongosh absent |
| Razorpay provider | NOT RUN | No TEST credentials/provider call |
| Native device | NOT RUN | No native build/runtime |

Command:
```bash
python3 -m pytest -c /dev/null -p no:cacheprovider -q \
  tests/test_task18_refund_safety_iteration3.py \
  tests/test_grocery_checkout_security_contract.py \
  tests/test_task10_payment_refund_notification_contract.py \
  tests/test_task22_checkout_audit_contract.py \
  tests/test_p0_payment_checkout_completion.py
```

## Bugs addressed

1. **Refund duplicate/over-refund safety:** verify order total equals captured amount in integer paise; atomically claim a refund request; query every provider refund-history page before issuing a new full refund; fail closed if history is unavailable, malformed, already pending, partial or completed.
2. **Refund accounting:** record provider refund events by refund ID; accumulate pending/completed amounts; do not mark a partial refund as fully refunded; do not reverse the full financial ledger until cumulative provider-confirmed refunds equal the eligible order amount.
3. **Admin refund feedback:** show provider status, confirmed refund amount and pending amount; hide retry for pending, partial, uncertain or reconciliation-required states.
4. **Checkout fulfillment:** explain when neither delivery nor pickup is available; show an options-loading message.
5. **Empty cart:** suppress misleading payment-method configuration warning when there are no checkout lines.
6. **Orders pickup wording:** Grocery pickup orders show “Pickup from shop”, not “Delivering to …”.

## Not addressed / remaining

- Automatic Grocery refunds are not implemented by this change.
- Existing provider refund activity causes the current full-refund workflow to stop for manual reconciliation; it does not automatically submit a remaining partial amount.
- No mocked HTTP integration test or real provider API test was run.
- No live DB concurrency/rollback test was run.
- Atta product image/description was not changed because no approved/verified product image asset was present.
- Notification preference switches mentioned in the earlier QA note were not found in the current frontend source; no new controls were invented.
- Historical BATCH-02 had 28 stale static contract failures. Three related contract test files were refreshed in this batch, but the full suite was not rerun; the current remaining stale-failure count is unknown.

## Environment / recovery blockers

- The archive has no `.git` directory/history.
- `scripts/preview-mongo-replset.sh` is missing. `scripts/preview.sh` and `scripts/replit-run.sh` exist but attempt dependency installation when dependencies are absent; neither was run.
- Node 22.16 and global TypeScript are available; Yarn, Expo CLI and frontend `node_modules` are absent.
- Python 3.13.5 and pytest are available; Motor and PyMongo are absent.
- `mongod`, `mongosh`, Docker and Podman are absent.
- No production database, production credentials, Razorpay or network retries were used.

## Historical BATCH-02 results — kept separate

The uploaded source reports: 393 PASS, 28 stale static FAIL, 3 BLOCKED, 27 NOT TESTED; backend runtime 61/61 PASS and frontend E2E 13/13 PASS were reported in that previous Emergent environment. Those historical results are not counted in the current 43-test result and were not independently rerun here.

## Final status

**Task 18: PARTIALLY IMPLEMENTED — TESTING REQUIRED.** Source fixes and focused tests are complete. Runtime/provider/database/device verification remains pending.
