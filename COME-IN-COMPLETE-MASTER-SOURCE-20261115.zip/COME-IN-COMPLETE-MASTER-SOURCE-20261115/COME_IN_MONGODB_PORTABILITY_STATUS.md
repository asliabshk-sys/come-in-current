# COME-IN — MongoDB Portability Status

## Checkpoint (2026-11-11) — COME-IN-MONGODB-PORTABLE-CHECKPOINT
- Baseline: `COME_IN_MASTER_BACKUP_TASK5_LIVE_RESUMPTION_2026-11-11.zip` — internal MANIFEST.sha256 609/609 PASS before any change.
- MongoDB 7.0.45 single-node replica set `rs0` provisioned in the Emergent workspace on 127.0.0.1:27018 (platform standalone mongod keeps 27017).
- `scripts/mongo/setup.sh` → PRIMARY ready; `init` 44 collections / 54 indexes; `testdb-cycle` PASS (disposable DB created and dropped); `health` PASS incl. transaction commit + abort.
- Backend (FastAPI) connected to rs0; `GET /api/` → `{"service":"come-in","status":"ok"}`. Expo 58.0.17 web preview renders on port 3000.
- Frontend deps installed with `yarn install --frozen-lockfile` (Yarn 1.22.22); no dependency versions changed. Only change to package.json: `start` script honours `PORT`.
- Docker Compose template (`mongo:7.0.45`) included but **NOT VERIFIED** — Docker is unavailable in this workspace.
- The ZIP does **not** contain a MongoDB server or data.
- Task 5 at checkpoint: **PARTIAL** — seven T5-MONGO scenarios, Expo Seller/Customer Preview, measured Repeat Order E2E and transaction-backed import not yet run.

Docs: `docs/mongodb/`. Scripts: `scripts/mongo/`, `scripts/verify-env.sh`, `scripts/release/`. Infra: `infra/mongodb/`.

## Checkpoint ZIP
- `COME-IN-MONGODB-PORTABLE-CHECKPOINT_2026-11-11.zip` — SHA-256 `89dbd9acf6dab02ab8e4c15db35978c2c3362787e316c2ecade4ded661efce32`, 504 manifest entries, extraction + manifest verify PASS, secret scan PASS.
- Clean-directory restoration test of this ZIP (`scripts/release/restoration_test.sh`, port 27019, fresh venv, empty yarn cache): **PASS**. Same Emergent pod, separate directory — not a new Emergent account.

## Final (2026-11-11) — COME-IN-MASTER-COMPLETE-TASK5-MONGODB
- Task 5 live: T5-MONGO-01..07 + measured Repeat Order + transaction-backed import: **9/9 PASS** (twice). Expo Customer + Seller Preview: **PASS**. Full backend regression: **415 PASS / 0 FAIL / 23 skipped**.
- Task 5 status: **COMPLETED** (preview scope). Open low finding F-1 (concurrent losers get 503 instead of 409; no oversell).
- Report: `COME_IN_TASK5_LIVE_MONGODB_COMPLETION_2026-11-11.md`. Final ZIP SHA-256 is in its adjacent `.sha256` sidecar (a ZIP cannot contain its own hash); its restoration result is in the adjacent `_RESTORATION_RESULT.txt`.


## MongoDB master completion mission — 2026-11-14 (PARTIAL)

- Source inventory: 50 application collections and 65 declared indexes (59 `_startup` + 6 Delivery Partner startup handler).
- Added strict Mongo client configuration, startup ping/topology check, index discovery/init/drift/restore verification, unique-index duplicate preflight, conservative checkout conflict classification and atomic Grocery payment/order capture.
- Backup/restore now uses mode-0600 MongoDB Tools config files; restore is restricted to disposable `comein_disposable_test_*` DBs.
- Offline targeted suite: 92 PASS; compileall and shell syntax PASS. No live MongoDB tests ran in this environment because mongod/mongosh/MongoDB tools, Motor and PyMongo are unavailable.
- See `docs/mongodb/MONGODB_MASTER_COMPLETION_REPORT.md` and `reports/MONGODB_FINAL_TEST_EVIDENCE.md`. Live transaction retries, unique-index duplicate preflight, validators, data integrity, production security/backup and final Catalogue Import remain BLOCKED.
