# Git Preservation Record — MongoDB Mission

- Repository branch: `main`
- HEAD at mission start: `4681a4c0ca3e45787825f4b196b3284daa23a1f0`
- No reset, clean, checkout, stash, rebase or commit was performed.
- Existing user changes and the Git index were preserved.
- The 15 pre-existing executable-bit differences remain: the Git index records mode `100755`, while the extracted working-copy files are mode `100644`. No chmod/reset was used to normalize them.
- New source/docs/tests were added as ordinary working-tree changes; no commit was created.
- Current status and content diffs remain in the working copy's `.git` metadata. The distributable checkpoint ZIP excludes `.git` to avoid exporting repository history containing unrelated/private historical content; the original working copy retains the full Git repository and index.
