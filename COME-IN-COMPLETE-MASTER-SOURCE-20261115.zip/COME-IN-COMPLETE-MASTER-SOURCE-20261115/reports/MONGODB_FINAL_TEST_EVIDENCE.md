# COME-IN MongoDB Final Test Evidence

**Execution environment:** extracted working copy `/mnt/data/COME-IN-MONGODB-PHASE2-WORK`; Python 3.13.  
**No live MongoDB service was available.** `mongod`, `mongosh`, Docker/Podman, `mongorestore`, Motor and PyMongo were not installed. All results below are offline/static/synthetic unless explicitly identified otherwise.

## 1. Python compilation

Command:

```bash
python -m compileall -q \
  backend/mongo_config.py \
  backend/mongo_transactions.py \
  backend/server.py \
  backend/tests/test_mongo_config.py \
  backend/tests/test_mongo_transactions.py \
  backend/tests/test_mongo_portability_tool.py \
  scripts/mongo/comein_mongo.py \
  scripts/mongo/export_sanitized_preview_backup.py
```

Result: **PASS** (exit code 0; no compilation diagnostics).

## 2. Focused offline and regression tests

Command:

```bash
python -m pytest -c /dev/null \
  backend/tests/test_mongo_config.py \
  backend/tests/test_mongo_transactions.py \
  backend/tests/test_mongo_portability_tool.py \
  backend/tests/test_grocery_checkout_security_contract.py \
  backend/tests/test_task5_customer_measured_shopping_contract.py \
  backend/tests/test_task5_measured_import_contract.py \
  backend/tests/test_restaurant_api_contract.py \
  backend/tests/test_delivery_partner_onboarding_contract.py \
  backend/tests/test_financial_security_contract.py -q
```

Actual output:

```text
92 passed in 4.30s
```

This includes offline config validation, conservative transaction-error classification, 65-index extraction, startup handler discovery, semantic drift checks, unique-index preflight pipeline contracts, session propagation and Grocery payment atomicity contracts, plus selected Grocery measured, Restaurant, Delivery Partner and financial regressions.

The `-c /dev/null` flag avoids the repository's `backend/pytest.ini` required `pytest-xdist` plugin, which is not installed in this environment. The repository test configuration was not changed.

## 3. MongoDB source specification

Command:

```bash
python scripts/mongo/comein_mongo.py spec > /tmp/comein-mongo-final-spec.json
```

Parsed result:

```text
source_collections= 50
source_indexes= 65
initializer_counts= {'_startup': 59, 'ensure_delivery_partner_indexes': 6}
```

This is a source-derived spec, not a live DB listing. `init`, `health`, `verify-indexes`, `preflight-indexes` and `tx-verify` were not run against MongoDB.

## 4. Shell syntax

Commands:

```bash
bash -n scripts/restore-db.sh
bash -n scripts/backup-db.sh
```

Result: **PASS** (both exit code 0).

## 5. Restore guard behavior

Tested the restore script with environment variables and no database connection:

| Scenario | Actual exit | Actual result |
|---|---:|---|
| `TARGET_DB == DB_NAME` | 2 | Refused source database restore |
| `TARGET_DB=comein_prod` | 2 | Refused non-disposable target namespace |
| Disposable target + missing archive | 2 | Refused because archive did not exist |

No restore command was run. `mongorestore` is unavailable.

## 6. Existing sanitized backup checksum

Command:

```bash
cd database-backup
sha256sum -c COME-IN-PREVIEW-TEST-DB-SANITIZED-20261114T134327Z.archive.gz.sha256
```

Actual output:

```text
COME-IN-PREVIEW-TEST-DB-SANITIZED-20261114T134327Z.archive.gz: OK
```

Archive size: 8,762 bytes. Supplied report states 52 collections, 38 documents and 117 total indexes with zero restore mismatches. This mission independently verified the checksum only; it did not re-run restore.

## 7. Live verification — BLOCKED / NOT RUN

The following executables/modules are absent: `mongod`, `mongosh`, `docker`, `podman`, `mongodump`, `mongorestore`, `motor`, `pymongo`.

The following were not executed and must not be treated as passing:

- MongoDB ping/topology/FCV on an actual server.
- Real initialization and verification of 65 indexes.
- Unique-index duplicate scan against real documents.
- Transaction commit/abort against replica set.
- Transient transaction retry and unknown commit result.
- Concurrent checkout and stock oversell test.
- Grocery/Restaurant payment callback race and duplicate prevention.
- Live schema validator warning/enforcement tests.
- Financial/stock/orphan/reference integrity scan.
- Independent `mongorestore` and document/index count comparison.
- Production TLS, least-privilege DB user, network and backup recovery checks.

Required environment: a disposable MongoDB 7.0.x replica set or supported sharded test cluster, MongoDB Database Tools, Python dependencies pinned to Motor 3.7.1 and PyMongo 4.18.2, and an isolated disposable DB name. No production URI or data may be used.
