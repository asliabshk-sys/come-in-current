# COME-IN MongoDB Phase 2 Investigation — 2026-11-14

## Working-copy safety

- Source baseline: extracted `COME-IN-MASTER-PROJECT` from the uploaded `COME-IN-MASTER-PROJECT-CODEX-READY 2.zip`.
- Changes were made only in `/mnt/data/COME-IN-MONGODB-PHASE2-WORK`.
- Original uploaded ZIP and the Phase 1 extraction were not modified.
- The 15 pre-existing Git mode-only entries were preserved. No reset, clean, checkout, index rewrite or production database operation was performed.
- The archive's current Git working copy already had 15 executable-bit differences from the index; those unrelated states remain unchanged.

## Priority 1 — Index portability

### Finding

`backend/server.py` declares indexes in two startup functions: `_startup()` (59) and `ensure_delivery_partner_indexes()` (6). The original `scripts/mongo/comein_mongo.py::index_specs()` parsed only `_startup()`, omitting the delivery-partner indexes from `spec`, `init`, and health/drift checks.

### Change

- Parse both named startup index initializers.
- Include initializer provenance in each emitted index spec.
- Fail clearly if either initializer disappears from source.
- Compare key patterns and declared `unique`, `sparse`, TTL and partial-filter options.
- Detect unexpected non-default values for those options as drift.
- Health output reports `indexes_expected`, `indexes_missing` and `indexes_ok` from the same complete inventory.

### Evidence

- CLI `spec`: 65 declarations; 59 from `_startup`, 6 from `ensure_delivery_partner_indexes`.
- Fake-database `init_db`: ensures 65 declarations.
- Drift tests cover missing delivery-partner indexes and semantic option mismatch.
- Health test verifies the 65-index inventory is the one consumed by health.
- No live MongoDB index inspection was possible in this environment.

## Priority 2 — Transaction/session investigation

### Source findings

- Ten transaction scopes use `start_session()` plus `start_transaction()`.
- No `with_transaction()` retry helper is used in those scopes.
- `create_order()` catches non-HTTP, non-duplicate exceptions and maps them to HTTP 503 `grocery_checkout_unavailable`.
- The existing live concurrency test allows 200, 409 or 503, while asserting only one order and zero remaining stock. It therefore verifies no oversell but does not enforce the desired 409 response for losing requests.
- PyMongo/Motor transaction callback retry behavior is not invoked by the current manual `start_transaction()` context. A transient transaction failure can reach the generic 503 handler rather than retrying the transaction and re-reading stock.
- Direct database calls in the transaction bodies were statically checked for `session=session`. Helper calls were inspected separately.
- In `create_order()`, the final shop revalidation called `_get_shop_or_404()` without the active transaction session. This meant that read was outside the transaction snapshot.

### Change

- `_get_shop_or_404(shop_id, session=None)` now accepts an optional session.
- The final shop revalidation in `create_order()` passes `session=session`.
- Existing callers remain compatible because the parameter is optional.

### Not changed

- No broad transaction refactor or retry loop was introduced. A correct retry implementation must preserve callback idempotency and distinguish `TransientTransactionError` from `UnknownTransactionCommitResult`; it should be validated against the installed Motor/PyMongo versions and a real disposable replica set first.
- The concurrent HTTP 503-versus-409 defect was not reproduced here because there is no MongoDB server, no Docker/Podman, no `mongod`/`mongosh`/dump utilities, no `backend/.env`, no `MONGO_URL`/`DB_NAME`, and neither `motor` nor `pymongo` is installed.
- No production credentials or database were accessed.

## Priority 3 — Schema validator assessment

- Source documentation says no server-side `$jsonSchema` validators are configured; source scan found no validator setup in startup or portability scripts.
- Pydantic validation exists at API boundaries, but internal/background/import write paths are not necessarily covered by every request model.
- A collection-by-collection priority assessment is in `docs/mongodb/SCHEMA_VALIDATOR_ASSESSMENT_2026-11-14.md`.
- Financial/payment/settlement records are the strongest first candidates for minimal validators, followed by carefully scoped account/catalog/order validators.
- No validators were installed: representative database documents and the newer Emergent source are unavailable, so strict requirements could reject legitimate legacy records or newer fields.

## Explicitly blocked

- Catalogue Import implementation: not changed; blocked pending recovery of the newer Emergent source and completion report.
- Live disposable-database concurrency reproduction and transaction retry verification: blocked by unavailable local MongoDB runtime and dependencies.
- Live index drift/creation verification: blocked by unavailable local MongoDB runtime.
- Validator rollout: blocked pending sanitized data profiling and source reconciliation.

## Changed files

- `scripts/mongo/comein_mongo.py`
- `backend/server.py`
- `backend/tests/test_mongo_portability_tool.py` (new)
- `backend/tests/test_grocery_checkout_security_contract.py`
- `docs/mongodb/SCHEMA_VALIDATOR_ASSESSMENT_2026-11-14.md` (new)
- `reports/MONGODB_PHASE2_INVESTIGATION_2026-11-14.md` (new)

## Tests and actual results

- `python scripts/mongo/comein_mongo.py spec` — PASS; output contains 65 indexes (59 + 6).
- `python -m compileall -q scripts/mongo/comein_mongo.py backend/server.py backend/tests/test_mongo_portability_tool.py backend/tests/test_grocery_checkout_security_contract.py` — PASS.
- `python -m pytest -c /dev/null backend/tests/test_mongo_portability_tool.py backend/tests/test_grocery_checkout_security_contract.py backend/tests/test_task5_customer_measured_shopping_contract.py backend/tests/test_task5_measured_import_contract.py -q` — 43 passed.
- Project-configured pytest invocation was not used because `backend/pytest.ini` requires `pytest-xdist`, which is not installed. The project config was not modified.
- Live MongoDB tests — BLOCKED / NOT RUN; no server, connection settings or Motor/PyMongo runtime available.

## Final Phase 2 status

- Index portability gap: **FIXED in source; offline verified**.
- Checkout session propagation gap: **FIXED for final shop revalidation; offline contract verified**.
- Transaction retry/concurrency behavior: **PARTIAL / BLOCKED pending disposable replica-set reproduction**.
- Schema validators: **ASSESSED; implementation deferred pending data profiling**.
- Catalogue Import: **BLOCKED pending newer Emergent source**.
