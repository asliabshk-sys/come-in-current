# COME-IN Ultimate Complete Master — Development Handover

## What this package is
This is a dated development handover built from the latest accessible verified Phase 5 Recovery checkpoint, with the Universal Catalogue Import changes documented in `DOCUMENTATION/COME-IN-UNIVERSAL-CATALOGUE-IMPORT-IMPLEMENTATION-STATUS-2026-11-12.md`. The original source archive and prior Master ZIP remain unchanged. The primary application tree is under `APPLICATION_SOURCE/COME-IN-WORKING-COPY-RECOVERED-V1/`.

## Source authority and limitations
- Primary source: `COME-IN-COMPLETE-MASTER-CHAND-AI-PHASE-5-RECOVERY-2026-11-12.zip` (SHA-256 `fad2094bfab37cd373e7ae9dfd6e9dcc591af6d764e8124e879239f616a2fe71`).
- This execution environment did not expose a live Codex workspace or the previously named `/mnt/data/chand_phase5_recovery_20261112/...` path. Therefore this package is complete relative to the latest accessible verified Phase 5 Recovery source, not a claim that an inaccessible active Codex workspace was independently inspected.
- Earlier checkpoints are preserved as original ZIP files under `PROJECT_HISTORY/VERIFIED_CHECKPOINTS/`. They are not merged into the primary source. A comparison report lists conflicting file versions.
- No `.git` metadata was present in the primary source; Git branches/commit history cannot be included.

## Restore / import
1. Extract this ZIP.
2. Open `APPLICATION_SOURCE/COME-IN-WORKING-COPY-RECOVERED-V1/` as the project root in Codex or import that folder into Emergent. Do not import `PROJECT_HISTORY` as application source.
3. Follow `COME-IN-CODEX-IMPORT-README.md` and `README.md` inside the project root.
4. Frontend uses Yarn Classic 1.22.22 (`packageManager` in `frontend/package.json`). Run `yarn install --frozen-lockfile` only after reviewing the known lockfile discrepancy documented in the dependency inventory; the current lockfile lacks `expo-audio` and `expo-image-picker` entries.
5. Backend manifests are in `backend/requirements.txt`; no Python lockfile or virtual environment is included.
6. Copy `.env.example` templates and populate secrets only in a secure environment/secret manager. Never put production credentials in this archive or chat.
7. Use a disposable non-production MongoDB replica set for transaction testing. No production database or customer data is included.

## Universal Catalogue Import status
A partial implementation adds bounded CSV/XLSX/PDF/image extraction, ZIP batch intake, seller-scoped staging-job APIs, and a web upload preview. Staged rows are not published. Seller edit/approval/apply, CHAND model extraction, category mapping, mobile picker/camera, enterprise adapters, and live MongoDB/API verification remain incomplete. See the dated implementation status report for exact tests and blockers. Do not treat this package as production-ready.

## Verification scope
The new outer ZIP is integrity-tested and independently extracted with file-by-file hashes verified. Python compilation, 39 focused tests and TS/TSX transpilation were run; full app build/runtime and live database integration were not. See the dated implementation status report and project inventory.
