# Documentation index

The primary source tree includes its README, project checkpoint, master task tracker, implementation history, decisions/blockers, QA reports, Task 5 business rules and phase reports.

Universal Catalogue Import (2026-11-12):
- `COME-IN-UNIVERSAL-CATALOGUE-IMPORT-IMPLEMENTATION-REPORT-2026-11-12.md` — source-level scope and limitations.
- `COME-IN-UNIVERSAL-CATALOGUE-IMPORT-TEST-REPORT-2026-11-12.md` — exact commands and actual results.
- `COME_IN_EMERGENT_MONGODB_INTEGRATION_HANDOFF.md` — transaction-backed Product/stock application requirements reserved for Emergent.

Do not treat historical reports as proof of current live production status; use each report's own date and scope. The active Codex workspace and live MongoDB deployment were not verified in this archive execution.

## Universal Catalogue Import — Offline Completion (2026-11-12)

- `UNIVERSAL_CATALOGUE_IMPORT_FINAL_AUDIT.md`
- `UNIVERSAL_CATALOGUE_IMPORT_TEST_REPORT.md`
- `UNIVERSAL_CATALOGUE_IMPORT_SECURITY_REPORT.md`
- `UNIVERSAL_CATALOGUE_IMPORT_EMERGENT_HANDOFF.md`
- `UNIVERSAL_CATALOGUE_IMPORT_CHANGE_MANIFEST.md`
- `UNIVERSAL_CATALOGUE_IMPORT_PENDING_BLOCKERS.md`

## Universal Catalogue Import — Offline Completion (2026-11-12)

## Universal Catalogue Import — Offline Completion (2026-11-12)

