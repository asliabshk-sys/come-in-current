# Final backup verification report

- Primary source: latest accessible verified Phase 5 Recovery checkpoint.
- Application source files copied: **556**.
- Application source directories copied: **93**.
- Final package files (including its internal manifest): **593**.
- Internal file-hash manifest entries: **592** (manifest does not hash itself).
- Historical verified checkpoint ZIPs: **6**.
- Frontend files: **153**; backend files: **77**; CHAND-related files: **47**.
- Test files included: **63**; source documentation/report files counted: **156**.

## Verification scope
The outer archive is CRC-tested, independently extracted, and compared file-by-file against the packaged tree. Every internal manifest entry is checked against the independent extraction. The outer ZIP checksum is supplied in the sidecar file.

## Qualification
The live Codex workspace was not accessible in this session. This backup is complete relative to the latest accessible verified Phase 5 Recovery archive and the listed Library artifacts. No production database/user data or secrets were added. This is archive verification, not a fresh app build/runtime verification.
