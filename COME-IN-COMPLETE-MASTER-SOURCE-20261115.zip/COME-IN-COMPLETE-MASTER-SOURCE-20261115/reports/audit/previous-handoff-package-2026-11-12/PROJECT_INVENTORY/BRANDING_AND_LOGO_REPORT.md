# Branding and logo inventory

- `frontend/src/components/BrandLogo.tsx` uses the supplied Come-In reference logo and app icon assets.
- `frontend/assets/branding/come-in-official-logo-from-reference.png` and `come-in-official-app-icon-from-reference.png` are present.
- `frontend/app.json` points app icon to `./assets/branding/come-in-official-app-icon-from-reference.png`.
- Android adaptive icon points to `./assets/images/come-in-adaptive-icon-reference.png`.
- Splash screen points to `./assets/images/come-in-splash-logo-reference.png`.
- Web favicon points to `./assets/images/come-in-favicon-reference.png`.
- CHAND screen (`frontend/app/chand.tsx`) is present, but no distinct CHAND AI logo asset or explicit CHAND-logo reference was found by filename/source scan.
- The approved new CHAND AI logo was not supplied as a separately identifiable asset in the accessible source. Its approval/implementation cannot be confirmed.
- Expo app.json asset references verified: 4/4 present.
- No branding assets were altered.
