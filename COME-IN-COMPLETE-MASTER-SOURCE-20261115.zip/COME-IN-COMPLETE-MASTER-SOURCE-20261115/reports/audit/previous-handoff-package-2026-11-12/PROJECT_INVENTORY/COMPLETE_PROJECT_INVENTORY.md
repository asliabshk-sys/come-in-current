# Complete project inventory summary

- Primary application files: **556**
- Primary application directories: **93**
- Frontend files: **153**
- Backend files: **77**
- CHAND-related path/name files: **47**
- Test files (backend Python and frontend test-named files): **63**
- Documentation/report files in source tree: **156**
- Additional Library documents included: **14**
- Historical checkpoint ZIPs included: **6**

## Area counts in primary application tree
- frontend: 153
- backend: 77
- docs: 28
- infra: 5
- scripts: 9
- project-reports: 133
- backups: 111
- previews: 2
- memory: 3
