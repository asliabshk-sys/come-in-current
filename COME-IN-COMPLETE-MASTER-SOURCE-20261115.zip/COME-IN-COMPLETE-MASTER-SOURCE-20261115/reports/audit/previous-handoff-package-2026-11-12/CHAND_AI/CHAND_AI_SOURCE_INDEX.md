# CHAND AI source index

Primary implementation paths (inside `APPLICATION_SOURCE/COME-IN-WORKING-COPY-RECOVERED-V1/`):
- `frontend/app/chand.tsx` — assistant screen, photo/gallery, voice, shopping flow.
- `frontend/src/lib/chand-party-planner.ts` — deterministic party planner.
- `frontend/scripts/test-chand-party-planner.cjs` — party planner test script.
- `backend/server.py` — API endpoints/provider adapters and related backend integration.
- `backend/tests/test_chand_*.py` — CHAND contracts and regression tests.
- `docs/CHAND_AI_PHASE_3_PROVIDER_AND_MOBILE_SETUP.md`
- `docs/CHAND_AI_PHASE_4_OWNER_SETUP_AND_RELEASE_GATE_2026-11-12.md`
- `docs/CHAND_AI_PHASE_5_EXECUTION_REPORT_2026-11-12.md`
- `project-reports/` — Phase 2–5 implementation and execution reports/evidence.

The inventory finds no separately named CHAND AI logo asset. The current CHAND screen source exists; COME-IN brand assets are present. No branding changes were made.
