# Dependency inventory

## Frontend
- `frontend/package.json` present; `packageManager` pins Yarn Classic 1.22.22.
- `frontend/yarn.lock` present and preserved unchanged.
- `expo-audio`: declared; lock entry MISSING.
- `expo-image-picker`: declared; lock entry MISSING.
- No `node_modules` directory or usable offline dependency cache is included/discovered.
- No npm/pnpm lockfile is used as a substitute.

## Backend
- `backend/requirements.txt` present. It contains pinned and ranged Python dependencies.
- No Python dependency lockfile or virtual environment was found.
- No offline wheelhouse/cache was found.
- Python version pin file was not identified in the project root.

The existing manifests are retained exactly; no dependency upgrade or lockfile fabrication was performed.
