# Working-copy restoration guide

1. Extract `COME-IN-ULTIMATE-COMPLETE-MASTER.zip`.
2. Use only `APPLICATION_SOURCE/COME-IN-WORKING-COPY-RECOVERED-V1/` as the application root. Preserve its existing directory layout.
3. Read the project `README.md`, `COME-IN-CODEX-IMPORT-README.md`, and `COME-IN-WORKING-COPY-RECOVERED-V1.md`.
4. Frontend: use the pinned Yarn 1.22.22 from `frontend/package.json`. Existing `yarn.lock` is included unchanged, but it is known to lack `expo-audio` and `expo-image-picker` entries. Do not use frozen install until those entries are legitimately resolved through Yarn/Expo on a network-enabled environment.
5. Backend: create an isolated Python environment and install from `backend/requirements.txt`; there is no lockfile/wheelhouse in this backup.
6. Create local environment files from `.env.example` templates. Keep real API keys, DB URIs, signing keys and payment credentials outside the project ZIP.
7. Configure a disposable non-production MongoDB replica set before attempting transaction tests.
8. Native Android/iOS builds require appropriate SDK/Xcode toolchains and real device testing.
9. `PROJECT_HISTORY/VERIFIED_CHECKPOINTS/` contains prior complete snapshots for comparison only; do not merge them automatically into the primary source.
