# COME-IN — Task 5 Final Business Decisions and Workspace Status

**Record date:** 31 October 2026  
**Scope:** Documentation/checkpoint recovery only  
**Business decision status:** **17/17 APPROVED**  
**Implementation status:** **PENDING — NOT AUTHORIZED**  
**Active Codex workspace:** **BLOCKED — NOT PROVEN**

## 1. Approval evidence and boundaries

The owner explicitly delegated the original 14 Task 5 business decisions to ChatGPT and accepted the 14 recommendations. The owner subsequently explicitly approved the three additional recommendations covering actual weighing, whole-piece produce and GST behavior. The owner has now reiterated that all 17 decisions are already approved and instructed that no further approval be requested.

Approval evidence is the owner's explicit approval/delegated authorization in the Task 5 conversation history. This record documents those approvals; it does not claim that implementation has occurred.

**Important distinction:** Business decisions being `APPROVED` does not mean they are `IMPLEMENTED`, `TESTED`, or `VERIFIED WORKING`. It does not authorize source/API/database changes. A separate explicit implementation instruction is still required.

## 2. All 17 approved business decisions

1. **Eligible measured products — APPROVED.** Explicitly configured loose fruits, vegetables, grains, pulses, spices and eligible loose liquids may use measured sale. Factory-sealed/branded fixed packs remain pack mode.
2. **Canonical units — APPROVED.** Mass is integer grams (g), volume is integer millilitres (ml), and any supported count remains whole pieces. kg↔g and L↔ml conversions are exact; no mass↔volume or density inference.
3. **Minimums and increments — APPROVED.** Defaults: 250 g minimum / 50 g step and 250 ml minimum / 50 ml step. Sellers may impose stricter limits, not weaker ones.
4. **Precision — APPROVED.** Technical precision is 1 g / 1 ml; reject invalid precision and never silently round requested quantities. Purchase minimum/step rules still apply.
5. **Seller rate basis — APPROVED.** Seller enters ₹/kg for mass and ₹/L for volume; fixed-pack pricing remains per pack.
6. **Financial rounding — APPROVED.** Use exact integer/rational arithmetic; round each measured line once to nearest paise using ROUND_HALF_UP, then sum line totals.
7. **Stock representation — APPROVED.** Measured stock is integer g/ml; seller UI may display kg/L through exact conversion. Fixed-pack stock remains integer pack count with its current meaning.
8. **Measured variants — APPROVED.** First release supports one measured configuration per listing. Existing fixed-pack variants remain unchanged.
9. **Quote and reservation — APPROVED.** Retain the 10-minute non-reserving quote. Revalidate and conditionally deduct exact stock at order placement in the existing transaction; concurrent orders must not create negative stock.
10. **Cancellation/restoration — APPROVED.** Restore exact measured base quantity only for cancellation eligible under existing unpaid/unaccepted policy, at most once. Paid refunds and paid/accepted cancellation remain separate.
11. **CSV/Excel import — APPROVED.** First release import remains pack-only. Measured listings are manually entered/edited; unsupported measured import fields are rejected clearly.
12. **Maximum quantity — APPROVED.** Platform caps: 100,000 g, 100,000 ml, and 1,000 pieces per line; seller may lower cap and available stock is the stricter limit. Decision 16 narrows whole-piece loose produce out of the first Measured release; it does not alter existing whole-item behavior.
13. **Legacy compatibility — APPROVED.** Missing mode defaults to pack. Do not infer measured mode from unit labels or reinterpret existing stock/cart/order `qty`; legacy `qty` remains pack/item count.
14. **Rollout — APPROVED.** New listings or explicit seller opt-in only; no automatic conversion. Any future conversion requires seller confirmation of actual stock and an auditable action.
15. **Actual weighing — APPROVED.** No automatic post-pick quantity or charge adjustment in the first Measured release. Any additional quantity or charge requires explicit customer consent before applying it. No silent increase.
16. **Whole-piece produce — APPROVED.** Loose produce sold by whole piece is excluded from the first Measured release. Existing whole-item/integer-quantity functionality remains unchanged; no fractional pieces and no reinterpretation of existing quantities.
17. **GST / Grocery tax — APPROVED.** Preserve current Grocery tax calculation and behavior. GST-inclusive/exclusive policy and any future tax-policy change are deferred until accountant/business confirmation.

## 3. Status separation

| Area | Status | Evidence / meaning |
|---|---|---|
| Business decisions | **APPROVED — 17/17** | Owner's explicit delegated approval of original 14 plus explicit approval of decisions 15–17. |
| Documentation | **UPDATED / CREATED in recovered copy** | Approval record, approved rules, tracker, checkpoint and blockers updated; final report, work history and backup manifest created. |
| Task 5 source implementation | **PENDING / NOT VERIFIED** | No Task 5 source implementation was performed in this recovery. |
| Task 5 tests | **NOT RUN** | No Task 5 test suite or runtime test was run. |
| Task 5 runtime/device verification | **NOT RUN** | No Preview, live API/database or device verification. |
| Active Codex workspace | **BLOCKED** | Current environment cannot establish which workspace is open in Codex. |
| Recovered copy | **DOCUMENTATION RECOVERY COPY ONLY** | Not the active workspace; not a complete project source tree in the mounted folder. |
| New ZIP | **NOT CREATED** | No new ZIP created because the mounted recovered folder is not a verified complete source workspace and the user instructed not to create one if complete source is unavailable. |

## 4. Workspace recovery findings

The only mounted working folder inspected was:

`/mnt/data/COME-IN-RECOVERY-WORKSPACE-20261031/COME-IN-WORKING-COPY-RECOVERED-V1/`

Observed facts:

- It contains project documentation, Task 5 decision/review reports, project reports and checksum manifest text files.
- It does **not** contain `frontend/`, `backend/`, root `package.json`, `pyproject.toml`, `requirements.txt`, or `app.json`.
- It has no `.git` metadata; `git rev-parse` and `git status` therefore cannot establish a branch or working-tree status.
- The original Master ZIP and later checkpoint ZIPs are present separately under `/mnt/data`; their existence does not prove which project root is currently open in Codex.
- The original Master ZIP contains frontend/backend source in its archive listing, but that archive is a preserved backup, not evidence of the active Codex workspace.

**Conclusion:** Active Codex workspace identification is **BLOCKED**. The recovered copy must not be declared active. No repeated filesystem search or source edit was performed to guess the active Codex root.

## 5. Safety and scope record

- Source code modification: **NONE**.
- API change: **NONE**.
- Database change / migration / new collection: **NONE**.
- Restaurant Mode: **UNTOUCHED**.
- Previously completed tasks: **not re-audited** as part of this documentation recovery.
- Task 18 runtime testing: **NOT RUN**.
- New ZIP: **NOT CREATED**.
- Existing backup archives: **preserved; not overwritten**.

## 6. Next safe gate (not an implementation instruction)

1. User/Codex must identify the exact currently open Codex workspace from Codex's own workspace/terminal context.
2. Confirm project root, `frontend/`, `backend/`, package/config files, Git repository, branch and working-tree status without discarding user changes.
3. Reconcile the actual workspace against the preserved Original Master ZIP and latest Task 20 cross-device-sync checkpoint.
4. Re-read only Task 5-relevant source in that confirmed workspace. Do not re-audit unrelated completed tasks.
5. Only after workspace proof and a separate explicit owner instruction may Task 5 implementation be considered.

**Final result:** Documentation/checkpoint recovery is recorded in this recovered copy. The business contract is fully approved (17/17). Active workspace recovery and Task 5 implementation remain **BLOCKED/PENDING**, not complete.
