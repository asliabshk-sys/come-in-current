# COME-IN — Task 5 Approved Business Rules

**Approval date:** 31 October 2026  
**Approval basis:** Owner’s explicit delegated decision authorization  
**Scope:** Grocery/shop measured-quantity selling only  
**Status:** ALL 17 BUSINESS DECISIONS APPROVED  
**Implementation:** NOT AUTHORIZED — separate owner permission required

## 1. Approved decisions

1. **Eligible products — Choice A.** Measured sale is limited to explicitly configured loose fruits, vegetables, grains, pulses, spices and eligible loose liquids. Factory-sealed/branded products and fixed-size packs remain pack mode. Product category or unit label alone must never silently activate measured mode.
2. **Canonical units — Choice A.** Mass uses integer grams (`g`); volume uses integer millilitres (`ml`); piece counts, where supported, are whole integers. Convert kg↔g and L↔ml exactly. No mass↔volume conversion or density inference.
3. **Minimum and steps — Choice B.** Defaults are 250 g minimum with 50 g steps and 250 ml minimum with 50 ml steps. A seller may impose a higher minimum or larger step, but not weaker limits. Piece quantities remain whole. The configured maximum must be reachable from the minimum by the allowed step.
4. **Precision — Choice A.** Technical storage precision is 1 g / 1 ml; pieces are whole. Reject invalid precision and never silently round a customer's requested quantity. Technical representability does not override minimum/step rules.
5. **Seller price basis — Choice A.** Sellers enter ₹/kg for mass and ₹/L for volume. Fixed-pack price remains a per-pack price. The customer sees the calculated amount for the selected quantity.
6. **Financial rounding — Choice A.** Use exact integer/rational arithmetic. Round each measured line once to the nearest paise using `ROUND_HALF_UP`, then sum the rounded line amounts. Do not use binary floating-point for authoritative money calculations.
7. **Seller stock — Choice B.** Measured stock is stored as integer grams or millilitres. Seller UI may accept/display kg/L using exact conversion and a preview. Fixed-pack stock remains an integer pack count with its existing meaning.
8. **Measured variants — Choice A.** First release has one measured configuration per listing. Existing fixed-pack variants remain supported and unchanged in pack mode. Measured variants are out of first-release scope.
9. **Quote and reservation — Choice B.** Retain the 10-minute non-reserving quote. At order placement, revalidate price, listing contract and available stock, then conditionally deduct the exact quantity in the existing transaction. Concurrent orders must not cause negative stock.
10. **Cancellation — Choice B.** Restore the exact persisted measured base quantity only when the existing unpaid/unaccepted cancellation policy permits it, at most once. Paid-order cancellation, refund and payment settlement remain separate; stock restoration is not a refund.
11. **CSV/Excel — Choice B.** First release remains pack-only for CSV/Excel import. Measured listings are entered/edited manually. Unsupported measured import fields must be rejected clearly, not guessed or converted.
12. **Per-line maximum — Choice B.** Platform caps: 100,000 g (100 kg), 100,000 ml (100 L), and 1,000 pieces per line. Seller may set a lower cap; available stock is always the stricter limit. Existing pack cap semantics remain unchanged.
13. **Legacy compatibility — Choice A.** Missing quantity mode means pack. Do not infer measured mode from `unit` text. Do not reinterpret or migrate existing stock, cart, quote or order records. Legacy `qty` continues to mean whole pack/item count.
14. **Rollout — Choice B.** Measured mode is available only to new listings or through explicit seller opt-in. No automatic conversion. Any later conversion requires seller confirmation of actual on-hand base stock and an auditable action. Until a safe conversion flow is approved and implemented, existing listings stay pack mode.

15. **Actual weighing / post-pick variance — APPROVED.** In the first Measured release, do not automatically adjust ordered quantity or charge after picking/weighing. Any additional quantity or additional charge requires explicit customer consent before it is applied. No silent increase is allowed.
16. **Whole-piece produce — APPROVED.** Loose produce sold by whole piece is excluded from the first Measured release. Existing whole-item / integer-quantity functionality remains unchanged; do not introduce fractional pieces or reinterpret existing quantities.
17. **GST / existing Grocery tax behavior — APPROVED.** Preserve the existing Grocery tax calculation and behavior. GST-inclusive/exclusive policy and any future tax-policy change are deferred until accountant/business confirmation. Task 5 must not alter tax behavior.

## 2. Combined mandatory contract

- Every sellable line has an unambiguous mode: legacy/fixed `pack` or explicit `measured` (and, where appropriate, whole-piece count). A single line cannot mix pack count and measured base quantity.
- Legacy pack `stock`, cart/quote/order `qty`, price multiplication, variant identity, and cancellation restoration retain their current meaning.
- Measured quantity is represented as an integer base amount (`g` or `ml`); no decimal inventory arithmetic.
- The server is authoritative for listing mode, dimension, base unit, min/step/max, rate, stock, quote totals and order totals. Client-submitted prices/totals are untrusted.
- A measured order snapshot must preserve listing identity, mode, dimension, exact base quantity, display unit/quantity if needed, rate basis, authoritative rate and final line total in paise.
- Quote is non-reserving for 10 minutes. Order placement revalidates and conditionally decrements stock atomically in the existing transaction. If stock is insufficient or a concurrent order wins, fail cleanly and ask the customer to refresh/review; never allow negative stock.
- Failed order transactions must leave order and stock unchanged. Idempotent retries must not double-decrement.
- Cancellation restores only the exact persisted quantity to the same listing/stock bucket, only when eligible, and at most once. It must not imply a refund.
- A listing contract change invalidates stale quotes/cart lines; customer must review a refreshed amount and price.
- Restaurant Mode, Restaurant cart/menu/checkout/orders/APIs/theme/navigation remain outside Task 5.

## 3. Customer experience principles

Use common grocery-app usability patterns as a benchmark, without copying any proprietary UI or implementation:

- Make the mode unmistakable: e.g. “Loose / measured” versus “Fixed pack”. Never make customers infer from a product title or unit label.
- Show the price basis clearly (₹/kg or ₹/L) and the live calculated price for the currently selected quantity.
- Offer predictable quantity controls based on the listing minimum and step; provide clear decrement/increment behavior and prevent invalid values.
- Show selected quantity and display unit in product detail, cart and checkout consistently (e.g. 500 g; 1.25 kg), while the server contract uses integer base units.
- Keep the cart line understandable: product, selected amount, rate basis, line total and availability/quote refresh state.
- At checkout, present server-confirmed quantities and totals; if price/stock changes, explain and require review rather than silently changing the order.
- Keep fixed packs simple: “1 pack / 2 packs” and per-pack pricing; do not expose measured controls on them.
- Provide clear errors for minimum, step, maximum, out-of-stock and stale-quote conditions.
- Seller entry should preview kg/L-to-g/ml conversion and calculated rate/stock before save; reject excess precision rather than silently rounding.

These are behavior and usability principles only. They do not authorize UI redesign, new visual identity, or copying Blinkit/Zepto screens, assets, wording or proprietary flows.

## 4. Explicit non-goals

No source code/API/database edits, database migration, new collection, bulk conversion, import expansion, payment/refund provider work, Restaurant Mode work, broad UI/architecture rewrite, ZIP rebuild or deployment is included in this approval. The three additional decisions do not grant implementation permission.

## 5. Remaining technical and operational verification before launch

These do not revoke the 17 approvals, but must be settled in implementation design or separately approved before a live launch:

- The approved first release does not automatically adjust post-pick quantity/charge. Any additional quantity or charge requires explicit customer consent. Any future short-pick, underweight, refund or tolerance workflow needs a separate documented policy before being enabled.
- Do not change existing Grocery GST/tax behavior. The GST-inclusive/exclusive policy remains deferred until accountant/business confirmation. Separately verify existing tax, discounts, delivery fees and seller settlement composition against measured line totals before launch, without changing tax behavior under this approval.
- Confirm the deployed database topology supports the existing transaction strategy. If it does not, stop and request an architecture decision; do not introduce a new collection or alternate persistence system under this approval.
