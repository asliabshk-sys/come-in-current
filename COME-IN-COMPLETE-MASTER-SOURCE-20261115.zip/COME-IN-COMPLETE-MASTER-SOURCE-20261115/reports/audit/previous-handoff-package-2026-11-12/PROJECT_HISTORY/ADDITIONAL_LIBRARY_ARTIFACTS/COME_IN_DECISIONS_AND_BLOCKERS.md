# COME-IN — Decisions and Blockers Register

**Updated:** 2026-10-31
**Source of truth:** `COME_IN_MASTER_TASK_TRACKER.md` and dated execution reports.

## Classification of remaining work

### A. Independently actionable source work

- **None currently identified.** The latest source-actionable Task 20 state-sync improvement is implemented and focused-verified. Other apparent gaps either require a product contract, external infrastructure, runtime evidence, or explicit approval. Do not create work merely to keep the queue active.

### B. Waiting for external infrastructure / credentials / environment

- **Task 10:** rider assignment, live map and ETA require real operational dispatch and a configured location/ETA provider. Existing order status timeline and polling are source-level only.
- **Task 11:** operational shop-call/agent dispatch requires dispatch infrastructure. Grocery refund settlement requires a verified collection/refund provider path.
- **Task 16:** live MongoDB replica-set transaction behavior, concurrency, secrets and backup/restore verification require configured environment and database access.
- **Task 17:** customer-facing payment enablement and refund reconciliation require configured payment provider, secrets, webhook verification and native build feasibility. Grocery online payment remains disabled.
- **Task 18:** full Expo typecheck, Preview, live API/database and device workflows require dependencies and configured runtime environment. This task was not run in this checkpoint.
- **Task 20:** provider-backed push requires provider configuration, device registration, permission/opt-in, durable retry and verifiable delivery receipts. Never simulate delivery.
- **Task 19:** production build needs build environment, secrets, provider readiness, backups and monitoring.

### C. Waiting for business / product decisions

- **Task 5 business decisions:** CLEARED — all 17 decisions are owner-approved. **Task 5 implementation:** PENDING / BLOCKED on proof of the active Codex workspace, source-level technical revalidation, and separate explicit implementation permission. Do not infer that business approval authorizes coding.
- **Task 9:** define eligible actors, proposal expiry, accept/reject outcomes, replacement compatibility and who bears price differences. Paid Grocery orders also require authoritative additional-payment/refund settlement before an order-level replacement can safely mutate totals.

### D. Waiting for explicit approval

- **Task 19:** explicit approval is required before production deployment or launch actions. No deployment or public release is authorized by this checkpoint.
- Any destructive database reset/migration, paid provider activation, recurring service, production payment/refund transaction or public deployment remains outside scope without explicit approval.

### E. Implemented at source but not sufficiently verified at runtime/integration level

- **Tasks 2–4:** theme, navigation and catalog source exist; visual/runtime and live inventory coverage remain unverified.
- **Tasks 6–8:** source implementations exist; runtime/device/live API verification remains pending. Do not repeat prior focused tests without a specific regression reason.
- **Task 11:** order-help and Restaurant refund status source exists; live provider/database behavior remains unverified and blockers in B remain.
- **Tasks 12–15:** seller import, shared login, seller/restaurant panel and admin panel source exists; live database and role/ownership runtime checks remain.
- **Task 20:** in-app feed, local fallback, account-synced read receipts and preferences are source-implemented; live API/database/device sync is unverified. Push is separately BLOCKED under B.
- **Task 21:** comparison source exists; live price coverage/runtime and optional distance/delivery data remain unverified.
- **Task 22:** Home Services tile/icon source exists; visual/runtime flow remains unverified.
- **Task 1:** source audit artifacts exist, but end-to-end role flows have not been verified.

## Task 20 state-sync contract and limitations

- Uses the existing authenticated `users` document; no new collection or database migration.
- Read IDs are bounded to the latest 100. Preferences are limited to Order, Refund and Support booleans.
- The backend derives the user ID from the authenticated token; the client cannot select another account's record.
- Existing local state is used as a first-sync migration source and remains an offline fallback. Server state is account-wide across devices when the API/database is reachable.
- A failed sync displays a warning; local persistence is not represented as server success.
- No push token, permission prompt, push send, SMS/email send or delivery receipt is created or simulated.

## Workspace and backup limitations

- The active Codex workspace is not mounted/identifiable in this execution environment. The available recovered working copy has no `.git` metadata.
- Original Master ZIP and previous Task 10/Task 20 checkpoint ZIPs must remain unchanged.
- No production credentials or live database were used.
