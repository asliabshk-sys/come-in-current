# COME-IN — Backup Manifest

**Updated:** 31 October 2026  
**Scope:** Inventory of existing archives visible in the current execution environment.  
**New archive created in this recovery:** **NO**.  
**Overwrite of existing archive:** **NO**.

## Existing archives verified in this environment

The following archive files were present under `/mnt/data`. Each passed `unzip -t`; SHA-256 values below were calculated from the exact files in this environment.

| Archive | Size (bytes) | SHA-256 | Integrity | Notes |
|---|---:|---|---|---|
| `COME-IN-PAYAT-SHOP-CANCELLATION-POST-CHANGE-20261030T104500Z(2).zip` | 4,174,437 | `f0bc080cfa6c25f82683c057bd5188ed8180492af1bd903d883020301a950853` | ZIP integrity: PASS (`unzip -t`) | Original Master ZIP; preserved baseline |
| `COME-IN-CONTINUOUS-UPDATE-TASK20-CROSS-DEVICE-SYNC-20261031.zip` | 4,398,339 | `fa16f436b75f1f7f1fb04dd0db553cab10e46ccfbe3d3cd2ce38d22378ac064f` | ZIP integrity: PASS (`unzip -t`) | Latest identified Task 20 cross-device-sync checkpoint |
| `COME-IN-RECOVERY-WORKING-COPY-TASK21-UPDATE-20261031.zip` | 4,179,548 | `f67c072cab21a8a44f9fd3dab93ab4f00fb76b9aa022269de040902cc2582d6c` | ZIP integrity: PASS (`unzip -t`) | Task 21 recovery working-copy checkpoint |
| `COME-IN-CONTINUOUS-UPDATE-TASK20-20261031.zip` | 4,368,776 | `a65730d2493a9cc45ec504ef8eb6c2121b56334367089dcb7cd82db3e5f4da89` | ZIP integrity: PASS (`unzip -t`) | Earlier Task 20 checkpoint |
| `COME-IN-TASK6-TASK11-TASK20-UPDATE-20261031.zip` | 4,382,828 | `a52600a2eafd9f531f294ec463f0115c37d4590d3942e7678a2256cfe8655803` | ZIP integrity: PASS (`unzip -t`) | Task 6/11/20 checkpoint |
| `COME-IN-TASK6-CHECKPOINT-TASK11-ORDER-HELP-REFUND-20261031.zip` | 4,315,472 | `a9881ed64c266981b31c5f64930c8d6206b80c9c5ac4dffa4c361aace206f387` | ZIP integrity: PASS (`unzip -t`) | Task 6/11 checkpoint |
| `COME-IN-TASK8-RESTAURANT-REPEAT-ORDER-AND-TASK6-SEARCH-UPDATE-20261031.zip` | 4,227,719 | `54ec8a065a021ac5f6ced5df23abec92dfb1a1470ebc99634dacfe65cc69c5b1` | ZIP integrity: PASS (`unzip -t`) | Task 8/6 checkpoint |
| `COME-IN-CONTINUOUS-UPDATE-TASK10-20261031.zip` | 4,384,305 | `ccda509dbc333ef1758a8e69b3a254398a8739d1e2a7c02e945034659e97965d` | ZIP integrity: PASS (`unzip -t`) | Task 10 checkpoint |

## Baseline and latest checkpoint

- Original Master ZIP: `COME-IN-PAYAT-SHOP-CANCELLATION-POST-CHANGE-20261030T104500Z(2).zip`; SHA-256 `f0bc080cfa6c25f82683c057bd5188ed8180492af1bd903d883020301a950853`. Preserved unchanged.
- Latest identified checkpoint: `COME-IN-CONTINUOUS-UPDATE-TASK20-CROSS-DEVICE-SYNC-20261031.zip`; SHA-256 `fa16f436b75f1f7f1fb04dd0db553cab10e46ccfbe3d3cd2ce38d22378ac064f`. Preserved unchanged.
- Existing archives are backups/checkpoints, not proof of the active Codex workspace.

## Recovery-copy limitations

The mounted recovered folder contains documentation and reports but does not contain `frontend/`, `backend/`, root package/config files or `.git`. Therefore it is not a verified complete active source workspace. Although preserved ZIP archives contain project source (the Original Master ZIP listing includes `backend/` and frontend project files), this recovery did not unpack or rebuild a new archive from them.

## Integrity and scope notes

- ZIP integrity check: all eight visible ZIP archives passed `unzip -t`.
- SHA-256: calculated for each listed archive as currently present.
- Existing archives were not modified, renamed, deleted or overwritten.
- No new ZIP was created because the active workspace is not proven and the mounted recovered copy is not a complete source tree.
- This manifest does not claim off-device backups, cloud copies, or files not visible in the current environment.
