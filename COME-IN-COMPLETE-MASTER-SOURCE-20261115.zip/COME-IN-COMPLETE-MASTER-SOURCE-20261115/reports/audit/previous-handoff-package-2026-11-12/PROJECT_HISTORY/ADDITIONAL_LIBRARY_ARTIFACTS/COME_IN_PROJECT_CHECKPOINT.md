# COME-IN — Project Checkpoint

**Checkpoint date:** 2026-10-31
**Project root:** `COME-IN-WORKING-COPY-RECOVERED-V1/`
**Working copy:** `/mnt/data/COME-IN-RECOVERY-WORKSPACE-20261031/COME-IN-WORKING-COPY-RECOVERED-V1/`
**Source baseline archive:** `COME-IN-PAYAT-SHOP-CANCELLATION-POST-CHANGE-20261030T104500Z(2).zip`
**Baseline SHA-256:** `f0bc080cfa6c25f82683c057bd5188ed8180492af1bd903d883020301a950853`

## Workspace identity and limitations

- This execution environment exposes the recovered working copy above, not the user's live Codex session. The actual active Codex workspace/root cannot be established from this environment.
- The recovered folder has no `.git` directory. Do not describe it as the active Codex workspace or infer Git state.
- `frontend/node_modules` and `backend/.venv` are absent. Do not run full frontend/runtime/device tests from this copy.
- The original baseline ZIP and prior Task 10 and Task 20 checkpoint ZIPs are separate preserved artifacts.

## Latest source checkpoint

- Tasks 6, 8 and 10 retain their previously recorded source implementation evidence; they were not audited or tested in this pass.
- Task 11 remains Partial: customer order help and Restaurant refund status work is retained; Grocery refund settlement and operational shop-call/agent dispatch remain blocked.
- Task 20 in-app feed is retained. This pass added account-synced read receipts and display preferences through authenticated routes on the existing `users` document. Provider-backed push remains BLOCKED.
- Task 21 remains Partial as previously recorded; it was not audited or tested in this pass.

## Current Task 20 implementation evidence

Files changed for this checkpoint:

1. `backend/server.py` — added authenticated `GET /notifications/state` and `PUT /notifications/state`; state is stored only on the current user's existing document, with bounded read IDs and three boolean preferences.
2. `frontend/app/notifications.tsx` — loads and saves server state, migrates legacy local state, serializes writes, retains local fallback and warns when sync fails.
3. `backend/tests/test_task20_cross_device_state_sync_contract.py` — five focused source-contract tests.
4. `backend/tests/test_task20_in_app_read_state_contract.py` — one assertion updated for the account-synced preference label; all four directly affected regression checks pass.
5. `COME_IN_MASTER_TASK_TRACKER.md` — status, work log and blockers updated.

Verification performed:

- Focused tests: **9 passed** (5 cross-device state sync + 4 affected local read-state regression).
- Python syntax compilation: PASS.
- TypeScript TSX transpilation: PASS, 0 diagnostics.
- No full suite, Task 18 runtime tests, Preview, live API/database, device, push, SMS/email, payment, build or deployment verification was performed.

## Current stop point

No further safe independent source task is identified in the current tracker. Task 5 needs a base-unit/stock contract; Task 9 needs replacement policy and authoritative Grocery settlement; Tasks 10/11 have operational infrastructure dependencies; Task 16 needs live database verification; Task 17 needs provider/build configuration; Task 18 runtime verification is intentionally excluded; Task 19 needs explicit approval. See `COME_IN_DECISIONS_AND_BLOCKERS.md`.

## Task 5 business-decision checkpoint — 17/17 approved (2026-10-31)

- All 17 Task 5 business decisions are owner-approved. Decisions 15–17 are: (15) no automatic post-pick quantity/charge adjustment; explicit customer consent before any extra quantity/charge; (16) whole-piece loose produce excluded from the first Measured release, preserving existing whole-item functionality; (17) preserve current Grocery tax behavior and defer GST-inclusive/exclusive policy until accountant/business confirmation.
- The approval register and approved business-rules document were updated, and a consolidated Task 5 final business-decisions/workspace-status document was added.
- Status separation: **Approved: 17/17 business decisions. Implemented: no Task 5 measured-quantity implementation verified. Tested: no Task 5 tests run in this documentation recovery.** Implementation remains unauthorized pending separate owner permission.
- Active Codex workspace: **BLOCKED / NOT PROVEN**. The mounted recovery copy contains project documentation and reports, but no `frontend/`, `backend/`, package/config files or `.git` repository. Do not declare it the active workspace. Existing ZIP archives contain source, but their presence does not prove which folder is currently open in Codex.
- No source/API/database changes, migrations, new collections, Restaurant Mode changes, Task 18 runtime tests, or new ZIP creation occurred.
- Existing archive preservation and integrity/hash evidence is recorded in `COME_IN_BACKUP_MANIFEST.md`.
