# COME-IN — Completed Work History and Status Ledger

**Updated:** 31 October 2026  
**Purpose:** Preserve a clear distinction between approved, implemented, tested, runtime-verified and blocked work.

## Status definitions

- **Approved:** owner has accepted a business/product decision. This does not mean code exists.
- **Implemented — source:** source changes and wiring exist in the cited checkpoint; runtime behavior may remain unverified.
- **Tested — focused source contract:** named tests/checks passed; this is not live integration or device verification.
- **Verified working:** only after real runtime/device/integration proof. Do not infer this from source tests.
- **Blocked:** a dependency or environment prevents safe completion/verification.
- **Pending:** not done or not adequately evidenced.

## Task 5 — decision and documentation history

| Work item | Status | Evidence / boundary |
|---|---|---|
| Original 14 measured-quantity business decisions | **APPROVED** | Owner delegated decision selection and accepted all 14 recommendations. |
| Additional Decision 15: actual weighing consent | **APPROVED** | No automatic post-pick quantity/charge adjustment; explicit customer consent for extra quantity/charge. |
| Additional Decision 16: whole-piece produce scope | **APPROVED** | Excluded from first Measured release; existing whole-item functionality preserved. |
| Additional Decision 17: GST behavior | **APPROVED** | Existing Grocery tax behavior unchanged; GST-inclusive/exclusive policy deferred pending accountant/business confirmation. |
| Combined Task 5 business contract | **APPROVED — 17/17** | Recorded in owner approval register, approved rules and final decisions report. |
| Task 5 measured-quantity source implementation | **PENDING / NOT AUTHORIZED** | No source changes in this documentation recovery. |
| Task 5 tests / runtime verification | **NOT RUN** | No Task 5 tests, Preview, live API/database or device tests run here. |

## Previously recorded source implementation and focused checks

The following history is carried forward from the existing Master Task Tracker and dated checkpoint reports. It was not re-audited in this documentation recovery.

| Master roadmap area | Previously recorded status | Previously recorded evidence / limitation |
|---|---|---|
| Tasks 2–4 | **Implemented — source** | Theme, navigation and catalog source recorded; visual/runtime/live inventory verification remains. |
| Task 6 | **Implemented — source; runtime pending** | Search/filter source recorded; earlier focused tests recorded as passed, not rerun here. |
| Task 7 | **Implemented — source** | Cart/checkout source recorded; live DB/payment/runtime verification remains. |
| Task 8 | **Implemented — source** | Repeat-order source and 6 focused source-contract tests recorded; runtime/device verification remains. |
| Task 10 | **Partial** | Customer polling hardening source and 3 focused tests recorded; live rider/map/ETA provider remains blocked. |
| Task 11 | **Partial** | Order-help/refund-status source and 6 focused tests recorded; Grocery refund settlement and operational dispatch remain blocked. |
| Tasks 12–15 | **Implemented — source** | Import, shared login, seller/restaurant and admin panel source recorded; live DB/role/ownership checks remain. |
| Task 16 | **Partial** | Backend/security/transaction source recorded; live Mongo replica-set, secrets, backup/restore and concurrency checks remain. |
| Task 17 | **Blocked / Partial** | Payment/provider/native build/refund reconciliation incomplete; Grocery online payments disabled. |
| Task 18 | **Partial — runtime/integration blocked** | Focused source tests exist in prior reports; no Task 18 runtime testing performed in this recovery. |
| Task 19 | **Pending / Blocked** | Production build/deployment not performed; requires readiness and explicit approval. |
| Task 20 | **Partial** | In-app feed and account-synced read-state/preferences source recorded; 9 focused tests and TSX transpilation recorded; provider-backed push and live sync remain blocked/unverified. |
| Task 21 | **Partial** | Price-comparison source safety checks recorded; live price coverage/runtime remains. |
| Task 22 | **Implemented — source** | Home Services tile/icon/navigation source recorded; runtime visual/flow verification remains. |

## This documentation recovery — 31 October 2026

- Updated `COME_IN_TASK5_OWNER_APPROVAL_RECORD.md` to record 17/17 approved decisions.
- Updated `COME_IN_TASK5_APPROVED_BUSINESS_RULES.md` to include Decisions 15–17 and the revised launch clarifications.
- Updated `COME_IN_MASTER_TASK_TRACKER.md`, `COME_IN_PROJECT_CHECKPOINT.md` and `COME_IN_DECISIONS_AND_BLOCKERS.md` to separate approved decisions from implementation/test status and record the active-workspace blocker.
- Created `COME_IN_TASK5_FINAL_BUSINESS_DECISIONS_AND_WORKSPACE_STATUS.md`.
- Created `COME_IN_COMPLETED_WORK_HISTORY.md` (this document) and `COME_IN_BACKUP_MANIFEST.md`.
- Documentation-only: no source/API/database/migration/Restaurant Mode changes; no Task 18 runtime tests; no new ZIP.

## Workspace caveat

This history document is stored in the recovered documentation copy. The active Codex workspace remains **BLOCKED / NOT PROVEN**. Previously reported source/test history is preserved as historical evidence and was not re-executed or independently re-audited here.
