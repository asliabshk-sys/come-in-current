# COME-IN — Task 5 Owner Approval Record

**Prepared:** 31 October 2026  
**Scope:** Task 5 — Grocery measured quantity, pricing and inventory rules  
**Overall status:** **ALL 17 BUSINESS DECISIONS APPROVED**  
**Implementation authorization:** **NOT GRANTED — separate permission still required**

## Approval recording rules

- The owner explicitly delegated selection of the original 14 Task 5 business decisions to ChatGPT and accepted all 14 recommended choices under that delegated authorization. The owner subsequently explicitly approved the three additional decisions (actual weighing, whole-piece produce scope, and GST preservation); no re-approval is requested.
- The original 14 recommendations are recorded individually as `APPROVED`; the three additional owner-approved decisions are recorded below as Decisions 15–17.
- **Approval basis:** Owner’s explicit delegated decision authorization.
- **Approval evidence:** Owner stated that ChatGPT was authorized to choose and recommend all 14 business decisions because the owner lacks domain experience, and explicitly accepted all of ChatGPT’s 14 recommended choices. The owner further stated that no additional approval is required unless a real contradiction or serious unresolved risk is found.
- This approval covers the business rules only. It does not authorize source/API/database changes, migrations, tests, ZIP rebuilds, or implementation.
- A separate explicit owner instruction is required before implementation begins.

## Decision-by-decision register

### Decision 1 — Eligible measured products

**Recommended choice:** A — Explicitly configured loose fruits, vegetables, grains, pulses, spices and eligible loose liquids may use measured sale. Factory-sealed/branded fixed packs remain pack mode.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 2 — Canonical measurement units

**Recommended choice:** A — Store mass as integer grams (g), volume as integer millilitres (ml), and count as whole pieces. Convert kg↔g and L↔ml exactly; do not infer mass↔volume.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 3 — Minimum quantity and increments

**Recommended choice:** B — Defaults of 250 g minimum with 50 g steps, and 250 ml minimum with 50 ml steps. Sellers may choose stricter limits (higher minimum/larger step), not weaker ones.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 4 — Quantity precision

**Recommended choice:** A — Technical precision of 1 g / 1 ml; pieces remain whole. Reject unsupported precision; never silently round a requested quantity. The allowed purchase step remains governed by Decision 3.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 5 — Seller price input basis

**Recommended choice:** A — Seller enters ₹/kg for mass and ₹/L for volume. Existing fixed-pack price remains a per-pack price and is not reinterpreted.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 6 — Financial rounding

**Recommended choice:** A — Use exact integer/rational arithmetic; round each measured line once to the nearest paise using ROUND_HALF_UP, then sum the rounded line amounts.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 7 — Seller stock entry and storage

**Recommended choice:** B — Store measured stock as integer g/ml; seller UI may enter/view kg/L using exact conversion and preview. Fixed-pack stock remains integer pack count in its existing meaning.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 8 — Measured variants

**Recommended choice:** A — In the first release, one measured configuration per listing; existing fixed-pack variants remain pack mode and unchanged.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 9 — Quote and stock reservation

**Recommended choice:** B — Keep the 10-minute quote non-reserving. At order placement, revalidate and conditionally decrement exact stock in a transaction. Concurrent orders must not make stock negative.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 10 — Cancellation and stock restoration

**Recommended choice:** B — Restore the exact measured base quantity only for cancellations eligible under the existing unpaid/unaccepted cancellation policy, at most once. Paid-order refund and paid/accepted cancellation remain separate policies.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 11 — CSV/Excel import

**Recommended choice:** B — Keep CSV/Excel import pack-only in the first release. Measured listings are entered/edited manually; unsupported measured import fields must be rejected clearly.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 12 — Maximum quantity per line

**Recommended choice:** B — Platform caps of 100,000 g (100 kg), 100,000 ml (100 L), and 1,000 pieces per line. Seller may set a lower cap; available stock is always the stricter limit.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 13 — Existing fixed-pack products and legacy records

**Recommended choice:** A — Records without an explicit measured mode remain pack mode. Do not infer mode from unit labels, migrate/reinterpret existing stock, or change the meaning of legacy cart/order `qty` (pack count).

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

### Decision 14 — Rollout and existing listing conversion

**Recommended choice:** B — Enable measured mode only for new listings or listings explicitly opted in by the seller. No automatic conversion. Any later conversion requires seller confirmation of actual stock and an auditable action.

**Approval status:** APPROVED — 31 October 2026  
**Owner decision:** Accepted recommended choice under delegated business authorization.  
**Approval basis:** Owner’s explicit delegated decision authorization.  
**Approval evidence:** Owner delegated selection of all 14 business decisions to ChatGPT and explicitly accepted all 14 recommended choices.

## Cross-decision compatibility gate

**Status: CLEARED AT BUSINESS-RULE LEVEL — see technical compatibility report for conditions and remaining risks.**

The owner has approved all 17 business decisions. The original 14 decisions have a desk-based compatibility review; Decisions 15–17 resolve the previously open policy questions about post-pick weighing, whole-piece produce scope and Grocery tax behavior. Technical compatibility and live-environment gates remain; see `COME_IN_TASK5_TECHNICAL_COMPATIBILITY_REPORT.md`:

1. Decisions 3 and 4: technical precision versus permitted minimum/step.
2. Decisions 5 and 6: price basis, exact arithmetic and line-level paise rounding.
3. Decisions 7, 13 and 14: separate measured stock versus unchanged legacy pack stock and explicit opt-in.
4. Decisions 8, 9 and 10: stable measured inventory identity for reservation and exact one-time restoration.
5. Decisions 3 and 12: seller/platform maximum must be at least the minimum and reachable on the configured step; available stock is the effective cap.
6. Decisions 9 and 13: old pack API `qty` must retain pack-count meaning; measured requests require an explicit, separately validated representation.
7. Decision 10: stock restoration is not a payment refund.
8. Decision 11: import remains pack-only unless a separate future scope is approved.
9. Restaurant Mode remains fully outside Task 5.

## Separate implementation authorization

**Implementation status: NOT AUTHORIZED — WAITING FOR SEPARATE OWNER PERMISSION.**

All 17 business decisions are approved. The desk-based compatibility review for the original 14 remains subject to the listed pre-implementation gates; Decisions 15–17 close the three additional business-policy questions. Task 5 implementation must still wait for a separate, explicit owner instruction authorizing implementation. No approval in this document grants that permission.

## Change log

| Date | Decision(s) | Change / evidence | Status effect |
|---|---|---|---|
| 31 October 2026 | 1–14 | Owner delegated selection of all 14 decisions to ChatGPT and explicitly accepted all 14 recommended choices. Each recommendation recorded individually with the same delegated-authorization evidence. | Decisions 1–14 APPROVED; implementation remains NOT AUTHORIZED |
| 31 October 2026 | 15–17 | Owner explicitly approved the additional recommendations on actual weighing consent, whole-piece produce exclusion from first Measured release, and preservation of existing Grocery tax behavior. | Decisions 15–17 APPROVED; total 17/17; implementation remains NOT AUTHORIZED |

## Additional owner-approved decisions — 15 to 17

The owner has explicitly approved all three decisions below in the prior Task 5 decision exchange. These are recorded as `APPROVED`; no further approval is required for these policy choices. Their approval does not authorize implementation.

### Decision 15 — Actual weighing / post-pick variance

**Approved rule:** The first Measured release must not automatically adjust the ordered quantity or charge after picking/weighing. Any additional quantity or additional charge requires explicit customer consent before it is applied. No silent increase is permitted.

**Approval status:** APPROVED — owner explicitly approved this additional recommendation.
**Approval basis:** Owner’s explicit approval in the Task 5 additional-decisions exchange.
**Implementation status:** Not implemented or tested by this documentation recovery.

### Decision 16 — Whole-piece produce

**Approved rule:** Loose produce sold by whole piece is excluded from the first Measured release. Existing whole-item / integer-quantity functionality remains unchanged and must not be disrupted. This decision does not introduce fractional pieces or reinterpret existing item quantities.

**Approval status:** APPROVED — owner explicitly approved this additional recommendation.
**Approval basis:** Owner’s explicit approval in the Task 5 additional-decisions exchange.
**Implementation status:** Not implemented or tested by this documentation recovery.

### Decision 17 — GST / existing Grocery tax behavior

**Approved rule:** Do not change the existing Grocery tax calculation or tax behavior as part of Task 5. Whether prices are GST-inclusive or GST-exclusive, and any future tax-policy change, is deferred until accountant/business confirmation.

**Approval status:** APPROVED — owner explicitly approved this additional recommendation.
**Approval basis:** Owner’s explicit approval in the Task 5 additional-decisions exchange.
**Implementation status:** No tax code was changed or tested by this documentation recovery.

## Updated approval boundary

**Business decisions:** 17/17 APPROVED.
**Source/API/database implementation:** NOT AUTHORIZED by this approval record; separate explicit permission remains required.
**Runtime/device/integration testing:** Not performed in this documentation-only recovery.
**Active Codex workspace:** BLOCKED / not proven from the available environment.
