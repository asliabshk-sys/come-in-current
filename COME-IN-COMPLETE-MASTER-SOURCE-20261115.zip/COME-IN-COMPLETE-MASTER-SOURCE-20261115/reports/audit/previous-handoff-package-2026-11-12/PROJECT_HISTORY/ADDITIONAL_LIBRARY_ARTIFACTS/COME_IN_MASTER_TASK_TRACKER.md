# COME-IN — Consolidated Master Task Tracker

**Created:** 2026-10-31  
**Project root:** `COME-IN-WORKING-COPY-RECOVERED-V1/`  
**Working copy:** `/mnt/data/COME-IN-RECOVERY-WORKSPACE-20261031/COME-IN-WORKING-COPY-RECOVERED-V1/`  
**Source archive:** `COME-IN-PAYAT-SHOP-CANCELLATION-POST-CHANGE-20261030T104500Z(2).zip`  
**Archive SHA-256:** `f0bc080cfa6c25f82683c057bd5188ed8180492af1bd903d883020301a950853`  
**Important:** This is a separate recovery working copy, not proof that the original Codex workspace was recovered. The archive contains no `.git` directory. The original archive remains unchanged.

## Status definitions

- **Implemented — source:** relevant source and wiring exist; this does not claim runtime verification.
- **Partial:** some required behavior exists, but one or more stated requirements remain incomplete or blocked.
- **Pending:** no adequate implementation evidence found, or work has not started.
- **Blocked:** implementation cannot be completed safely until a stated dependency, decision, credential, provider, or environment is available.
- **Verified working:** only use after a real runtime/device/integration check. No whole task is marked this way in this tracker.

## Approved 22-task roadmap — consolidated status

| Master task | Approved task | Current status | Evidence / remaining work |
|---:|---|---|---|
| 1 | Existing Project Audit | **Partial** | Source structure, APIs, reports and contracts are documented. End-to-end behavior across customer/seller/restaurant/admin roles has not been verified in the current environment. |
| 2 | Theme and Design | **Implemented — source** | Shopping theme tokens and separate Restaurant Mode theme/source exist. Preserve existing colors, logo and theme switching; runtime visual verification remains. |
| 3 | Home Screen and Navigation | **Implemented — source** | Expo Router routes, tabs and Home discovery cards exist. Runtime navigation verification remains. |
| 4 | Categories and Catalog | **Implemented — source** | Category/reference catalog and canonical Master Catalog/shop listing APIs exist. Reference catalog entries are not live inventory; live listing coverage needs operational data. |
| 5 | Quantity, Variants and Units | **Business contract approved (17/17); implementation Pending / workspace BLOCKED** | All 17 Task 5 business decisions are owner-approved and documented. Existing source evidence still describes integer pack/item quantities; measured base-unit support is not implemented or verified. No source/API/database changes or Task 5 tests were performed in this documentation recovery. Implementation requires separate explicit permission and active-workspace/source revalidation. |
| 6 | Search and Filters | **Implemented — source; runtime pending** | Shopping Search now supports partial/case-insensitive token matching across name, brand, category, shop and description; relevance ranking; category filtering; live-first duplicate-ID deduplication; and safe price-low-to-high sorting with invalid prices last. Existing live catalog hook performs one fetch per mount, guards post-unmount updates, and clears stale products on failure; Search displays compact loading/error notices and labels preview-only fallback. Previous focused tests: 3 passed (not rerun in this pass). Runtime/live API/Preview/device verification remains pending. |
| 7 | Cart and Checkout | **Implemented — source** | Separate shopping and Restaurant carts, Buy Now/cart, checkout quote/price/stock validation and order safeguards exist. Live database/payment/runtime verification remains. |
| 8 | Repeat Order | **Implemented — source** | Grocery/shop reorder remains intact. Restaurant Order Detail now offers Repeat Order only for delivered/picked-up orders; it reloads the current approved restaurant/menu, resolves exact menu item/variant/add-ons, skips discontinued/unavailable or conflicting options safely, merges only compatible same-restaurant cart lines within quantity limits, and writes to the existing Restaurant Cart. Checkout/backend revalidate live menu availability and recalculate current item/variant/add-on prices, tax and fees; existing idempotency-key lookup plus unique index protect order creation. Focused source-contract tests: 6 passed. Runtime/device verification remains pending. |
| 9 | Out-of-Stock Replacement | **Blocked / Partial** | Cart-level customer-selected replacement/removal exists. Order-level proposal/accept/reject workflow is not implemented. Paid Grocery UPI price increases/decreases cannot be safely settled because no verified Grocery additional-payment/refund mechanism exists. |
| 10 | Live Tracking | **Partial — customer polling hardened at source** | Authenticated order tracking, persisted status timeline and authorized operator location writes remain intact. Customer screen now prevents overlapping 10-second polling requests, ignores responses for a stale order/screen, and clears its polling timer on unmount. Focused source-contract tests: 3 passed. No verified rider assignment, live map provider, ETA provider or live runtime/device check. |
| 11 | Order Help and Refund Status | **Partial — source implemented, blockers remain** | Customer help loads own Grocery/Restaurant orders, displays order/payment/refund states and available order details, and links support tickets to exact order kind/ID with backend customer ownership checks. Restaurant refund states are mapped from backend values; explicit request/update timestamps are persisted by admin/provider webhook flow. **Blocked:** Grocery refund settlement has no verified collection/refund provider path; operational shop-call/agent dispatch has no configured dispatch infrastructure. Actual refund execution remains Admin-only. Existing focused tests: 6 passed (not rerun in this pass). No live DB/provider/runtime verification. |
| 12 | Excel/CSV Price and Stock Import | **Implemented — source** | Seller-scoped preview/apply import, row validation, SKU identity and transaction-protected writes exist. Live replica-set/import workflow remains unverified. |
| 13 | Login and Account | **Implemented — source** | Shared auth store, secure token storage and customer account/order routes exist. Cross-mode session behavior still needs runtime verification. |
| 14 | Seller/Shop/Restaurant Panel | **Implemented — source** | Seller products/orders/support and Restaurant owner dashboard/menu/order source exist. Runtime role/ownership verification remains. |
| 15 | Admin Panel | **Implemented — source** | Admin routes, master catalog, announcements, support and earnings screens exist with role-protected backend routes. Runtime role checks remain. |
| 16 | Backend, Database and Security | **Partial** | FastAPI/Motor, JWT/role checks, validation and transaction-based checkout source exist. Live Mongo replica-set behavior, secrets configuration, backup/restore and concurrency integration checks remain. |
| 17 | Payments and Notifications | **Blocked / Partial** | Restaurant Razorpay backend verification/webhook/refund source exists, but customer-facing online checkout is not fully enabled; Grocery Razorpay/Stripe are disabled; no verified push provider/device-token workflow exists. Native Razorpay build feasibility and refund reconciliation remain blockers. |
| 18 | Testing and Bug Fixes | **Partial — runtime/integration blocked** | Historical focused source-contract suites passed for their scoped tasks. Latest continuation ran only Task 20 cross-device state sync plus its directly affected local read-state regression contracts (**9 passed**) and TSX syntax transpilation (0 diagnostics); no full suite or Task 18 runtime tests were run. Full Expo typecheck, Preview, live API/database and device workflows remain unverified because dependencies and configured runtime infrastructure are unavailable. |
| 19 | Production Build and Launch | **Pending / Blocked** | No production build/deployment was performed from this recovery copy. Requires correct build environment, secrets, provider readiness, backup/monitoring checklist and explicit deployment approval. |
| 20 | Smart Notification System | **Partial — in-app feed plus account-synced read state/preferences; provider-backed push BLOCKED** | Authenticated `/notifications/mine` remains a read-only, customer-scoped feed from persisted Grocery/Restaurant order status, supported Restaurant refund and support-ticket histories. Added authenticated `GET/PUT /notifications/state`, storing at most 100 read IDs and three boolean display preferences on the signed-in user document; existing device-local values migrate on first sync, updates are serialized, and local fallback plus a sync warning remain if the API is unavailable. No new collection, schema migration, push provider or dependency. **Push is BLOCKED** until provider configuration, device registration/permission/opt-in and verifiable delivery receipts/retry handling exist. Do not simulate delivery. Focused state-sync plus affected local-state regression tests: **9 passed**; TSX transpilation: 0 diagnostics. Live API/database/device sync remains unverified. |
| 21 | Smart Price Comparison | **Partial — existing implementation retained** | Exact canonical master product + variant matching, approved shops, available positive-stock offers, ascending price sort, lowest price, stock and update timestamps exist. Current pass additionally rejects zero/negative/non-numeric prices for new master links and filters malformed legacy offers. Live price coverage, runtime verification and optional distance/delivery data remain dependent on real data/providers. |
| 22 | Home Services Logo/Icon and Tile Integration | **Implemented — source** | Home screen has a Home Services ModeCard using bundled `home-services.png`, routes to `/services`, and a Home Services section also routes to that screen. Runtime visual/flow verification remains. |

## Reconciliation: separate implementation-report numbering

The dated `COME-IN-TASK18` through `COME-IN-TASK25` reports use a later implementation-work numbering scheme. They are **not** the approved Master Roadmap task numbers. Map them by feature scope as follows:

| Implementation report number | Report subject | Master roadmap task(s) it informs |
|---:|---|---|
| 10 | Payments, refunds and order notifications | 11, 17, 20 |
| 11 | Live order tracking | 10 |
| 12 | Customer support / order help | 11 |
| 13–14 | Seller support status and UI | 14 (and 11 for support workflow) |
| 15–17 | Razorpay checkout / native integration / build feasibility | 17, 19 |
| 18 | Cart variants, stock and checkout | 5, 7 |
| 19 | Seller/admin workflows | 12, 14, 15, 16 |
| 20 | Product catalog, variants and stock | 4, 5, 12, 21 |
| 21 | Customer shopping workflow / Buy Now | 5, 7 |
| 22 | Checkout audit | 7, 16, 18 |
| 23 | Order tracking | 10, 16 |
| 24 | Repeat order | 8 |
| 25 | Replacement design/implementation review | 9, 11, 17 |

Do not use a report named `TASK21-CUSTOMER-SHOPPING` as evidence that Master Roadmap Task 21 (Smart Price Comparison) is complete.

## Current blockers and dependencies

1. **Task 9 depends on Task 17:** safe order-level replacement requires an authoritative Grocery payment/collection state and verified additional-payment/refund settlement. A manual UPI confirmation is not a gateway settlement callback. Do not mutate paid order totals or claim a refund without authoritative confirmation.
2. **Task 17 depends on provider/build configuration:** Grocery online payments are disabled; native Razorpay feasibility is unresolved; no real payment/refund tests have been run. No credentials/secrets are included in this package.
3. **Task 20 push is BLOCKED:** provider configuration, device registration, permission/opt-in, durable delivery/retry handling and delivery receipts are absent. Preserve the in-app feed; never simulate push delivery.
4. **Task 19 is last-stage work:** build/deployment must wait until implementation and testing prerequisites are met and explicit approval is obtained.
5. **Task 10:** rider assignment, map and ETA remain blocked on real operational/provider infrastructure; never invent location or ETA. **Task 11:** Grocery refund settlement and operational shop-call/agent dispatch remain blocked. **Task 21:** do not invent distance, delivery fee, stock or shop prices when source data is absent.
6. **Runtime environment:** `frontend/node_modules` and `backend/.venv` are absent in this recovery copy. No dependencies were installed. The active Codex workspace is not mounted in this execution environment; the recovery copy is separate and has no Git metadata.

## Work log — 2026-10-31

- Created a separate recovery working copy from the already verified archive; did not overwrite an existing directory.
- Preserved the uploaded archive unchanged.
- Task 21 focused safety improvement: `MasterLinkIn.price` now requires `> 0`, consistent with ordinary seller product validation; the comparison query excludes non-positive and non-numeric legacy prices so invalid offers cannot appear as the lowest verified price.
- Added/updated focused source-contract coverage for those conditions.
- Verification run: `python -m py_compile backend/server.py` — PASS; `python -m pytest -c /dev/null -q tests/test_targeted_tasks_9_12_15_18_21.py -k task21` — **2 passed, 8 deselected**.
- This is source/contract verification only; no MongoDB, API server, Expo Preview, device, payment provider or production test was run.

## Next execution order and current stop point

1. Task 20 account-synced in-app read state/preferences is now implemented at source level using the existing authenticated `users` record; provider-backed push remains BLOCKED.
2. No further independent source task was identified that can be completed safely from the current evidence without a product decision, external infrastructure, runtime environment or explicit approval.
3. Task 5 now has an approved 17-decision business contract spanning base units, stock, quote/order, cancellation, import, post-pick consent, whole-piece scope and tax preservation. The business-decision blocker is cleared; implementation remains pending and active-workspace identification is blocked. Do not add decimal-only UI quantities.
4. Task 9 order-level replacement requires explicit actor/eligibility/rejection/price-delta policy and authoritative Grocery additional-payment/refund settlement. Cart-level replacement must not be repurposed as an order mutation.
5. Task 10 rider assignment/map/ETA and Task 11 operational dispatch require real operational/provider infrastructure; Task 11 Grocery refund settlement requires a verified collection/refund path.
6. Task 16 remains Partial pending live Mongo replica-set transaction, secrets, backup/restore and concurrency verification; no new source defect was established in this pass.
7. Task 17 payment work remains blocked on provider/native-build configuration and verified settlement/refund reconciliation.
8. Task 18 runtime/integration testing is intentionally not attempted; dependencies and configured API/database/device environment are unavailable.
9. Task 19 production build/deployment is last-stage work and requires build environment, secrets, provider readiness, backup/monitoring readiness and explicit approval.
10. Tasks 2–4, 6–8, 12–15, 21–22 have source implementation evidence but still need the appropriate live/runtime verification. Do not repeat completed source tests without a specific regression reason.

**Current classification:** no safe independent source task remains identified from the current tracker. Continue when the missing product decisions or external prerequisites become available; do not manufacture completion.

## Work log — 2026-10-31 (Master Task 20 account-synced state)

- Added authenticated `GET /notifications/state` and `PUT /notifications/state` routes, scoped to the signed-in customer/shopkeeper's own existing `users` document. Only a bounded list of up to 100 read IDs and the three approved boolean in-app display preferences are stored; no new collection or migration was introduced.
- `frontend/app/notifications.tsx` now loads server state, merges legacy device-local read IDs on first sync, migrates local preferences when no server state exists, and persists later read/preference changes through a serialized write queue. Existing local storage remains as an offline fallback with a visible sync warning. Account-switch guard prevents a queued old-account write from being sent using a newly active account.
- Updated the existing local read-state contract test for the new account-synced label and added `backend/tests/test_task20_cross_device_state_sync_contract.py`.
- Focused verification: **9 passed** across the new sync contract (5) and directly affected local read-state regression contract (4); `python -m py_compile` PASS; TypeScript `transpileModule` for `frontend/app/notifications.tsx` PASS with **0 diagnostics**.
- No Task 6, 8, 10, 11 or 21 tests were run. No Task 18 runtime tests, full suite, live API/database, device, Preview, push provider, SMS/email or payment tests were run.
- Task 20 remains Partial because push delivery is BLOCKED pending provider configuration, device registration/permission/opt-in, durable retry and verifiable delivery receipts. Account-synced state is source-implemented but not live integration/device verified.
- No further safe independent source task was identified: Task 5 needs a base-unit/stock contract; Task 9 needs replacement policy and authoritative Grocery settlement; Tasks 10/11 need operational infrastructure; Task 16 needs live DB verification; Task 17 needs provider/build configuration; Task 18 is excluded; Task 19 needs explicit approval.
- Original Master ZIP and previous Task 10 and Task 20 checkpoint ZIPs remain untouched.
