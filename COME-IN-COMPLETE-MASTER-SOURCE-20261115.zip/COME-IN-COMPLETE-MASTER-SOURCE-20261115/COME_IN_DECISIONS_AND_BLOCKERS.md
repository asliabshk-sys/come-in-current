# COME-IN — Decisions and Blockers

## Approved decisions (preserved from history, plus BATCH-02)
| # | Decision | Source |
|---|---|---|
| D1 | Shopping and Restaurant Mode stay separate flows with separate carts. Restaurant Mode is never removed. | Owner rules |
| D2 | Fixed-Pack and Loose/Measured grocery stay separate modes. Their offers are never compared against each other. | Owner rules / Task 5 |
| D3 | Measured quantities and stock are whole g/ml. Price is per kg/L. The line total is rounded HALF_UP on the server. Checkout always uses the server quote. | Task 5 |
| D4 | Fixed-pack limit is 1000 per product/variant. Measured limit is 100000 g/ml. | Task 5 |
| D5 | Online cancellation is allowed only before payment, so the refund state is `not_charged`. Never claim a refund that did not happen. | Task 11 |
| D6 | **Push notifications are not configured. Only in-app notifications exist.** Owner choice confirmed on 2026-11-11. Every notification stores `channel=in_app` and `push_status=not_configured`. | BATCH-02 |
| D7 | **Payments use the ZIP's test/mock mode only:** COD, pickup, cash-at-shop and UPI intent. Razorpay stays OFF until the owner provides keys and approves. Confirmed 2026-11-11. | BATCH-02 |
| D8 | Shop owners get a new-order notification. For online-payment orders it is sent only after the server verifies payment. | BATCH-02 |
| D9 | Auth rate limits: 10 failed logins per 15 min per e-mail (×5 per IP), register 20/h, forgot password 5/h, reset 10/15 min. Over the limit returns HTTP 429. Only failed logins count. | BATCH-02 |
| D10 | No seeding of a predictable admin. An admin is created only from `ADMIN_EMAIL`/`ADMIN_PASSWORD` (≥16 characters). | Existing |
| D11 | Task 19 (Production Launch) is not started without explicit owner approval. | Owner rules |
| D12 | Testing runs only on the preview DB with TEST accounts, never on production or real customer data. | Owner rules |

## Technical blockers
| # | Blocker | Affects | Needed from |
|---|---|---|---|
| B1 | Razorpay TEST keys (`RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`) and `GROCERY_ONLINE_PAYMENTS_ENABLED=true` | Tasks 17, 18 | Owner |
| B2 | Push delivery: Firebase `google-services.json` and a native build | Task 20 (push part) | Owner (optional) |
| B3 | Native Razorpay payment sheet: needs a native build, not Expo Go | Task 17 | Build pipeline |
| B4 | Production MongoDB must support transactions (replica set or Atlas) | Checkout and imports in production | Deployment |
| B5 | Production secrets, costs and approval | Task 19 | Owner |

## Pending approvals
- Live Razorpay keys and real payments (after Task 18 payment tests).
- Deployment / Task 19.
- Optional: enabling push notifications.

## Dependencies and unresolved issues
- 28 stale static contract tests still assert old source text. They need rewriting, and there is no runtime impact (`backend/tests/STALE_CONTRACT_TESTS.txt`).
- 26 non-blocking TypeScript strictness errors remain (implicit any, narrow literal comparisons).
- The restore drill has not been run.
- Production `CORS_ORIGINS` is `*` in preview and must be restricted.
- Translations: the `m.*` keys are missing in Odia, Urdu and Malayalam, and the `n.*` keys exist only in English and Hindi. Those languages fall back to English.
- The OTP login and verification feature does not exist. Login is e-mail + password.
- Web dialogs with 3 or more buttons fall back to confirm/cancel and run the last action (`src/utils/alert.ts`).
- An in-progress Buy Now is held in memory, so refreshing `/checkout` falls back to the full cart.


## Task 18 QA Iteration 3 — new safety rules and blockers (2026-11-11)
| # | Decision / rule | Evidence / status |
|---|---|---|
| D13 | A Restaurant refund must be bounded by the captured payment amount, which must equal the eligible order amount in integer paise. | Implemented in source; database/provider runtime verification pending. |
| D14 | Before submitting a full refund, read the complete provider refund history. If any pending/completed/partial refund already exists, do not submit another full refund; require reconciliation. | Implemented; provider API not called in this environment. |
| D15 | Concurrent COME-IN admin refund submissions use a compare-and-set claim. Ambiguous provider outcomes remain blocked for reconciliation. | Implemented in source; concurrency runtime test pending. |
| D16 | A financial ledger reversal is created only after cumulative provider-confirmed refunds reach the full eligible order amount. | Implemented in source; webhook/ledger runtime test pending. |
| D17 | Pending refund amounts and provider-confirmed refunded amounts are stored/displayed separately. | Implemented in source; UI runtime pending. |

## Current environment blockers
| # | Blocker | Affects | Needed |
|---|---|---|---|
| B6 | `scripts/preview-mongo-replset.sh` is absent from the uploaded ZIP; no Git history or Iteration 3 diff exists. | Task 18 interrupted-work recovery | A verified source copy/report from the previous Emergent workspace, if one exists. |
| B7 | Expo CLI, Yarn and frontend `node_modules` are absent. | Seller/Customer UI runtime | Existing dependencies in an approved local/Codex workspace; do not auto-install. |
| B8 | Motor, PyMongo, `mongod`, `mongosh`, Docker and Podman are absent. | MongoDB-backed runtime/transaction tests | A disposable transaction-capable test environment. |
| B9 | Razorpay TEST credentials/provider access not supplied or used. | Task 17/18 refund provider tests | Owner-approved TEST credentials in a secure secret store. |

## Refund scope limitation
The Iteration 3 source hardening applies to the existing Restaurant admin refund route. Automatic Grocery refunds remain pending. If provider history contains any existing pending or completed refund, the current full-refund workflow deliberately stops and requests manual reconciliation rather than automatically issuing a remainder refund. This is a fail-closed safety choice, not a completed partial-refund workflow.
