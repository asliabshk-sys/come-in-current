// Idempotent single-node replica-set initialisation. Run with: mongosh --port <port> --file rs-init.js
const rsName = process.env.MONGO_RS_NAME || 'rs0';
const host = process.env.MONGO_RS_HOST || '127.0.0.1:27018';

let initiated = false;
try {
  const s = rs.status();
  print(`[rs-init] replica set "${s.set}" already initialised`);
} catch (e) {
  if (e.codeName === 'NotYetInitialized' || /no replset config/i.test(String(e.message))) {
    const r = rs.initiate({ _id: rsName, members: [{ _id: 0, host }] });
    printjson(r);
    initiated = true;
  } else {
    throw e;
  }
}

for (let i = 0; i < 60; i++) {
  if (db.hello().isWritablePrimary) {
    print(`[rs-init] PRIMARY ready (set=${db.hello().setName}, host=${db.hello().me}, newly_initiated=${initiated})`);
    quit(0);
  }
  sleep(1000);
}
print('[rs-init] ERROR: no PRIMARY after 60s');
quit(1);
