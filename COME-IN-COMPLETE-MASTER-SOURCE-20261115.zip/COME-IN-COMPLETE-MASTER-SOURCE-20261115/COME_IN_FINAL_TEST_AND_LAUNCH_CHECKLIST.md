# COME-IN — Consolidated Testing & Launch-Readiness Checklist (prepared 2026-11-11)

Nothing has been launched or published. Run this once, after all implementation is done. Use a test database only, never customer data.

## 0. Setup
- [ ] Fresh install from `COME_IN_MASTER_BACKUP.zip` per `COME-IN-CODEX-IMPORT-README.md` (Node 20.19+, Yarn 1.22.22, Python 3.11, MongoDB **replica set**; grocery checkout needs transactions).
- [ ] `yarn tsc --noEmit` in frontend and fix any type errors (never run so far).
- [ ] `python -m pytest` for the existing backend tests; run `ruff check backend`.
- [ ] Backend starts with no CRITICAL config logs (JWT_SECRET, CORS_ORIGINS set; CORS not `*`).

## 1. Shopping core (regression)
- [ ] Browse → product → cart → quote → place order with COD, UPI (shop confirms), cash at shop/pickup, rewards-covered order.
- [ ] Price change / stock change / expired quote gives the 409 flows; idempotent double-submit returns the same order.
- [ ] Customer cancel before payment restores stock; refund status shows "not charged".
- [ ] Repeat order (pack items) and out-of-stock replacement still work.
- [ ] Restaurant Mode: browse, cart, COD/pickup checkout, tracking, support are unchanged.

## 2. Task 5 measured products
- Run the checklists in `project-reports/COME-IN-TASK5-MEASURED-SHOPPING-HANDOFF-2026-11-11.json` and `COME_IN_TASK5_COMPLETE_IMPLEMENTATION.json` (seller entry, `/api/grocery/measured-price`, quote/order/stock in grams, CSV import columns, Master Catalog measured link, Hindi labels, measured repeat order).

## 3. Batch 01
- [ ] Task 11: `/api/orders/mine` includes `refund_summary`; the orders screen shows the line.
- [ ] Task 15: announcement with N days shows on Home for the right audience and disappears after it expires.
- [ ] Task 16: security headers on every response; `scripts/backup-db.sh` and then `scripts/restore-db.sh` into `<DB>_restore_test` succeed (restore drill).
- [ ] Task 20: order status change, help-ticket update and restock (0 → >0) create notifications; mark read / read all; other users cannot read them (owner check).
- [ ] Task 21: comparison panel appears for master-linked listings; measured offers are compared only with measured offers.

## 4. Task 17 Grocery Razorpay (TEST keys only, after owner approval)
- [ ] With the flag off: the option is hidden, `online_razorpay` is rejected with 422, and the config says `razorpay_enabled:false`.
- [ ] With test keys + flag: a guest can't pick online; a signed-in customer places the order → pending_payment / razorpay_pending and stock is held.
- [ ] Pay with a Razorpay test card/UPI on web → verify → paid → the shop sees it as pending → accept as normal.
- [ ] Close the payment window → order still unpaid; retry reuses the gateway order; Cancel restores stock.
- [ ] Tampered signature → 400; wrong amount → 409; another user's order → 404.
- [ ] Webhook `payment.captured` (signed) marks it paid once; a duplicate event is ignored; a capture after cancel sets `refund_status=under_review`.
- [ ] Wait past 30 min, then Pay → order auto-cancelled and stock released.

## 5. Security & data
- [ ] Role checks: customer/shopkeeper/admin endpoints, shop ownership, admin-only announcements.
- [ ] No secrets in the repo, frontend bundle or logs (`grep -R "rzp_live\|SECRET=" .`).
- [ ] Delete test records created during testing.

## 6. Launch readiness (needs owner's explicit approval at each step)
- [ ] Production MongoDB (replica set) and a backup schedule + verified restore.
- [ ] Production env secrets set in the hosting secret store (JWT_SECRET, CORS_ORIGINS, Razorpay **live** keys only after approval, webhook secret).
- [ ] Privacy policy, terms and refund policy pages; Razorpay account activation (KYC).
- [ ] Android build: native Razorpay module (if online pay is needed in the app), app signing, Play Store listing.
- [ ] Push notifications provider (optional), set up only with owner approval.
- [ ] Final smoke test on the production URL and device, then a go/no-go decision by the owner.
