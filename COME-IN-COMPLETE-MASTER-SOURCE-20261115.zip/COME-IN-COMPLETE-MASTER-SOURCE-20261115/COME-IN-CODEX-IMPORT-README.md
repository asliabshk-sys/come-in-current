# COME-IN — Codex Import README

**Package:** COME-IN-WORKING-COPY-RECOVERED-V1 (Codex export)

This is a recovery working copy restored from `COME-IN-MASTER-BACKUP-v7.zip` (SHA-256 `e8151645e38e38e39324b877d4a99cc20ba60f9d816255bb410555f3e902a7df`) inside Emergent. It is not the old original working copy.

It also contains one code fix made after the restore, in `frontend/app/seller/orders.tsx`. The function `confirmUpiPayment` was moved out of `useEffect`. Before the fix, pressing the "Confirm UPI" button threw a ReferenceError.

## Structure
```
frontend/         Expo 57 + React Native 0.86 + React Native Web + Expo Router (TypeScript)
  app/            routes (tabs, product, category, checkout, seller/*, admin, restaurant/*, ...)
  src/            api client, stores, i18n, theme, restaurant mode, components, data
  package.json, yarn.lock (Yarn 1.22.22, exact versions; .npmrc save-exact)
backend/          FastAPI + Motor (MongoDB)
  server.py       all /api routes
  financial_rules.py, referral_rules.py, restaurant_*.py, integrations/
  requirements.txt, pytest.ini, tests/
docs/             feature/setup docs (backend tests read docs/COME-IN-CHAND-SETUP-2026-10-19.md)
scripts/          preview.sh, replit-install.sh, replit-run.sh
previews/         design mockup PNGs (not runtime screenshots)
project-reports/  historical reports from the v7 root + the original v7 manifest
memory/           PRD notes from the recovery session
MANIFEST.sha256   SHA-256 of every file in this package
```

## Requirements
- Node.js `^20.19.4`, `^22.13`, or `>=24.3`. Tested with 20.20.2.
- Yarn 1.22.22
- Python 3.11
- MongoDB with transactions. This means a replica set or Atlas. A single-node replica set is enough for local work.

## Install
```bash
cd frontend && yarn install --frozen-lockfile
cd ../backend && python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
```
- `requirements.txt` lists `emergentintegrations==0.2.2`. That package comes from Emergent's private index. Outside Emergent, either install it with `--extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/`, or remove that line. `server.py` does not import it directly; check with `grep emergentintegrations backend/*.py`.
- The `frontend/scripts/*` files must be executable (`chmod +x frontend/scripts/*.js frontend/scripts/*.sh`). Without this, the `preinstall` hook fails with exit code 126.

## Environment variables
1. Copy `backend/.env.example` to `backend/.env`.
2. Copy `frontend/.env.example` to `frontend/.env`.
3. Fill in the values. No real secret values are included in this package.

| Variable | Needed for | Required |
|---|---|---|
| MONGO_URL, DB_NAME | database (must support transactions) | yes |
| JWT_SECRET | login tokens | yes |
| CORS_ORIGINS | frontend origin | yes |
| FINANCIAL_TIMEZONE | earnings dashboards | yes (default Asia/Kolkata) |
| BANK_DATA_ENCRYPTION_KEY | saving bank details (Fernet key) | yes, for bank features |
| PUBLIC_APP_URL / EXPO_PUBLIC_APP_URL / PASSWORD_RESET_URL | referral and reset links | recommended |
| ADMIN_EMAIL / ADMIN_PASSWORD | seeds an admin at startup | optional |
| EMERGENT_LLM_KEY, INTEGRATION_PROXY_URL | image uploads (Emergent storage) | optional |
| RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET / RAZORPAY_WEBHOOK_SECRET | online payment | optional |
| SMTP_HOST / PORT / USER / PASSWORD / FROM | password reset email | optional |
| COMEIN_AI_PROVIDER / BASE_URL / API_KEY / MODEL | CHAND generative answers | optional |
| EXPO_PUBLIC_BACKEND_URL (frontend) | API base URL | yes |

## Run the preview locally
```bash
# 1) MongoDB as a single-node replica set
mongod --replSet rs0 --port 27017 --dbpath ./mongo-data
mongosh --eval 'rs.initiate({_id:"rs0",members:[{_id:0,host:"127.0.0.1:27017"}]})'
# 2) Backend (from the backend/ folder)
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
# 3) Frontend (from the frontend/ folder)
yarn start          # = expo start --web --port 3000
```
- Open http://localhost:3000. The first bundle takes 20–40 s.
- Health check: `GET /api/` returns `{"service":"come-in","status":"ok"}`.

## Tests
- Contract tests: `cd backend && python -m pytest -q`
- Runtime e2e: `backend/tests/test_preview_runtime_e2e.py`. It needs a running backend, `EXPO_PUBLIC_BACKEND_URL`, and test accounts supplied through `COMEIN_TEST_{ADMIN,CUSTOMER,SELLER,RESTO}_{EMAIL,PASSWORD}`. Run it with `-n 0`. It creates TEST_ data, so never run it against production.

## Runtime status (verified in the Emergent preview, isolated test DB)
**PASS:**
- Home screen and bottom tabs
- Categories, product details, quantity stepper and variants
- Search and cart
- Grocery COD checkout, seller order status updates and customer tracking
- Login, register and logout
- Admin panel and admin earnings
- Seller registration, admin approval, seller products and orders
- Restaurant Mode, through to a COD order
- Shops, Services, Request, Language, Referral and Addresses
- CHAND in catalog-only mode

**Known bugs (not fixed):**
1. `/restaurant/orders` has no index route. It resolves to `/restaurant/[id]` and shows "Restaurant unavailable".
2. `GET /api/orders/{id}/tracking` returns "Tracking ended" before the order is out for delivery.
3. `become-seller.tsx`: `styles.chip` and `styles.chipText` are undefined, so the shop-type chips have no styling.
4. On mobile, the `seller/products` header title wraps one character per line.
5. The "Address saved" success message is shown in red.
6. Searching "atta" also returns unrelated items from the same category.
7. The UPI confirm button fix is in the code, but it has not been tested at runtime on a UPI order.

**Blocked (configuration needed):**
- Online payment: needs the Razorpay variables.
- Image uploads: needs `EMERGENT_LLM_KEY`.
- Password reset email: needs the SMTP variables.
- CHAND generative answers: needs the `COMEIN_AI_*` variables.

## Excluded from this package
- `.env` files
- `test_credentials.md`
- `node_modules/`
- Build and cache folders: `.metro-cache/`, `.expo/`, `__pycache__/`, `.pytest_cache/`
- `*.pyc`, `*.log`
- Emergent template files, the Master v7 ZIP itself, `test_reports/`, and the database data
