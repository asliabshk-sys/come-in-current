# COME-IN MongoDB Schema Validation Report

## Finding

No persistent MongoDB `$jsonSchema` validators or startup `collMod` migrations are declared in the application or portability initializer. `comein_mongo.py init` creates collections and indexes only. Existing Pydantic models, endpoint checks, unique indexes and transaction conditions provide application-level validation, but do not constrain every internal writer or future direct database writer.

The repository includes live-test cases that temporarily install a test validator with `collMod` and turn it off again. Those are test fixtures, not production collection validators.

## Collection-by-collection rollout plan

The 50 source-referenced collections are listed below. The proposed validator levels are recommendations only; no validator was installed because no live document profile or newer Emergent source was available.

| Priority | Collections | Candidate stable invariants | Rollout decision |
|---|---|---|---|
| P0 — financial | `financial_ledger`, `settlement_requests`, `settlement_order_allocations`, `grocery_payments`, `restaurant_payments`, `restaurant_payment_events`, `payout_bank_accounts`, `financial_audit` | Required identity/reference strings, INR amount numeric type and non-negative/negative reversal semantics, status types, event/idempotency identifiers, timestamps | BLOCKED pending representative-document profiling, status enumeration and migration compatibility review |
| P1 — accounts/catalog/orders | `users`, `shops`, `products`, `orders`, `grocery_quotes`, `restaurants`, `restaurant_menu`, `restaurant_orders`, `master_products`, `catalogue_import_jobs` | Stable IDs, ownership strings, status fields, timestamps; Product variants/measured fields require union-compatible schemas; legacy Product and order shapes must remain valid | BLOCKED pending profiling and complete writer map |
| P1 — delivery partner | `delivery_partner_applications`, `delivery_partner_audit`, `delivery_partner_referrals` | Application/referral state, owner identifiers, encrypted payload strings, audit timestamps | BLOCKED pending encrypted legacy record profiling and key-rotation plan |
| P2 — user workflows | `addresses`, `restaurant_carts`, `restaurant_reviews`, `restaurant_support`, `service_providers`, `service_appointments`, `home_service_slot_reservations`, `home_service_settings`, `referrals`, `referral_rewards`, `referral_ledger`, `referral_link_events`, `referral_audit`, `restock_alerts`, `files` | Ownership, state/status, timestamps, nonnegative stock/quantity where stable, references | BLOCKED pending profile and endpoint writer coverage |
| P3 — flexible/history | `notifications`, `announcements`, `status_checks`, `request_anything`, `agent_assist`, `catalog_import_history`, `catalog_price_audit`, `retail_price_import_history`, `retail_price_offers`, `retail_price_price_audit`, `chand_feedback`, `assistant_rate_limits`, `auth_rate_limits`, `password_resets` | Minimal stable envelope, expiry fields for TTL collections, event/audit timestamps; preserve flexible payload and history fields | Prefer permissive validators or none until field-shape inventory is complete |

## All 50 source-referenced collections

`addresses`, `agent_assist`, `announcements`, `assistant_rate_limits`, `auth_rate_limits`, `catalog_import_history`, `catalog_price_audit`, `catalogue_import_jobs`, `chand_feedback`, `delivery_partner_applications`, `delivery_partner_audit`, `delivery_partner_referrals`, `files`, `financial_audit`, `financial_ledger`, `grocery_payments`, `grocery_quotes`, `home_service_settings`, `home_service_slot_reservations`, `master_products`, `notifications`, `orders`, `password_resets`, `payout_bank_accounts`, `products`, `referral_audit`, `referral_ledger`, `referral_link_events`, `referral_rewards`, `referrals`, `request_anything`, `restaurant_carts`, `restaurant_menu`, `restaurant_orders`, `restaurant_payment_events`, `restaurant_payments`, `restaurant_reviews`, `restaurant_support`, `restaurants`, `restock_alerts`, `retail_price_import_history`, `retail_price_offers`, `retail_price_price_audit`, `service_appointments`, `service_providers`, `settlement_order_allocations`, `settlement_requests`, `shops`, `status_checks`, `users`.

## Safe rollout gates

1. Recover the newest Emergent source and compare all writes/models first.
2. Export schema-only or sanitized representative samples from a disposable clone; never print PII.
3. Profile missing/null/type distributions and enumerate existing status variants.
4. Draft validators from actual documents and all writer paths, including import/background/test paths.
5. Apply `validationLevel: "moderate"` and `validationAction: "warn"` only to a disposable clone first.
6. Measure warnings and test valid legacy writes, updates, measured products, Restaurant Mode, payment/refund and delivery-partner workflows.
7. Only after review, plan a staged production migration with rollback instructions. Do not use `strict/error` until the legacy corpus is proven compatible.

**Status: PARTIAL / BLOCKED.** The assessment is source-backed; live profiling and validator enforcement are not complete.
