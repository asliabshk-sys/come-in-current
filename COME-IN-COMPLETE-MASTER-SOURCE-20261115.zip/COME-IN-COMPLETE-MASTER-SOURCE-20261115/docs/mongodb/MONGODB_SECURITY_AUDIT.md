# COME-IN MongoDB Security Audit

**Evidence basis:** source/configuration inspection, `.gitignore`, environment templates and the supplied 2026-11-14 secret-scan report. No production environment or credentials were accessed.

| Area | Evidence / finding | Status | Required action |
|---|---|---|---|
| Credential storage | Backend reads `MONGO_URL` from environment; `.env` files are Git-ignored; no real `.env` was present in the working copy | PARTIAL | Store production URI only in managed secret storage; rotate if ever exposed |
| URI/log redaction | Portability health output now emits `REDACTED`, not the URI; backup/restore tools use mode-0600 temporary config files rather than URI process arguments | COMPLETE for CLI/tool arguments; broader logs PARTIAL | Keep exception/log review in deployment verification |
| TLS | Production configuration requires TLS and rejects insecure certificate-validation URI options | SOURCE COMPLETE | Verify actual cluster TLS and certificate validation |
| Database target guard | New `MONGO_EXPECTED_DB_NAME` guard prevents accidental mismatch; production requires it | SOURCE COMPLETE | Set exact expected DB name in deployment secrets |
| Connection authorization | No database role provisioning or least-privilege role definition was found | MISSING | Create app user limited to application DB; separate migration/index-admin role |
| Network restrictions | Local replica-set template binds loopback; managed network allowlist not represented in source | PARTIAL | Restrict managed cluster ingress to app hosts/private network |
| Authentication/ownership | Existing JWT and role/owner checks exist; catalogue staging binds shop, seller and job; Delivery Partner routes use role/state checks | PARTIAL | Run cross-tenant integration tests against disposable deployment |
| Encryption at rest/in transit | TLS now required for production; bank and Delivery Partner PII fields are Fernet-encrypted in application code | PARTIAL | Confirm managed storage encryption and key backups/rotation |
| Key rotation | Separate `BANK_DATA_ENCRYPTION_KEY` and `DELIVERY_PARTNER_DATA_ENCRYPTION_KEY`; no dual-key rotation workflow found | MISSING | Design versioned key IDs and controlled re-encryption/rollback |
| PII in logs | Source mostly logs bounded error context and IDs; no comprehensive dynamic PII log scan possible | PARTIAL | Run sanitized log scan in staging; avoid logging raw docs, uploads, addresses or credentials |
| Injection | PyMongo filters are mostly constructed as explicit dictionaries; import regex SKU uses `re.escape` | PARTIAL | Review all new query paths and enforce typed allowlists |
| Backup privacy | Supplied sanitized preview report shows no unredacted sensitive fields; script redacts password/token/encrypted identity/bank fields | PARTIAL | Review every new sensitive field against redaction allowlist before each backup |
| Secret scan | Supplied report states zero credential-pattern matches and no `.env`/key files; preview test account passwords are intentionally present in a test script | PARTIAL | Keep test accounts disposable and rotate test passwords |

## Production security gates

- Managed secret store for Mongo URI, JWT and encryption keys.
- TLS enabled and verified; network access restricted.
- Application DB user limited to required database/collections; no cluster-admin role.
- Separate migration/index-admin identity with audited, temporary use.
- Independent backup encryption and access controls.
- Versioned encryption-key rotation and recovery procedure.
- Cross-seller/customer and Delivery Partner document-access tests.
- Sanitized application and database audit logs.

No secret values are reproduced in this report.
