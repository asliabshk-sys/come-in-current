# COME-IN MongoDB Step 1 — Updated Completion Matrix (15 Nov 2026)

**Overall PARTIAL / LIVE BLOCKED.** See `MONGODB_STEP1_FINAL_EXECUTION_REPORT_2026-11-15.md` for evidence.

| Area | Evidence-based status | Next gate |
|---|---|---|
| MongoDB config and lifecycle | PARTIAL | Live ping/outage/reconnect |
| Collections and Pydantic schemas | PARTIAL | Real BSON profile |
| 67 indexes | PARTIAL | Real list/create/unique enforcement |
| Persistent JSON schema validators | BLOCKED | Apply in disposable test DB |
| Sessions/driver callbacks | PARTIAL | Real commit/abort/retry |
| Unknown commit/idempotency | PARTIAL | Real ambiguous commit and dedupe |
| Measured inventory/concurrency | PARTIAL | Concurrent stock acceptance |
| Catalogue Import | PARTIAL | Real atomic duplicate/rollback |
| Grocery order/payment | PARTIAL | Real payment + stock tests |
| Restaurant provider payment/refund/ledger | PARTIAL | Real refund webhook + ledger |
| Delivery Partner authorization | PARTIAL | Live scoped auth/provider readiness |
| Backup and restore | PARTIAL | Real mongodump/mongorestore drill |
| Security permissions/TLS | BLOCKED | Isolated role and TLS tests |
| Backend regression | PARTIAL | 498 passed / 2 known UI failures; four runtime modules |
| Live replica-set acceptance | BLOCKED | Free compatible host and tools |
