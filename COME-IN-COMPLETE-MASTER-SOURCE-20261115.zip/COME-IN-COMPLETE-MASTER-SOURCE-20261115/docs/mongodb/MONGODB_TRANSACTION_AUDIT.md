# COME-IN MongoDB Transaction Audit

**Scope:** source inspection of `backend/server.py` after the Phase 2 working-copy changes. No live MongoDB connection was available.

## Transaction scopes

The source now contains 11 explicit `start_session()` / `start_transaction()` scopes:

| Function | Purpose | Session propagation evidence | Status |
|---|---|---|---|
| `_maybe_create_referral_reward` | Referral threshold → reward + audit | Reads and writes use the session | PARTIAL — manual transaction; retry behavior unverified |
| `admin_review_referral` | Referral review, user/referral state and audit | Transaction operations use session | PARTIAL |
| `admin_update_referral_reward` | Reward status, ledger and audit | Transaction operations use session | PARTIAL |
| `import_shop_products` | Legacy CSV/Excel Product writes + price audit + history | In-transaction product re-reads/writes use session | PARTIAL — live rollback not rerun |
| `admin_retail_price_import` | Retail price upserts + audit + import history | Transaction operations use session | PARTIAL |
| `create_order` | Grocery quote claim, stock decrement, order and reward debit | Session passed to resolver, shop revalidation, quote update, stock decrement, order and reward helpers | PARTIAL — no live competing checkout reproduction |
| `_cancel_grocery_order` | Order cancellation + stock restoration | Order reads/writes and stock restoration use session | PARTIAL |
| `request_shop_settlement` | Settlement request + allocations + audit | All in-transaction operations use session | PARTIAL |
| `request_restaurant_settlement` | Restaurant settlement + allocations + audit | All in-transaction operations use session | PARTIAL |
| `admin_settlement_decision` | Conditional state transition + allocation cleanup + audit | All in-transaction operations use session | PARTIAL |
| `_mark_grocery_paid` | Grocery payment capture + order state | New Phase 2 change: payment and order reads/writes share one session/transaction | PARTIAL — no live callback/concurrency test |

No `with_transaction()` callback is currently used. All 11 scopes use manual transaction context managers. The source therefore does not demonstrate driver-managed retry for `TransientTransactionError` or `UnknownTransactionCommitResult`.

## Checkout conflict correction

The grocery checkout performs authoritative in-transaction product re-reads and conditional `$inc` stock decrements (`stock >= qty`). It raises HTTP 409 directly when the conditional decrement returns no modification. A competing transaction can instead cause a labeled transient transaction abort which previously fell through to the generic HTTP 503 handler.

Phase 2 added a conservative post-abort diagnostic:

1. Only errors carrying `TransientTransactionError` are considered.
2. A fresh, non-transactional stock read runs after the aborted transaction.
3. HTTP 409 is returned only if that fresh read explicitly raises `insufficient_stock`.
4. If the label is absent, the read fails, stock is sufficient, or the failure is another kind, the infrastructure HTTP 503 remains.

This is a classification fix, not a retry implementation. It has offline unit/contract coverage only. A real concurrent replica-set reproduction is BLOCKED until a disposable replica set and PyMongo/Motor are available.

## Payment and financial consistency findings

- Grocery Razorpay capture previously updated `orders` and `grocery_payments` in separate operations. Phase 2 now wraps both updates and their state checks in one transaction. Late capture does not resurrect a cancelled/closed order; it records an `under_review` marker. A second capture against an already-paid order sets a reconciliation marker.
- Grocery payment collection has no declared unique index on `gateway_order_id` or `gateway_payment_id`. These are candidates for unique sparse indexes, but remain BLOCKED pending a live duplicate preflight.
- Restaurant payment verification updates the restaurant order, payment record and financial ledger in separate operations; the webhook also processes order/payment/event/ledger state across multiple operations. Compare-and-set state updates, event idempotency and ledger idempotency exist, but the entire set is not atomic.
- Restaurant refund flows call an external payment provider. They use a compare-and-set refund claim and explicit reconciliation states; provider I/O must not be placed inside a long-running MongoDB transaction. Post-provider payment/order writes are still separate and require live fault-injection tests.
- Payment-intent creation can race before the provider order is persisted. A unique gateway-order ID index is a candidate, but it does not alone prevent two intents for the same COME-IN order.
- Single-document UPI confirmation uses an atomic conditional update and does not require a multi-document transaction for the state fields currently changed.

## Required live verification

Run only against a dedicated disposable replica set with the actual pinned Motor 3.7.1 / PyMongo 4.18.2 dependencies:

- transaction commit and abort;
- labeled transient transaction retry and unknown commit reconciliation;
- two customers competing for the final stock unit (one success, one 409; never oversell);
- same idempotency key submitted concurrently;
- duplicate and concurrent Grocery payment callback;
- Restaurant payment verification/webhook duplicate delivery;
- refund claim races and provider timeout reconciliation;
- settlement duplicate allocation and rollback.

The current workspace has no `mongod`, `mongosh`, Docker/Podman, Motor or PyMongo installed. These live tests are BLOCKED, not passed.
