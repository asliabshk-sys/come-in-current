# COME-IN — Expo Environment & Preview Setup

## Pins
Node ^20.19.4 | ^22.13 | >=24.3 · Yarn **1.22.22** · Expo SDK **58.0.17** · React Native **0.88.0** · lockfile `frontend/yarn.lock`.

## Steps
```bash
chmod +x frontend/scripts/*.js frontend/scripts/*.sh scripts/*.sh scripts/mongo/*.sh
cd frontend && yarn install --frozen-lockfile        # never npm; never upgrade
cp .env.example .env                                  # EXPO_PUBLIC_BACKEND_URL=<non-production backend URL>
PORT=3000 yarn start                                  # expo start --port ${PORT:-8081}; open http://localhost:3000 (web)
cd .. && bash scripts/verify-env.sh                   # automated toolchain/env verification
```

## Emergent Preview specifics
- Supervisor runs `yarn start` in `/app/frontend` with `PORT=3000`; the start script honours `PORT`, so the web preview is served on 3000 and routed by the preview URL.
- `frontend/.env`: keep the platform's `REACT_APP_BACKEND_URL` and set `EXPO_PUBLIC_BACKEND_URL` to the same value (the Expo app reads `EXPO_PUBLIC_BACKEND_URL`). All API calls go to `<URL>/api/...`.
- Expo inlines `EXPO_PUBLIC_*` at bundle time → `sudo supervisorctl restart frontend` after changing.
- First web bundle takes 20–40 s.

## Non-production environment template
`frontend/.env.example` (frontend) and `backend/.env.example` (backend). Real values come from the platform secret store; never commit `.env`.
