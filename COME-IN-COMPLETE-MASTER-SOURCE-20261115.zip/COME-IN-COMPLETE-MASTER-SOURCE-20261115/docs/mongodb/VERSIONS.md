# COME-IN — Dependency & Version Requirements

Verified in the Emergent workspace on 2026-11-11 (`bash scripts/verify-env.sh` → PASS).

| Component | Required | Verified here | Declared in |
|---|---|---|---|
| MongoDB server | 7.0.45 (FCV 7.0), replica set | 7.0.45, rs0 | `infra/mongodb/docker-compose.yml` (`mongo:7.0.45`) |
| mongosh | 2.x | 2.14.1 | — |
| Python | 3.11 | 3.11.18 | `backend/requirements.txt` |
| PyMongo / Motor | 4.18.2 / 3.7.1 | 4.18.2 / 3.7.1 | `backend/requirements.txt` |
| FastAPI / Uvicorn | 0.110.1 / 0.25.0 | same | `backend/requirements.txt` |
| Node.js | ^20.19.4, ^22.13 or >=24.3 | 24.19.0 | Expo SDK 58 engines |
| Yarn | 1.22.22 (classic) | 1.22.22 | `frontend/package.json#packageManager` |
| Expo SDK | 58.0.17 | 58.0.17 | `frontend/package.json` |
| React Native | 0.88.0 | 0.88.0 | `frontend/package.json` |
| React / React DOM | 19.3.0 | 19.3.0 | `frontend/package.json` |
| expo-router | 58.0.25 | 58.0.25 | `frontend/package.json` |
| TypeScript | 6.0.3 | 6.0.3 | `frontend/package.json` |
| Lockfile | `frontend/yarn.lock` (install with `--frozen-lockfile`) | installed cleanly | — |

Notes
- `emergentintegrations==0.2.2` is on Emergent's private index; outside Emergent add `--extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/` or drop the line (not imported by `server.py`).
- Do not run `expo install --fix` / upgrade suggestions; versions are pinned on purpose. `.npmrc` has `save-exact=true`.
