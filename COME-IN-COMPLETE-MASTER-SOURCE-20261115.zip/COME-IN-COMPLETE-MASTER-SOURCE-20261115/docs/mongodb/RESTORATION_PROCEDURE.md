# COME-IN — Restoration Procedure (new Emergent account / new dev environment)

The Master ZIP has **code, config, scripts and docs only — no MongoDB server, no data, no secrets.**

## Procedure

| # | Step | Command / action | Automated? | Needs external credentials / infra? |
|---|---|---|---|---|
| 1 | Upload the Master ZIP | upload to the new workspace (or download from the checkpoint link) | No (manual) | No |
| 2 | Extract + verify | `unzip <zip> && cd COME-IN-WORKING-COPY-RECOVERED-V1 && sha256sum -c --quiet MANIFEST.sha256` | Yes | No |
| 3 | Read setup instructions | `docs/mongodb/MONGODB_SETUP.md` (this folder) | No (manual) | No |
| 4 | Configure authorised test credentials | `cp backend/.env.example backend/.env`, `cp frontend/.env.example frontend/.env`; fill `MONGO_URL`, `DB_NAME`, `JWT_SECRET`, `BANK_DATA_ENCRYPTION_KEY`, `EXPO_PUBLIC_BACKEND_URL` | Partly (templates) | Local rs: **No**. Atlas/managed: **Yes** (test-only user via secret store) |
| 5 | Provision replica set | `bash scripts/mongo/setup.sh` (local) · `docker compose -f infra/mongodb/docker-compose.yml up -d` (Docker) · Atlas (external) | Yes | Needs `mongod` 7.0.x binary (present in Emergent image) or Docker |
| 6 | Initialise collections + indexes | included in setup.sh (`comein_mongo.py init`) | Yes | No |
| 7 | Verify connectivity | included (`health` → ping, PRIMARY) | Yes | No |
| 8 | Verify transactions | included (`tx-verify` + disposable `testdb-cycle`) | Yes | No |
| 9 | Run health check | `python3 scripts/mongo/comein_mongo.py health` | Yes | No |
| 10 | Install deps | `cd frontend && yarn install --frozen-lockfile`; `pip install -r backend/requirements.txt` | Yes | Registry access (npm + Emergent pip index for `emergentintegrations`) |
| 11 | Verify toolchain | `bash scripts/verify-env.sh` | Yes | No |

Emergent workspace specifics: place `backend/`, `frontend/` and the rest of the project at `/app`, keep the platform's
`REACT_APP_BACKEND_URL` in `frontend/.env` and set `EXPO_PUBLIC_BACKEND_URL` to the same value, set
`MONGO_URL=mongodb://127.0.0.1:27018/?replicaSet=rs0`, then `sudo supervisorctl restart backend frontend`.
After every pod restart re-run `bash scripts/mongo/setup.sh` (supervisor conf.d is not persistent; data in `/root/mongo-rs0-data` is).

## One-command clean-directory test
`bash scripts/release/restoration_test.sh <zip> <empty_work_dir> [port]` — extracts, verifies the manifest, creates `.env` from templates
with random local secrets, builds a fresh venv + empty-cache `yarn install --frozen-lockfile`, provisions an isolated replica set on
`port` (default 27019) with its own dbpath, runs init / disposable-DB / transactions / health, boots the backend on :8099, runs
`verify-env.sh`, then stops everything and deletes the data.

## Recorded results (2026-11-11)

| Archive | Environment | Result |
|---|---|---|
| COME-IN-MONGODB-PORTABLE-CHECKPOINT | Same Emergent pod, **separate clean directory** `/root/restore-test-checkpoint`, separate port 27019 + dbpath, fresh venv, empty yarn cache | **PASS** (steps 2, 4–11 automated; manifest 504/504; health ok; tx commit+abort ok; backend `/api/` ok) |
| COME-IN-MASTER-COMPLETE-TASK5-MONGODB | same method | see `COME_IN_MONGODB_PORTABILITY_STATUS.md` |

**Not tested:** a literally new Emergent account/pod (not available from this session), Docker Compose (Docker unavailable),
Atlas/managed replica set (no authorised external credentials supplied). Steps 1 and 3 are manual by nature.
