# COME-IN MongoDB Master Document — 15 November 2026

**Evidence boundary:** Source-level completion checkpoint based on the recovered Phase 2 **partial** ZIP. This is not a live verified production release; it has no Git history. No production MongoDB/customer records, paid providers, or credentials were used. Approved project plan: **Step 1 MongoDB + Backup + Restore ONLY**.

## 1. Provenance and architecture

- Baseline upload: `COME-IN-MONGODB-MISSION-PARTIAL-CHECKPOINT-20261114 (1).zip`; SHA-256 `72b32dbd5673a2bfd166355ca1e3203d5004cc2c24bdccefad7c2a5f59f40132`.
- Verified original read-only recovery: `/mnt/data/COME-IN-MONGODB-READONLY-RECOVERY-20261115/COME-IN-MONGODB-PHASE2-WORK` (681 files).
- Separate development copy: `/mnt/data/COME-IN-MONGODB-STEP1-DEV-20261115`. Unchanged original ZIP and recovery folder. Original `.git` NOT available in this partial ZIP.
- Original SHA manifest conflicts: 14 `PROJECT_MANIFEST.json` and 22 `MANIFEST.sha256` historical differences, reconciled in `audit/COME_IN_PHASE2_SOURCE_RECONCILIATION_2026-11-15.md` of the read-only recovery. These historical manifests were preserved, not regenerated in place.
- React Native / Expo Router → FastAPI (`backend/server.py`, `/api/*` routes) → Motor async client (`AsyncIOMotorClient`) → **existing MongoDB**. Pydantic validates inbound API payloads. Auth uses existing JWT role/user scopes. Existing seller/Restaurant/Delivery workflows retained.
- One existing Product collection stores product and stock, including `stock` in integer g/ml for measured products and nested `variants[].stock`. **No separate inventory collection**.
- Backend requirements preserve `motor==3.7.1`, `pymongo==4.18.2` from `backend/requirements.txt`.

## 2. Configuration and lifecycle

- `backend/mongo_config.py`: requires APP_ENV, DB_NAME, MONGO_URL; rejects system DBs, unsupported DB names and production without expected DB and TLS; enforces pool/timeouts and certificate checks; never prints URI values in config exception text.
- `backend/server.py`: start-up `ping` and `hello`; fails closed if standalone (multi-document transactions not supported), then indexes initialized; existing application shutdown closes MongoDB client (source inspection required for each runtime deployment).
- `.env.example` templates remain templates; do not package `.env`, tokens, credentials, private document uploads or live database dumps.
- Required operational tests: credentials/role least privilege, actual TLS identity, topology, shutdown/reconnect, network partition behaviour, replica-set feature compatibility; all **NOT RUN** here.

## 3. Collection inventory (source-derived, not live BSON-schema proof)

All **51** collection names are statically discovered from the modified source. This includes the *new* `catalogue_import_audit`, so it is not the historical 50 collection baseline. Source AST usage is not evidence that these collections actually exist in a deployed DB. For models, inspect `backend/server.py` (`ProductIn`, `ProductVariantIn`, `MeasureIn`, `OrderIn`, payment/refund/order classes), `backend/catalogue_import_engine.py`, and delivery-partner/CHAND modules. Actual field-presence and type profiling requires a sanitized disposable data copy.

| # | Collection | Schema-evidence limitation |
|---:|---|---|
| 1 | `addresses` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 2 | `agent_assist` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 3 | `announcements` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 4 | `assistant_rate_limits` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 5 | `auth_rate_limits` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 6 | `catalog_import_history` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 7 | `catalog_price_audit` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 8 | `catalogue_import_audit` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 9 | `catalogue_import_jobs` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 10 | `chand_feedback` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 11 | `delivery_partner_applications` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 12 | `delivery_partner_audit` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 13 | `delivery_partner_referrals` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 14 | `files` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 15 | `financial_audit` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 16 | `financial_ledger` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 17 | `grocery_payments` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 18 | `grocery_quotes` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 19 | `home_service_settings` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 20 | `home_service_slot_reservations` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 21 | `master_products` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 22 | `notifications` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 23 | `orders` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 24 | `password_resets` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 25 | `payout_bank_accounts` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 26 | `products` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 27 | `referral_audit` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 28 | `referral_ledger` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 29 | `referral_link_events` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 30 | `referral_rewards` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 31 | `referrals` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 32 | `request_anything` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 33 | `restaurant_carts` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 34 | `restaurant_menu` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 35 | `restaurant_orders` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 36 | `restaurant_payment_events` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 37 | `restaurant_payments` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 38 | `restaurant_reviews` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 39 | `restaurant_support` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 40 | `restaurants` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 41 | `restock_alerts` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 42 | `retail_price_import_history` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 43 | `retail_price_offers` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 44 | `retail_price_price_audit` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 45 | `service_appointments` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 46 | `service_providers` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 47 | `settlement_order_allocations` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 48 | `settlement_requests` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 49 | `shops` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 50 | `status_checks` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |
| 51 | `users` | Database document shape unverified; source write paths in `backend/server.py` and any corresponding Pydantic models are authoritative until sampled. |

## 4. Index inventory and safe rollout

Source defines **67** application indexes: 61 in `_startup` and 6 in Delivery Partner initialization. Historical baseline has 65; the *new* two are partial unique indexes for `(catalogue_import_job_id, catalogue_import_record_index)` on Products and `apply_key` on `catalogue_import_audit`. Historical index definitions retained. All 67 pass a fake-DB portability/index drift test; **not installed/confirmed on real MongoDB**. Existing shop+SKU globally unique index is intentionally NOT created because legacy duplicate profiling has not occurred; import write-fence and transaction recheck avoid silently merging stock, pending live concurrency proof.

| # | Collection | Key directions | Semantic options | Initializer |
|---:|---|---|---|---|
| 1 | `notifications` | `user_id:1, created_at:-1` | `defaults` | `_startup` |
| 2 | `assistant_rate_limits` | `rate_key:1` | `unique=true` | `_startup` |
| 3 | `assistant_rate_limits` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` |
| 4 | `chand_feedback` | `user_id:1, created_at:-1` | `defaults` | `_startup` |
| 5 | `chand_feedback` | `user_id:1, request_id:1` | `unique=true` | `_startup` |
| 6 | `chand_feedback` | `status:1, created_at:-1` | `defaults` | `_startup` |
| 7 | `notifications` | `user_id:1, read:1` | `defaults` | `_startup` |
| 8 | `auth_rate_limits` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` |
| 9 | `restock_alerts` | `product_id:1, active:1` | `defaults` | `_startup` |
| 10 | `users` | `email:1` | `unique=true` | `_startup` |
| 11 | `users` | `referral_code:1` | `unique=true, sparse=true` | `_startup` |
| 12 | `referrals` | `referred_user_id:1` | `unique=true` | `_startup` |
| 13 | `referrals` | `referrer_id:1, status:1` | `defaults` | `_startup` |
| 14 | `referrals` | `qualifying_order_id:1` | `unique=true, partialFilterExpression={"qualifying_order_id": {"$type": "string"}}` | `_startup` |
| 15 | `referral_rewards` | `reward_key:1` | `unique=true` | `_startup` |
| 16 | `referral_rewards` | `referrer_id:1, status:1` | `defaults` | `_startup` |
| 17 | `referral_ledger` | `idempotency_key:1` | `unique=true, sparse=true` | `_startup` |
| 18 | `referral_ledger` | `user_id:1, created_at:-1` | `defaults` | `_startup` |
| 19 | `referral_audit` | `created_at:-1` | `defaults` | `_startup` |
| 20 | `referral_link_events` | `referrer_id:1, created_at:-1` | `defaults` | `_startup` |
| 21 | `payout_bank_accounts` | `beneficiary_type:1, beneficiary_id:1` | `unique=true` | `_startup` |
| 22 | `settlement_requests` | `beneficiary_user_id:1, created_at:-1` | `defaults` | `_startup` |
| 23 | `settlement_requests` | `beneficiary_user_id:1, beneficiary_type:1, beneficiary_id:1, idempotency_key:1` | `unique=true` | `_startup` |
| 24 | `settlement_requests` | `status:1, created_at:-1` | `defaults` | `_startup` |
| 25 | `settlement_order_allocations` | `order_key:1` | `unique=true` | `_startup` |
| 26 | `settlement_order_allocations` | `settlement_id:1` | `defaults` | `_startup` |
| 27 | `financial_audit` | `created_at:-1` | `defaults` | `_startup` |
| 28 | `financial_ledger` | `idempotency_key:1` | `unique=true` | `_startup` |
| 29 | `financial_ledger` | `beneficiary_user_id:1, recorded_at:-1` | `defaults` | `_startup` |
| 30 | `financial_ledger` | `order_id:1, recorded_at:-1` | `defaults` | `_startup` |
| 31 | `shops` | `owner_id:1` | `defaults` | `_startup` |
| 32 | `shops` | `status:1` | `defaults` | `_startup` |
| 33 | `products` | `shop_id:1` | `defaults` | `_startup` |
| 34 | `products` | `owner_id:1` | `defaults` | `_startup` |
| 35 | `products` | `catalogue_import_job_id:1, catalogue_import_record_index:1` | `unique=true, partialFilterExpression={"catalogue_import_job_id": {"$type": "string"}, "catalogue_import_record_index": {"$type": "int"}}` | `_startup` |
| 36 | `catalogue_import_audit` | `apply_key:1` | `unique=true, partialFilterExpression={"apply_key": {"$type": "string"}}` | `_startup` |
| 37 | `orders` | `customer_id:1` | `defaults` | `_startup` |
| 38 | `orders` | `shop_id:1` | `defaults` | `_startup` |
| 39 | `orders` | `grocery_idempotency_scope:1` | `unique=true, sparse=true` | `_startup` |
| 40 | `grocery_quotes` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` |
| 41 | `grocery_quotes` | `scope:1, status:1` | `defaults` | `_startup` |
| 42 | `files` | `owner_id:1` | `defaults` | `_startup` |
| 43 | `restaurants` | `owner_id:1` | `defaults` | `_startup` |
| 44 | `restaurants` | `status:1, available:1, city:1` | `defaults` | `_startup` |
| 45 | `restaurant_menu` | `restaurant_id:1, available:1` | `defaults` | `_startup` |
| 46 | `addresses` | `user_id:1, is_default:-1` | `defaults` | `_startup` |
| 47 | `restaurant_orders` | `customer_id:1, created_at:-1` | `defaults` | `_startup` |
| 48 | `restaurant_orders` | `restaurant_id:1, created_at:-1` | `defaults` | `_startup` |
| 49 | `restaurant_orders` | `customer_id:1, idempotency_key:1` | `unique=true` | `_startup` |
| 50 | `restaurant_payments` | `gateway_order_id:1` | `unique=true, sparse=true` | `_startup` |
| 51 | `restaurant_payment_events` | `event_id:1` | `unique=true, sparse=true` | `_startup` |
| 52 | `restaurant_reviews` | `restaurant_id:1, customer_id:1` | `unique=true` | `_startup` |
| 53 | `password_resets` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` |
| 54 | `restaurant_support` | `user_id:1, created_at:-1` | `defaults` | `_startup` |
| 55 | `restaurant_support` | `user_id:1, request_id:1` | `unique=true, partialFilterExpression={"request_id": {"$type": "string"}}` | `_startup` |
| 56 | `restaurant_carts` | `user_id:1` | `unique=true` | `_startup` |
| 57 | `service_providers` | `owner_id:1` | `unique=true, sparse=true` | `_startup` |
| 58 | `service_appointments` | `customer_id:1, created_at:-1` | `defaults` | `_startup` |
| 59 | `service_appointments` | `provider_id:1, created_at:-1` | `defaults` | `_startup` |
| 60 | `home_service_slot_reservations` | `provider_id:1, slot_key:1` | `unique=true` | `_startup` |
| 61 | `home_service_settings` | `key:1` | `unique=true` | `_startup` |
| 62 | `delivery_partner_applications` | `user_id:1` | `unique=true` | `ensure_delivery_partner_indexes` |
| 63 | `delivery_partner_applications` | `referral_code:1` | `unique=true, sparse=true` | `ensure_delivery_partner_indexes` |
| 64 | `delivery_partner_applications` | `status:1, updated_at:-1` | `defaults` | `ensure_delivery_partner_indexes` |
| 65 | `delivery_partner_audit` | `application_id:1, created_at:-1` | `defaults` | `ensure_delivery_partner_indexes` |
| 66 | `delivery_partner_referrals` | `referred_application_id:1` | `unique=true` | `ensure_delivery_partner_indexes` |
| 67 | `delivery_partner_referrals` | `referrer_application_id:1, created_at:-1` | `defaults` | `ensure_delivery_partner_indexes` |

**Safe runbook:** `python scripts/mongo/comein_mongo.py spec` for plans; collect disposable duplicate preflight (`preflight` command if supported by CLI); review definitions and legacy conflicts; initialize against disposable replica set; verify via `verify-indexes` and `health`. Do not delete conflicts. Do not assume fake-DB tests prove index deployment.

## 5. Schema validators

- Existing app validates API payloads with Pydantic but the original checkpoint contained no installed persistent MongoDB validators.
- Added `scripts/mongo/catalogue_audit_validator.py` defining `$jsonSchema` for **new** `catalogue_import_audit` only. Default is printed plan, no DB operation; `--apply` requires `APP_ENV=test`, explicit matching `--confirm-disposable-db`, `comein_disposable_test_*` namespace and *localhost-only* Mongo URI, with an empty/new audit collection.
- Legacy collections are **not** assigned speculative strict validators. Profile BSON fields and legacy versions first; use warning-only tests on disposable clone before enabling server enforcement. No validators were installed in this execution.

## 6. Transactions, retries, idempotency and concurrency

- `backend/mongo_transactions.py::run_transaction` uses Motor's `session.with_transaction(callback)`; this is driver-managed transaction/commit retry, not `retryWrites` masquerading as transaction retry. Callback database operations carry `session=session`. Do not perform provider API requests, notifications or irreversible actions inside callbacks.
- Three newly callback-managed main paths: `_apply_catalogue_import_job_transactionally`, `_mark_grocery_paid`, `_commit_restaurant_capture`. Restaurant failure and refund claim helpers also use the driver helper. Ten older manual transaction scopes remain in other workflows; they remain source-implemented but lack general callback retries.
- Imports: confirmed seller-owned staged approved records are revalidated through `_import_measure` and `ProductIn`; the transaction conditionally claims job, fences the shop, rejects same-shop SKU collisions, inserts unavailable Product+stock (no separate inventory), inserts audit, marks records and job `APPLIED` together. Deterministic idempotency keys and two partial unique indexes; repeats reconcile committed job/product/audit IDs. A failed/ambiguous transaction returns 503 unless durable result is confirmed.
- Grocery: quote claim, conditional stock deductions, order insert and cancellation restoration remain existing manual scopes; captured payment/order state now commits as one retried callback, with late-capture review and notification after commit.
- Restaurant: verified provider capture and signed webhook use same transactional payment/order helper; late capture never reopens cancelled orders. Signed failed-payment state and admin refund claim now use retried DB-only transactions. Provider refund calls occur **after** the committed claim. **Remaining risk:** Restaurant signed refund webhook uses a new atomic callback, with duplicate/out-of-order protections. Admin post-provider refund persistence and ledger writes can still span multiple documents; full live tests and those targeted source improvements remain pending.
- External provider validation remains required: server-side captured status, matching INR amount, gateway-order/payment IDs. A signed webhook alone does not justify marking an order paid without checking matched captured entity facts.
- **Offline test caveat:** AST-sourced execution with in-memory fake transactions proves callback logic under injected failure/retries; cannot establish actual MongoDB conflict isolation, write concern, unknown-commit driver behaviour, indexes or concurrency.

## 7. Universal Catalogue Import detailed contract

1. Seller uploads files to `catalogue_import_jobs`; CHAND suggestions do not auto-approve.
2. Seller edits/reviews records; approved records must have matching seller identity.
3. Seller sends explicit `confirm:true` at unchanged `POST /shops/{shop_id}/catalogue-import/jobs/{job_id}/confirm-apply`.
4. Re-check job+shop+seller ownership in transaction. Existing `APPLY_PENDING_EMERGENT` jobs can apply only if previously confirmed by same owner.
5. Re-run validation and use existing Product.stock/variants; measured base-unit quantities remain integer. Import SKU duplicate raises 409. No automatic overwrite/merge or quantity adjustment.
6. Insert with `available:false`, provenance filename/location/SHA-256 and two publication markers; seller publishes through existing workflow. Partial unique index and shop write-fence provide idempotency/concurrency protection at source level.
7. Product inserts, import audit and job `APPLIED` status commit atomically or rollback. Errors expose bounded generic details and require reconciliation.

## 8. Backup, restore, security

- `scripts/backup-db.sh` uses private URI config file, 0600 permissions, **unique `mktemp -d` destination** and SHA-256 sidecar; no overwrites. It never ran against live MongoDB here. Offline mock `mongodump` test creates two distinct checksummed fake archives.
- `scripts/restore-db.sh` rejects a source DB target and requires `comein_disposable_test_*`, sidecar checksum, and post-restore index verification. **No actual restore drill** could run without `mongorestore` and replica-set MongoDB.
- `scripts/mongo/comein_mongo.py`: source-derived index specs, duplicate preflight, health and transaction checks; no migrations were run on user/production DBs.
- Security: Seller/owner scoping rechecked in import transaction; `available:false`; URI redaction; no migrations on production. Remaining live checks: roles/collection permissions, TLS, cross-tenant API tests, legacy record profiling, Aadhaar/PAN/PII access, delivery partner document storage, error-response review, audit log retention.

## 9. Backend API source inventory

These **177** FastAPI route declarations are parsed from the source. This is not evidence each API can run without dependencies or live database. Existing route paths were not renamed. CRUD paths touch collections via `backend/server.py` and its helpers.

| Method | Path | Source handler |
|---|---|---|
| GET | `/` | `root` |
| POST | `/status` | `create_status_check` |
| GET | `/status` | `list_status_checks` |
| POST | `/auth/register` | `register` |
| POST | `/auth/login` | `login` |
| GET | `/referrals/me` | `referral_dashboard` |
| POST | `/referrals/home-banner-claim` | `claim_first_home_referral_banner` |
| GET | `/referral/validate` | `validate_referral` |
| GET | `/referral` | `open_referral` |
| GET | `/admin/referrals` | `admin_referrals` |
| PATCH | `/admin/referrals/{referral_id}/review` | `admin_review_referral` |
| PATCH | `/admin/referral-rewards/{reward_id}` | `admin_update_referral_reward` |
| GET | `/auth/me` | `me` |
| PATCH | `/auth/me` | `update_me` |
| POST | `/auth/password/forgot` | `forgot_password` |
| POST | `/auth/password/reset` | `reset_password` |
| POST | `/uploads/image` | `upload_image` |
| GET | `/uploads/{storage_path:path}` | `serve_upload` |
| POST | `/shops` | `create_shop` |
| GET | `/shops/mine` | `my_shop` |
| PATCH | `/shops/{shop_id}` | `update_shop` |
| PATCH | `/shops/{shop_id}/availability` | `set_shop_availability` |
| GET | `/shops` | `list_shops` |
| GET | `/shops/{shop_id}` | `get_shop` |
| POST | `/chand/feedback` | `submit_chand_feedback` |
| GET | `/chand/feedback/mine` | `my_chand_feedback` |
| GET | `/admin/chand/feedback` | `admin_chand_feedback` |
| GET | `/admin/chand/feedback/summary` | `admin_chand_feedback_summary` |
| PATCH | `/admin/chand/feedback/{feedback_id}` | `admin_update_chand_feedback` |
| POST | `/assistant/context` | `assistant_context` |
| GET | `/assistant/health` | `assistant_health` |
| POST | `/assistant/transcribe` | `assistant_transcribe` |
| POST | `/assistant/vision` | `assistant_vision` |
| POST | `/admin/master-products` | `create_master_product` |
| GET | `/catalog/master-products` | `search_master_products` |
| POST | `/shops/{shop_id}/master-products/{master_product_id}/link` | `link_master_product` |
| POST | `/shops/{shop_id}/products` | `create_product` |
| POST | `/shops/{shop_id}/catalogue-import/jobs` | `create_catalogue_import_job` |
| GET | `/shops/{shop_id}/catalogue-import/jobs/{job_id}` | `get_catalogue_import_job` |
| GET | `/shops/{shop_id}/catalogue-import/jobs` | `list_catalogue_import_jobs` |
| GET | `/shops/{shop_id}/catalogue-import/categories` | `list_catalogue_import_categories` |
| PATCH | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}` | `edit_catalogue_import_record` |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/approve` | `approve_catalogue_import_record` |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/reject` | `reject_catalogue_import_record` |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/bulk-approve` | `bulk_approve_catalogue_import_records` |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/confirm-apply` | `confirm_catalogue_import_apply` |
| POST | `/shops/{shop_id}/products/import` | `import_shop_products` |
| GET | `/shops/{shop_id}/products/import-template` | `shop_product_import_template` |
| GET | `/admin/catalog-import-history` | `admin_catalog_import_history` |
| GET | `/admin/catalog-price-audit` | `admin_catalog_price_audit` |
| GET | `/catalog/price-comparison` | `compare_master_product_prices` |
| GET | `/admin/retail-price-import/template` | `retail_price_import_template` |
| POST | `/admin/retail-price-import` | `admin_retail_price_import` |
| GET | `/catalog/retail-prices` | `public_retail_prices` |
| GET | `/admin/retail-price-import/history` | `admin_retail_price_import_history` |
| GET | `/shops/{shop_id}/products` | `list_shop_products` |
| GET | `/catalog/products` | `list_catalog_products` |
| PATCH | `/products/{product_id}` | `update_product` |
| DELETE | `/products/{product_id}` | `delete_product` |
| POST | `/grocery/measured-price` | `measured_price` |
| POST | `/grocery/quotes` | `create_grocery_quote` |
| POST | `/orders` | `create_order` |
| POST | `/orders/{order_id}/confirm-upi-payment` | `confirm_grocery_upi_payment` |
| GET | `/orders/mine` | `my_orders` |
| POST | `/orders/{order_id}/cancel` | `cancel_grocery_order` |
| GET | `/shops/{shop_id}/orders` | `shop_orders` |
| PATCH | `/orders/{order_id}/status` | `update_order_status` |
| GET | `/orders/{order_id}` | `get_grocery_order_details` |
| GET | `/orders/{order_id}/tracking` | `get_order_tracking` |
| POST | `/orders/{order_id}/tracking/location` | `update_order_tracking_location` |
| POST | `/requests/anything` | `submit_request_anything` |
| GET | `/requests/anything/mine` | `my_requests_anything` |
| POST | `/requests/assist` | `submit_agent_assist` |
| GET | `/admin/announcements` | `admin_announcements` |
| POST | `/admin/announcements` | `create_announcement` |
| PATCH | `/admin/announcements/{announcement_id}` | `set_announcement_active` |
| GET | `/admin/dashboard` | `admin_dashboard` |
| GET | `/announcements/active` | `active_announcements` |
| GET | `/admin/users` | `admin_users` |
| PATCH | `/admin/users/{user_id}/role` | `admin_update_user_role` |
| GET | `/admin/shops` | `admin_shops` |
| PATCH | `/admin/shops/{shop_id}/status` | `admin_set_shop_status` |
| GET | `/admin/orders` | `admin_orders` |
| POST | `/earnings/orders/{kind}/{order_id}/cash-collected` | `confirm_manual_cash_collection` |
| GET | `/admin/earnings` | `admin_earnings` |
| GET | `/admin/earnings/ledger` | `admin_earnings_ledger` |
| GET | `/admin/earnings/transactions` | `admin_earnings_transactions` |
| GET | `/earnings/mine` | `shopkeeper_earnings` |
| GET | `/admin/earnings/bank-account` | `admin_platform_bank_account` |
| PUT | `/admin/earnings/bank-account` | `save_admin_platform_bank_account` |
| GET | `/shops/{shop_id}/bank-account` | `get_shop_bank_account` |
| PUT | `/shops/{shop_id}/bank-account` | `save_shop_bank_account` |
| GET | `/restaurants/{restaurant_id}/bank-account` | `get_restaurant_bank_account` |
| PUT | `/restaurants/{restaurant_id}/bank-account` | `save_restaurant_bank_account` |
| PATCH | `/admin/financial-policy/{kind}/{entity_id}` | `admin_set_financial_policy` |
| GET | `/admin/earnings/settlements` | `admin_settlement_list` |
| POST | `/shops/{shop_id}/settlements` | `request_shop_settlement` |
| POST | `/restaurants/{restaurant_id}/settlements` | `request_restaurant_settlement` |
| PATCH | `/admin/earnings/settlements/{settlement_id}` | `admin_settlement_decision` |
| GET | `/admin/requests/anything` | `admin_requests_anything` |
| GET | `/admin/requests/assist` | `admin_agent_assist` |
| PATCH | `/admin/requests/anything/{req_id}/status` | `admin_update_request` |
| PATCH | `/admin/requests/assist/{req_id}/status` | `admin_update_assist` |
| GET | `/restaurants` | `list_restaurants` |
| GET | `/restaurants/mine` | `my_restaurants` |
| POST | `/restaurants` | `create_restaurant` |
| GET | `/restaurants/{restaurant_id}` | `restaurant_detail` |
| GET | `/restaurants/{restaurant_id}/serviceability` | `restaurant_delivery_serviceability` |
| PATCH | `/restaurants/{restaurant_id}` | `update_restaurant` |
| PATCH | `/restaurants/{restaurant_id}/availability` | `restaurant_availability` |
| GET | `/restaurants/{restaurant_id}/menu` | `restaurant_menu` |
| POST | `/restaurants/{restaurant_id}/menu` | `create_menu_item` |
| PATCH | `/restaurants/{restaurant_id}/menu/{item_id}` | `update_menu_item` |
| DELETE | `/restaurants/{restaurant_id}/menu/{item_id}` | `delete_menu_item` |
| GET | `/addresses` | `list_addresses` |
| POST | `/addresses` | `create_address` |
| PATCH | `/addresses/{address_id}` | `update_address` |
| DELETE | `/addresses/{address_id}` | `delete_address` |
| GET | `/restaurant/cart` | `get_restaurant_cart` |
| PUT | `/restaurant/cart` | `save_restaurant_cart` |
| DELETE | `/restaurant/cart` | `clear_restaurant_cart` |
| POST | `/restaurant/orders` | `create_restaurant_order` |
| GET | `/restaurant/orders/mine` | `my_restaurant_orders` |
| GET | `/restaurants/{restaurant_id}/orders` | `restaurant_orders` |
| PATCH | `/restaurant/orders/{order_id}/status` | `update_restaurant_order_status` |
| POST | `/restaurant/orders/{order_id}/cancel` | `cancel_restaurant_order` |
| GET | `/restaurant/payments/config` | `restaurant_payment_config` |
| POST | `/restaurant/orders/{order_id}/payment-intent` | `create_restaurant_payment_intent` |
| POST | `/restaurant/orders/{order_id}/payment-retry` | `retry_restaurant_payment` |
| POST | `/restaurant/payments/verify` | `verify_restaurant_payment` |
| POST | `/restaurant/payments/razorpay-webhook` | `razorpay_webhook` |
| POST | `/restaurants/{restaurant_id}/reviews` | `create_restaurant_review` |
| POST | `/restaurant/support` | `create_restaurant_support` |
| GET | `/restaurant/support/mine` | `my_restaurant_support` |
| GET | `/seller/support` | `seller_order_support` |
| PATCH | `/seller/support/{ticket_id}` | `seller_update_order_support` |
| GET | `/admin/restaurant/support` | `admin_restaurant_support` |
| PATCH | `/admin/restaurant/support/{ticket_id}` | `admin_update_restaurant_support` |
| POST | `/admin/restaurant/orders/{order_id}/refund` | `admin_refund_restaurant_order` |
| GET | `/admin/restaurant/orders` | `admin_restaurant_orders` |
| GET | `/admin/restaurants` | `admin_restaurants` |
| PATCH | `/admin/restaurants/{restaurant_id}/status` | `admin_restaurant_status` |
| GET | `/home-services/fee-policy` | `get_home_service_fee_policy` |
| PATCH | `/admin/home-services/fee-policy` | `set_home_service_fee_policy` |
| GET | `/home-services/providers` | `list_service_providers` |
| GET | `/home-services/providers/mine` | `my_service_provider` |
| POST | `/home-services/providers` | `register_service_provider` |
| PATCH | `/home-services/providers/{provider_id}` | `update_service_provider` |
| PATCH | `/home-services/providers/{provider_id}/photo` | `update_service_provider_photo` |
| POST | `/home-services/appointments` | `create_service_appointment` |
| GET | `/home-services/appointments/mine` | `my_service_appointments` |
| GET | `/home-services/appointments/provider` | `provider_service_appointments` |
| PATCH | `/home-services/appointments/{appointment_id}/status` | `update_service_appointment` |
| GET | `/admin/home-services/providers` | `admin_service_providers` |
| PATCH | `/admin/home-services/providers/{provider_id}/approval` | `admin_approve_service_provider` |
| GET | `/grocery/payments/config` | `grocery_payment_config` |
| POST | `/orders/{order_id}/payment-intent` | `create_grocery_payment_intent` |
| POST | `/grocery/payments/verify` | `verify_grocery_payment` |
| GET | `/notifications/mine` | `my_notifications` |
| GET | `/notifications/unread-count` | `my_unread_notifications` |
| POST | `/notifications/read-all` | `read_all_notifications` |
| POST | `/notifications/{notification_id}/read` | `read_notification` |
| GET | `/products/{product_id}/restock-alert` | `restock_alert_status` |
| POST | `/products/{product_id}/restock-alert` | `subscribe_restock_alert` |
| DELETE | `/products/{product_id}/restock-alert` | `unsubscribe_restock_alert` |
| GET | `/delivery-partner/provider-status` | `delivery_partner_provider_status` |
| POST | `/delivery-partner/otp/request` | `delivery_partner_otp_request` |
| POST | `/delivery-partner/otp/verify` | `delivery_partner_otp_verify` |
| POST | `/delivery-partner/identity/start` | `delivery_partner_identity_start` |
| PUT | `/delivery-partner/application` | `save_delivery_partner_application` |
| POST | `/delivery-partner/application/submit` | `submit_delivery_partner_application` |
| GET | `/delivery-partner/application/mine` | `my_delivery_partner_application` |
| GET | `/delivery-partner/referral` | `delivery_partner_referral` |
| GET | `/delivery-partner/admin/applications` | `admin_delivery_partner_applications` |
| GET | `/delivery-partner/admin/applications/{application_id}` | `admin_delivery_partner_application_detail` |
| PATCH | `/delivery-partner/admin/applications/{application_id}` | `admin_decide_delivery_partner_application` |
| GET | `/delivery-partner/access` | `delivery_partner_access` |

## 10. Tests and release gates

- Baseline focused offline suite before modifications: `37 passed`. Test config `backend/pytest.ini` requires `pytest-xdist` not installed; used `pytest -c /dev/null` **only** to run unchanged tests directly, not to weaken their assertions.
- Final offline all available test modules: **477 passed, 2 failed** (both pre-existing Home UI static markers; independently reproduced on original recovered source). 4 environment-dependent runtime/live modules not collected.
- `python -m compileall`, bash syntax, fake index initialization, mocked backup no-clobber, case-based auth/transaction tests run; separate evidence in `MONGODB_FINAL_TEST_EVIDENCE_2026-11-15.md`.
- `tsc -p frontend/tsconfig.json --noEmit`: **FAILED** due missing Expo/React Native modules/tsconfig inheritance, no network/dependency installation. Frontend source was not modified.
- Live verification: **BLOCKED**. `mongod`, `mongosh`, `mongodump`, `mongorestore`, Docker/Podman and Motor/PyMongo unavailable. No live MongoDB commit/abort/restore/index data, production gateway or provider event verification.

## 11. Pending environment and production configuration

Use only a disposable replica-set capable local test database with supported OS/server/driver pairing and the exact existing pins. Install dependencies only in an authorized environment; never connect to a production URI. Prove all 14 handoff checks: topology, role grants, indexes/duplicates, atomic multi-row apply, rollback, concurrent confirmation, ambiguous commit retry, cross-shop boundaries, unpublished visibility, legacy compatibility, variants, Task 5 measured units, Restaurant regression, sanitized log evidence. Test actual backup and restore into *another* disposable namespace and verify record/index counts. Later deployment requires signed Razorpay webhook, TLS, least-privilege users, backups/restore runbook, provider/notification configurations; none activated here.

**Readiness:** SOURCE-LEVEL WORK PARTIAL; production and 100% MongoDB completion NOT certified. Keep Step 2 and all later approved tasks out of scope.
