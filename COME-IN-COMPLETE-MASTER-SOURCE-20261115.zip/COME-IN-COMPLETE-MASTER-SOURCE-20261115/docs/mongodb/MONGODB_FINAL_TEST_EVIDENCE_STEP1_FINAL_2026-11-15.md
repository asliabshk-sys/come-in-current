# MongoDB Step 1 — Exact test evidence (15 Nov 2026)

| Command / evidence | Result | Kind |
|---|---|---|
| `reports/STEP1_FINAL_BASELINE_TESTS.log` | 469 PASS, 2 FAIL | Offline baseline |
| `reports/STEP1_FINAL_VALIDATED_REGRESSION.log` | 498 PASS, 2 FAIL | Expanded offline regression |
| `reports/STEP1_REFUND_ADMIN_TESTS.log` | 6 PASS | Fake DB transaction |
| `reports/STEP1_DELIVERY_PARTNER_TESTS.log` | 8 PASS | Fake DB transaction |
| `reports/STEP1_RESTORE_INDEX_TESTS.log` | 6 PASS | Script guard/fake restore |
| `reports/STEP1_REFUND_LEDGER_TESTS.log` | 20 PASS before final ledger addition | Older focused suite |
| `reports/STEP1_REFUND_LEDGER_SOURCE_CONTRACTS.log` | 14 PASS | Updated refund source assertions |
| `reports/STEP1_FINAL_DECLARED_INDEX_SPEC.json` | 51 source collections / 67 declared indexes | Source AST, no actual DB |
| Python compileall | PASS | Syntax only |
| Bash -n | PASS | Syntax only |
| `reports/STEP1_FINAL_FRONTEND_TYPESCRIPT.log` | Exit 2, missing dependency/types, 3,850 TS diagnostics | Frontend build BLOCKED |

### Two unchanged legacy frontend failures
`test_frontend_contracts.py::test_shopping_home_theme_contract_and_separate_mode_routes`: missing testID `request-anything-card`.
`test_frontend_contracts.py::test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest`: missing text `Voice search unavailable`. Source untouched; not a MongoDB change.

### Tests NOT run
`test_batch_5task_runtime.py`, `test_iter_notifications_admin_measured.py`, `test_preview_runtime_e2e.py`, `test_task5_live_mongo_transactions.py`: excluded from 73-file offline suite owing to runtime environment dependencies. Live PyMongo/Motor session, transaction commit/abort, transient error and unknown-commit tests, concurrent inserts/stock, index creation/enforcement, persistent validator enforcement, and actual MongoDB Tools backup/restore drill **NOT RUN**.

### Exact live environment status
`mongod`, `mongosh`, `mongodump`, `mongorestore`, Docker/Podman not available. Python import checks: Motor and PyMongo missing. No package download or paid service initiated. Debian 13 runtime is not assumed to be a supported MongoDB 8 replica-set host without verified compatible packages. An authorized, isolated, compatible free host is required.
