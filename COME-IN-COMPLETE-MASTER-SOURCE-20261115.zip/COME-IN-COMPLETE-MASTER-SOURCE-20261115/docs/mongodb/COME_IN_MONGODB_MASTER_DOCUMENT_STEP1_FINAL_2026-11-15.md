# COME-IN — MongoDB Master Document (Step 1 final source campaign)

**Date:** 15 November 2026  
**Authority:** source inventory and actually executed offline commands, not prior completion claims.  
**Overall outcome:** **PARTIAL / LIVE VERIFICATION BLOCKED**. This source is not certified production-ready.

## Provenance and preservation
- Input: `COME-IN-MONGODB-STEP1-SOURCE-CHECKPOINT-20261115.zip`.
- Verified SHA-256: `12c98826a73f2590d66b51bff8a9871d28825c7199d037d959ce47023e9f95af`; CRC PASS; 589 initial files.
- Isolated working copy: `/mnt/data/COME-IN-MONGODB-STEP1-FINAL-20261115`. Prior source ZIP and historical archives unchanged.
- **`.git` was absent in the checkpoint.** No original Git branch/HEAD/working tree may be inferred from this development copy.
- Historic manifests and existing README/docs preserved. The current-source checkpoint uses a newly generated manifest.
- Frontend app layout, Restaurant Mode theme/navigation and authentication contracts were not modified.

## Architecture and configuration
FastAPI Python API defined in `backend/server.py`, Pydantic request models, MongoDB documents with Motor async client, PyMongo utilities for operational scripts, Expo Router / React Native frontend. Stock for fixed-pack or measured products remains on the existing `products` document/variant, **never in a new inventory collection**. Grocery and Restaurant have distinct order/payment collections and separate carts; shared customer identity and roles preserved.

Client setup: `backend/mongo_config.py` validates `MONGO_URL`, `DB_NAME`, `APP_ENV`, `MONGO_EXPECTED_DB_NAME`, TLS and bounded connection/pool timeouts. Production explicitly requires TLS and an expected DB name, rejects insecure TLS flags. `backend/server.py` constructs `AsyncIOMotorClient` and closes it on shutdown. Source-only tests verified; no actual reconnection/failover test.

Existing driver versions in `backend/requirements.txt`: `pymongo==4.18.2`, `motor==3.7.1`. Pinned values were **not changed**.

## Collections (51 source-derived names; actual live BSON schemas not profiled)
The table is a source inventory, **not a claim that every collection is instantiated in a real MongoDB deployment**. Request models in `server.py`, `catalogue_import_engine.py` and other modules do not amount to complete database-level validators; stored legacy documents may use additional optional fields.

| Collection | Declared indexes | Schema evidence / legacy validation |
|---|---:|---|
| `addresses` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `agent_assist` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `announcements` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `assistant_rate_limits` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `auth_rate_limits` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `catalog_import_history` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `catalog_price_audit` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `catalogue_import_audit` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `catalogue_import_jobs` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `chand_feedback` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `delivery_partner_applications` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `delivery_partner_audit` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `delivery_partner_referrals` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `files` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `financial_audit` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `financial_ledger` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `grocery_payments` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `grocery_quotes` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `home_service_settings` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `home_service_slot_reservations` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `master_products` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `notifications` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `orders` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `password_resets` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `payout_bank_accounts` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `products` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `referral_audit` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `referral_ledger` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `referral_link_events` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `referral_rewards` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `referrals` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `request_anything` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurant_carts` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurant_menu` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurant_orders` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurant_payment_events` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurant_payments` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurant_reviews` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurant_support` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `restaurants` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `restock_alerts` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `retail_price_import_history` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `retail_price_offers` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `retail_price_price_audit` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `service_appointments` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `service_providers` | 1 | Source usage identified; inspect model/legacy BSON before validator |
| `settlement_order_allocations` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `settlement_requests` | 3 | Source usage identified; inspect model/legacy BSON before validator |
| `shops` | 2 | Source usage identified; inspect model/legacy BSON before validator |
| `status_checks` | 0 | Source usage identified; inspect model/legacy BSON before validator |
| `users` | 2 | Source usage identified; inspect model/legacy BSON before validator |

Canonical modeling rules: measured quantities use integer base units (g/ml), rounded per-line pricing and stock CAS; legacy pack behavior preserved. No unapproved auto merge of seller-import products. No destructive schema migrations.

## Complete index declaration register (67 specs)
Originally **65** indexed specifications were reported: 59 core plus 6 Delivery Partner. The 15 November development baseline contains **67** (61 core plus 6 Delivery Partner) after two Catalogue Import partial unique additions. `scripts/mongo/comein_mongo.py` derives specifications from startup handler AST and supports `spec`, read-only `preflight-indexes`, reviewed `init`, `verify-indexes` and health checks. `init_db` now refuses to make any collection or index mutation if a declared unique constraint has duplicate groups at preflight. **No real indexes were installed or listed during this campaign.**

| # | Collection | Ordered keys | Options |
|---:|---|---|---|
| 1 | `notifications` | `[["user_id", 1], ["created_at", -1]]` | `{}` |
| 2 | `assistant_rate_limits` | `[["rate_key", 1]]` | `{"unique": true}` |
| 3 | `assistant_rate_limits` | `[["expires_at", 1]]` | `{"expireAfterSeconds": 0}` |
| 4 | `chand_feedback` | `[["user_id", 1], ["created_at", -1]]` | `{}` |
| 5 | `chand_feedback` | `[["user_id", 1], ["request_id", 1]]` | `{"unique": true}` |
| 6 | `chand_feedback` | `[["status", 1], ["created_at", -1]]` | `{}` |
| 7 | `notifications` | `[["user_id", 1], ["read", 1]]` | `{}` |
| 8 | `auth_rate_limits` | `[["expires_at", 1]]` | `{"expireAfterSeconds": 0}` |
| 9 | `restock_alerts` | `[["product_id", 1], ["active", 1]]` | `{}` |
| 10 | `users` | `[["email", 1]]` | `{"unique": true}` |
| 11 | `users` | `[["referral_code", 1]]` | `{"unique": true, "sparse": true}` |
| 12 | `referrals` | `[["referred_user_id", 1]]` | `{"unique": true}` |
| 13 | `referrals` | `[["referrer_id", 1], ["status", 1]]` | `{}` |
| 14 | `referrals` | `[["qualifying_order_id", 1]]` | `{"unique": true, "partialFilterExpression": {"qualifying_order_id": {"$type": "string"}}}` |
| 15 | `referral_rewards` | `[["reward_key", 1]]` | `{"unique": true}` |
| 16 | `referral_rewards` | `[["referrer_id", 1], ["status", 1]]` | `{}` |
| 17 | `referral_ledger` | `[["idempotency_key", 1]]` | `{"unique": true, "sparse": true}` |
| 18 | `referral_ledger` | `[["user_id", 1], ["created_at", -1]]` | `{}` |
| 19 | `referral_audit` | `[["created_at", -1]]` | `{}` |
| 20 | `referral_link_events` | `[["referrer_id", 1], ["created_at", -1]]` | `{}` |
| 21 | `payout_bank_accounts` | `[["beneficiary_type", 1], ["beneficiary_id", 1]]` | `{"unique": true}` |
| 22 | `settlement_requests` | `[["beneficiary_user_id", 1], ["created_at", -1]]` | `{}` |
| 23 | `settlement_requests` | `[["beneficiary_user_id", 1], ["beneficiary_type", 1], ["beneficiary_id", 1], ["idempotency_key", 1]]` | `{"unique": true}` |
| 24 | `settlement_requests` | `[["status", 1], ["created_at", -1]]` | `{}` |
| 25 | `settlement_order_allocations` | `[["order_key", 1]]` | `{"unique": true}` |
| 26 | `settlement_order_allocations` | `[["settlement_id", 1]]` | `{}` |
| 27 | `financial_audit` | `[["created_at", -1]]` | `{}` |
| 28 | `financial_ledger` | `[["idempotency_key", 1]]` | `{"unique": true}` |
| 29 | `financial_ledger` | `[["beneficiary_user_id", 1], ["recorded_at", -1]]` | `{}` |
| 30 | `financial_ledger` | `[["order_id", 1], ["recorded_at", -1]]` | `{}` |
| 31 | `shops` | `[["owner_id", 1]]` | `{}` |
| 32 | `shops` | `[["status", 1]]` | `{}` |
| 33 | `products` | `[["shop_id", 1]]` | `{}` |
| 34 | `products` | `[["owner_id", 1]]` | `{}` |
| 35 | `products` | `[["catalogue_import_job_id", 1], ["catalogue_import_record_index", 1]]` | `{"unique": true, "partialFilterExpression": {"catalogue_import_job_id": {"$type": "string"}, "catalogue_import_record_index": {"$type": "int"}}}` |
| 36 | `catalogue_import_audit` | `[["apply_key", 1]]` | `{"unique": true, "partialFilterExpression": {"apply_key": {"$type": "string"}}}` |
| 37 | `orders` | `[["customer_id", 1]]` | `{}` |
| 38 | `orders` | `[["shop_id", 1]]` | `{}` |
| 39 | `orders` | `[["grocery_idempotency_scope", 1]]` | `{"unique": true, "sparse": true}` |
| 40 | `grocery_quotes` | `[["expires_at", 1]]` | `{"expireAfterSeconds": 0}` |
| 41 | `grocery_quotes` | `[["scope", 1], ["status", 1]]` | `{}` |
| 42 | `files` | `[["owner_id", 1]]` | `{}` |
| 43 | `restaurants` | `[["owner_id", 1]]` | `{}` |
| 44 | `restaurants` | `[["status", 1], ["available", 1], ["city", 1]]` | `{}` |
| 45 | `restaurant_menu` | `[["restaurant_id", 1], ["available", 1]]` | `{}` |
| 46 | `addresses` | `[["user_id", 1], ["is_default", -1]]` | `{}` |
| 47 | `restaurant_orders` | `[["customer_id", 1], ["created_at", -1]]` | `{}` |
| 48 | `restaurant_orders` | `[["restaurant_id", 1], ["created_at", -1]]` | `{}` |
| 49 | `restaurant_orders` | `[["customer_id", 1], ["idempotency_key", 1]]` | `{"unique": true}` |
| 50 | `restaurant_payments` | `[["gateway_order_id", 1]]` | `{"unique": true, "sparse": true}` |
| 51 | `restaurant_payment_events` | `[["event_id", 1]]` | `{"unique": true, "sparse": true}` |
| 52 | `restaurant_reviews` | `[["restaurant_id", 1], ["customer_id", 1]]` | `{"unique": true}` |
| 53 | `password_resets` | `[["expires_at", 1]]` | `{"expireAfterSeconds": 0}` |
| 54 | `restaurant_support` | `[["user_id", 1], ["created_at", -1]]` | `{}` |
| 55 | `restaurant_support` | `[["user_id", 1], ["request_id", 1]]` | `{"unique": true, "partialFilterExpression": {"request_id": {"$type": "string"}}}` |
| 56 | `restaurant_carts` | `[["user_id", 1]]` | `{"unique": true}` |
| 57 | `service_providers` | `[["owner_id", 1]]` | `{"unique": true, "sparse": true}` |
| 58 | `service_appointments` | `[["customer_id", 1], ["created_at", -1]]` | `{}` |
| 59 | `service_appointments` | `[["provider_id", 1], ["created_at", -1]]` | `{}` |
| 60 | `home_service_slot_reservations` | `[["provider_id", 1], ["slot_key", 1]]` | `{"unique": true}` |
| 61 | `home_service_settings` | `[["key", 1]]` | `{"unique": true}` |
| 62 | `delivery_partner_applications` | `[["user_id", 1]]` | `{"unique": true}` |
| 63 | `delivery_partner_applications` | `[["referral_code", 1]]` | `{"unique": true, "sparse": true}` |
| 64 | `delivery_partner_applications` | `[["status", 1], ["updated_at", -1]]` | `{}` |
| 65 | `delivery_partner_audit` | `[["application_id", 1], ["created_at", -1]]` | `{}` |
| 66 | `delivery_partner_referrals` | `[["referred_application_id", 1]]` | `{"unique": true}` |
| 67 | `delivery_partner_referrals` | `[["referrer_application_id", 1], ["created_at", -1]]` | `{}` |

## Database schema validators and legacy profiling
The only source-defined strict validator is for the **new** `catalogue_import_audit` collection (`scripts/mongo/catalogue_audit_validator.py`); `--apply` is guarded by APP_ENV=test, disposable DB name and unauthenticated localhost URI. Not applied to MongoDB. Legacy Product/order/payment/job schema validators **must not be installed** until a real disposable copy has been profiled. `scripts/mongo/legacy_profile_disposable.py` is a read-only, privacy-preserving profile of collection/doc counts, missing or invalid Product stock, and duplicate groups; guarded by explicit local/test/DB confirmation. Profile command not run because drivers/server absent.

## Sessions, transactions, retries and uncertain commits
`backend/mongo_transactions.py:run_transaction` uses Motor `session.with_transaction(callback)`. Every old manual `session.start_transaction()` scope in `server.py` was migrated to DB-only callback execution (10 conversions). Conversion preserves session-bound operations, returns and authorization/stock checks. No irreversible provider call is inside a transaction callback. The project now has **20 endpoint/helper transaction flows** using `run_transaction`:

- `_maybe_create_referral_reward`
- `admin_review_referral`
- `admin_update_referral_reward`
- `_apply_catalogue_import_job_transactionally`
- `import_shop_products`
- `admin_retail_price_import`
- `create_order`
- `_cancel_grocery_order`
- `request_shop_settlement`
- `request_restaurant_settlement`
- `admin_settlement_decision`
- `_commit_restaurant_capture`
- `_mark_restaurant_payment_failed`
- `_claim_restaurant_refund_for_gateway`
- `_apply_restaurant_refund_webhook_transactionally`
- `_persist_restaurant_admin_refund_state`
- `_mark_grocery_paid`
- `save_delivery_partner_application`
- `submit_delivery_partner_application`
- `admin_decide_delivery_partner_application`

- Driver callback retries on `TransientTransactionError` and retries commit on `UnknownTransactionCommitResult` are delegated to Motor/PyMongo. No unbounded custom retry loop was added.
- Grocery order unknown commit performs idempotency-key read to avoid recreating already committed orders; conditional stock decrement, quote claim and reward debit remain inside one transaction.
- Grocery cancel restocks once atomically with order status, and no after-abort stock restoration is attempted.
- Settlement requests use unique idempotency/allocated-order checks; approval/audit mutations use the same transaction.
- Referral rewards and reviews use session-bound writes and duplicate-key checks.
- The new tests prove *fake-driver* rollback/retry behavior, not replica-set behavior.

## Catalogue Import
Seller review and staging are unchanged: confirm-apply validates `ProductIn` and `_import_measure`, verifies seller/shop ownership within transaction, inserts Products with `available: false`, initial stock in Product document, provenance filename/SHA, job/record identity and audit, then APPLIED state together. Duplicate import prevented with partial unique job/record indexes and reconciliation. No unsupported SKU merging/overwriting, no separate stock collection. Previous offline tests preserved; real rollback/concurrency and index enforcement remain BLOCKED.

## Grocery orders/payments/inventory
Quote claim, stock compare-and-set decrement, order insert and optional approved reward debit remain in a driver-retried callback; order notification occurs after commit. Payment capture is transactional and verifies provider evidence. Unknown commit is reconciled against unique checkout scope. A standalone MongoDB deployment must fail closed (do not silently run nontransactional checkout). Measured quantities use integer base units, server-side quote totals, minimum/step/maximum rules and separate Restaurant isolation.

## Restaurant payment, refund and financial integrity
Restaurant captured/failed payment, order state and refund claim use DB-only callbacks. Signed refund webhook and Restaurant Admin Refund post-provider state updates now update payment and order atomically. On a completed provider refund, the **financial ledger reversal** (when the original finalized ledger exists) runs with the same transaction via `_record_refund_reversal(..., session=session)`; failure aborts payment/order updates. The external Razorpay request remains **outside** the callback and is never replayed to fix a database error. Late/webhook updates cannot downgrade already completed refunds. Partial earlier refund history may require manual reconciliation. Only provider-confirmed completion triggers ledger reversal. No actual provider or live Mongo transaction tested.

## Delivery Partner DB authorization and consistency
Encrypted draft fields remain stored as encrypted text; public projections exclude PII. Role checks separate admin, seller and customer. Application draft+audit, verified submission+audit, and admin approval+audit+referral record now commit together; each callback checks current owner/status and verification requirements in session. OTP, Aadhaar/PAN and document adapters intentionally fail closed until verified vendors are integrated. These are provider dependencies; never simulate verification or grant access merely from environment configuration. No live RBAC or encryption storage acceptance test yet.

## Backup and recovery
- `scripts/backup-db.sh`: unique no-clobber private archive directory, MongoDB Tools config 0600, gzip `mongodump`, SHA-256 sidecar.
- `scripts/restore-db.sh`: APP_ENV=test, distinct disposable source/target, exact confirmation, unauthenticated localhost Mongo URI; requires empty destination, does not use `--drop`. Check archive sidecar, restore via MongoDB Tools, compare collection names/document counts/index definitions with `scripts/mongo/verify_disposable_restore.py` and verify all declared source indexes.
- Tests of safety guards and mock scripts passed. **No actual mongodump or mongorestore happened.** A successful script run on a real disposable replica set is required before declaring recovery VERIFIED.
- Relationship anomalies and BSON field compatibility cannot be inferred from document counts; profile and sample schema acceptance are still needed.

## Security
Configuration forbids insecure production TLS, URI values excluded from known diagnostics; no production credentials, production data or paid services were used. Sensitive Delivery Partner fields encrypted before database persistence; other tenant authorization is checked at endpoints. Least-privileged MongoDB roles, live TLS, actual DB permissions, real driver behavior, secrets rotation, and native privacy/document verification remain BLOCKED/UNVERIFIED. Any logger output containing sensitive information must be reviewed before launch.

## Full current HTTP API source inventory (177 declared routes)
These declarations show route/method/function **as present in code**, not proof that runtime FastAPI mounting or integration tests completed.

| Method | Route path | Function |
|---|---|---|
| `GET` | `/` | `root` |
| `POST` | `/status` | `create_status_check` |
| `GET` | `/status` | `list_status_checks` |
| `POST` | `/auth/register` | `register` |
| `POST` | `/auth/login` | `login` |
| `GET` | `/referrals/me` | `referral_dashboard` |
| `POST` | `/referrals/home-banner-claim` | `claim_first_home_referral_banner` |
| `GET` | `/referral/validate` | `validate_referral` |
| `GET` | `/referral` | `open_referral` |
| `GET` | `/admin/referrals` | `admin_referrals` |
| `PATCH` | `/admin/referrals/{referral_id}/review` | `admin_review_referral` |
| `PATCH` | `/admin/referral-rewards/{reward_id}` | `admin_update_referral_reward` |
| `GET` | `/auth/me` | `me` |
| `PATCH` | `/auth/me` | `update_me` |
| `POST` | `/auth/password/forgot` | `forgot_password` |
| `POST` | `/auth/password/reset` | `reset_password` |
| `POST` | `/uploads/image` | `upload_image` |
| `GET` | `/uploads/{storage_path:path}` | `serve_upload` |
| `POST` | `/shops` | `create_shop` |
| `GET` | `/shops/mine` | `my_shop` |
| `PATCH` | `/shops/{shop_id}` | `update_shop` |
| `PATCH` | `/shops/{shop_id}/availability` | `set_shop_availability` |
| `GET` | `/shops` | `list_shops` |
| `GET` | `/shops/{shop_id}` | `get_shop` |
| `POST` | `/chand/feedback` | `submit_chand_feedback` |
| `GET` | `/chand/feedback/mine` | `my_chand_feedback` |
| `GET` | `/admin/chand/feedback` | `admin_chand_feedback` |
| `GET` | `/admin/chand/feedback/summary` | `admin_chand_feedback_summary` |
| `PATCH` | `/admin/chand/feedback/{feedback_id}` | `admin_update_chand_feedback` |
| `POST` | `/assistant/context` | `assistant_context` |
| `GET` | `/assistant/health` | `assistant_health` |
| `POST` | `/assistant/transcribe` | `assistant_transcribe` |
| `POST` | `/assistant/vision` | `assistant_vision` |
| `POST` | `/admin/master-products` | `create_master_product` |
| `GET` | `/catalog/master-products` | `search_master_products` |
| `POST` | `/shops/{shop_id}/master-products/{master_product_id}/link` | `link_master_product` |
| `POST` | `/shops/{shop_id}/products` | `create_product` |
| `POST` | `/shops/{shop_id}/catalogue-import/jobs` | `create_catalogue_import_job` |
| `GET` | `/shops/{shop_id}/catalogue-import/jobs/{job_id}` | `get_catalogue_import_job` |
| `GET` | `/shops/{shop_id}/catalogue-import/jobs` | `list_catalogue_import_jobs` |
| `GET` | `/shops/{shop_id}/catalogue-import/categories` | `list_catalogue_import_categories` |
| `PATCH` | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}` | `edit_catalogue_import_record` |
| `POST` | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/approve` | `approve_catalogue_import_record` |
| `POST` | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/reject` | `reject_catalogue_import_record` |
| `POST` | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/bulk-approve` | `bulk_approve_catalogue_import_records` |
| `POST` | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/confirm-apply` | `confirm_catalogue_import_apply` |
| `POST` | `/shops/{shop_id}/products/import` | `import_shop_products` |
| `GET` | `/shops/{shop_id}/products/import-template` | `shop_product_import_template` |
| `GET` | `/admin/catalog-import-history` | `admin_catalog_import_history` |
| `GET` | `/admin/catalog-price-audit` | `admin_catalog_price_audit` |
| `GET` | `/catalog/price-comparison` | `compare_master_product_prices` |
| `GET` | `/admin/retail-price-import/template` | `retail_price_import_template` |
| `POST` | `/admin/retail-price-import` | `admin_retail_price_import` |
| `GET` | `/catalog/retail-prices` | `public_retail_prices` |
| `GET` | `/admin/retail-price-import/history` | `admin_retail_price_import_history` |
| `GET` | `/shops/{shop_id}/products` | `list_shop_products` |
| `GET` | `/catalog/products` | `list_catalog_products` |
| `PATCH` | `/products/{product_id}` | `update_product` |
| `DELETE` | `/products/{product_id}` | `delete_product` |
| `POST` | `/grocery/measured-price` | `measured_price` |
| `POST` | `/grocery/quotes` | `create_grocery_quote` |
| `POST` | `/orders` | `create_order` |
| `POST` | `/orders/{order_id}/confirm-upi-payment` | `confirm_grocery_upi_payment` |
| `GET` | `/orders/mine` | `my_orders` |
| `POST` | `/orders/{order_id}/cancel` | `cancel_grocery_order` |
| `GET` | `/shops/{shop_id}/orders` | `shop_orders` |
| `PATCH` | `/orders/{order_id}/status` | `update_order_status` |
| `GET` | `/orders/{order_id}` | `get_grocery_order_details` |
| `GET` | `/orders/{order_id}/tracking` | `get_order_tracking` |
| `POST` | `/orders/{order_id}/tracking/location` | `update_order_tracking_location` |
| `POST` | `/requests/anything` | `submit_request_anything` |
| `GET` | `/requests/anything/mine` | `my_requests_anything` |
| `POST` | `/requests/assist` | `submit_agent_assist` |
| `GET` | `/admin/announcements` | `admin_announcements` |
| `POST` | `/admin/announcements` | `create_announcement` |
| `PATCH` | `/admin/announcements/{announcement_id}` | `set_announcement_active` |
| `GET` | `/admin/dashboard` | `admin_dashboard` |
| `GET` | `/announcements/active` | `active_announcements` |
| `GET` | `/admin/users` | `admin_users` |
| `PATCH` | `/admin/users/{user_id}/role` | `admin_update_user_role` |
| `GET` | `/admin/shops` | `admin_shops` |
| `PATCH` | `/admin/shops/{shop_id}/status` | `admin_set_shop_status` |
| `GET` | `/admin/orders` | `admin_orders` |
| `POST` | `/earnings/orders/{kind}/{order_id}/cash-collected` | `confirm_manual_cash_collection` |
| `GET` | `/admin/earnings` | `admin_earnings` |
| `GET` | `/admin/earnings/ledger` | `admin_earnings_ledger` |
| `GET` | `/admin/earnings/transactions` | `admin_earnings_transactions` |
| `GET` | `/earnings/mine` | `shopkeeper_earnings` |
| `GET` | `/admin/earnings/bank-account` | `admin_platform_bank_account` |
| `PUT` | `/admin/earnings/bank-account` | `save_admin_platform_bank_account` |
| `GET` | `/shops/{shop_id}/bank-account` | `get_shop_bank_account` |
| `PUT` | `/shops/{shop_id}/bank-account` | `save_shop_bank_account` |
| `GET` | `/restaurants/{restaurant_id}/bank-account` | `get_restaurant_bank_account` |
| `PUT` | `/restaurants/{restaurant_id}/bank-account` | `save_restaurant_bank_account` |
| `PATCH` | `/admin/financial-policy/{kind}/{entity_id}` | `admin_set_financial_policy` |
| `GET` | `/admin/earnings/settlements` | `admin_settlement_list` |
| `POST` | `/shops/{shop_id}/settlements` | `request_shop_settlement` |
| `POST` | `/restaurants/{restaurant_id}/settlements` | `request_restaurant_settlement` |
| `PATCH` | `/admin/earnings/settlements/{settlement_id}` | `admin_settlement_decision` |
| `GET` | `/admin/requests/anything` | `admin_requests_anything` |
| `GET` | `/admin/requests/assist` | `admin_agent_assist` |
| `PATCH` | `/admin/requests/anything/{req_id}/status` | `admin_update_request` |
| `PATCH` | `/admin/requests/assist/{req_id}/status` | `admin_update_assist` |
| `GET` | `/restaurants` | `list_restaurants` |
| `GET` | `/restaurants/mine` | `my_restaurants` |
| `POST` | `/restaurants` | `create_restaurant` |
| `GET` | `/restaurants/{restaurant_id}` | `restaurant_detail` |
| `GET` | `/restaurants/{restaurant_id}/serviceability` | `restaurant_delivery_serviceability` |
| `PATCH` | `/restaurants/{restaurant_id}` | `update_restaurant` |
| `PATCH` | `/restaurants/{restaurant_id}/availability` | `restaurant_availability` |
| `GET` | `/restaurants/{restaurant_id}/menu` | `restaurant_menu` |
| `POST` | `/restaurants/{restaurant_id}/menu` | `create_menu_item` |
| `PATCH` | `/restaurants/{restaurant_id}/menu/{item_id}` | `update_menu_item` |
| `DELETE` | `/restaurants/{restaurant_id}/menu/{item_id}` | `delete_menu_item` |
| `GET` | `/addresses` | `list_addresses` |
| `POST` | `/addresses` | `create_address` |
| `PATCH` | `/addresses/{address_id}` | `update_address` |
| `DELETE` | `/addresses/{address_id}` | `delete_address` |
| `GET` | `/restaurant/cart` | `get_restaurant_cart` |
| `PUT` | `/restaurant/cart` | `save_restaurant_cart` |
| `DELETE` | `/restaurant/cart` | `clear_restaurant_cart` |
| `POST` | `/restaurant/orders` | `create_restaurant_order` |
| `GET` | `/restaurant/orders/mine` | `my_restaurant_orders` |
| `GET` | `/restaurants/{restaurant_id}/orders` | `restaurant_orders` |
| `PATCH` | `/restaurant/orders/{order_id}/status` | `update_restaurant_order_status` |
| `POST` | `/restaurant/orders/{order_id}/cancel` | `cancel_restaurant_order` |
| `GET` | `/restaurant/payments/config` | `restaurant_payment_config` |
| `POST` | `/restaurant/orders/{order_id}/payment-intent` | `create_restaurant_payment_intent` |
| `POST` | `/restaurant/orders/{order_id}/payment-retry` | `retry_restaurant_payment` |
| `POST` | `/restaurant/payments/verify` | `verify_restaurant_payment` |
| `POST` | `/restaurant/payments/razorpay-webhook` | `razorpay_webhook` |
| `POST` | `/restaurants/{restaurant_id}/reviews` | `create_restaurant_review` |
| `POST` | `/restaurant/support` | `create_restaurant_support` |
| `GET` | `/restaurant/support/mine` | `my_restaurant_support` |
| `GET` | `/seller/support` | `seller_order_support` |
| `PATCH` | `/seller/support/{ticket_id}` | `seller_update_order_support` |
| `GET` | `/admin/restaurant/support` | `admin_restaurant_support` |
| `PATCH` | `/admin/restaurant/support/{ticket_id}` | `admin_update_restaurant_support` |
| `POST` | `/admin/restaurant/orders/{order_id}/refund` | `admin_refund_restaurant_order` |
| `GET` | `/admin/restaurant/orders` | `admin_restaurant_orders` |
| `GET` | `/admin/restaurants` | `admin_restaurants` |
| `PATCH` | `/admin/restaurants/{restaurant_id}/status` | `admin_restaurant_status` |
| `GET` | `/home-services/fee-policy` | `get_home_service_fee_policy` |
| `PATCH` | `/admin/home-services/fee-policy` | `set_home_service_fee_policy` |
| `GET` | `/home-services/providers` | `list_service_providers` |
| `GET` | `/home-services/providers/mine` | `my_service_provider` |
| `POST` | `/home-services/providers` | `register_service_provider` |
| `PATCH` | `/home-services/providers/{provider_id}` | `update_service_provider` |
| `PATCH` | `/home-services/providers/{provider_id}/photo` | `update_service_provider_photo` |
| `POST` | `/home-services/appointments` | `create_service_appointment` |
| `GET` | `/home-services/appointments/mine` | `my_service_appointments` |
| `GET` | `/home-services/appointments/provider` | `provider_service_appointments` |
| `PATCH` | `/home-services/appointments/{appointment_id}/status` | `update_service_appointment` |
| `GET` | `/admin/home-services/providers` | `admin_service_providers` |
| `PATCH` | `/admin/home-services/providers/{provider_id}/approval` | `admin_approve_service_provider` |
| `GET` | `/grocery/payments/config` | `grocery_payment_config` |
| `POST` | `/orders/{order_id}/payment-intent` | `create_grocery_payment_intent` |
| `POST` | `/grocery/payments/verify` | `verify_grocery_payment` |
| `GET` | `/notifications/mine` | `my_notifications` |
| `GET` | `/notifications/unread-count` | `my_unread_notifications` |
| `POST` | `/notifications/read-all` | `read_all_notifications` |
| `POST` | `/notifications/{notification_id}/read` | `read_notification` |
| `GET` | `/products/{product_id}/restock-alert` | `restock_alert_status` |
| `POST` | `/products/{product_id}/restock-alert` | `subscribe_restock_alert` |
| `DELETE` | `/products/{product_id}/restock-alert` | `unsubscribe_restock_alert` |
| `GET` | `/delivery-partner/provider-status` | `delivery_partner_provider_status` |
| `POST` | `/delivery-partner/otp/request` | `delivery_partner_otp_request` |
| `POST` | `/delivery-partner/otp/verify` | `delivery_partner_otp_verify` |
| `POST` | `/delivery-partner/identity/start` | `delivery_partner_identity_start` |
| `PUT` | `/delivery-partner/application` | `save_delivery_partner_application` |
| `POST` | `/delivery-partner/application/submit` | `submit_delivery_partner_application` |
| `GET` | `/delivery-partner/application/mine` | `my_delivery_partner_application` |
| `GET` | `/delivery-partner/referral` | `delivery_partner_referral` |
| `GET` | `/delivery-partner/admin/applications` | `admin_delivery_partner_applications` |
| `GET` | `/delivery-partner/admin/applications/{application_id}` | `admin_delivery_partner_application_detail` |
| `PATCH` | `/delivery-partner/admin/applications/{application_id}` | `admin_decide_delivery_partner_application` |
| `GET` | `/delivery-partner/access` | `delivery_partner_access` |

## Actual test and deployment state
- Original isolated checkpoint baseline rerun: **469 PASS / 2 FAIL** on 69 selected runnable files; same 2 pre-existing Home UI assertion failures.
- Expanded final offline regression: **498 PASS / 2 FAIL** on 73 selected offline-runnable files. Four runtime/live modules excluded due unavailable environment dependencies.
- Backend `compileall` and backup/restore/mongo Bash syntax: PASS. Spec extraction: 51 collections / 67 indexes.
- Expo/React Native dependencies (`frontend/node_modules`) absent. TypeScript command returned code 2 with missing module/types; NOT a verified frontend build.
- Missing `mongod`, `mongosh`, `mongodump`, `mongorestore`, Docker, Podman, Motor and PyMongo; no compatible network package repository or wheels available in this environment. **Zero live replica-set, transaction, validator enforcement, index creation, or actual restore-drill tests.**

## Safe next actions (remain within approved Step 1)
1. Make a free, compatible isolated local replica-set environment available with actual MongoDB server, PyMongo/Motor and Database Tools. Never use production hosts.
2. Profile a disposable database and run read-only index duplicate preflight. Review duplicate groups and legacy fields. Do not delete/merge records.
3. Apply/create 67 indexes only after preflight; run verify-indexes, validator migration with confirmed disposable target; test validator enforcement.
4. Run live Catalogue retry/double-apply, Grocery/Restaurant stock races, unknown-commit fault injection, refund ledger rollback and Delivery Partner authorization; collect real test logs.
5. Run private test database backup, restore into fresh empty disposable DB, compare collection names/counts/indexes and business relationships; rehearse restart/outage recovery.
6. Update evidence and checkpoint, then request authorization before Step 2. **Do not start Step 2 now.**
