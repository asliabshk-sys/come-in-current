# COME-IN MongoDB Step 1 — Completion and Evidence Report (15 Nov 2026)

**Campaign classification: PARTIAL (source progress with live infrastructure BLOCKED).** Do not report 100% complete.

## Baseline and non-destructive preservation
Recovered checkpoint SHA-256 `72b32dbd5673a2bfd166355ca1e3203d5004cc2c24bdccefad7c2a5f59f40132`; baseline 681 files; copied to `/mnt/data/COME-IN-MONGODB-STEP1-DEV-20261115`; source `.git` absent. Historical 14 and 22 manifest mismatches not overwritten. Bounded search of four existing ZIP archives found **zero** copies of `_apply_catalogue_import_job_transactionally`. No older sources substituted and no db migrations/production operations run.

## Completion matrix (15 scoped areas)

Only **COMPLETED**, **PARTIAL** or **BLOCKED** represent actual verification stages. Source-only success is PARTIAL when live evidence required.

| # | Area | Status | Evidence and pending dependency |
|---:|---|---|---|
| 1 | Connection / TLS / timeouts / startup / shutdown | **PARTIAL** | mongo_config.py, server.py startup; offline config tests; no live MongoDB |
| 2 | Collection and model inventory | **PARTIAL** | 51 source-derived names; no BSON sample/profile |
| 3 | Indexes / duplicate preflight | **PARTIAL** | 65 original specifications preserved plus 2 new partial unique; fake index tests; live preflight blocked |
| 4 | Sessions / transaction lifecycle | **PARTIAL** | 10 original manual scopes plus 3 new driver callbacks; no real replica-set test |
| 5 | Unknown commit / transient retry | **PARTIAL** | Motor with_transaction used for Catalogue, Grocery capture and Restaurant capture/fail/refund claim; other manual flows lack generalized retries |
| 6 | Idempotency / concurrency | **PARTIAL** | Catalogue import per-record unique keys, job claim and shop document fence; fake fault-injection; live race tests missing |
| 7 | Persistent schema validators | **PARTIAL** | New audit-only $jsonSchema migration script in plan/disposable-test mode; existing collection validators blocked on data profiling |
| 8 | Catalogue Import apply | **PARTIAL** | Atomic seller-approved Product writes with unavailable initial state; 7+ fake fault-injection tests; no live Mongo |
| 9 | Grocery payment / stock | **PARTIAL** | Existing checkout stock CAS preserved; captured payment moved to driver transaction; no live gateway/replica-set |
| 10 | Restaurant payment / refund | **PARTIAL** | Captured and failed payment + refund claim are atomic source callbacks; signed refund webhook now transactionally updates both documents (8 focused fake-driver tests); admin post-provider persistence still has multi-write gaps |
| 11 | Delivery partner MongoDB workflows | **PARTIAL** | Existing 6 index declarations and source preserved; no runtime authorization test |
| 12 | Backup / restore | **PARTIAL** | No-clobber unique backup destination; mocked script safety pass; actual mongodump/restore missing |
| 13 | Security / privacy | **PARTIAL** | Authenticated shop-scoped import, URI redaction/config guard, no production credentials; live RBAC/TLS/index role check missing |
| 14 | Full frontend / backend regression | **PARTIAL** | 477 passed, 2 pre-existing UI contract fails; 4 runtime modules not collected; TS dependency resolution unavailable |
| 15 | Live MongoDB replica-set verification | **BLOCKED** | mongod/mongosh/mongodump/mongorestore, Motor/PyMongo unavailable |

## Existing code modifications (original paths)
- `M` `backend/mongo_transactions.py`
- `M` `backend/server.py`
- `M` `backend/tests/test_catalogue_import_workflow_contract.py`
- `M` `backend/tests/test_chand_demo_contract.py`
- `M` `backend/tests/test_functional_blockers_regression.py`
- `M` `backend/tests/test_grocery_checkout_security_contract.py`
- `M` `backend/tests/test_mongo_portability_tool.py`
- `M` `backend/tests/test_mongo_transactions.py`
- `M` `backend/tests/test_restaurant_api_contract.py`
- `M` `backend/tests/test_shared_system_integration_contract.py`
- `M` `backend/tests/test_task10_payment_refund_notification_contract.py`
- `M` `backend/tests/test_task18_refund_safety_iteration3.py` (updated source-location assertions after atomic refund webhook refactor)
- `M` `scripts/backup-db.sh`

## New source and test files at audit time
- `A` `backend/tests/test_catalogue_transaction_apply_offline.py`
- `A` `backend/tests/test_mongo_backup_safety_offline.py`
- `A` `backend/tests/test_grocery_capture_transaction_offline.py`
- `A` `backend/tests/test_restaurant_capture_transaction_offline.py`
- `A` `backend/tests/test_restaurant_refund_webhook_transaction_offline.py`
- `A` `backend/tests/test_catalogue_validator_migration.py`
- `A` `scripts/mongo/catalogue_audit_validator.py`

## Exact commands and actual outcomes
- `PYTHONPATH=$PWD:$PWD/backend pytest -c /dev/null -q backend/tests/test_mongo_config.py backend/tests/test_mongo_transactions.py backend/tests/test_catalogue_import_job_api_contract.py backend/tests/test_catalogue_import_workflow_contract.py backend/tests/test_mongo_portability_tool.py` → **37 PASS** before edits. Standard project config could not launch (`pytest-xdist` not installed); using explicit alternative config did not change source.
- `PYTHONPATH=$PWD:$PWD/backend pytest -c /dev/null -q backend/tests/test_*.py` → **COLLECTION ERROR** (3 API/UI runtime modules require `/app/frontend/.env`, 1 live test requires BSON, unavailable); no tests in that run passed.
- `PYTHONPATH=$PWD:$PWD/backend pytest -c /dev/null -q $(cat /mnt/data/COME-IN-MONGODB-STEP1-DEV-20261115.FINAL-SAFE-TEST-LIST.txt)` (conceptual equivalent of bash `mapfile` and explicit arguments) → **477 passed, 2 failed** across 70 offline-runnable modules, 4 excluded environment-dependent files. Log `reports/MONGODB_STEP1_OFFLINE_TEST_RUN_2026-11-15.log` (v3 post-refund fix).
- Failures: `test_frontend_contracts.py::test_shopping_home_theme_contract_and_separate_mode_routes` missing `testID="request-anything-card"`; `test_frontend_contracts.py::test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest` missing `Voice search unavailable`. The same 2 failures reproduced **on the untouched original read-only recovery**: 17 passed, 2 failed. No frontend changes were made.
- `python -m compileall -q backend scripts/mongo` → compile check; final confirmation log in evidence appendix. `bash -n scripts/backup-db.sh scripts/restore-db.sh scripts/mongo/setup.sh scripts/mongo/start-replset.sh` → syntax checked.
- `python scripts/mongo/catalogue_audit_validator.py` → plan-only JSON, no DB access.
- `tsc -p frontend/tsconfig.json --noEmit --pretty false` → **failed**, missing Expo/React Native/TypeScript base types and compiler config dependencies; output log saved; no dependency installs or network retries.
- MongoDB external binaries and Motor/PyMongo imports: **not installed**. No successful live MongoDB transaction or real restore test. Local staging fake database tests are *not* a substitute.

## Remaining source tasks (not hidden by live blocker)
1. Convert or characterize ten older manual transaction scopes and robustly handle ambiguous outcomes without duplicate external side effects.
2. Signed Restaurant refund processed/failed webhook now updates payment and order atomically via driver-managed callback (8 focused fake-driver tests). Admin post-provider refund persistence and ledger reconciliation remain multi-write paths; live testing and further focused source work are required before claiming complete consistency.
3. Profile legacy BSON documents and duplicate keys before actual index migration and validators. Validate cross-seller and identity/PII security with real authorized sessions.
4. Actual local disposable replica-set tests, index create/list/read, `$jsonSchema` install and reject, backup and restore, concurrency and crash recovery remain BLOCKED by missing tools/runtime.
5. Two pre-existing frontend contract failures and missing TS dependency tree are separately reported, **not** fixed in MongoDB Step 1.

## Scope preserved
No Code edits to frontend, Restaurant UI/theme/navigation, auth schema or unrelated features. Only MongoDB-dependent business writes/source-only tests, restoration scripts and documentation updated. No source ZIP overwrites, Git destructive ops, paid APIs, live Razorpay calls or production credentials. The next approved project step is **Step 2 Source ZIP Safety**, NOT started and NOT yet authorized.

## Final additional source fix — signed Restaurant refund webhook

The signed `refund.processed`/`refund.failed` path now delegates payment + order refund state to `_apply_restaurant_refund_webhook_transactionally`. It uses a database-only callback under Motor `with_transaction`, preserves prior provider-confirmed completed state against late failed/pending events, refuses inconsistent refund amounts, flags both records for reconciliation on malformed refund history, and performs any idempotent financial ledger reversal **after commit**. The webhook event row is still persisted separately and therefore requires live duplicate/ordering verification. Fake session tests: **8 PASS**; real MongoDB integration remains BLOCKED. `backend/tests/test_task18_refund_safety_iteration3.py` asserts the replacement transaction helper and both writes. The narrower Restaurant admin post-provider persistence remains PARTIAL.
