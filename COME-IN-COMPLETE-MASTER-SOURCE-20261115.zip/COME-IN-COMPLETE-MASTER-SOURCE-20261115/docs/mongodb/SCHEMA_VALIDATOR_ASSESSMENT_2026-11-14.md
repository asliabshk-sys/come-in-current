# COME-IN MongoDB Schema Validator Assessment — 2026-11-14

## Scope and evidence

This is a source-based assessment of the extracted COME-IN archive. It is not a live database profile. The current source references 50 application collections and 65 explicit non-`_id` index declarations. `docs/mongodb/SCHEMA_AND_VALIDATION.md` states that no server-side `$jsonSchema` validators are configured; source inspection found no `collMod` or collection validator setup in startup or portability initialization.

Pydantic request models and endpoint-level business validation exist, but they do not constrain every internal write path, imported record, background operation, or future direct database writer. MongoDB validators could therefore provide defense in depth. They must not be introduced until representative existing documents have been profiled against the proposed schema.

## Collection assessment

| Priority | Collections | Assessment | Safe validator direction |
|---|---|---|---|
| P0 — financial integrity | `financial_ledger`, `settlement_requests`, `settlement_order_allocations`, `grocery_payments`, `restaurant_payments`, `restaurant_payment_events` | High-value money, allocation and payment-event records. Existing unique indexes provide idempotency but do not validate required field types or allowed status/value domains. | Consider minimal required-field/type validators and narrowly scoped enums. Preserve shop/restaurant variants and legacy optional fields. Profile every existing record first. |
| P1 — identity and inventory | `users`, `shops`, `products`, `orders`, `restaurant_orders`, `restaurants`, `restaurant_menu` | Core records with meaningful invariants, but broad legacy and mode-specific shapes. Product documents support fixed-pack, measured, variants and import metadata; orders have multiple payment and fulfillment states. | Use permissive validators for stable required fields only after sampling and mapping all write paths. Do not require fields that are optional in legacy records. |
| P1 — partner onboarding | `delivery_partner_applications`, `delivery_partner_referrals`, `delivery_partner_audit` | Ownership, review state and encrypted identity data deserve storage-level guardrails. The delivery partner feature is relatively new and later Emergent changes may not be represented in this archive. | Defer final schema until newer Emergent source and final completion report are recovered. Avoid validating encrypted payload internals or unverified field names. |
| P2 — customer/service workflows | `addresses`, `service_providers`, `service_appointments`, `home_service_slot_reservations`, `restaurant_carts`, `restaurant_reviews`, `restaurant_support`, `grocery_quotes`, `referrals`, `referral_rewards`, `referral_ledger`, `payout_bank_accounts` | Several already have Pydantic validation and/or unique indexes. Some records are flexible or have status-dependent fields. | Add only where stable invariants are proven and where API validation alone is insufficient. Existing indexes remain the primary concurrency/idempotency controls. |
| P3 — flexible records and audit/history | `notifications`, `announcements`, `status_checks`, `request_anything`, `agent_assist`, `files`, `catalog_import_history`, `catalog_price_audit`, `catalogue_import_jobs`, `retail_price_import_history`, `retail_price_offers`, `retail_price_price_audit`, `chand_feedback`, `financial_audit`, `referral_audit`, `referral_link_events`, `delivery_partner_audit`, `master_products`, `restock_alerts`, `assistant_rate_limits`, `auth_rate_limits`, `password_resets`, `home_service_settings` | Many have intentionally extensible payloads, append-only history, TTL semantics, or source-specific shapes. | Prefer narrow validation only after write-path inventory. Do not impose rigid schemas on opaque payloads or audit snapshots. TTL indexes do not require validators. |

The source also references `catalogue_import_jobs` as a flexible job/record payload. Its final schema remains deliberately outside this phase because the newer Emergent Catalogue Import implementation may differ from this archive.

## Recommended rollout safeguards

1. Recover the newer Emergent source and its November 14 completion report before finalizing partner, catalogue, product or order schemas.
2. Obtain a sanitized live/disposable database sample and report field presence, BSON types, nullability, status values and legacy variants per collection. Do not include personal values in the report.
3. Draft validators from observed records and all source write paths, not only Pydantic request models.
4. Run validation in warning mode on a disposable replica-set database first; collect and classify violations without rewriting records.
5. Remediate legacy records only through a separately reviewed, reversible migration plan. Never delete or coerce records automatically.
6. Enable `validationAction: "error"` only after zero unexplained violations and compatibility tests for each writer. Choose `strict` or `moderate` per collection based on verified legacy state.
7. Add regression tests for valid legacy documents, new writes, invalid types, status transitions, and each variant/mode.

## Decision

No MongoDB validators are installed or enabled in this phase. The source supports a strong recommendation to prioritize minimal validators for financial/payment/settlement records, followed by carefully scoped validators for core account/catalog/order records. Actual validator definitions are **BLOCKED** on live data profiling and newer-source reconciliation; implementing speculative validators would risk rejecting legitimate legacy documents or current writes.
