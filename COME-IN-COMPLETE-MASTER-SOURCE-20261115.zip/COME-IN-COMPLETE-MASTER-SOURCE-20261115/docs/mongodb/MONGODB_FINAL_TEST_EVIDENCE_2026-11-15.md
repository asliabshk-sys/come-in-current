# COME-IN MongoDB Offline Test Evidence — 15 Nov 2026

**Test evidence, not live acceptance.** Baseline targeted suite 37 PASS (no code edits). Final backend offline suite: **477 PASS, 2 FAIL** in 70 test files; 4 runtime/live test modules unavailable for collection (3 need `/app/frontend/.env` and API service; 1 needs `bson`/Motor/PyMongo and MongoDB). Full log: `reports/MONGODB_STEP1_OFFLINE_TEST_RUN_2026-11-15.log`.

The two failing frontend/static tests are `test_frontend_contracts.py::test_shopping_home_theme_contract_and_separate_mode_routes` and `test_frontend_contracts.py::test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest`. They fail identically in untouched read-only baseline (17 PASS, 2 FAIL). Those are not new MongoDB regressions and were deliberately not changed. Baseline log: `reports/MONGODB_STEP1_ORIGINAL_UI_CONTRACT_BASELINE_2026-11-15.log`.

Test inventory: `backend/tests/test_catalogue_transaction_apply_offline.py`, `test_restaurant_capture_transaction_offline.py`, `test_grocery_capture_transaction_offline.py`, `test_catalogue_validator_migration.py`, `test_mongo_backup_safety_offline.py`, `test_restaurant_refund_webhook_transaction_offline.py` (8 PASS), existing `test_mongo_portability_tool.py` and all other offline backend contract tests.

Static: `python -m compileall -q backend scripts/mongo` and `bash -n scripts/backup-db.sh scripts/restore-db.sh scripts/mongo/setup.sh scripts/mongo/start-replset.sh` run. Validator plan command produced JSON and no DB connection. `tsc -p frontend/tsconfig.json --noEmit --pretty false` failed missing Expo/React/TS dependencies; see `reports/MONGODB_STEP1_FRONTEND_TSC_2026-11-15.log`. No installation/network attempt.

**Transaction/restore reality:** No database, no driver, no actual MongoDB test; fake session unit/fault tests are offline only. No provider/payment request executed. Actual commit/abort, persistent validator installation, live indexes and restore are BLOCKED.

**Last regression after refund webhook fix:** 477 PASS, 2 FAIL across 70 offline test files. `python -m compileall -q backend scripts/mongo` EXIT 0, `bash -n scripts/backup-db.sh scripts/restore-db.sh scripts/mongo/setup.sh scripts/mongo/start-replset.sh` EXIT 0; focused transaction tests 29 PASS (at prior snapshot). The updated v3 log is included in `reports/MONGODB_STEP1_OFFLINE_TEST_RUN_2026-11-15.log`. No live DB tests.
