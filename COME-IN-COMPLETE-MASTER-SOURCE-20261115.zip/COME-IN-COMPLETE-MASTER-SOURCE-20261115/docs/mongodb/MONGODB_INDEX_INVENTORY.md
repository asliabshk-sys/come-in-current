# COME-IN MongoDB Index Inventory

**Source:** `backend/server.py` FastAPI startup handlers, parsed by `scripts/mongo/comein_mongo.py`.

- Declared non-`_id` indexes: **65**
- Main startup `_startup`: **59**
- Delivery Partner startup `ensure_delivery_partner_indexes`: **6**
- Collections referenced by backend source: **50**
- Collections with declared indexes: **38**
- This is a source inventory, not a live database index listing.

## Declared indexes

### `addresses` (1)
- `user_id:1, is_default:-1` _(initializer: `_startup`)_
### `assistant_rate_limits` (2)
- `rate_key:1` — unique=true _(initializer: `_startup`)_
- `expires_at:1` — expireAfterSeconds=0 _(initializer: `_startup`)_
### `auth_rate_limits` (1)
- `expires_at:1` — expireAfterSeconds=0 _(initializer: `_startup`)_
### `chand_feedback` (3)
- `user_id:1, created_at:-1` _(initializer: `_startup`)_
- `user_id:1, request_id:1` — unique=true _(initializer: `_startup`)_
- `status:1, created_at:-1` _(initializer: `_startup`)_
### `delivery_partner_applications` (3)
- `user_id:1` — unique=true _(initializer: `ensure_delivery_partner_indexes`)_
- `referral_code:1` — unique=true; sparse=true _(initializer: `ensure_delivery_partner_indexes`)_
- `status:1, updated_at:-1` _(initializer: `ensure_delivery_partner_indexes`)_
### `delivery_partner_audit` (1)
- `application_id:1, created_at:-1` _(initializer: `ensure_delivery_partner_indexes`)_
### `delivery_partner_referrals` (2)
- `referred_application_id:1` — unique=true _(initializer: `ensure_delivery_partner_indexes`)_
- `referrer_application_id:1, created_at:-1` _(initializer: `ensure_delivery_partner_indexes`)_
### `files` (1)
- `owner_id:1` _(initializer: `_startup`)_
### `financial_audit` (1)
- `created_at:-1` _(initializer: `_startup`)_
### `financial_ledger` (3)
- `idempotency_key:1` — unique=true _(initializer: `_startup`)_
- `beneficiary_user_id:1, recorded_at:-1` _(initializer: `_startup`)_
- `order_id:1, recorded_at:-1` _(initializer: `_startup`)_
### `grocery_quotes` (2)
- `expires_at:1` — expireAfterSeconds=0 _(initializer: `_startup`)_
- `scope:1, status:1` _(initializer: `_startup`)_
### `home_service_settings` (1)
- `key:1` — unique=true _(initializer: `_startup`)_
### `home_service_slot_reservations` (1)
- `provider_id:1, slot_key:1` — unique=true _(initializer: `_startup`)_
### `notifications` (2)
- `user_id:1, created_at:-1` _(initializer: `_startup`)_
- `user_id:1, read:1` _(initializer: `_startup`)_
### `orders` (3)
- `customer_id:1` _(initializer: `_startup`)_
- `shop_id:1` _(initializer: `_startup`)_
- `grocery_idempotency_scope:1` — unique=true; sparse=true _(initializer: `_startup`)_
### `password_resets` (1)
- `expires_at:1` — expireAfterSeconds=0 _(initializer: `_startup`)_
### `payout_bank_accounts` (1)
- `beneficiary_type:1, beneficiary_id:1` — unique=true _(initializer: `_startup`)_
### `products` (2)
- `shop_id:1` _(initializer: `_startup`)_
- `owner_id:1` _(initializer: `_startup`)_
### `referral_audit` (1)
- `created_at:-1` _(initializer: `_startup`)_
### `referral_ledger` (2)
- `idempotency_key:1` — unique=true; sparse=true _(initializer: `_startup`)_
- `user_id:1, created_at:-1` _(initializer: `_startup`)_
### `referral_link_events` (1)
- `referrer_id:1, created_at:-1` _(initializer: `_startup`)_
### `referral_rewards` (2)
- `reward_key:1` — unique=true _(initializer: `_startup`)_
- `referrer_id:1, status:1` _(initializer: `_startup`)_
### `referrals` (3)
- `referred_user_id:1` — unique=true _(initializer: `_startup`)_
- `referrer_id:1, status:1` _(initializer: `_startup`)_
- `qualifying_order_id:1` — unique=true; partialFilterExpression={"qualifying_order_id": {"$type": "string"}} _(initializer: `_startup`)_
### `restaurant_carts` (1)
- `user_id:1` — unique=true _(initializer: `_startup`)_
### `restaurant_menu` (1)
- `restaurant_id:1, available:1` _(initializer: `_startup`)_
### `restaurant_orders` (3)
- `customer_id:1, created_at:-1` _(initializer: `_startup`)_
- `restaurant_id:1, created_at:-1` _(initializer: `_startup`)_
- `customer_id:1, idempotency_key:1` — unique=true _(initializer: `_startup`)_
### `restaurant_payment_events` (1)
- `event_id:1` — unique=true; sparse=true _(initializer: `_startup`)_
### `restaurant_payments` (1)
- `gateway_order_id:1` — unique=true; sparse=true _(initializer: `_startup`)_
### `restaurant_reviews` (1)
- `restaurant_id:1, customer_id:1` — unique=true _(initializer: `_startup`)_
### `restaurant_support` (2)
- `user_id:1, created_at:-1` _(initializer: `_startup`)_
- `user_id:1, request_id:1` — unique=true; partialFilterExpression={"request_id": {"$type": "string"}} _(initializer: `_startup`)_
### `restaurants` (2)
- `owner_id:1` _(initializer: `_startup`)_
- `status:1, available:1, city:1` _(initializer: `_startup`)_
### `restock_alerts` (1)
- `product_id:1, active:1` _(initializer: `_startup`)_
### `service_appointments` (2)
- `customer_id:1, created_at:-1` _(initializer: `_startup`)_
- `provider_id:1, created_at:-1` _(initializer: `_startup`)_
### `service_providers` (1)
- `owner_id:1` — unique=true; sparse=true _(initializer: `_startup`)_
### `settlement_order_allocations` (2)
- `order_key:1` — unique=true _(initializer: `_startup`)_
- `settlement_id:1` _(initializer: `_startup`)_
### `settlement_requests` (3)
- `beneficiary_user_id:1, created_at:-1` _(initializer: `_startup`)_
- `beneficiary_user_id:1, beneficiary_type:1, beneficiary_id:1, idempotency_key:1` — unique=true _(initializer: `_startup`)_
- `status:1, created_at:-1` _(initializer: `_startup`)_
### `shops` (2)
- `owner_id:1` _(initializer: `_startup`)_
- `status:1` _(initializer: `_startup`)_
### `users` (2)
- `email:1` — unique=true _(initializer: `_startup`)_
- `referral_code:1` — unique=true; sparse=true _(initializer: `_startup`)_

## Verification semantics

- `spec` discovers every `@app.on_event("startup")` handler and extracts literal `db.<collection>.create_index(...)` declarations. Non-literal declarations fail extraction rather than being silently skipped.
- `init` creates missing application collections, creates all declared indexes, then verifies the full inventory. Index creation errors propagate; no critical failure is swallowed.
- `health` checks all declared indexes and transaction capability.
- `verify-indexes` performs a read-only index verification suitable after restoring into a disposable database.
- `preflight-indexes` performs a read-only duplicate-group scan for all declared unique indexes. It returns counts only, never duplicate key values.
- Explicitly declared index names are compared. Server-generated names are accepted when no explicit name is required.

## Additional candidate indexes — NOT applied

The following query paths have no source-declared index. They require a live duplicate preflight and workload review before any migration; no index was added because this environment has no MongoDB connection.

| Collection | Candidate key | Reason / gate |
|---|---|---|
| `grocery_payments` | `gateway_order_id` unique sparse; `gateway_payment_id` unique sparse | Prevent duplicate gateway intent/payment identity; BLOCKED pending legacy duplicate scan and live callback tests |
| `catalogue_import_jobs` | `job_id` unique; `(shop_id, seller_id, created_at desc)` | UUID job identity and seller-scoped listing; BLOCKED pending duplicate scan and newer Emergent source reconciliation |
| `retail_price_offers` | `(retailer_key, retailer_shop_id_key, external_key)` unique | Existing upsert identity; BLOCKED pending duplicate scan |
| `master_products` | `(name_key, category_id)` unique partial | Source already checks duplicate before insert; source comment explicitly defers unique index pending live audit/approval |

Do not add or remove production indexes automatically. Run `preflight-indexes` against an authorized disposable clone, review findings, then plan a separately approved migration.
