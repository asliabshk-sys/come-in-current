# COME-IN MongoDB Backup and Restore Guide

## Backup classes — do not conflate them

| Class | Purpose | Data handling | Production proof |
|---|---|---|---|
| Sanitized preview/test backup | Shareable test fixture; sensitive fields redacted and selected auth/TTL collections emptied | May be included in a project ZIP only after fresh redaction and restore verification | **Not production backup proof** |
| Development backup | Recover a named local/dev database | Keep access restricted; do not package raw PII or secrets | No production proof |
| Production backup | Operational disaster recovery for the live service | Encrypted storage, managed credentials, retention, access logs and independent recovery region | Requires authorized managed infrastructure and a timed restore drill; NOT performed in this mission |

## Existing sanitized preview artifact

- Archive: `database-backup/COME-IN-PREVIEW-TEST-DB-SANITIZED-20261114T134327Z.archive.gz`
- Size: 8,762 bytes
- SHA-256: `956a749a2a936342c5e890326b3aad7145fe71aac6822ed3af435a44b7c14d7b`
- Sidecar checksum verification: PASS when run from `database-backup/`
- Supplied `reports/mongodb/BACKUP_VERIFICATION_REPORT.json`: 52 collections, 38 documents, 117 total indexes, zero reported restore mismatches, zero unredacted sensitive fields.

The report is supplied historical evidence. This workspace could not run `mongorestore` or independently restore the archive because MongoDB Database Tools and a MongoDB server are unavailable.

## Backup commands

`scripts/backup-db.sh` uses `mongodump --archive --gzip` and writes a SHA-256 sidecar. It reads `MONGO_URL` and `DB_NAME` from the environment or `backend/.env`. The URI is passed to MongoDB Database Tools through a mode-0600 temporary config file rather than a process argument. Do not run it against production as part of this mission. For production, use the organization's approved encrypted managed backup process and secret store.

The sanitized preview exporter `scripts/mongo/export_sanitized_preview_backup.py` requires `ALLOW_SANITIZED_PREVIEW_SOURCE=yes` and a non-production DB name ending `_dev`, `_test` or `_preview`. It uses timestamped `comein_disposable_test_*` work/restore databases, a mode-0600 MongoDB Tools config file, redacts selected fields, removes selected auth/TTL collections, writes a sanitized archive, restores it into a second disposable database and compares per-collection document/index/options metadata. It requires PyMongo and MongoDB Database Tools and was not executed here.

## Restore safety

`scripts/restore-db.sh` now:

1. Requires an archive and adjacent SHA-256 sidecar.
2. Refuses `TARGET_DB == DB_NAME`.
3. Requires `TARGET_DB` to begin with `comein_disposable_test_`.
4. Restores only to that disposable namespace.
5. Runs `comein_mongo.py verify-indexes` against the restored database and fails if any source-declared index is missing or semantically drifted.

Example (only with an explicitly disposable replica set and a valid archive):

```bash
MONGO_URL="$DISPOSABLE_MONGO_URL" \
DB_NAME="comein_dev" \
TARGET_DB="comein_disposable_test_restore_review01" \
bash scripts/restore-db.sh database-backup/example.archive.gz
```

Never set `TARGET_DB` to a production name. The script deliberately has no live-restore override.

## Recovery acceptance gates

- Verify archive SHA-256 before restore.
- Restore to a fresh disposable DB only.
- Compare all 50 expected application collection names with restored collection names; investigate intentional tooling/system collections separately.
- Compare document counts and collection options using a generated manifest.
- Verify all source-declared indexes (currently 65) using `verify-indexes`; compare any additional approved indexes separately.
- Check required unique index definitions and TTL/partial/sparse options.
- Run read-only integrity diagnostics (payment/order references, stock, ownership and ledger idempotency).
- Run transaction commit/abort and application smoke tests.
- Record server version, FCV, topology, restore duration, archive checksum and test evidence without secrets or PII.

## Current limitation

The current restore script passes the URI through a mode-0600 MongoDB Tools config file and verifies the source-declared index set, but does not yet accept a full per-collection document-count manifest as an input. Production retention, encryption, off-site replication, restore-time objective and recovery-point objective are not configured or verified in this environment. Production backup readiness remains BLOCKED.
