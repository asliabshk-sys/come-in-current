# COME-IN — MongoDB Transaction Configuration and Audit

## Requirement

Multi-document ACID transactions require a replica set or supported sharded deployment. The development configuration pins MongoDB 7.0.45. A standalone `mongod` is not sufficient for Grocery checkout, cancellation, imports, referrals or settlements.

## Current transaction scopes

`backend/server.py` contains 11 explicit `start_session()` / `start_transaction()` scopes. The current detailed source-backed review is in `MONGODB_TRANSACTION_AUDIT.md`.

| Function | Transactional work |
|---|---|
| `_maybe_create_referral_reward` | referral threshold, reward and audit |
| `admin_review_referral` | referral/user state and audit |
| `admin_update_referral_reward` | reward, ledger and audit |
| `import_shop_products` | legacy seller product import, price audit and history |
| `admin_retail_price_import` | retailer price upserts, audit and import history |
| `create_order` | quote claim, stock deduction, Grocery order and reward debit |
| `_cancel_grocery_order` | order cancellation and stock restoration |
| `request_shop_settlement` | settlement request, allocations and audit |
| `request_restaurant_settlement` | restaurant settlement, allocations and audit |
| `admin_settlement_decision` | conditional state transition, allocation cleanup and audit |
| `_mark_grocery_paid` | Grocery payment capture and order state in one transaction |

All direct collection operations within these scopes were statically checked for `session=session`; nested checkout helpers receive the session explicitly. The `create_order` shop revalidation now also uses the active session.

## Retry and error semantics

- The application currently uses manual transaction context managers; no `with_transaction()` callback is present.
- Driver retryable reads/writes are enabled in the Mongo client options, but this is not equivalent to retrying a multi-document transaction.
- Grocery checkout maps a labeled `TransientTransactionError` to HTTP 409 only when a fresh post-abort read proves insufficient stock. Other errors remain HTTP 503.
- Unknown commit result reconciliation and bounded whole-transaction retry are not implemented/verified. Do not add a broad retry loop until idempotent callback behavior is proven with a live replica set.

## Connection settings

- Local replica set: `mongodb://127.0.0.1:27018/?replicaSet=rs0`
- Docker host: `mongodb://localhost:27017/?replicaSet=rs0&directConnection=true`
- Managed cluster: use a TLS-enabled URI from a secret store.
- Pool and timeout defaults: `backend/mongo_config.py`.
- Production requires `MONGO_EXPECTED_DB_NAME` and effective TLS; DB target mismatch fails startup.

## Verification commands

```bash
python scripts/mongo/comein_mongo.py spec
python scripts/mongo/comein_mongo.py preflight-indexes
python scripts/mongo/comein_mongo.py init
python scripts/mongo/comein_mongo.py verify-indexes
python scripts/mongo/comein_mongo.py tx-verify
python scripts/mongo/comein_mongo.py health
```

`preflight-indexes` is read-only and returns duplicate group counts only. `init` creates collections/indexes and verifies all source declarations; index creation failures are fatal. Run write-capable commands only against an authorized non-production database. `health` performs a temporary commit/abort probe in `_portability_healthcheck` and therefore requires write permissions.

## Live acceptance

Use only a disposable replica set and the pinned Motor 3.7.1 / PyMongo 4.18.2 environment. Run `backend/tests/test_task5_live_mongo_transactions.py` only after checking that its configured database is disposable; it creates and deletes synthetic test records. Add live tests for transaction retries, unknown commit, Grocery stock race, payment callback races and settlement rollback. No live transaction test ran in this audit environment.
