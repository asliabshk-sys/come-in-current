# MongoDB Backup / Restore Evidence — 15 Nov 2026

- `scripts/backup-db.sh` now calls `mktemp -d` for a private, non-overwritable timestamped run directory and uses private mode-0600 URI tool configuration and SHA-256 sidecar. `umask 077` protects the archive.
- `test_mongo_backup_safety_offline.py` ran with a **mock mongodump binary**, not a database: two independent runs created two differently named archives with valid SHA-256 and private file mode. It also checks restore refuses source/prod target before invoking tools. This proves script path safety only.
- Existing `scripts/restore-db.sh` checks archive sidecar and only permits `comein_disposable_test_*` target distinct from configured source DB; uses namespace remapping and post-restore index verification. No production restore attempted.
- `mongodump`, `mongorestore` and `mongod` are **NOT installed** in this environment. **No actual database backup, no real restore, no document/collection/index comparison** was executed, despite earlier historical reports describing archived sanitized backup results.
- Required live drill: initiate free authorized disposable replica set; create data with known counts and deterministic sample relationships; run backup; SHA verify; restore into a fresh second disposable database; compare source/target collection counts, selected hashes, 67 index definitions, important owner/reference relationships and query/transaction health. Never restore onto production or reuse original backup archive name.

Status **PARTIAL / actual restore BLOCKED**.
