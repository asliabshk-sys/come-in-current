# COME-IN MongoDB Collection Inventory

**Source:** `backend/server.py` collection references and operation calls.

- Application collections referenced: **50**
- Declared non-`_id` indexes: **65**
- No live database connection was available; document counts, validators, collection options and actual index presence are unverified.

## Collection inventory

| Collection | Source operations (AST count) | Declared indexes | Notes |
|---|---:|---:|---|
| `addresses` | create_index=1, delete_one=1, find=1, find_one=3, insert_one=1, update_many=2, update_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `agent_assist` | find=1, find_one=2, insert_one=1, update_one=1 | 0 | Customer support/assist requests. |
| `announcements` | count_documents=1, find=2, find_one=1, insert_one=1, update_one=1 | 0 | Admin-managed public announcements. |
| `assistant_rate_limits` | create_index=2, find_one=2, update_one=4 | 2 | Has unique rate_key and TTL expiry indexes. |
| `auth_rate_limits` | create_index=1, find_one=1, update_one=1 | 1 | Has TTL expiry index. |
| `catalog_import_history` | find=1, insert_one=1 | 0 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `catalog_price_audit` | find=1, insert_one=1 | 0 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `catalogue_import_jobs` | find=1, find_one=2, insert_one=1, update_one=5 | 0 | Seller-scoped staging only; confirm-apply does not create Product/stock in this source. |
| `chand_feedback` | aggregate=1, count_documents=1, create_index=3, find=2, find_one=5, insert_one=1, update_one=1 | 3 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `delivery_partner_applications` | create_index=3, find=1, find_one=12, insert_one=1, update_one=3 | 3 | Sensitive delivery-partner onboarding; encrypted sensitive fields. |
| `delivery_partner_audit` | create_index=1, insert_one=4 | 1 | Delivery-partner admin audit records. |
| `delivery_partner_referrals` | create_index=2, update_one=1 | 2 | Delivery-partner referral links. |
| `files` | create_index=1, find_one=2, insert_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `financial_audit` | create_index=1, insert_one=6 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `financial_ledger` | count_documents=1, create_index=3, find=2, find_one=3, update_one=2 | 3 | Idempotent financial snapshots and refund reversals. |
| `grocery_payments` | find_one=4, insert_one=1, update_one=2 | 0 | Razorpay payment intents/captures; currently no declared index in source. |
| `grocery_quotes` | create_index=2, find_one=1, insert_one=2, update_one=2 | 2 | Checkout quote tokens; TTL index on expires_at. |
| `home_service_settings` | create_index=1, find_one=3, update_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `home_service_slot_reservations` | create_index=1, delete_one=4, insert_one=2 | 1 | Unique provider/slot reservation records. |
| `master_products` | distinct=1, find=1, find_one=3, insert_one=1 | 0 | Admin master catalogue; source duplicate check has no unique index yet. |
| `notifications` | count_documents=2, create_index=2, find=1, insert_one=1, update_many=1, update_one=1 | 2 | In-app notifications and read state. |
| `orders` | aggregate=1, count_documents=1, create_index=3, find=5, find_one=16, insert_one=1, update_one=7 | 3 | Grocery checkout, stock reservation, cancellation and payment state. |
| `password_resets` | create_index=1, delete_many=2, find_one=1, insert_one=1, update_one=1 | 1 | Has TTL expiry index. |
| `payout_bank_accounts` | create_index=1, find_one=3, update_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `products` | create_index=2, delete_one=1, distinct=1, find=5, find_one=11, insert_one=3, update_one=6 | 2 | Seller catalogue, fixed-pack/variant/measured stock; central inventory source. |
| `referral_audit` | create_index=1, insert_one=5 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `referral_ledger` | create_index=2, find=4, find_one=2, insert_one=2, update_one=2 | 2 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `referral_link_events` | count_documents=1, create_index=1, insert_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `referral_rewards` | count_documents=1, create_index=2, find=2, find_one=3, insert_one=1, update_one=1 | 2 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `referrals` | create_index=3, find=3, find_one=2, insert_one=1, update_one=4 | 3 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `request_anything` | count_documents=1, find=2, find_one=2, insert_one=1, update_one=1 | 0 | Customer request submissions. |
| `restaurant_carts` | create_index=1, delete_one=2, find_one=1, update_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `restaurant_menu` | create_index=1, delete_one=1, find=3, find_one=5, insert_one=1, update_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `restaurant_orders` | count_documents=1, create_index=3, find=5, find_one=20, insert_one=1, update_one=16 | 3 | Restaurant order/payment lifecycle. |
| `restaurant_payment_events` | create_index=1, find_one=1, insert_one=2 | 1 | Signed webhook event idempotency; unique sparse event_id. |
| `restaurant_payments` | create_index=1, find_one=9, insert_one=1, update_one=13 | 1 | Restaurant payment intents, capture and refund state. |
| `restaurant_reviews` | create_index=1, find=1, find_one=1, insert_one=1, update_one=1 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `restaurant_support` | count_documents=1, create_index=2, find=3, find_one=6, insert_one=1, update_one=2 | 2 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `restaurants` | count_documents=1, create_index=2, find=8, find_one=7, insert_one=1, update_one=4 | 2 | Restaurant entities and owner settings; Restaurant Mode must remain isolated. |
| `restock_alerts` | create_index=1, find=1, find_one=1, update_many=1, update_one=2 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `retail_price_import_history` | find=1, insert_one=1 | 0 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `retail_price_offers` | find=1, find_one=2, update_one=1 | 0 | Retailer price offers updated by compound logical key; no unique index declared. |
| `retail_price_price_audit` | insert_one=1 | 0 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `service_appointments` | create_index=2, find=2, find_one=3, insert_one=1, update_one=1 | 2 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `service_providers` | create_index=1, find=3, find_one=11, insert_one=1, update_one=3 | 1 | Backend collection reference; inspect its endpoint/model paths before adding validators or indexes. |
| `settlement_order_allocations` | create_index=2, delete_many=1, insert_one=2 | 2 | Unique order allocation records. |
| `settlement_requests` | count_documents=1, create_index=3, find=4, find_one=9, insert_one=2, update_one=1 | 3 | Settlement requests and state transitions. |
| `shops` | count_documents=1, create_index=2, find=9, find_one=12, insert_one=1, update_one=3 | 2 | Seller-owned shop records and operational settings. |
| `status_checks` | find=1, insert_one=1 | 0 | Status/check records. |
| `users` | count_documents=5, create_index=2, delete_one=1, find=1, find_one=11, insert_one=3, update_one=9 | 2 | Accounts, roles, auth profile; password hashes excluded from admin response projections. |

## Source and integrity observations

- All 50 names are statically referenced through `db.<collection>` in `backend/server.py`; no dynamic `db[...]` collection access was found in application backend/scripts during this audit.
- `catalogue_import_jobs` is a staging collection. The current source records seller confirmation as `APPLY_PENDING_EMERGENT`; it does not create products or update stock in the new Universal Catalogue Import flow.
- `grocery_payments` and `retail_price_offers` have important idempotency/query paths but no declared indexes. Candidate unique indexes are documented separately and remain blocked on live duplicate preflight.
- The `_portability_healthcheck` collection is tooling scratch data, not one of the 50 application collections; transaction verification inserts and removes marker documents.
- MongoDB `$jsonSchema` validators are not configured in source. See `MONGODB_SCHEMA_VALIDATION_REPORT.md`.

## MongoDB-related source, tooling and evidence files reviewed

**Runtime/configuration**
- `backend/server.py` — Motor client, collection reads/writes, index startup handlers, transaction scopes, health-adjacent APIs, auth/ownership and payment/refund flows.
- `backend/mongo_config.py` — validated connection URI, environment, database target, TLS, pool and timeout configuration.
- `backend/mongo_transactions.py` — conservative transaction error-label and post-abort stock-conflict classification.
- `backend/requirements.txt`, `backend/.env.example` — pinned Motor/PyMongo requirements and environment template.
- `backend/catalogue_import_engine.py`, `backend/catalogue_chand_adapter.py` — file parsing/normalization and AI suggestion; no Mongo client in these modules.

**Provisioning and portability**
- `scripts/mongo/comein_mongo.py` — collection/index initialization, spec, health, transaction probe, disposable DB lifecycle, index verification and unique-index preflight.
- `scripts/mongo/setup.sh`, `scripts/mongo/start-replset.sh` — local replica-set provisioning.
- `infra/mongodb/mongod-rs0.conf`, `infra/mongodb/rs-init.js`, `infra/mongodb/supervisor-mongodb-rs0.conf`, `infra/mongodb/docker-compose.yml`, `infra/mongodb/.env.example` — local topology templates.

**Backup and restore**
- `scripts/backup-db.sh`, `scripts/restore-db.sh` — archive/checksum and disposable-only restore.
- `scripts/mongo/export_sanitized_preview_backup.py` — sanitized preview export and independent restore/count/index comparison.
- `database-backup/BACKUP_INSTRUCTIONS.md` and the supplied sanitized `.archive.gz` + `.sha256` sidecar.

**Tests reviewed or added**
- `backend/tests/test_mongo_portability_tool.py`
- `backend/tests/test_mongo_config.py`
- `backend/tests/test_mongo_transactions.py`
- `backend/tests/test_grocery_checkout_security_contract.py`
- `backend/tests/test_task5_live_mongo_transactions.py` (live-only; not run in this environment)
- `backend/tests/test_task5_customer_measured_shopping_contract.py`
- `backend/tests/test_task5_measured_import_contract.py`
- `backend/tests/test_restaurant_api_contract.py`
- `backend/tests/test_delivery_partner_onboarding_contract.py`
- `backend/tests/test_financial_security_contract.py`

**Documentation/evidence**
- `docs/mongodb/` — setup, transaction, schema, version, restoration, troubleshooting and this mission's collection/index/security/backup/validator reports.
- `docs/UNIVERSAL_CATALOGUE_IMPORT_EMERGENT_HANDOFF.md`, `COME_IN_EMERGENT_MONGODB_INTEGRATION_HANDOFF.md` — source contract for staging-only import and reserved Emergent apply phase.
- `reports/mongodb/live-mongo-spec-2026-11-14.json`, `reports/mongodb/BACKUP_VERIFICATION_REPORT.json`, `reports/security/SECRET_SCAN_2026-11-14.md`, `reports/MONGODB_FINAL_TEST_EVIDENCE.md`.

The above is the MongoDB-specific file set identified from repository structure and source references; it does not imply every unrelated application file was a MongoDB artifact.
