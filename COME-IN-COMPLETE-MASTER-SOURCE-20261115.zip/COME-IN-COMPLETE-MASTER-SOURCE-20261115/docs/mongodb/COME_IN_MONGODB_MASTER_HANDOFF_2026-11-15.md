# COME-IN — MongoDB Step 1 Master Handoff (15 Nov 2026)

## Do not rebuild
This is a recovered **partial** Phase 2 source, NOT verified active Codex Git working tree. Original ZIP SHA-256: `72b32dbd5673a2bfd166355ca1e3203d5004cc2c24bdccefad7c2a5f59f40132`; recovered baseline inventory 681 files; `.git` absent. Original archive, read-only extraction and historical archives were not modified. Modified code is only in separate directory `/mnt/data/COME-IN-MONGODB-STEP1-DEV-20261115`.

## Approved sequence
1. MongoDB + Backup + Restore — **current Step 1, PARTIAL**.
2. Source ZIP Safety — NOT STARTED.
3. Task 5 Measured Cart and Checkout — NOT STARTED.
4. Customer Workflow + Refund + Replacement — NOT STARTED.
5. Catalogue Import Approval Workflow — NOT STARTED as separate roadmap step; MongoDB atomic apply was updated ONLY as Step 1 dependency.
6. Chand AI — NOT STARTED.
7. Payments + Notifications + Security — NOT STARTED as separate roadmap step; MongoDB consistency was changed ONLY within Step 1.
8. COME-IN Assist + Delivery Partner — NOT STARTED.
9. Final Testing and Launch — NOT STARTED.

## Primary source map
- Backend: `backend/server.py` (FastAPI, models, indexes, transaction endpoints), `backend/mongo_config.py` (safe config), `backend/mongo_transactions.py` (driver-managed callback helper).
- Mongo tooling: `scripts/mongo/comein_mongo.py`, `scripts/mongo/catalogue_audit_validator.py`, `scripts/backup-db.sh`, `scripts/restore-db.sh`.
- Catalogue: `backend/catalogue_import_engine.py`, `backend/catalogue_chand_adapter.py`, staged seller record routes in `backend/server.py`.
- Modes: existing Grocery and Restaurant handlers in `backend/server.py`, customer/seller/driver/admin auth untouched. Stock in `db.products`; no separate inventory.
- Frontend unchanged: `frontend/`, routes/theme/login shared session and separate Restaurant Mode preserved.
- `docs/mongodb/COME_IN_MONGODB_MASTER_DOCUMENT_2026-11-15.md`: full 51 collection, 67 index, 177 route, security, schema, transaction, backup, dependency inventory.

## What was implemented in this isolated working copy
- Source-backed transactional, idempotent Seller-approved Catalogue Import confirmation/apply: job+shop owner fence, validated ProductIn and measured base units, existing Product stock, unavailable Product insert, audit row, APPLIED state, failure reconciliation; two partial unique indexes.
- `run_transaction` helper using Motor `session.with_transaction`; used for new Catalogue apply, existing Grocery capture and Restaurant capture/failure/refund claim. No provider calls inside callbacks. Existing Grocery order/cancellation stock transactions preserved.
- Restaurant provider capture state checks strengthened; late capture does not re-open cancelled orders; refund claim becomes atomic before external provider request.
- Conservative source-defined persistent validator for *new* catalogue audit collection only; default plan, disposable localhost-only guarded apply. No collMod or other DB migration run.
- Unique private no-clobber backup destination; existing restore script preserved.
- Focused executable offline fake-driver rollback, transient retry, ambiguous commit, idempotency, SKU collision, owner authorization, Restaurant/Grocery state, backup mock and validator safety tests. Existing structural test expectations updated to follow moved transaction boundaries; do not confuse changed source-location assertions with bypassed tests.

## Actual tests and blockers
- Before change 37 passed in targeted suite.
- After change 477 passed and 2 unchanged/pre-existing frontend contract failures (the same 2 reproduced on original recovery). 4 runtime/live test files could not be collected with missing `/app/frontend/.env` or missing `bson`/Motor/PyMongo.
- `mongod`, `mongosh`, `mongodump`, `mongorestore`, Docker/Podman, Motor/PyMongo unavailable. **NO** live commit, abort, replica-set index, validator installation, actual backup/restore, external Razorpay, notification delivery test. Compiler `tsc` fails missing frontend dependencies; no install attempted.
- Ten old manual transaction scopes remain; Restaurant signed refund webhook is now callback-atomic, while admin post-provider status and ledger writes can still be multi-document; no provider transaction safety certification. Shop+SKU legacy duplicates not profiled; globally unique index **not** added. All original 65 indexes plus 2 new declared; no index deployed.

## Safe next action — no production databases
1. Restore the **actual newer Nov 14 source only if found and verified**, compare instead of overwriting; bounded archive search found no `_apply_catalogue_import_job_transactionally` in available historical archives. Existing implementation in this isolated working copy remains preserved.
2. On **authorized disposable localhost replica set** with compatible MongoDB and the existing pinned drivers, run `python scripts/mongo/comein_mongo.py spec`, duplicate preflight, reviewed `init`, `verify-indexes`, `health`; run `python scripts/mongo/catalogue_audit_validator.py` plan then `--apply --confirm-disposable-db <exact disposable name>` with APP_ENV=test.
3. Run live test `backend/tests/test_task5_live_mongo_transactions.py` only with disposable test credentials, plus real Catalogue atomic multi-insert, forced rollback, concurrent double-confirm, retry/unknown commit; Restaurant capture, fail/refund and Grocery payment races. No standalone DB for transaction tests.
4. Run real mongodump + disposable restore drill with clean unique output and independent data/index counts. Never point restore to real database.
5. Complete remaining old transaction callbacks and Restaurant admin post-provider refund persistence/ledger atomicity; add tests. Document before any prod change.
6. Update completion matrix with actual commands, setup specs and sanitized test evidence; do NOT call Step 1 COMPLETE until validated. Do NOT begin Step 2 without explicit authorization.

## Integrity and checksum policies
The original `SHA256SUMS`, `PROJECT_MANIFEST.json`, and `MANIFEST.sha256` are preserved **as historical evidence** and may legitimately mismatch new source modifications. The new checkpoint has a separately named **current-source SHA256 manifest**. No Git history is present in the input ZIP; do not claim the checkpoint contains original Git status/commits.

**Important:** No project rebuild, UI redesign, unrelated source changes, production credentials, paid service or production DB activity occurred in this campaign.
