# COME-IN — MongoDB Step 1 Master Handoff, final source campaign

**Read `MONGODB_STEP1_FINAL_EXECUTION_REPORT_2026-11-15.md` and `COME_IN_MONGODB_MASTER_DOCUMENT_STEP1_FINAL_2026-11-15.md` first.** They supersede earlier status interpretations while retaining older reports as historical evidence.

## Authoritative baseline and location
- Source: `/mnt/data/COME-IN-MONGODB-STEP1-FINAL-20261115` extracted as an isolated copy from latest verified 15-Nov Source ZIP; original archives untouched.
- Baseline SHA-256: `12c98826a73f2590d66b51bff8a9871d28825c7199d037d959ce47023e9f95af`; 589 files; baseline hash map `reports/STEP1_FINAL_BASELINE_INVENTORY.json`.
- `.git` directory missing in original checkpoint: **not the original Git worktree**. Never claim Git history/HEAD or uncommitted original changes were recovered.
- Python API source `backend/server.py`; Mongo connection `backend/mongo_config.py`; retries `backend/mongo_transactions.py`; Catalog Import modules `backend/catalogue_import_engine.py`, `backend/catalogue_chand_adapter.py`; Mongo tools under `scripts/mongo`.

## Implemented in this campaign
- Converted 10 remaining manual sessions to driver callbacks, now 20 `run_transaction` source flows; protected checkout idempotency and existing feature state.
- Restaurant Admin post-provider refund state, signed-webhook payment/order and financial ledger reversal are same transactional unit; external API call never in retried callback.
- Delivery Partner draft/submit/approval transactions with status, audit and referrals, seller/customer boundary and verification guards.
- Index initialization now does preflight duplicate grouping and stops before mutation on conflicts; 67 declared index specifications, 51 source collections.
- Hardened restore and added read-only disposable profile & counts/index recovery comparison.

## Offline verification
- Expanded 73-module test selection: **498 passed, 2 pre-existing frontend failures**. Four runtime/live test modules omitted for absent dependencies. Report `reports/STEP1_FINAL_VALIDATED_REGRESSION.log` and final test evidence doc.
- Compilation + Bash syntax passes, source specs export 67 indexes, native frontend dependencies unavailable (`tsc` failed). No live DB tested.

## Safe runbook for a future Codex/developer
1. Preserve all original ZIPs and the new checkpoint; verify SHA256 and integrity first. Do not run Git clean/reset/checkout/stash or overwrite older source.
2. Use a separate disposable, free, transaction-capable local MongoDB replica set and install exact pinned `pymongo==4.18.2`, `motor==3.7.1` and MongoDB Tools without production secrets.
3. Restore code dependencies in a disposable environment only. Run `PYTHONPATH=$PWD:$PWD/backend pytest -c /dev/null -q` on selected offline suites; do not silently bypass failures. Fetch full test evidence from report.
4. With test variables and explicit confirmations set, run `python scripts/mongo/comein_mongo.py spec`, read-only `preflight-indexes`, `python scripts/mongo/legacy_profile_disposable.py`. Review duplicate groups and legacy fields; apply **no destructive migrations**.
5. Review `init` and validator migration with disposable test DB. Run `verify-indexes` and signed MongoDB JSON-schema rejection tests. Do not assume the validator script was installed yet.
6. Run LIVE MongoDB transaction/commit/abort/transient retry/unknown commit/concurrent checkout, double-import and refund/ledger rollback, plus scoped user/seller/admin/Delivery Partner authorization tests; record sanitized actual results.
7. Run `scripts/backup-db.sh`, `scripts/restore-db.sh` into new empty disposable test DB and `verify_disposable_restore.py`. Save actual document/index/relationship verification logs.
8. Update evidence and completion matrix. Step 1 status remains PARTIAL until real requirements pass. **Do not start Step 2 unless explicitly authorized by user**.

## Production-only requirements / security
Replica set redundancy, credentials, server role privileges and TLS, provider keys/webhooks, PII encryption keys, gateway reconciliation, notifications and real delivery identity verification require separate production approval and must never be simulated or purchased here.

## Source preserved
No frontend source edits, no separate inventory collection, no automatic product merge, no paid deployment, no live production data, no recovered original Git history.
