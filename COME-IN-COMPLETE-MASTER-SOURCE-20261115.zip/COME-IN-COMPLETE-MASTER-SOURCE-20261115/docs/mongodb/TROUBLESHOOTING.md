# COME-IN — MongoDB Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Checkout / cancel / import returns 503 "not committed" | `MONGO_URL` points to a standalone mongod | Point to replica set; run `comein_mongo.py health` → `replica_set` must be `rs0` |
| `Transaction numbers are only allowed on a replica set member or mongos` | same as above | same |
| `NotYetInitialized` / `no replset config has been received` | mongod started with `--replSet` but never initiated | `mongosh --port 27018 --file infra/mongodb/rs-init.js` |
| `ServerSelectionTimeoutError` after Docker start, host `localhost:27017` unreachable from another container | replica-set member host differs from client host | from host use `directConnection=true`; from another container change `MONGO_RS_HOST` to the service name and re-initiate on a fresh volume |
| Emergent pod restarted → backend cannot connect to 27018 | `/etc/supervisor/conf.d/mongodb-rs0.conf` is not persistent | `bash scripts/mongo/setup.sh` (data in `/root/mongo-rs0-data` is kept) |
| `Address already in use` on 27017 | Emergent's platform mongod owns 27017 | keep rs on 27018 (default) |
| `mongod` exits: `DBPathInUse` | another mongod uses the same dbpath | stop it or set `MONGO_RS_DBPATH` |
| Health check `indexes_missing` not empty | DB created before indexes / new index in `server.py` | `comein_mongo.py init` (or restart backend — startup creates them) |
| `IndexOptionsConflict` / `IndexKeySpecsConflict` | an index with same keys but different options exists | drop that index manually on the **test** DB, then `init` |
| `DuplicateKeyError` on `users.email` during seeding | user already exists | expected; seeding is idempotent |
| Leftover `comein_disposable_test_*` databases | test run interrupted | `comein_mongo.py testdb-drop` |
| `Authentication failed` (Atlas) | wrong test-user secret or user lacks role on `DB_NAME` | rotate through the secret store; grant `readWrite` |
| Atlas: `IP not in access list` | network access rule | add the workspace egress IP (temporary, test cluster only) |
| `pymongo`/`motor` import error | backend deps missing | `pip install -r backend/requirements.txt` |
| Expo serves on 8081 instead of 3000 | `PORT` not exported | `PORT=3000 yarn start` (script is `expo start --port ${PORT:-8081}`) |
