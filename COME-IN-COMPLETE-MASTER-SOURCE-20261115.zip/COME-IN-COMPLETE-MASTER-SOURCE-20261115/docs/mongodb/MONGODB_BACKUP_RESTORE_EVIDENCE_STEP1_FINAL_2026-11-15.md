# Backup/Restore — Step 1 final verification evidence

**Source safety improvements implemented; actual recovery drill BLOCKED.**

- `scripts/backup-db.sh` remains private no-clobber gzip+SHA archiving, config mode 0600.
- `scripts/restore-db.sh` now rejects APP_ENV other than test, remote/authenticated URIs, source or target names outside disposable prefix, same source/target, and any confirmation mismatch. Requires fresh empty target. The CLI no longer includes `--drop`.
- `scripts/mongo/verify_disposable_restore.py`: read-only source-vs-restored collection count, per-collection document count, index semantic comparison; refuses empty source.
- `scripts/mongo/legacy_profile_disposable.py`: read-only duplicate-key and Product anomaly counts, local/test/confirmation guard; no records/PII printed.
- Offline tests: `test_mongo_backup_safety_offline.py` baseline PASS and `test_step1_final_restore_index_profile_offline.py` 6 PASS.
- Actual `mongodump`, `mongorestore`, restore drill, index verification and application relationship validation: **NOT RUN**, tools and replica set unavailable.

**Actual acceptance on disposable local environment**: create clean test source; run app index initializer and validator plan; use backup-db.sh; set APP_ENV=test and DB_NAME=comein_disposable_test_source, select new TARGET_DB=comein_disposable_test_restore_..., set CONFIRM_DISPOSABLE_RESTORE_DB equal target; run restore-db.sh with archive and sidecar; inspect emitted counts/index report; run business relationship checks before claiming recovery. Do not use production data/credentials.
