# COME-IN — MongoDB Setup (portable)

COME-IN needs **MongoDB with multi-document transactions**: a replica set (a single node is fine for development) or MongoDB Atlas. A standalone `mongod` makes checkout, cancellation, imports, referrals and settlements return HTTP 503 by design.

> The Master ZIP contains code, configuration and scripts. **It does not contain a MongoDB server or any data.** Every new environment must provision a replica set or connect to an authorised one.

## 1. Choose a deployment

| Option | When | How | Verified |
|---|---|---|---|
| A. Local single-node replica set (no Docker) | Emergent workspace, any Linux/macOS box with `mongod` 7.0.x | `bash scripts/mongo/setup.sh` | **Yes** — Emergent workspace 2026-11-11 + clean-directory restore test |
| B. Docker Compose | Laptop/CI with Docker | `docker compose -f infra/mongodb/docker-compose.yml up -d` | **No** — Docker was not available in the Emergent workspace |
| C. Managed (Atlas or company replica set) | Shared dev/staging/prod | Supply `MONGO_URL` via secrets; `MODE=external bash scripts/mongo/setup.sh` | Not tested (needs external credentials) |

## 2. Option A — local replica set (recommended for Emergent)

```bash
cp backend/.env.example backend/.env       # then set MONGO_URL + DB_NAME + JWT_SECRET ...
# MONGO_URL=mongodb://127.0.0.1:27018/?replicaSet=rs0
bash scripts/mongo/setup.sh                # starts rs0 on 127.0.0.1:27018, initiates it, creates collections+indexes, runs disposable-DB test, health check
```
What `setup.sh` does (all idempotent, safe to re-run):
1. If supervisor exists: copies `infra/mongodb/supervisor-mongodb-rs0.conf` → `/etc/supervisor/conf.d/` and starts program `mongodb-rs0`. Otherwise starts `scripts/mongo/start-replset.sh` with `nohup`.
2. `start-replset.sh` runs `mongod --replSet rs0 --port 27018 --bind_ip 127.0.0.1 --dbpath /root/mongo-rs0-data` and runs `infra/mongodb/rs-init.js` (initiates only if not yet initiated; waits for PRIMARY).
3. `comein_mongo.py init` — creates every statically referenced application collection and every index declared by all FastAPI startup handlers (currently 65: 59 main + 6 Delivery Partner). It verifies the full inventory after creation; critical index failures are not swallowed.
4. `comein_mongo.py testdb-cycle` — creates `comein_disposable_test_<UTC>`, initialises it, verifies transactions, **drops it**.
5. `comein_mongo.py health` — JSON report; exit code 0 only if ping, PRIMARY, transactions (commit + abort) and all indexes are OK.

Why port **27018**: in Emergent the platform runs its own standalone `mongod` on 27017 (read-only supervisor config, no `--replSet`). The replica set runs alongside it on 27018. Data lives in `/root/mongo-rs0-data` (persistent across pod restarts in Emergent; `/etc/supervisor/conf.d` is not — after a pod restart just re-run `bash scripts/mongo/setup.sh`).

Config-file alternative: `mongod --config infra/mongodb/mongod-rs0.conf` then `mongosh --port 27018 --file infra/mongodb/rs-init.js`.

## 3. Option B — Docker Compose (version pinned `mongo:7.0.45`)

```bash
cp infra/mongodb/.env.example infra/mongodb/.env
docker compose -f infra/mongodb/docker-compose.yml up -d     # healthcheck runs rs-init.js
# backend/.env: MONGO_URL=mongodb://localhost:27017/?replicaSet=rs0&directConnection=true
MODE=external bash scripts/mongo/setup.sh
```
Cleanup: `docker compose -f infra/mongodb/docker-compose.yml down -v` (deletes the volume).

## 4. Option C — managed replica set / Atlas

Credentials are **never** stored in the repo or ZIP. Supply them through the platform's secret store (Emergent: deployment secrets; CI: masked variables).
```
MONGO_URL=mongodb+srv://<user>:<password>@<cluster-host>/?retryWrites=true&w=majority
DB_NAME=<isolated_test_db_name>
MODE=external bash scripts/mongo/setup.sh
```
Use a test-only user limited to the test database (`readWrite` on `<db>` + `comein_disposable_test_*` if you run `testdb-cycle`).

## 5. Environment variables (template: `backend/.env.example`)

| Variable | Purpose | Example placeholder |
|---|---|---|
| `MONGO_URL` | connection string; must reach a replica set / Atlas; TLS required in production | `mongodb://127.0.0.1:27018/?replicaSet=rs0` |
| `DB_NAME` | database name | `comein_dev` |
| `APP_ENV` | required explicit environment (`development`, `test`, `staging`, `production`) | `development` |
| `MONGO_EXPECTED_DB_NAME` | exact database target guard; required in production | `comein_dev` |
| `MONGO_MAX_POOL_SIZE` / `MONGO_MIN_POOL_SIZE` / `MONGO_MAX_CONNECTING` | bounded pool controls | `50` / `0` / `4` |
| `MONGO_SERVER_SELECTION_TIMEOUT_MS` / `MONGO_CONNECT_TIMEOUT_MS` / `MONGO_SOCKET_TIMEOUT_MS` / `MONGO_WAIT_QUEUE_TIMEOUT_MS` | bounded timeouts | `8000` / `5000` / `20000` / `10000` |
| `MONGO_RS_PORT` / `MONGO_RS_NAME` / `MONGO_RS_DBPATH` / `MONGO_RS_BIND` | only for `start-replset.sh` | `27018` / `rs0` / `/root/mongo-rs0-data` / `127.0.0.1` |

## 6. Connection configuration in the app

`backend/mongo_config.py` validates the URI, database name, production TLS/expected-name guard and bounded pool/timeouts before `AsyncIOMotorClient` is created. Startup pings MongoDB and rejects standalone topology. Transactions use `client.start_session()` + `session.start_transaction()` (see `TRANSACTIONS.md`). Driver requirements: Motor 3.7.1 over PyMongo 4.18.2.

## 7. Command reference

| Command | Result |
|---|---|
| `python3 scripts/mongo/comein_mongo.py health` | full health JSON, exit 0/1 |
| `python3 scripts/mongo/comein_mongo.py tx-verify` | transaction commit + abort check only |
| `python3 scripts/mongo/comein_mongo.py init` | collections + indexes |
| `python3 scripts/mongo/comein_mongo.py testdb-cycle` | disposable DB create → init → verify → drop |
| `python3 scripts/mongo/comein_mongo.py testdb-drop` | drop any leftover `comein_disposable_test_*` DBs |
| `python3 scripts/mongo/comein_mongo.py spec` | print collection + index spec parsed from all startup handlers |
| `python3 scripts/mongo/comein_mongo.py preflight-indexes` | read-only duplicate scan before unique-index migration |
| `python3 scripts/mongo/comein_mongo.py verify-indexes` | verify source-declared indexes in the configured DB |
| `bash scripts/verify-env.sh` | Node/Yarn/Python/Expo/RN/lockfile/env verification |
| `bash scripts/backup-db.sh` / `restore-db.sh` | `mongodump` backup; restore is restricted to `comein_disposable_test_*` and verifies declared indexes |

See also: `SCHEMA_AND_VALIDATION.md`, `TRANSACTIONS.md`, `VERSIONS.md`, `TROUBLESHOOTING.md`, `EXPO_ENVIRONMENT.md`, `RESTORATION_PROCEDURE.md`.
