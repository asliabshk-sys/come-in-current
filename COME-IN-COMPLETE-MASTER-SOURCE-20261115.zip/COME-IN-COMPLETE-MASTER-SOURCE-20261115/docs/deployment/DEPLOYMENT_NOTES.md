# COME-IN — Deployment Notes

**Production deployment has never been performed and is BLOCKED (Task 19) pending explicit owner approval.**

Before any production deploy:
1. Managed MongoDB replica set / Atlas (transactions), URI supplied via secret manager only.
2. `APP_ENV=production` + explicit `CORS_ORIGINS` (no `*`), strong `JWT_SECRET`, distinct Fernet keys in a secret manager.
3. HTTPS/TLS termination and trusted proxy config.
4. Provider decisions: Razorpay (TEST then LIVE), SMTP, Chand AI provider, OTP/Aadhaar/PAN, document storage, Firebase push.
5. Native builds (EAS / Android SDK / Xcode) — not set up in this package.
6. Run `scripts/backup-db.sh` + `scripts/restore-db.sh` drill against the production-like cluster.
7. Fix KI-5/KI-6 (typecheck/lint) and re-run the full test matrix in `TESTING_GUIDE.md`.

Historical environment guides: `scripts/replit-install.sh`, `scripts/replit-run.sh`, `docs/mongodb/EXPO_ENVIRONMENT.md`, `docs/COME_IN_EMERGENT_MONGODB_INTEGRATION_HANDOFF.md`.
