# Universal Catalogue Import — Pending Blockers

## Emergent-only / live database
- Implement actual approved staging record to existing Product creation.
- Initialize stock/variants atomically with Product insert.
- Add unique idempotency index after duplicate audit.
- Implement job claim, transaction commit/abort, rollback, ambiguous-commit reconciliation and retry.
- Persist per-record Product IDs and mark records/job applied only in the successful transaction.
- Revalidate current shop ownership, category existence, SKU uniqueness and all ProductIn/Task 5 rules inside the transaction.
- Verify publication after commit and cart/checkout against actual MongoDB.
- Test cross-shop isolation and concurrent approvals/confirmations.

## Provider/runtime
- Configure CHAND provider in the approved deployment and verify real connectivity, timeout and provider response schema. Codex did not read or use API keys.
- `.xls` needs `xlrd`; not installed here. Legacy `.xls` route remains dependency-gated.
- Scanned PDF OCR fallback uses optional PyMuPDF/Pillow/pytesseract; deployment must install/verify these dependencies and Tesseract language packs if desired. OCR quality remains manual-review-only.
- Full Expo/TypeScript typecheck and build require the project dependency tree; no package install was attempted.
- Mobile file picker/camera integration and browser/device E2E remain unverified.

## Existing broad-suite failures (unrelated to this change)
- `test_shopping_home_theme_contract_and_separate_mode_routes`: expects `testID="request-anything-card"` in Home TSX; absent in checkpoint source.
- `test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest`: expects `Voice search unavailable` literal in Home TSX; absent in checkpoint source.
- These unrelated Home UI files were deliberately not changed.

## Runtime suite blockers
- `test_preview_runtime_e2e.py` reads `/app/frontend/.env`, absent from isolated checkpoint; two dependent runtime modules fail collection for the same reason.
- Live MongoDB transaction test is excluded by instruction.

## Known non-blocking limitations
- Duplicate content detection is within one uploaded batch only; no concurrency-safe cross-job uniqueness guarantee.
- Original binary source files are not retained for download; staging preserves parsed source values/text, filename/location and SHA-256.
- No malware scanning.
- Category IDs are returned from existing product records, but canonical category existence must be revalidated by Emergent before Product insert.
- Seller record array mutations require concurrency/CAS verification in the live DB environment.
