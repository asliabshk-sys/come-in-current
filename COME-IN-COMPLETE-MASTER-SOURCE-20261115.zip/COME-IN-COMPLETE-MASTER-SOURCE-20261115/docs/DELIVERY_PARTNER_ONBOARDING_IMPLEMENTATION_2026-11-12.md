# COME-IN Delivery Partner Onboarding — Implementation Report

Date: 2026-11-12  
Authoritative baseline: `COME-IN-UNIVERSAL-CATALOGUE-IMPORT-OFFLINE-COMPLETION-MASTER-2026-11-12.zip`  
Baseline SHA-256: `d447e83610307812cd94f408adc5f6e066ec3fe42370db4195541577116edca5`

## Scope and isolation

A separate Delivery Partner application/profile workflow was added. It does not reuse or modify the Shop Seller registration route, seller dashboard, shop records, seller role assignment, or seller permissions. Existing `become-seller.tsx`, `seller/products.tsx`, and `seller/orders.tsx` were byte-for-byte compared against the authoritative ZIP and are unchanged.

The applicant retains their existing COME-IN login role. Delivery Partner eligibility is represented in the separate `delivery_partner_applications` collection and checked server-side; approval does not convert a customer account into a shopkeeper or grant seller permissions.

## Implemented source

- Separate mobile onboarding screen at `frontend/app/delivery-partner.tsx`, linked from Account for customer users.
- Separate admin review screen at `frontend/app/admin-delivery-partners.tsx`, linked from the Admin account group.
- Draft application API with required full name, mobile, residential address, alternate contact and explicit consent validation.
- Sensitive draft fields are encrypted using a dedicated Fernet key (`DELIVERY_PARTNER_DATA_ENCRYPTION_KEY`) before MongoDB persistence. No Aadhaar/PAN number is collected or persisted.
- Applicant can retrieve only their own application; public projection omits identity details.
- Admin queue returns verification/status metadata only. An admin-only detail endpoint decrypts minimum application fields and writes an audit event.
- Admin decision state machine supports approve, reject, correction required, suspend and reactivate with admin ID, reason and timestamp audit.
- Submit and access checks are server-side. Submission and approval fail closed unless phone, Aadhaar, PAN and document verification flags are all verified.
- Unique user/application and referral-code indexes; referral attribution is linked to an approved referrer and recorded only when the referred application is approved. No rewards are automatically granted.
- Referral sharing is offered only for approved applications using the device share sheet.

## API additions

- `GET /api/delivery-partner/provider-status`
- `POST /api/delivery-partner/otp/request`
- `POST /api/delivery-partner/otp/verify`
- `POST /api/delivery-partner/identity/start`
- `PUT /api/delivery-partner/application`
- `POST /api/delivery-partner/application/submit`
- `GET /api/delivery-partner/application/mine`
- `GET /api/delivery-partner/referral`
- `GET /api/delivery-partner/admin/applications`
- `GET /api/delivery-partner/admin/applications/{application_id}`
- `PATCH /api/delivery-partner/admin/applications/{application_id}`
- `GET /api/delivery-partner/access`

## Database changes

New collections (created on first write):
- `delivery_partner_applications`
- `delivery_partner_audit`
- `delivery_partner_referrals`

Indexes are created at application startup: unique applicant user ID, unique sparse referral code, application status/update ordering, audit application/time ordering, unique referred application ID and referrer/time ordering. No existing collection is reset or migrated.

## Security boundaries and blockers

- OTP vendor is not selected/integrated. OTP request/verify endpoints return HTTP 503 and never simulate success.
- Authorized Aadhaar and PAN verification vendors are not selected/integrated. Identity start returns HTTP 503. No unauthorized Aadhaar lookup is implemented; Aadhaar/PAN numbers are not collected.
- Secure document storage/upload adapter is not integrated. Document upload is intentionally unavailable; no unencrypted identity document is accepted or served.
- Consequently, no applicant can submit for approval and no administrator can approve until trusted provider integration sets verification evidence through a reviewed server-side adapter. The UI displays provider adapter pending status.
- The encryption key must be supplied through a managed secret store before draft PII can be saved. Never commit the key or reuse the bank-data key.
- HTTPS/TLS, managed encryption-key rotation/backup, provider legal review, retention/deletion policy and production deployment configuration remain owner/platform gates.

## Verification evidence

- Baseline archive SHA-256: PASS.
- Baseline ZIP integrity and 625 entries: PASS.
- Backend `py_compile`: PASS.
- AST parse: PASS.
- Focused contract regression: 34 passed, 0 failed (run with `python -m pytest -c /dev/null ...` because repository `pytest.ini` requires unavailable `pytest-xdist`).
- Shop Seller registration/dashboard source comparison: unchanged for `become-seller.tsx`, `seller/products.tsx`, and `seller/orders.tsx`.
- Full API runtime tests against MongoDB: NOT RUN (Motor/PyMongo packages and non-production MongoDB are unavailable in this environment).
- Frontend TypeScript/Expo/native build: NOT RUN (frontend dependency installation is not available in this environment).
- Real OTP/Aadhaar/PAN/document-provider verification: BLOCKED (authorized providers and credentials unavailable).

## Release classification

Delivery Partner onboarding: PARTIAL. Safe draft, encryption boundary, private owner retrieval, admin review state machine, referral attribution boundary and frontend entry points are implemented. Real identity verification, secure document upload, end-to-end approval, live database/API testing and native UI testing remain BLOCKED/NOT RUN. Do not declare production-ready or deploy.
