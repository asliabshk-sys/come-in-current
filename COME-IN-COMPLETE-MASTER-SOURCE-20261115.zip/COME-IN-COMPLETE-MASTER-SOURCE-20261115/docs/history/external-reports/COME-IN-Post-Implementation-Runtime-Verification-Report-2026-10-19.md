# COME-IN — Post-Implementation Runtime Verification Report
Date: 2026-10-19

## 1. Candidate verification and preservation
- Candidate: `COME-IN-Shop-Registration-Account-Only-Pre-APK-2026-10-19.zip`
- Expected SHA-256: `f9a7557143e19f9a680a1f1fbae20a5ee1a4d9f52a2ef17be3c6f87464500936`
- Actual SHA-256 before verification: exact match.
- Actual SHA-256 after verification: exact match.
- `unzip -t /mnt/data/COME-IN-Shop-Registration-Account-Only-Pre-APK-2026-10-19.zip`: PASS, `No errors detected in compressed data`.
- Extracted to a separate working directory for inspection. The candidate ZIP was not edited or overwritten.
- No project source/configuration files were changed during this verification. No new project ZIP was created.
- No APK was built.

## 2. Dependency restoration and frontend commands
The project declares `packageManager: yarn@1.22.22` in `frontend/package.json`. No `yarn.lock`, `package-lock.json`, or `pnpm-lock.yaml` exists anywhere in the candidate. `frontend/node_modules` is absent.

Attempted command:
```sh
cd frontend
corepack yarn@1.22.22 install --no-lockfile --ignore-scripts --non-interactive
```
Result: BLOCKED, exit 1. Corepack could not download Yarn because network/DNS access failed:
```text
Error when performing the request to https://registry.yarnpkg.com/yarn/-/yarn-1.22.22.tgz
TypeError: fetch failed
Error: getaddrinfo EAI_AGAIN registry.yarnpkg.com
```
No lockfile was created, removed, or modified. Dependencies could not be installed.

Commands and results:

| Command | Result | Observed output / reason |
|---|---|---|
| `npm run typecheck` | BLOCKED (exit 2) | TypeScript reports `tsconfig.json(2,14): error TS6053: File 'expo/tsconfig.base' not found`; numerous missing React/Expo modules and types, including `react` and `@react-native-async-storage/async-storage`. The resulting missing type/config errors are not a valid clean typecheck. |
| `npm run lint` | BLOCKED (exit 127) | `sh: 1: expo: not found` |
| `npm run build:web` | BLOCKED (exit 127) | `sh: 1: expo: not found` |
| `npm run start -- --non-interactive` | BLOCKED (exit 127) | `sh: 1: expo: not found` |

## 3. Shop registration entry-point verification
Static source audit and automated contract tests were executed. Actual rendered screens could not be launched because frontend dependencies are unavailable.

| Required check | Status | Evidence / limitation |
|---|---|---|
| Online Shops has no customer-facing registration entry point | PASS (source only); runtime BLOCKED | `frontend/app/shops.tsx` has no registration label or `/become-seller` navigation. Online and Offline use the same browsing component. No rendered-screen assertion was possible. |
| Offline Shops has no customer-facing registration entry point | PASS (source only); runtime BLOCKED | Same shared `shops.tsx` component; no registration button/link/card/banner or registration navigation found there. No rendered-screen assertion was possible. |
| Approved/customer-visible shops still appear | PASS (source contract); live runtime BLOCKED | `shops.tsx` still requests `GET /shops`, normalizes and merges returned shops with seed data, renders `shops-list`, and navigates to `/shop/{id}`. Backend `GET /shops` filters to `status: approved`; `/shops/{shop_id}` rejects non-approved shops. No live database was available to confirm actual records. |
| Search, filters, shop details, shopping navigation retained | PASS (source contract); runtime BLOCKED | Search input, All/Online/Offline tabs, open-now/delivery filters, offline category filters, shop rows and shop-detail navigation remain in source. No browser interaction was run. |
| Account > Add Your Shop opens all four modes | PASS (source only); runtime BLOCKED | Account source defines Online Shop, Offline Shop, Restaurant and Home Services; test IDs exist for each mode. Online/Offline route to `/become-seller`, Restaurant to `/restaurant/dashboard`, and Home Services to `/services?openRegistration=1`. No actual taps/navigation were executed. |
| Shop Products empty state directs to Account and has no duplicate registration button | PASS (source only); runtime BLOCKED | Empty state text says to open Account and choose Add Your Shop; no direct `/become-seller` button/navigation found in this screen. |
| Shop Orders empty state directs to Account and has no duplicate registration button | PASS (source only); runtime BLOCKED | Empty state text says to open Account and choose Add Your Shop; no direct `/become-seller` button/navigation found in this screen. |
| Unauthorized shop registration is prevented | PASS (source inspection); live API status BLOCKED | `POST /shops` depends on `get_current_user`; unauthenticated requests are defined to return 401. Actual HTTP request was not executed. |
| Non-admin shop approval is prevented | PASS (source inspection); live API status BLOCKED | `PATCH /admin/shops/{shop_id}/status` depends on `require_role("admin")`; the dependency is defined to return 401 when unauthenticated and 403 when authenticated with a disallowed role. Actual HTTP requests and test-account checks were not executed. |
| Restaurant Mode theme/branding unchanged | PASS for this verification | No project source, assets, or configuration files were modified during this verification. Runtime visual comparison could not be performed. |

## 4. Exact source audit commands
```sh
rg -n -i 'add your shop|register your shop|register shop|become-seller|openRegistration|Add Your Shop|Open your shop|register.*shop|shop.*register' frontend/app
rg -n '"/shops"|@api.get\("/shops|shops.find' backend/server.py
rg -n -A35 -B5 'async def list_shops|@api.get\("/shops"\)' backend/server.py
```
The only remaining shop-registration wording found was in Account, the registration form/auth copy, and Shop Products/Shop Orders empty-state guidance. The latter two are text-only directions to Account, not direct registration entry points. The generic sign-in description in `auth.tsx` says “open your shop” but is not an Online/Offline browsing-page entry point.

## 5. Backend tests and startup
Commands:
```sh
cd backend
PYTHONPATH=. python -m pytest -c /dev/null -q tests/test_shop_registration_browse_entrypoints.py
PYTHONPATH=. python -m pytest -c /dev/null -q tests
python -m py_compile server.py restaurant_pricing.py restaurant_serviceability.py
python -c 'import server'
```
Results:
- Targeted entry-point tests: PASS, `4 passed in 0.04s`.
- Full backend tests: PASS, `166 passed, 23 skipped in 0.91s`.
- Python syntax check: PASS, exit 0.
- Backend startup/import: BLOCKED, exit 1:
```text
ModuleNotFoundError: No module named 'bcrypt'
```
The live backend could not be started; no live MongoDB/database connection or authorized test accounts were available. Therefore actual HTTP status codes (401/403) were not observed and are not claimed as runtime PASS.

## 6. Defects / blockers discovered and fixes
No code defects were changed in this verification pass; no project files were modified.

Environment blockers:
1. The candidate has no frontend package-manager lockfile, so dependency resolution is not reproducible from a lockfile.
2. Corepack cannot download Yarn due `EAI_AGAIN registry.yarnpkg.com`.
3. Frontend dependencies are absent; typecheck, lint, web build and app startup are blocked.
4. Backend import/startup is blocked by missing `bcrypt`.
5. Live database, browser automation and authorized/unauthorized test accounts were unavailable; live shop visibility, tap-through flows, and actual 401/403 HTTP responses remain unverified.

## 7. Final artifact
Because no project files were changed, no new project ZIP was produced. The original candidate remains the final artifact:
- ZIP: `COME-IN-Shop-Registration-Account-Only-Pre-APK-2026-10-19.zip`
- SHA-256: `f9a7557143e19f9a680a1f1fbae20a5ee1a4d9f52a2ef17be3c6f87464500936`
- ZIP integrity: PASS.
