# COME-IN — Online Shop Product Listing, Pricing & Description

**Date:** 2026-10-19  
**Starting candidate:** `COME-IN-Secure-Earnings-Dashboards-Pre-APK-2026-10-19.zip`  
**Expected and observed starting SHA-256:** `79216c4bdb9c781f253ffbfea44657eea93e460661e6a36b8f211a007703f422`  
**Starting ZIP integrity:** `unzip -t` passed before extraction.

## Feature inventory

| Requirement | Status | Evidence / note |
|---|---|---|
| Existing seller product management route | Present and extended | `frontend/app/seller/products.tsx` |
| Create/edit/deactivate own-shop product | Present in existing system | Uses existing `/shops/{shop_id}/products`, `/products/{id}` endpoints; server ownership checks retained |
| Product name, category, INR selling price, description | Extended and validated | Required nonblank name/category/description; positive bounded price; MRP must not be below price |
| Product image | Existing upload mechanism reused | Existing `api.upload` path remains; web image picker is supported in this screen |
| Price/quality explanation prompt | Newly added | Seller guidance explains real quality/material/freshness/brand/quantity/packaging/warranty differences; Hindi examples are examples only |
| Variants and stock | Existing flow retained and stricter validation added | Variant IDs, positive price, integer stock and MRP checks on the form/schema |
| Pending shop draft products | Newly enabled for owner | Owner may view/manage private product drafts while shop is pending; unrelated callers still receive 404 |
| Public product catalog | Existing implementation retained | `/catalog/products` only uses approved shops, available listings and in-stock products/variants |
| Customer catalog description preview | Newly added | Live ProductCard shows a two-line description preview |
| Full product description | Present | Existing product detail screen renders description as ordinary React Native text, not injected HTML |
| Cart/checkout price | Existing server-side rule retained | `CartLine.price` is documented as ignored; checkout resolves authoritative saved price |
| Multiple shops per owner | Not supported by current project model | Existing shop registration explicitly enforces one shop per owner in this MVP; no parallel ownership model added |

## Files changed

- `backend/server.py`
  - Product schema now rejects non-positive/overly large selling prices, overly large stock, blank name/category/description, and oversized image URLs; text fields are trimmed and Unicode descriptions are preserved.
  - Product variant selling prices must be positive and bounded.
  - `/shops/{shop_id}/products` allows the authenticated owner (or Admin) to view a pending shop's drafts while preserving public 404 behavior for non-owners; approved shop products continue to be returned as before.
- `frontend/app/seller/products.tsx`
  - Required-field and price/MRP/stock/variant checks.
  - Added “Description / Why is this product priced this way?” guidance with illustrative Hindi examples and a warning not to invent claims.
  - Shows pending/suspended shop status and clarifies drafts are not public until approval.
  - Added safe loading error handling.
- `frontend/app/become-seller.tsx`
  - Existing shop page's product entry now reads “Add item / manage products”.
- `frontend/src/components/ProductCard.tsx`
  - Shows a two-line description preview for real live listings.
- `backend/tests/test_online_shop_product_listing_contract.py` (new)
  - Static contracts for validation, private pending drafts, approved catalog filtering, seller form and description rendering.

## Test results

| Check | Result | Type / limitation |
|---|---|---|
| Starting ZIP SHA-256 | PASS | Exact match before edits |
| Starting ZIP integrity | PASS | `unzip -t` before edits |
| Python syntax | PASS | `python -m py_compile backend/server.py backend/financial_rules.py backend/referral_rules.py` |
| Backend regression suite | **195 passed, 23 skipped, 0 failed** | Run from `backend`: `PYTHONPATH=. python -m pytest -c /dev/null -q tests` |
| Changed TSX syntax/transpile | PASS for 3 files, 0 syntax diagnostics | TypeScript `transpileModule`; not a full typecheck |
| Full frontend typecheck | BLOCKED / failed due to unavailable dependencies and base config | `npm run typecheck` exited 2; missing React Native/Expo modules and TypeScript standard library diagnostics; `node_modules` absent |
| Frontend lint | BLOCKED | `npm run lint` exited 127: `expo: not found` |
| Web build | BLOCKED | `npm run build:web` exited 127: `expo: not found` |
| Backend import / live API / MongoDB | NOT RUN successfully | Environment lacks runtime dependencies/secrets and a configured test MongoDB; source-level contracts do not prove end-to-end behavior |
| Replit / device UI | NOT RUN | App was not launched in Replit or on a device |
| APK | NOT built | Explicitly excluded from this task |

## Security and behavior notes

- Product writes continue to use authenticated endpoints and server-side shop ownership checks; client-supplied owner/role values are not used to grant access.
- Public catalog visibility continues to depend on approved shop status and available stock. Pending-shop products remain drafts and are not included in the public catalog.
- Descriptions are rendered using React Native `Text`, not an HTML injection mechanism. HTML-looking content therefore remains text rather than being executed.
- Existing checkout uses backend-resolved prices; this task did not alter the order/checkout model or Restaurant Mode theme/branding.
- Existing image upload support is reused; this task does not add a new cloud image provider or change upload deployment configuration.
- Because frontend dependencies and live MongoDB were unavailable, do not describe the UI/API as end-to-end verified or production-ready.

## Remaining blockers / next actions

1. Restore the project's compatible Yarn/Expo dependencies using the declared package manager (`yarn@1.22.22`) when registry/cache access is available.
2. Run full TypeScript typecheck, lint, and web build after dependency installation.
3. Start the backend with configured secrets and a safe MongoDB test database; exercise create/edit/list/public-catalog/checkout and cross-shop authorization end to end.
4. Verify product photo upload in the actual target runtime; the current seller screen's file-picker path is web-only.
5. Keep the existing one-shop-per-owner restriction unless a separately designed, tested multi-shop ownership migration is approved.

## Packaging

The standalone project ZIP excludes `node_modules`, Python caches, `.pytest_cache`, `.pyc` files, and private `.env` files. Example environment templates are retained. The source candidate and historical ZIPs were not edited.
