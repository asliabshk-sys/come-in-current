# COME-IN P0 Continuation — Shop registration, payment choices and checkout

Date: 2026-10-19

## Base candidate verification and preservation
- Base: `COME-IN-P0-CONTINUATION-CANDIDATE-Pre-APK-2026-10-19.zip`
- Base SHA-256: `fbbaf1ecbb1ab159aecc1c2fe80108a93db2f26581f871a8643f7c48c3d7c2db`
- Base size: 4,000,430 bytes
- Base ZIP integrity: PASS (`unzip -t`)
- Work performed in a separate extraction directory; base candidate and earlier ZIP backups were not overwritten.
- No APK was built; no Replit/Preview launch or deployment was performed.
- Restaurant theme/branding assets were not changed. Existing Excel/CSV import source was preserved.

## Additional source changes

1. `backend/server.py`
   - Grocery order request now accepts the shop's actual configured `cod`, `upi`, `cash_shop`, and `pickup` methods. Stripe/Razorpay Grocery methods still fail closed because that customer checkout integration is not configured.
   - The server validates the selected method against the resolved shop, re-checks settings inside the stock transaction, requires a configured UPI ID for UPI orders, and prevents cash-at-shop/pickup payment for delivery orders.
   - UPI order creation stores a server-generated `upi://pay` intent with the exact order amount, INR currency, shop UPI ID and COME-IN order reference. UPI orders remain `pending_payment` / `awaiting_upi_payment` and are not marked paid by a client callback.
   - Added owner/admin-only `POST /orders/{order_id}/confirm-upi-payment`. The shopkeeper must check their bank/UPI statement before confirming receipt; the endpoint then marks the order paid and moves it to the seller's pending queue. This is manual verification, not automatic gateway/bank verification.
2. `frontend/app/checkout.tsx`
   - Displays COD, UPI and cash-at-shop/pickup only when enabled and applicable to that shop and fulfillment choice.
   - UPI selection creates a pending order and offers to open the device's UPI app using the order-specific payment URI. The UI explicitly says payment is not confirmed until the shopkeeper verifies the credit.
3. `frontend/app/seller/orders.tsx`
   - Shows payment status and adds an owner-side UPI receipt confirmation action for orders awaiting UPI confirmation.
4. `frontend/app/become-seller.tsx`
   - Updated UPI help text to accurately explain UPI-app initiation and manual bank-statement verification. Existing shop profile creation/update API calls and fields remain in place.
5. `frontend/app/restaurant/dashboard.tsx`
   - New restaurant registration and profile editing now expose saved COD and pay-at-pickup choices; at least one method must be selected. Online-only Razorpay is not advertised as usable until a customer-facing payment screen is integrated.
6. `frontend/app/restaurant/checkout.tsx`
   - Loads the selected restaurant's saved payment settings and offers its enabled COD and pickup methods only. It no longer blindly submits a payment method that the restaurant has disabled.
7. Tests
   - Added source-contract regression coverage for UPI intent, pending/manual verification, seller confirmation, per-shop choices and restaurant payment settings. Updated older contract expectations to match the safer UPI flow.

## Verification performed
- `python -m py_compile backend/server.py backend/restaurant_pricing.py backend/restaurant_serviceability.py`: PASS.
- `cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests`: **163 passed, 23 skipped, 0 failed**.
- Frontend TypeScript syntax check was attempted with the globally available `tsc`; no TS1xxx syntax diagnostics were reported for changed files, but full typecheck is **BLOCKED** because `frontend/node_modules` is absent (React/Expo/React Native declarations and project base config cannot resolve).
- Frontend lint and web build remain **BLOCKED** because Expo dependencies are not installed.
- Backend startup remains **BLOCKED** by the previously observed missing `bcrypt` dependency.
- No live MongoDB persistence test, browser UI run, UPI app launch, real bank payment or end-to-end order run was performed in this environment.

## Honest completion status

- Restaurant Delivery Area panel: **source remains removed**; rendered browser confirmation still pending.
- Quantity/variant, Add to Cart and Buy Now: existing variant-aware flow and the previous Buy Now fix are preserved; browser-to-checkout end-to-end test remains pending.
- Add New Shop: existing authenticated shop create/update and `/shops/mine` flow is preserved; live DB persistence/refresh verification remains pending.
- Add New Restaurant: registration form saves the chosen COD/pickup settings; live DB persistence/refresh verification remains pending.
- Per-shop COD/cash-at-shop/pickup: UI and backend enforce selected shop settings at order creation; live multi-shop integration remains pending.
- UPI: **UPI app initiation is implemented**, and the seller has a manual receipt-confirmation workflow. **Automatic payment verification/settlement is NOT implemented.** A direct UPI URI cannot prove that money reached the shop. A verified provider integration with shop-specific settlement/credentials or a supported marketplace settlement setup is still required for automatic confirmation. No order is marked paid just because the customer opened the UPI app.
- Grocery Stripe/Razorpay and Restaurant Razorpay customer UI: not presented as functional in checkout until the customer-facing integration is completed and configured.

This is an improved pre-APK candidate, not a claim that live payment processing and every end-to-end path has been fully verified.
