# CHAND AI — Phase 3 Provider and Mobile Integration

Updated: 12 November 2026
Status: **PARTIAL — native integration source added; dependency installation, live services and device verification remain blocked**

## 1. Native mobile packages and permissions

The frontend targets Expo SDK 58. The mobile integration now declares these SDK-matched packages in `frontend/package.json`:

- `expo-image-picker ~58.0.10` — system camera and gallery picker.
- `expo-audio ~58.0.12` — native microphone recording.

The SDK 58 Expo reference lists these versions as compatible. References: [Expo ImagePicker SDK 58](https://docs.expo.dev/versions/v58.0.0/sdk/imagepicker/) and [Expo Audio SDK 58](https://docs.expo.dev/versions/v58.0.0/sdk/audio/).

`frontend/app.json` includes both config plugins. The image-picker plugin supplies photo-library and camera permission descriptions and disables its duplicate microphone permission; `expo-audio` supplies the microphone permission. Background recording is disabled. A new native binary is required for these config-plugin changes to take effect.

**Important dependency blocker:** the existing `frontend/yarn.lock` could not be regenerated in this environment. `yarn` was not installed, and Corepack could not download the repository-pinned Yarn 1.22.22 because DNS resolution for `registry.yarnpkg.com` failed (`EAI_AGAIN`). `package.json` is updated, but the lockfile remains unchanged. Do not use a frozen-lockfile install until the lockfile is refreshed in a network-enabled project environment.

When registry access is restored, from `frontend/` run:

```bash
corepack yarn --version
corepack yarn expo install expo-image-picker expo-audio
corepack yarn typecheck
corepack yarn expo-doctor
```

Review the resulting `yarn.lock` diff before accepting it. Do not upgrade the Expo SDK as part of this task.

## 2. Photo shopping — frontend flow now wired

`frontend/app/chand.tsx` now provides:

- Camera and gallery permission requests, with actionable denial messages.
- Camera capture and gallery selection.
- Image preview, replace and cancel controls.
- Authenticated `api.chandVision` upload using the existing multipart helper.
- Indeterminate upload/search state and request error handling.
- Recognized product clues and actual public catalog matches returned by the backend.
- Explicit customer confirmation. Fixed-pack products can be sent to the existing Cart; measured or variant products open the existing product page so the customer chooses the Task 5 amount or exact variant.

Backend accepts JPEG, PNG and WebP only, maximum 5 MB. Unsupported image formats are rejected by the backend with a visible error; use a supported image format. Uploaded bytes are processed in memory and are not stored by the endpoint.

The upload UI shows a busy/progress state but does **not** report a percentage: the existing Expo fetch multipart helper does not expose byte-level upload progress. No simulated percentage is shown.

## 3. Voice shopping — frontend flow now wired

`frontend/app/chand.tsx` now provides:

- Native microphone permission request.
- Start, stop/transcribe and cancel recording controls.
- 90-second recording cap.
- Auto, Hindi and English language selection.
- Authenticated `api.chandTranscribe` multipart upload.
- Transcription placed into the editable message field for customer review.
- The customer must press Send to search the live COME-IN catalog; recording/transcription does not automatically submit a shopping query.
- Permission, recording and network/provider errors are shown in the UI.

Recording is configured as an MP4/M4A-compatible upload (`audio/mp4`). The backend accepts this MIME type and returns transcript text only; audio is not persisted by the endpoint. Actual codec/container compatibility still requires Android and iOS device testing.

## 4. Live AI provider configuration

The backend already has OpenAI-compatible and Ollama adapters in `backend/server.py`. The `/assistant/context` endpoint retrieves approved public catalog data first, passes bounded session history and that data to the configured provider, and returns the provider answer plus actual catalog matches. If the provider is unavailable, the app falls back to catalog-grounded text and labels the request as unavailable/offline guidance.

Configure secrets only in the backend deployment secret manager:

- `COMEIN_AI_PROVIDER=openai_compatible`
- `COMEIN_AI_BASE_URL=https://<provider-host>/v1`
- `COMEIN_AI_API_KEY=<secret>`
- `COMEIN_AI_MODEL=<multimodal chat/vision model>`
- `COMEIN_STT_MODEL=<provider-supported transcription model>`

The provider must support the OpenAI-compatible `/chat/completions` endpoint with image input and `/audio/transcriptions` for voice. For Ollama, set `COMEIN_AI_PROVIDER=ollama`, a reachable `COMEIN_AI_BASE_URL`, and an installed vision-capable `COMEIN_AI_MODEL`; the current speech endpoint requires an OpenAI-compatible transcription API and does not use Ollama for speech.

The Chand header reports configuration as unverified until an actual `/assistant/context` request returns a non-empty provider answer. A successful live provider request has **not** been performed in this execution because no owner credentials or reachable provider endpoint were supplied. `GET /assistant/health` is configuration-only and sets `live_probe: false`.

## 5. Budget and party planner integration

The existing budget list now accepts current live fixed-pack products, selected variants and measured Task 5 products. It supports quantity editing/removal, uses the existing measured price calculation for estimates, refreshes `/catalog/products` before transfer, obtains `/grocery/measured-price` quotes for measured items, validates current variant/pack stock, and transfers through the existing Cart API/context. Checkout remains authoritative for final price and stock.

The party planner continues to collect occasion, guest count and budget, then searches the real public catalog through Chand. The returned catalog matches can be added to the same editable budget list, including measured items and variants. This is still a guided catalog-assisted planner, not a deterministic per-guest quantity optimizer or fully automated substitution engine. Customers must review and confirm the Cart transfer; no purchase is made automatically.

## 6. Database verification

No non-production MongoDB URI or running MongoDB replica set was supplied. Feedback persistence, unique/deduplication indexes, TTL expiry, rate limiting, validation, admin authorization and error handling therefore remain unverified against a live database. Existing source-level tests remain available. Do not point this test run at production data.

## 7. Verification results and release gates

- Focused Chand, Task 5, Cart, Checkout, Restaurant and Support regression: **130 passed / 0 failed across 19 modules**.
- `python -m py_compile backend/server.py`: PASS.
- TypeScript syntax transpilation: PASS for 89 TS/TSX files with 0 syntax diagnostics (syntax only; not semantic typechecking).
- Semantic TypeScript typecheck: BLOCKED because `frontend/node_modules` and `expo/tsconfig.base` are unavailable.
- Expo dependency validation, Metro bundle and Android/iOS build: BLOCKED because dependencies/Expo CLI are unavailable and `yarn.lock` is stale relative to the newly declared dependencies.
- Android/iOS photo picker, microphone, codec, upload and end-to-end tests: NOT RUN; no Android/iOS device or build toolchain is attached.
- Live AI provider: BLOCKED; credentials/reachable endpoint not supplied.
- Non-production MongoDB verification: BLOCKED; separate MongoDB replica set not supplied.
- Full backend suite: current collection attempt stopped with 4 errors (three runtime tests require absent `/app/frontend/.env`; Task 5 live MongoDB test requires unavailable `bson`). No full-suite pass is claimed.

**Release decision: PARTIAL. Chand is not FULLY LIVE and is not production ready.**
