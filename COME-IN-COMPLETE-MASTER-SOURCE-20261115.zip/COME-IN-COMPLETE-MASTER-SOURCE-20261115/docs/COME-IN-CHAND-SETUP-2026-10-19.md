# CHAND assistant setup

1. Configure the normal COME-IN backend variables in `backend/.env` or the deployment secret manager (`MONGO_URL`, `DB_NAME`, `JWT_SECRET`). Never commit `.env` or real secrets.
2. For database-grounded retrieval without a generative model, no AI credentials are required. The `/api/assistant/context` endpoint returns bounded public approved listings from the configured database.
3. To enable the optional OpenAI-compatible answer adapter, configure all three server-side variables:
   - `COMEIN_AI_BASE_URL` — provider API base URL (the adapter appends `/chat/completions`)
   - `COMEIN_AI_API_KEY` — secret key, stored only in deployment secrets/backend environment
   - `COMEIN_AI_MODEL` — provider model identifier
4. Restart the backend after changing environment variables. The frontend must point `EXPO_PUBLIC_BACKEND_URL` at this backend.
5. Test against a non-production MongoDB database first. Verify that approved shops/products/restaurants/services are discoverable and pending/unapproved listings are not exposed.
6. The current workspace lacks frontend dependencies and the `bcrypt` Python package, so live app startup and provider/database integration testing remain blocked. See the implementation report.

The provider adapter is retrieval-grounded but not a guaranteed factuality boundary. Continue to validate all prices/stock at checkout and keep consequential actions in the existing authenticated APIs.


## Optional open-source local AI (Ollama)

- Set `COMEIN_AI_PROVIDER=ollama`.
- Set `COMEIN_AI_MODEL` to the exact model name already installed with Ollama (for example, a model you have pulled locally).
- Set `COMEIN_AI_BASE_URL=http://127.0.0.1:11434` only when Ollama and the COME-IN backend share the same host/network namespace. If backend runs in a container, use the reachable host/service address instead; do not expose Ollama publicly without access controls.
- Leave `COMEIN_AI_API_KEY` blank for the native Ollama adapter. It calls `/api/chat`, sends `stream=false`, and uses a 30-second timeout.
- Ollama software and open model weights may be usable without per-token cloud fees, but hardware, electricity, disk, and hosting can cost money. Model licences vary; verify the selected model's licence before redistribution or commercial use.
- This configuration is optional and was not live-tested in the current offline workspace. Without a reachable provider, CHAND should fall back to the existing database-grounded result response.


## 2026-11-12 integration update

- The Chand screen now renders current public catalog results with existing product cards. The backend context response includes product IDs, image URLs, brand, variants and existing Task 5 `sell_by` / `measure` fields.
- The frontend reuses existing cart/product-detail/checkout behavior; measured products must continue through the existing measured picker and server quote. Do not add a second pricing implementation.
- Up to eight recent user/assistant turns can be supplied in the context request for the optional provider. They are not stored in MongoDB.
- The provider system prompt restricts Chand to COME-IN products, shops, services and application help; current catalog facts must come only from the supplied approved-listing context.
- Hindi, English and Roman-Hindi/Hinglish matching is requested in the provider prompt. Actual language quality depends on the configured provider/model and has not been live-tested.
- Header microphone entry opens the Chand composer and focuses the text field. On supported devices the user may use the OS keyboard microphone; this is not an in-app speech-recognition implementation. Review the transcript and press Send.
- Product/shop fulfillment labels show the shop type and shop-declared delivery/pickup flags only. These do not confirm address-level serviceability; existing checkout/backend validation remains authoritative.
- No Chand API key belongs in frontend `.env` or the app bundle. Provider credentials remain backend/deployment secrets.
- Current unresolved capabilities: native speech-to-text permission/recognition, image picker + OCR/vision, budget list optimizer/editor, persistent conversation history, dedicated Chand feedback/Admin review and live provider/runtime verification.
