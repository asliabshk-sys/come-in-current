# Universal Catalogue Import — Security Report

## Implemented source-level controls

- Per-file 10 MiB, total batch 20 MiB, max 20 uploaded files; extracted record cap 10,000.
- Filename must be present, at most 255 characters, and contain no ASCII control characters. Path separators are normalized before display/provenance use; names are never used as local filesystem destinations.
- Extension/content signatures are checked. Specific MIME types must match the extension; neutral `application/octet-stream` is accepted for formats where browsers commonly send it.
- CSV encoding is UTF-8/UTF-8-BOM; empty/malformed header rows are rejected. Source cells are retained literally and are not evaluated.
- XLSX internal ZIP member count, expanded size and compression ratio are bounded. Workbook reads are read-only/data-only; formulas are not executed.
- ZIP archive member count, total uncompressed bytes, compression ratio, encryption and path traversal are checked; entries are read in memory and not extracted to disk.
- PDF page count is capped at 100. Scanned OCR is optional, limited to five textless pages and 20 MP per page, with OCR timeout.
- Image decoding is validated and capped at 40 MP; OCR is bounded by a timeout. OCR text is marked unverified and is not normalized into price/stock automatically.
- CHAND receives uploaded text as untrusted data with explicit system-level instruction to ignore embedded commands. No tool execution is exposed by this adapter.
- CHAND suggestions require exact source reference, evidence snippet contained in source text, suggested value contained in the snippet, allowed field name, and valid finite nonnegative numeric values for price/MRP/stock. Confidence is finite and clamped to [0,1].
- CHAND provider request uses bounded connect/read timeout and one retry for transient failures. Provider errors retain source extraction and no suggestions.
- Seller APIs scope jobs by `shop_id` and `seller_id`, and verify shop ownership. Review mutations are locked after seller apply confirmation.
- Imported Product documents require both `catalogue_import_approved == true` and `catalogue_import_applied == true`; legacy products without import provenance retain existing eligibility rules.

## Tests added/executed

- MIME/extension mismatch rejected; octet-stream accepted only after signature validation.
- Control-character filename rejected.
- ZIP path traversal rejected.
- Formula-like CSV text preserved literally; not executed.
- CHAND prompt-injection text remains in data payload while system prompt marks it untrusted.
- Unsupported/non-finite/negative numeric suggestions rejected.
- Transient provider failure retried once; no real provider call used.
- Review actions locked after apply-confirmation state.
- Scanned PDF synthetic OCR tested; output remains `NEEDS_REVIEW` and does not populate price/stock.

## Residual risks / limitations

- No antivirus/malware scanner is integrated.
- Raw source files are not retained as downloadable blobs; provenance is filename, source location and SHA-256 plus extracted source values/text.
- Cross-job duplicate upload detection and concurrency-safe idempotency require a MongoDB unique index/transaction; current duplicate detection is per upload batch.
- Seller review array updates are source-level, but concurrent edits/approvals need conditional version/CAS protection in the live database integration.
- Category existence is not revalidated against a canonical category collection by the current preflight helper; Emergent must revalidate against actual category records before Product insert.
- A system prompt cannot mathematically guarantee LLM obedience; strict output/evidence validation is the actual enforcement boundary.
- PDF OCR and image OCR accuracy are not guaranteed. OCR output never becomes verified product data automatically.
- `.xls` requires `xlrd`, absent in the current environment. The legacy endpoint already advertises `.xls`; this new engine now routes it to the optional adapter and reports the missing dependency.
- No live API, authentication session, MongoDB, provider or production security test was performed.

**Conclusion:** Useful offline hardening is in place, but this is not a security certification or production approval.
