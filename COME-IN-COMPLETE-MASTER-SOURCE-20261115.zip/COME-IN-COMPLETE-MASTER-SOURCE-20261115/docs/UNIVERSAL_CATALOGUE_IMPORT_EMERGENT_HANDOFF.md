# Universal Catalogue Import — Emergent Integration Handoff

**Purpose:** Complete the final Product/stock application step using the existing COME-IN MongoDB deployment. This document is a source-level contract only. Codex did not connect to MongoDB or execute transactions.

## Existing source APIs

All routes are authenticated with `get_current_user`, fetch the shop and call `_assert_shop_owner(shop, user)`. Job-level access also binds `job_id`, `shop_id`, and `seller_id`.

| Method | Path | Purpose |
|---|---|---|
| POST | `/shops/{shop_id}/catalogue-import/jobs` | Upload/extract, optional CHAND suggestion, stage job |
| GET | `/shops/{shop_id}/catalogue-import/jobs` | List seller's jobs |
| GET | `/shops/{shop_id}/catalogue-import/jobs/{job_id}` | Job detail and record preview |
| GET | `/shops/{shop_id}/catalogue-import/categories` | Existing category IDs used by master/shop products |
| PATCH | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}` | Seller edits supported fields |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/approve` | Validate and approve one record |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/reject` | Reject one record |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/bulk-approve` | Approve only complete eligible records; uncertain AI rows are skipped |
| POST | `/shops/{shop_id}/catalogue-import/jobs/{job_id}/confirm-apply` | Requires `{"confirm":true}`; sets `APPLY_PENDING_EMERGENT`, does not write Product/stock |

After `APPLY_PENDING_EMERGENT`, Codex source now locks edit, approve, reject and bulk-approve actions. The final transaction processor is not implemented here.

## Staging document shape

Collection: `catalogue_import_jobs`.

```json
{
  "job_id": "uuid",
  "shop_id": "existing shop id",
  "seller_id": "authenticated owner id",
  "status": "APPLY_PENDING_EMERGENT",
  "source_files": [{"filename":"stock.csv","detected_type":"csv","sha256":"...","pages_or_sheets":1,"warnings":[]}],
  "records": [{
    "source_file":"stock.csv", "source_location":"row:2", "source_sha256":"...",
    "raw_values":{"Product":"Rice","Price":"65"},
    "normalized":{"name":"Rice","price":"65","stock":null},
    "seller_edited_fields":{"stock":"10","category_id":"existing-id"},
    "review_status":"APPROVED", "approved_by":"seller-id", "approved_at":"...",
    "chand":{"source_reference":{},"extracted_fields":{},"suggested_fields":{},"confidence":{},"field_evidence":{},"missing_fields":[],"uncertain_fields":[],"duplicate_candidates":[],"review_status":"NEEDS_REVIEW"}
  }],
  "applied": false,
  "seller_confirmed_by": "seller-id",
  "seller_confirmed_at": "..."
}
```

The schema above is representative, not a MongoDB validator/migration. The raw upload binary is not persisted by this source workflow.

## Existing Product model and Task 5 rules

- Product collection is `db.products`; Product request schema is `ProductIn` / `ProductVariantIn`.
- Stock is stored on Product (`stock`) and on `variants[].stock` where variants are used; do not invent a separate inventory collection.
- Fixed-pack products preserve legacy behavior.
- Measured products use existing `sell_by`, `measure`, `MEASURED_SELL_BY`, `_import_measure`, and integer base-unit stock contract. Do not convert base units or recompute prices independently.
- Customer catalogue publication for legacy products without import markers remains governed by existing shop approval, availability and positive stock rules. Imported products carrying import provenance require `catalogue_import_approved is True` AND `catalogue_import_applied is True`.
- Existing checkout re-resolves cart lines through backend quote/availability checks. Preserve those contracts.

## Required transaction contract

1. Start a MongoDB session/transaction using the same deployment-supported pattern as existing legacy import.
2. Re-read job and shop inside the transaction; verify current authenticated seller still owns the shop.
3. Require `status == APPLY_PENDING_EMERGENT`, `applied != true`, matching `seller_confirmed_by`, and explicit confirmation timestamp.
4. Claim job with a conditional atomic state update; only one concurrent worker may win.
5. Revalidate each approved record using current `ProductIn`, `_import_measure`, category existence, price/stock bounds, SKU uniqueness and variant rules.
6. Refuse records not `APPROVED`, already mapped to a Product, or carrying invalid/missing source provenance.
7. Use deterministic idempotency key `catalogue-import:{shop_id}:{job_id}:{record_index}` and a reviewed unique index on `(catalogue_import_job_id, catalogue_import_record_index)` (partial filter for imported records). Reconcile ambiguous commit before retry.
8. Insert Product and initial stock in the same transaction. Set server-controlled `shop_id`, owner, `catalogue_import_job_id`, record index, source metadata, `catalogue_import_approved:true`, `catalogue_import_applied:true`; do not trust client-supplied ownership/publication markers.
9. Store resulting Product ID per staging record. Mark records `APPLIED`, job `applied:true`, status `APPLIED`, and persist bounded results in the same transaction.
10. Commit. Customer visibility becomes possible only after successful commit. On any failure abort the entire job batch (unless product owner approves a documented chunked model).

## Atomicity, retry and rollback

- Product insertion and initial stock must be atomic.
- Do not perform a second stock increment after insert.
- A repeated request with same idempotency key returns the prior Product ID and must not add stock again.
- On validation/unique-index/write/audit failure, rollback every Product and stock change in the batch.
- If client timeout makes commit ambiguous, read job/idempotency records before retrying.
- No `APPLIED` marker may survive an aborted transaction.
- Conditional job claim must protect concurrent confirmations/workers.

## Cross-shop security

Re-fetch shop and verify `owner_id == authenticated_user.id` immediately before application. All job lookups and updates bind `job_id + shop_id + seller_id`. Never trust `shop_id`, seller ID, product owner, category, price, stock, or publication flags supplied by frontend. Cross-shop attempts must fail without disclosing job existence or contents.

## Emergent verification sequence

1. Confirm MongoDB topology supports multi-document transactions and record server version/topology in sanitized evidence.
2. Verify deployment DB user's least-privilege read/write/index rights; never print credentials.
3. Check for existing duplicate import provenance before adding the unique index.
4. Apply reviewed unique index and verify its definition.
5. Apply one approved record; verify Product fields, stock, source provenance, job status and customer visibility after commit.
6. Apply multiple records; force a mid-batch error and verify full rollback.
7. Send concurrent confirm/worker requests; prove exactly one applies.
8. Retry after normal timeout and simulated ambiguous commit; prove no duplicate Product and no double stock.
9. Attempt cross-shop list/detail/edit/approve/reject/confirm/apply.
10. Verify pending/unapproved/rejected/unapplied products are hidden and rejected by cart quote/checkout.
11. Verify legacy products remain visible under existing rules.
12. Verify fixed-pack, variants, measured base units, stock deduction, cancellation restoration and concurrency.
13. Run Restaurant Mode catalogue/order/pricing regression against the actual deployment.
14. Capture commit/abort logs, test IDs, index definition, sanitized errors and final acceptance report.

**Reserved for Emergent:** All live MongoDB operations above. Do not execute from Codex/offline workspace.

## Existing live transaction test and exact command

The repository includes `backend/tests/test_task5_live_mongo_transactions.py`. It creates synthetic `TEST T5` users, shops, products and orders, then removes those synthetic records at module teardown. It currently verifies existing Task 5 checkout transactions and the **legacy** product CSV import transaction; it does **not** yet exercise the new `catalogue_import_jobs` → approved record → Product creation flow.

Run only against a disposable, non-production Emergent replica-set deployment with the backend already running and dedicated test admin credentials. From the `backend/` directory, provide environment variables through the approved secret manager (never paste them into logs):

```bash
EXPO_PUBLIC_BACKEND_URL="$EXPO_PUBLIC_BACKEND_URL" \
MONGO_URL="$MONGO_URL" \
DB_NAME="$DB_NAME" \
COMEIN_TEST_ADMIN_EMAIL="$COMEIN_TEST_ADMIN_EMAIL" \
COMEIN_TEST_ADMIN_PASSWORD="$COMEIN_TEST_ADMIN_PASSWORD" \
python -m pytest tests/test_task5_live_mongo_transactions.py -q
```

This is a pre-existing Task 5 transaction regression command, not acceptance of the new universal-import transaction. Emergent must additionally add and run live integration tests for the new staging workflow covering one/multi-record commit, mid-batch rollback, duplicate idempotency key, concurrent confirm/apply, retry after ambiguous commit, cross-shop isolation, and post-commit catalogue/cart/checkout publication. Never point this synthetic-data suite at production.
