# COME-IN Ultimate Consolidation — Source Inventory

Date: 2026-10-19. Inventory is limited to archives physically present in `/mnt/data` during this consolidation. Every archive listed below was SHA-256 hashed and passed `unzip -t`. Existing archive files were preserved; none was overwritten or deleted.

| Archive | Size (bytes) | SHA-256 |
|---|---:|---|
| `COME-IN-AI-Assistant-Fully-Connected-Multilingual-Pre-APK-2026-10-19.zip` | 3,846,118 | `66cacb94fb706fb67885876212fe5d87496f70a49b9cc498e02526fb01a6863b` |
| `COME-IN-Online-Shop-Product-Listing-Pricing-Description-Pre-APK-2026-10-19.zip` | 3,822,174 | `4833324a2c783ba2f0003d10da41eed0f0fac718822b46cac9eceb0d7941e8a9` |
| `COME-IN-P0-CONTINUATION-CANDIDATE-Pre-APK-2026-10-19.zip` | 4,000,430 | `fbbaf1ecbb1ab159aecc1c2fe80108a93db2f26581f871a8643f7c48c3d7c2db` |
| `COME-IN-P0-PARTIAL-Delivery-Panel-Fix-Pre-APK-2026-10-19.zip` | 3,995,702 | `3317800429ca2125c41d62d56af0995b33cfe9653bfe80aadee370058b2a9552` |
| `COME-IN-P0-UPI-Shop-Payment-Checkout-Pre-APK-2026-10-19.zip` | 3,763,347 | `e1353cfd9a3ba29ed1bd286f79fc96eb8cbdba8a5b426ac5a2a813ab00172a1c` |
| `COME-IN-Referral-Earn-Implementation-Pre-APK-2026-10-19-v2.zip` | 4,068,057 | `5e02b6283a3ac7841eea3c4a0d38a245318f4f76a0ccda7a9eda73f5fb935db4` |
| `COME-IN-Referral-Earn-Implementation-Pre-APK-2026-10-19.zip` | 4,068,057 | `6dbf2050c2501240038dce336f10fd87b967d465e80286f7ffbbbd531ce77525` |
| `COME-IN-Role-Security-Retail-Price-Import-Pre-APK-2026-10-19.zip` | 3,764,228 | `f78d07a87dc733e1ef1728a59621982c989f7e076c40086f678cc92bebc867dd` |
| `COME-IN-Secure-Earnings-Dashboards-Pre-APK-2026-10-19.zip` | 3,815,763 | `79216c4bdb9c781f253ffbfea44657eea93e460661e6a36b8f211a007703f422` |
| `COME-IN-Shop-Registration-Account-Only-Pre-APK-2026-10-19.zip` | 3,911,318 | `f9a7557143e19f9a680a1f1fbae20a5ee1a4d9f52a2ef17be3c6f87464500936` |
| `COME-IN-Ultimate-Consolidated-Master-Pre-APK-2026-10-19.zip` | 3,864,815 | `18fad7cb867ea9781543e40f2ecc2de899e33ab1f0d3cf774893269a9fd151f7` |
| `COME-IN-Ultimate-Consolidated-Master-Real-Services-Phase1-Pre-APK-2026-10-19.zip` | 3,888,263 | `1b1de5ee2077762739ba201bcddeb1f9b387d93a5adf028eb97f37f29106e0e9` |

The two Referral archives have different SHA-256 hashes and were treated as distinct versions. The newest source tree includes the optional hosted-compatible/Ollama CHAND provider work, along with the prior consolidation source and history documents.

## Historical ZIPs mentioned in earlier reports but unavailable here

- `COME-IN-Excel-Import-UI-and-Regression-Fixes-Pre-APK-2026-10-19.zip` (older record expected SHA-256: `c0d7c26fcaa32661079c0a7db97057e2bc6b7eb40ebfa05029922b804e2779ee`)
- `COME-IN-Compact-UI-Product-Checkout-Shopkeeper-Payments-Verified.zip` (older record expected SHA-256: `0115041fd07520d73e63948c3d85e568f6396d1986f4af49dcf27737256e39e3`)
- `COME-IN-Shopping-Theme-Reference-Matched-Pre-Replit.zip` and later-named reference-matched snapshots
- `COME-IN-Final-Completed-Fixes-Verified-Android.zip` (older record expected SHA-256: `5bc7a23ef78ee85a977cb1c4479b41baf819321a54610b0ab1ca098bd4edcde2`)
- `COME-IN-Restaurant-Mode-final-pre-Replit.zip`
- `COME-IN-Final-Restaurant-Mode-Verification-2026-10-15.zip`

Their absence from this workspace does not prove they are unavailable elsewhere. Their contents were not fabricated or assumed inspected. Source code and reports in the latest candidate were used where the named historical ZIP was absent.
