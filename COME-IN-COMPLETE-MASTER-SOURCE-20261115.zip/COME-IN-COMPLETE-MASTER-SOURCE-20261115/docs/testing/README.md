# Testing docs

- How to run: `../../TESTING_GUIDE.md`
- Current evidence (2026-11-14): `../../CODEX_HANDOFF.md` §E and `../../reports/testing/`
- Historical evidence: `../../project-reports/`, `../../COME_IN_TEST_REPORT.md`, `../../COME_IN_QA_REPORT.md`, `../COME-IN-UNIVERSAL-CATALOGUE-IMPORT-TEST-REPORT-2026-11-12.md`
- Stale contract list maintained by earlier sessions: `../../backend/tests/STALE_CONTRACT_TESTS.txt`
