# COME-IN — API Routes (generated 2026-11-14 from backend/server.py)

Total: 177 routes, all mounted under `/api` (FastAPI `APIRouter`). Line numbers refer to `backend/server.py`.

Auth: `get_current_user` (JWT Bearer) and `require_role("admin")` dependencies; see each handler.

## (root)

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/` | 644 |

## addresses

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/addresses` | 4549 |
| POST | `/api/addresses` | 4553 |
| PATCH | `/api/addresses/{address_id}` | 4563 |
| DELETE | `/api/addresses/{address_id}` | 4575 |

## admin

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/admin/referrals` | 935 |
| PATCH | `/api/admin/referrals/{referral_id}/review` | 942 |
| PATCH | `/api/admin/referral-rewards/{reward_id}` | 988 |
| GET | `/api/admin/chand/feedback` | 1363 |
| GET | `/api/admin/chand/feedback/summary` | 1368 |
| PATCH | `/api/admin/chand/feedback/{feedback_id}` | 1379 |
| POST | `/api/admin/master-products` | 1840 |
| GET | `/api/admin/catalog-import-history` | 2493 |
| GET | `/api/admin/catalog-price-audit` | 2499 |
| GET | `/api/admin/retail-price-import/template` | 2557 |
| POST | `/api/admin/retail-price-import` | 2563 |
| GET | `/api/admin/retail-price-import/history` | 2670 |
| GET | `/api/admin/announcements` | 3545 |
| POST | `/api/admin/announcements` | 3551 |
| PATCH | `/api/admin/announcements/{announcement_id}` | 3560 |
| GET | `/api/admin/dashboard` | 3604 |
| GET | `/api/admin/users` | 3647 |
| PATCH | `/api/admin/users/{user_id}/role` | 3653 |
| GET | `/api/admin/shops` | 3670 |
| PATCH | `/api/admin/shops/{shop_id}/status` | 3680 |
| GET | `/api/admin/orders` | 3693 |
| GET | `/api/admin/earnings` | 3897 |
| GET | `/api/admin/earnings/ledger` | 3931 |
| GET | `/api/admin/earnings/transactions` | 3942 |
| GET | `/api/admin/earnings/bank-account` | 4066 |
| PUT | `/api/admin/earnings/bank-account` | 4071 |
| PATCH | `/api/admin/financial-policy/{kind}/{entity_id}` | 4104 |
| GET | `/api/admin/earnings/settlements` | 4116 |
| PATCH | `/api/admin/earnings/settlements/{settlement_id}` | 4209 |
| GET | `/api/admin/requests/anything` | 4241 |
| GET | `/api/admin/requests/assist` | 4247 |
| PATCH | `/api/admin/requests/anything/{req_id}/status` | 4258 |
| PATCH | `/api/admin/requests/assist/{req_id}/status` | 4280 |
| GET | `/api/admin/restaurant/support` | 5134 |
| PATCH | `/api/admin/restaurant/support/{ticket_id}` | 5138 |
| POST | `/api/admin/restaurant/orders/{order_id}/refund` | 5172 |
| GET | `/api/admin/restaurant/orders` | 5332 |
| GET | `/api/admin/restaurants` | 5336 |
| PATCH | `/api/admin/restaurants/{restaurant_id}/status` | 5340 |
| PATCH | `/api/admin/home-services/fee-policy` | 5470 |
| GET | `/api/admin/home-services/providers` | 5655 |
| PATCH | `/api/admin/home-services/providers/{provider_id}/approval` | 5663 |

## announcements

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/announcements/active` | 3630 |

## assistant

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/assistant/context` | 1394 |
| GET | `/api/assistant/health` | 1608 |
| POST | `/api/assistant/transcribe` | 1628 |
| POST | `/api/assistant/vision` | 1666 |

## auth

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/auth/register` | 829 |
| POST | `/api/auth/login` | 864 |
| GET | `/api/auth/me` | 1033 |
| PATCH | `/api/auth/me` | 1043 |
| POST | `/api/auth/password/forgot` | 1081 |
| POST | `/api/auth/password/reset` | 1097 |

## catalog

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/catalog/master-products` | 1861 |
| GET | `/api/catalog/price-comparison` | 2505 |
| GET | `/api/catalog/retail-prices` | 2658 |
| GET | `/api/catalog/products` | 2694 |

## chand

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/chand/feedback` | 1331 |
| GET | `/api/chand/feedback/mine` | 1358 |

## delivery-partner

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/delivery-partner/provider-status` | 6037 |
| POST | `/api/delivery-partner/otp/request` | 6049 |
| POST | `/api/delivery-partner/otp/verify` | 6058 |
| POST | `/api/delivery-partner/identity/start` | 6063 |
| PUT | `/api/delivery-partner/application` | 6068 |
| POST | `/api/delivery-partner/application/submit` | 6113 |
| GET | `/api/delivery-partner/application/mine` | 6128 |
| GET | `/api/delivery-partner/referral` | 6136 |
| GET | `/api/delivery-partner/admin/applications` | 6145 |
| GET | `/api/delivery-partner/admin/applications/{application_id}` | 6152 |
| PATCH | `/api/delivery-partner/admin/applications/{application_id}` | 6166 |
| GET | `/api/delivery-partner/access` | 6202 |

## earnings

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/earnings/orders/{kind}/{order_id}/cash-collected` | 3841 |
| GET | `/api/earnings/mine` | 3969 |

## grocery

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/grocery/measured-price` | 2977 |
| POST | `/api/grocery/quotes` | 2987 |
| GET | `/api/grocery/payments/config` | 5687 |
| POST | `/api/grocery/payments/verify` | 5757 |

## home-services

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/home-services/fee-policy` | 5465 |
| GET | `/api/home-services/providers` | 5507 |
| GET | `/api/home-services/providers/mine` | 5522 |
| POST | `/api/home-services/providers` | 5527 |
| PATCH | `/api/home-services/providers/{provider_id}` | 5538 |
| PATCH | `/api/home-services/providers/{provider_id}/photo` | 5551 |
| POST | `/api/home-services/appointments` | 5567 |
| GET | `/api/home-services/appointments/mine` | 5596 |
| GET | `/api/home-services/appointments/provider` | 5600 |
| PATCH | `/api/home-services/appointments/{appointment_id}/status` | 5612 |

## notifications

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/notifications/mine` | 5896 |
| GET | `/api/notifications/unread-count` | 5903 |
| POST | `/api/notifications/read-all` | 5908 |
| POST | `/api/notifications/{notification_id}/read` | 5914 |

## orders

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/orders` | 3031 |
| POST | `/api/orders/{order_id}/confirm-upi-payment` | 3194 |
| GET | `/api/orders/mine` | 3222 |
| POST | `/api/orders/{order_id}/cancel` | 3298 |
| PATCH | `/api/orders/{order_id}/status` | 3317 |
| GET | `/api/orders/{order_id}` | 3410 |
| GET | `/api/orders/{order_id}/tracking` | 3419 |
| POST | `/api/orders/{order_id}/tracking/location` | 3441 |
| POST | `/api/orders/{order_id}/payment-intent` | 5703 |

## products

| Method | Path | server.py line |
|---|---|---:|
| PATCH | `/api/products/{product_id}` | 2734 |
| DELETE | `/api/products/{product_id}` | 2778 |
| GET | `/api/products/{product_id}/restock-alert` | 5923 |
| POST | `/api/products/{product_id}/restock-alert` | 5928 |
| DELETE | `/api/products/{product_id}/restock-alert` | 5937 |

## referral

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/referral/validate` | 918 |
| GET | `/api/referral` | 925 |

## referrals

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/referrals/me` | 876 |
| POST | `/api/referrals/home-banner-claim` | 902 |

## requests

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/requests/anything` | 3476 |
| GET | `/api/requests/anything/mine` | 3496 |
| POST | `/api/requests/assist` | 3502 |

## restaurant

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/restaurant/cart` | 4586 |
| PUT | `/api/restaurant/cart` | 4605 |
| DELETE | `/api/restaurant/cart` | 4620 |
| POST | `/api/restaurant/orders` | 4625 |
| GET | `/api/restaurant/orders/mine` | 4698 |
| PATCH | `/api/restaurant/orders/{order_id}/status` | 4710 |
| POST | `/api/restaurant/orders/{order_id}/cancel` | 4744 |
| GET | `/api/restaurant/payments/config` | 4753 |
| POST | `/api/restaurant/orders/{order_id}/payment-intent` | 4758 |
| POST | `/api/restaurant/orders/{order_id}/payment-retry` | 4788 |
| POST | `/api/restaurant/payments/verify` | 4800 |
| POST | `/api/restaurant/payments/razorpay-webhook` | 4877 |
| POST | `/api/restaurant/support` | 5026 |
| GET | `/api/restaurant/support/mine` | 5056 |

## restaurants

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/restaurants/{restaurant_id}/bank-account` | 4090 |
| PUT | `/api/restaurants/{restaurant_id}/bank-account` | 4097 |
| POST | `/api/restaurants/{restaurant_id}/settlements` | 4170 |
| GET | `/api/restaurants` | 4425 |
| GET | `/api/restaurants/mine` | 4447 |
| POST | `/api/restaurants` | 4451 |
| GET | `/api/restaurants/{restaurant_id}` | 4465 |
| GET | `/api/restaurants/{restaurant_id}/serviceability` | 4472 |
| PATCH | `/api/restaurants/{restaurant_id}` | 4482 |
| PATCH | `/api/restaurants/{restaurant_id}/availability` | 4494 |
| GET | `/api/restaurants/{restaurant_id}/menu` | 4506 |
| POST | `/api/restaurants/{restaurant_id}/menu` | 4518 |
| PATCH | `/api/restaurants/{restaurant_id}/menu/{item_id}` | 4528 |
| DELETE | `/api/restaurants/{restaurant_id}/menu/{item_id}` | 4540 |
| GET | `/api/restaurants/{restaurant_id}/orders` | 4705 |
| POST | `/api/restaurants/{restaurant_id}/reviews` | 5005 |

## seller

| Method | Path | server.py line |
|---|---|---:|
| GET | `/api/seller/support` | 5060 |
| PATCH | `/api/seller/support/{ticket_id}` | 5082 |

## shops

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/shops` | 1186 |
| GET | `/api/shops/mine` | 1215 |
| PATCH | `/api/shops/{shop_id}` | 1223 |
| PATCH | `/api/shops/{shop_id}/availability` | 1238 |
| GET | `/api/shops` | 1253 |
| GET | `/api/shops/{shop_id}` | 1286 |
| POST | `/api/shops/{shop_id}/master-products/{master_product_id}/link` | 1874 |
| POST | `/api/shops/{shop_id}/products` | 1912 |
| POST | `/api/shops/{shop_id}/catalogue-import/jobs` | 1978 |
| GET | `/api/shops/{shop_id}/catalogue-import/jobs/{job_id}` | 2067 |
| GET | `/api/shops/{shop_id}/catalogue-import/jobs` | 2118 |
| GET | `/api/shops/{shop_id}/catalogue-import/categories` | 2126 |
| PATCH | `/api/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}` | 2136 |
| POST | `/api/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/approve` | 2160 |
| POST | `/api/shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}/reject` | 2180 |
| POST | `/api/shops/{shop_id}/catalogue-import/jobs/{job_id}/bulk-approve` | 2196 |
| POST | `/api/shops/{shop_id}/catalogue-import/jobs/{job_id}/confirm-apply` | 2219 |
| POST | `/api/shops/{shop_id}/products/import` | 2244 |
| GET | `/api/shops/{shop_id}/products/import-template` | 2481 |
| GET | `/api/shops/{shop_id}/products` | 2676 |
| GET | `/api/shops/{shop_id}/orders` | 3309 |
| GET | `/api/shops/{shop_id}/bank-account` | 4076 |
| PUT | `/api/shops/{shop_id}/bank-account` | 4083 |
| POST | `/api/shops/{shop_id}/settlements` | 4123 |

## status

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/status` | 662 |
| GET | `/api/status` | 669 |

## uploads

| Method | Path | server.py line |
|---|---|---:|
| POST | `/api/uploads/image` | 1116 |
| GET | `/api/uploads/{storage_path:path}` | 1149 |
