# Universal Catalogue Import — Test Report

**Date:** 12 November 2026  
**Status:** Offline/mock/source-contract tests only; no live database or provider tests.

## Checkpoint discrepancy

The checkpoint's previous report contains the exact 22-file command. Re-running it on the untouched checkpoint before edits produced `146 passed in 2.26s`. The older 46 figure is an earlier-stage result and is not the current checkpoint result.

## Final focused command

Run from `APPLICATION_SOURCE/COME-IN-WORKING-COPY-RECOVERED-V1`:

```bash
PYTHONPATH=backend python -m pytest -c /dev/null \
 backend/tests/test_catalogue_chand_adapter.py backend/tests/test_catalogue_import_workflow_contract.py \
 backend/tests/test_universal_catalogue_import_engine.py backend/tests/test_catalogue_import_job_api_contract.py \
 backend/tests/test_catalog_import_security_contract.py backend/tests/test_master_catalog_api_contract.py \
 backend/tests/test_master_catalog_seller_ui_contract.py backend/tests/test_task5_measured_import_contract.py \
 backend/tests/test_task5_customer_measured_shopping_contract.py backend/tests/test_task5_task7_ui_implementation_contract.py \
 backend/tests/test_shopping_catalog_contract.py backend/tests/test_shopping_cart_variants_contract.py \
 backend/tests/test_grocery_checkout_security_contract.py backend/tests/test_restaurant_api_contract.py \
 backend/tests/test_restaurant_pricing.py backend/tests/test_restaurant_serviceability.py \
 backend/tests/test_chand_demo_contract.py backend/tests/test_chand_feedback_contract.py \
 backend/tests/test_chand_localization_contract.py backend/tests/test_chand_media_contract.py \
 backend/tests/test_chand_ollama_provider_contract.py backend/tests/test_chand_shopping_integration_contract.py -q
```

**Actual final result:** `154 passed in 2.58s`.

## Broader offline-safe suite

```bash
TESTS=$(find backend/tests -maxdepth 1 -name 'test_*.py' \
 ! -name 'test_task5_live_mongo_transactions.py' \
 ! -name 'test_batch_5task_runtime.py' \
 ! -name 'test_iter_notifications_admin_measured.py' \
 ! -name 'test_preview_runtime_e2e.py' | sort | tr '\n' ' ')
PYTHONPATH=backend python -m pytest -c /dev/null $TESTS -q \
 -k 'not test_shopping_home_theme_contract_and_separate_mode_routes and not test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest'
```

**Actual result:** `400 passed, 2 deselected in 6.28s`.

Without the `-k` exclusions, the same broad run yielded **400 passed, 2 failed**. Both failures are existing, unrelated assertions in `backend/tests/test_frontend_contracts.py` against `frontend/app/(tabs)/index.tsx`: missing `testID="request-anything-card"` and missing literal `Voice search unavailable`. No change was made to that unrelated Home UI.

An initial all-tests collection attempt (excluding only the Mongo test) was blocked by three runtime-oriented test modules importing `test_preview_runtime_e2e.py`, which reads `/app/frontend/.env`; that file is not present in the isolated checkpoint. The following modules were therefore excluded from the broad offline-safe run: `test_task5_live_mongo_transactions.py`, `test_batch_5task_runtime.py`, `test_iter_notifications_admin_measured.py`, `test_preview_runtime_e2e.py`.

## Compilation and frontend checks

```bash
python -m py_compile backend/catalogue_import_engine.py backend/catalogue_chand_adapter.py backend/server.py
```

**Result:** PASS.

Global TypeScript compiler API `transpileModule` syntax check:
- `frontend/app/seller/products.tsx`: PASS
- `frontend/src/lib/api.ts`: PASS

Full project command `tsc --noEmit -p frontend/tsconfig.json`: **BLOCKED**. The extracted source has no `frontend/node_modules` and no resolvable Expo base config/type dependencies. No packages were installed.

## Explicitly not tested

- Live MongoDB topology, transactions, commit/abort, rollback, unique indexes, concurrency, migrations.
- Live FastAPI service/database requests.
- Actual CHAND provider connectivity or credentials.
- Expo build, complete TS typecheck, browser/device E2E, mobile camera/file picker.
- Real-world OCR quality for Hindi handwriting, skewed/blurred photos, or varied scans.
- XLS workbook runtime, because `xlrd` is absent in this environment.
- Atomic cross-job duplicate protection or import retry across concurrent requests.

These are not counted as passed.
