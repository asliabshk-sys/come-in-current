# Universal Catalogue Import — Change Manifest

## Modified backend
- `backend/catalogue_import_engine.py` — `.xls` adapter route; upload filename/MIME validation; optional bounded scanned-PDF OCR fallback; existing CSV/XLSX/PDF/image/ZIP paths retained.
- `backend/catalogue_chand_adapter.py` — explicit untrusted-document system boundary; evidence and numeric validation; finite confidence; sanitized duplicate candidates; bounded timeout and one transient retry.
- `backend/server.py` — MIME/filename validation wired into staging upload; post-confirm review lock for edit/approve/reject/bulk approve.

## Modified/added tests
- `backend/tests/test_universal_catalogue_import_engine.py` — metadata validation, CSV formula-like literal preservation, XLS dependency behavior, scanned PDF OCR.
- `backend/tests/test_catalogue_chand_adapter.py` — injection boundary, numeric suggestion rejection, confidence sanitation, retry.
- `backend/tests/test_catalogue_import_workflow_contract.py` — review lock after apply confirmation.

## Documentation added
- `docs/UNIVERSAL_CATALOGUE_IMPORT_FINAL_AUDIT.md`
- `docs/UNIVERSAL_CATALOGUE_IMPORT_TEST_REPORT.md`
- `docs/UNIVERSAL_CATALOGUE_IMPORT_SECURITY_REPORT.md`
- `docs/UNIVERSAL_CATALOGUE_IMPORT_EMERGENT_HANDOFF.md`
- `docs/UNIVERSAL_CATALOGUE_IMPORT_CHANGE_MANIFEST.md`
- `docs/UNIVERSAL_CATALOGUE_IMPORT_PENDING_BLOCKERS.md`

No Product/Inventory schema migration, live DB operation, external provider request, Restaurant Mode edit, navigation redesign, or production data mutation was performed.
