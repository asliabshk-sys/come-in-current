# COME-IN — Architecture

```
 Expo app (frontend/)  ──HTTPS JSON──►  FastAPI (backend/server.py, /api/*)  ──Motor──►  MongoDB 7.0 replica set (DB_NAME)
   Expo Router routes                     JWT auth + RBAC (customer / shopkeeper / admin)      52 collections, 59 indexes
   src/lib/api.ts (EXPO_PUBLIC_BACKEND_URL) Pydantic validation                                 multi-document transactions
   src/store (auth, cart, location)        business rules: financial/referral/refund/restaurant
   Restaurant Mode shell (src/restaurant)   integrations/: delivery_provider, order_notifications
                                            optional providers (env-gated, fail closed):
                                              Razorpay · SMTP · Emergent object storage · Chand AI provider
                                              (openai_compatible | ollama) · OTP/Aadhaar/PAN/doc storage
```

## Frontend
- Expo SDK 58.0.17, React Native 0.88.0, React 19.3.0, Expo Router 58.0.25, TanStack Query 5, TypeScript 6.0.3.
- Entry `expo-router/entry` → `app/_layout.tsx` (providers: auth, cart, location, i18n, query client).
- Two visual modes: shopping (default theme `src/theme.ts`) and Restaurant Mode (`src/restaurant/theme.ts`, `RestaurantModeShell.tsx`).
- i18n: `src/i18n/translations.ts` (multilingual; see `docs/COME-IN-TRANSLATION-INVENTORY-2026-10-19.csv`).

## Backend
- One module `server.py` with `api = APIRouter(prefix="/api")`; 177 routes (`docs/api/API_ROUTES.md`).
- Startup `_startup()`: config warnings, 59 `create_index` calls, optional admin seed.
- Transactions: checkout stock decrement, measured quantities, settlements, imports, home-service slot reservations, referral rewards.
- Encryption: Fernet for bank details and delivery-partner PII (separate keys).

## Data
See `docs/mongodb/` and `reports/mongodb/live-mongo-spec-2026-11-14.json`.
