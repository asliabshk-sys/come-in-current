# CHAND AI Phase 4 — Owner Setup and Release Gate

This guide is for the owner/operator of the existing COME-IN workspace. Run commands from `frontend/` unless noted. Do not add real secrets to source files or archives.

## A. Restore Yarn and regenerate the lockfile

Prerequisites: a network-enabled machine/container with Node 22, Corepack, and DNS access to the configured npm/Yarn registry. The project pins Yarn 1.22.22 in `frontend/package.json`.

```bash
cd frontend
corepack enable
corepack prepare yarn@1.22.22 --activate
yarn --version
# Must print 1.22.22. If not, stop.

# Resolve the declared Expo SDK 58 native packages using Expo's installer.
yarn expo install expo-image-picker expo-audio

# Install and write a genuine Yarn v1 lockfile from the manifest.
yarn install

# Confirm a clean reproducible install after the lockfile has been generated.
yarn install --frozen-lockfile

# Check SDK package compatibility and run the project's semantic typecheck.
yarn expo install --check
yarn typecheck
yarn lint
```

Do not hand-edit `yarn.lock`. Do not delete existing dependencies to force installation. Review the lockfile diff and retain the exact package versions selected by Expo SDK 58.

## B. Expo configuration and bundles

```bash
cd frontend
yarn expo config --type public
yarn expo-doctor
yarn expo export --platform android
yarn expo export --platform ios
```

A JavaScript export is not a native binary build. For native development builds, use an Android SDK/ADB environment for Android and macOS/Xcode for iOS, with the repository's normal Expo prebuild/run workflow. Confirm generated permission strings in the native app and test them on devices.

## C. Backend provider secrets

Set only in the backend secret manager/environment (never in Expo public variables):

- `COMEIN_AI_PROVIDER=openai_compatible` (or `ollama` for an owner-managed reachable Ollama service)
- `COMEIN_AI_BASE_URL=<provider-compatible API base URL>`
- `COMEIN_AI_API_KEY=<secret>` (required for hosted OpenAI-compatible provider; do not expose it client-side)
- `COMEIN_AI_MODEL=<chat model identifier>`
- `COMEIN_STT_MODEL=<supported transcription model>` (speech transcription requires the OpenAI-compatible provider path)

For hosted provider configuration, base URL, API key and model must all be present. For Ollama, model and reachable base URL are required; default `127.0.0.1:11434` only works when the service shares the backend network namespace. Verify by making real authenticated requests to `/assistant/context`, `/assistant/vision` and `/assistant/transcribe`; `/assistant/health` is not a live connectivity test. Check Hindi and English, timeout, provider failure and rate-limit cases. Never log prompt payloads or credentials.

## D. Non-production MongoDB replica set

Use the existing `infra/mongodb/` compose/configuration and `scripts/mongo/` helpers only in an isolated environment. Provision a disposable replica set and configure backend `MONGO_URL` to that non-production URI. Confirm it contains no production customer data. Run the Task 5 live transaction tests and Chand feedback/admin/rate-limit tests. Do not use production URI for tests.

## E. Required final gates

- Focused and full backend tests pass, including required `pytest-xdist` and live MongoDB scenarios.
- TypeScript semantic typecheck, Expo Doctor and Android/iOS bundles/builds pass.
- Real device camera/gallery and microphone tests pass; verify image upload and native audio container/codec compatibility.
- Real provider chat, vision and transcription requests pass with Hindi/English coverage and error/rate-limit tests.
- Party planner provides deterministic per-guest quantities, editable substitutions and totals based on actual catalog prices.
- Customer workflow through existing Cart and Checkout passes; Task 5 and Restaurant Mode regressions pass.
- Admin feedback authorization and customer data isolation pass against the isolated database.

Only after all gates pass may the owner assess production readiness. This guide does not authorize production deployment.
