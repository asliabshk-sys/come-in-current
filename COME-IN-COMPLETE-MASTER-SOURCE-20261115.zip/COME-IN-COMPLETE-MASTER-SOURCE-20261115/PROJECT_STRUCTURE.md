# COME-IN — Project Structure (actual, 2026-11-14)

Single project root: `COME-IN-MASTER-PROJECT/`. There are no other frontend/backend roots and no nested project ZIPs inside this package.

```
COME-IN-MASTER-PROJECT/
├── CODEX_START_HERE.md        ← read first
├── CODEX_HANDOFF.md           ← architecture, status, MongoDB, evidence, next task
├── PROJECT_MANIFEST.json      ← machine-readable paths + file list + git revision
├── MASTER_TASK_TRACKER.md     ← consolidated tracker + next tasks
├── PROJECT_STATUS.md, PROJECT_STRUCTURE.md, KNOWN_ISSUES.md, CHANGELOG.md
├── RESTORE_AND_SETUP.md, TESTING_GUIDE.md, SECURITY_NOTES.md, README.md, .gitignore
├── COME_IN_*.md/.json/.xlsx, COME-IN-CODEX-IMPORT-README.md, MANIFEST.sha256   ← historical project records (kept at original paths)
│
├── frontend/                  Expo SDK 58 app (Expo Router, TypeScript)
│   ├── package.json, yarn.lock, .npmrc, app.json, tsconfig.json, metro.config.js, expo-env.d.ts, .env.example
│   ├── app/                   routes: (tabs)/, product/, category/, shop/, seller/, restaurant/, admin*, chand, checkout, delivery-partner …
│   ├── src/                   lib/api.ts, store/, i18n/, components/, data/, restaurant/, utils/, theme.ts
│   ├── assets/                branding, fonts, illustrations, images
│   ├── constants/testIds/
│   └── scripts/               cmd-guard (preinstall), install-guard.sh, sync-shims.sh, test-chand-party-planner.cjs
│
├── backend/                   FastAPI app
│   ├── server.py              all /api routes + startup indexes
│   ├── *_rules.py, restaurant_*.py, security_config.py, catalogue_import_engine.py, catalogue_chand_adapter.py
│   ├── integrations/          delivery_provider.py, order_notifications.py
│   ├── requirements.txt, requirements-catalogue-import.txt, pytest.ini, .env.example
│   └── tests/                 61 offline contract modules + 5 live modules + seed script + preview_test_env.sh
│
├── infra/mongodb/             docker-compose.yml, mongod-rs0.conf, rs-init.js, supervisor-mongodb-rs0.conf, .env.example
├── scripts/                   backup-db.sh, restore-db.sh, preview.sh, verify-env.sh, replit-*.sh,
│                              delivery-partner-live-api-check.sh, mongo/{setup.sh,start-replset.sh,comein_mongo.py,export_sanitized_preview_backup.py}
├── docs/                      feature docs; mongodb/; history/; architecture/; api/; deployment/; testing/
├── reports/                   audit/ (discovery + compatibility + previous handoff package), mongodb/, testing/, security/
├── database-backup/           sanitized preview/test DB archive + BACKUP_INSTRUCTIONS.md
├── project-reports/           historical execution/test reports (2026-10 → 2026-11-12)
├── backups/                   historical pre-change doc snapshots from earlier sessions (not DB backups)
├── memory/                    PRD notes from earlier sessions
└── previews/                  design mockup PNGs (not runtime screenshots)
```

Differences from the requested target layout (intentional, to avoid breaking paths):
- There is no `infra/docker/`; the only Docker artefact is `infra/mongodb/docker-compose.yml`.
- Historical records remain at their original root paths and in `project-reports/`, `backups/`, `memory/`.
- Earlier checkpoint ZIPs are delivered separately (`COME-IN-PROJECT-HISTORY-CHECKPOINTS.zip`), not inside the project, so Codex never sees competing roots.
