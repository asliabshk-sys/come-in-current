# COME-IN — Restore and Setup

## Prerequisites
- Node.js 20.19.4+/22.13+/24.3+ (verified 24.19.0), Yarn 1.22.22 (`packageManager` pin)
- Python 3.11 (verified 3.11.18)
- MongoDB 7.0.x server + mongosh + MongoDB Database Tools (mongodump/mongorestore) — replica set required

## 1. Environment files
```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
python -c "import secrets;print(secrets.token_urlsafe(48))"                                  # JWT_SECRET
python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"     # BANK_DATA_ENCRYPTION_KEY
python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"     # DELIVERY_PARTNER_DATA_ENCRYPTION_KEY (distinct)
```
Set `MONGO_URL=mongodb://127.0.0.1:27018/?replicaSet=rs0`, `DB_NAME=comein_dev` (or any disposable name). Optional `ADMIN_EMAIL`/`ADMIN_PASSWORD` (≥16 chars) seeds an admin at startup.

## 2. MongoDB
```bash
MONGO_RS_DBPATH=/tmp/mongo-rs0-data LAUNCHER=nohup bash scripts/mongo/setup.sh   # starts rs0 on 27018, creates collections+indexes, runs tx health check
# Docker alternative:
docker compose -f infra/mongodb/docker-compose.yml up -d    # MONGO_URL=mongodb://localhost:27017/?replicaSet=rs0&directConnection=true
python3 scripts/mongo/comein_mongo.py health
```

## 3. Backend
```bash
cd backend
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt --extra-index-url https://d33sy5i8bnduwe.cloudfront.net/simple/
# (emergentintegrations is not imported by server.py; outside Emergent you may remove that line instead)
pip install -r requirements-catalogue-import.txt      # optional parsers/OCR
python -m uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

## 4. Frontend
```bash
chmod +x frontend/scripts/*.js frontend/scripts/*.sh
cd frontend && yarn install --frozen-lockfile
yarn web        # or: yarn start / bash ../scripts/preview.sh
```

## 5. Restore the included database backup (preview/test data only)
See `database-backup/BACKUP_INSTRUCTIONS.md`. Always restore into a NEW disposable database.

## 6. Git
The package contains a `.git` directory with a baseline commit created at packaging time (the received source had no Git history). `git log` shows it; the commit hash is in `PROJECT_MANIFEST.json`.
