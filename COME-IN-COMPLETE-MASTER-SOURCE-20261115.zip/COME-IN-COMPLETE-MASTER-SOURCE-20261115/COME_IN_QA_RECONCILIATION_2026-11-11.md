# COME-IN — 24-Test QA Reconciliation

**Date:** 2026-11-11  
**Baseline Master ZIP SHA-256:** `57333c3bd8bba2335eff79b431239fd014c75efb9aff9434d53230119f97a304`  
**Scope:** 24 failures previously recorded in the 52-file offline/source-contract suite.

## Result

- Reproduced before reconciliation: **309 passed / 24 failed** across 52 files.
- After reconciliation: **333 passed / 0 failed** across the same 52 files.
- The 24 failures were individually inspected. **23 were stale source-contract expectations** tied to older literal strings or implementation shapes. **1 was a genuine developer-tooling gap** (missing `typecheck` and `build:web` package scripts), now addressed in `frontend/package.json`.
- No genuine application bug, test-data failure, or regression introduced by the previous five-task batch was identified in these 24 failures.
- Test assertions were updated to check current behavior; no failing tests were skipped, marked xfail, or suppressed.

## Individual classification

| # | Failing test | Classification | Reconciliation / current behavior checked |
|---:|---|---|---|
| 1 | `test_chand_support_has_confirmation_and_status_disclosures` | Stale source-contract | Submit action now creates/reuses a request ID and opens the confirmation step; confirmation and status disclosures remain present. |
| 2 | `test_existing_refund_flow_checks_paid_order_and_duplicate_refund_status` | Stale source-contract | Replaced old simplistic refund literal checks with paid-order, paise amount equality, blocked states, compare-and-set claim, provider-history and uncertain-state checks. |
| 3 | `test_provider_configuration_and_safety_docs_are_present` | Stale source-contract | `.env.example` intentionally leaves provider blank; server defaults to `openai_compatible`. |
| 4 | `test_expo_public_backend_url_is_documented_and_used` | Stale source-contract | Current frontend example uses the configured local backend port `8001`, not obsolete `8000`. |
| 5 | `test_frontend_exposes_typecheck_and_production_web_build_scripts` | Genuine tooling gap — fixed | Added `typecheck: tsc --noEmit` and `build:web: expo export --platform web`. Execution remains blocked by missing frontend dependencies/Expo CLI. |
| 6 | `test_account_notification_payment_and_help_rows_have_real_routes_and_honest_status_screens` | Stale source-contract | Push status is communicated through `t("n.pushOff")`; the test now checks that no permission prompt/native notification scheduler is invoked. |
| 7 | `test_restaurant_account_alias_keeps_existing_links_compatible` | Stale source-contract | Compatibility alias remains in Restaurant navigation and redirects to the shared Account; order confirmation correctly routes to order history. |
| 8 | `test_grocery_order_contract_requires_quote_idempotency_and_fails_closed_for_unconfigured_gateways` | Stale source-contract | Current flow validates shop-enabled methods, explicitly blocks Stripe, and gates Razorpay on the Grocery flag plus server keys. |
| 9 | `test_notification_contract_is_fail_closed_and_no_token_registration_route_is_exposed` | Stale source-contract | In-app notification endpoints are expected; test now checks absence of push/device-token registration routes and retains unconfigured-provider assertions. |
| 10 | `test_new_grocery_cash_shop_and_pickup_orders_use_pickup_specific_pending_state` | Stale source-contract | Current order state expression distinguishes COD, UPI, Razorpay pending and pay-at-pickup pending. |
| 11 | `test_grocery_cancellation_accepts_new_and_legacy_pay_at_shop_states_without_changing_cod` | Stale source-contract | Cancellation allowlist includes the additional unpaid `razorpay_pending` state; collected/paid/refunded states remain protected. |
| 12 | `test_grocery_cancellation_keeps_protected_payment_states_outside_allowlist` | Stale source-contract | Updated allowlist assertion to include `razorpay_pending` while retaining fail-closed protection for paid/cash-collected states. |
| 13 | `test_product_detail_has_distinct_buy_now_checkout_action` | Stale source-contract | Buy Now uses a separate `buyNowLine` and routes to checkout; it does not replace the persisted cart. |
| 14 | `test_webhook_event_is_recorded_after_processing_for_retry_safety` | Stale source-contract | Test now checks both Grocery handler-before-record and Restaurant processing-before-final-record ordering; prior `index()` assertion selected the wrong branch. |
| 15 | `test_shared_tracking_endpoint_supports_restaurant_orders_without_fake_coordinates` | Stale source-contract | Current permission check rejects mismatched owner snapshots and additionally verifies current restaurant record ownership. |
| 16 | `test_no_shared_notification_delivery_provider_is_claimed_by_current_source` | Stale source-contract | In-app notifications are implemented; test now distinguishes these routes from absent native push-token registration/delivery. |
| 17 | `test_cart_line_price_comes_from_selected_variant_and_subtotal_uses_line_price` | Stale source-contract | Subtotal uses `lineAmount()` so measured products are priced by base-unit amount; variant price is applied to the selected product snapshot. |
| 18 | `test_task18_preview_environment_example_exists_without_secrets` | Stale source-contract | Updated obsolete local URL expectation to current port `8001`; secret-free assertion retained. |
| 19 | `test_buy_now_is_an_isolated_checkout_line_and_does_not_replace_persisted_cart` | Stale source-contract | Current `startBuyNow` has measured amount validation and a separate fixed-pack 1,000-item cap; the former single qty expression was obsolete. |
| 20 | `test_product_detail_keeps_variant_identity_and_quantity_controls_connected` | Stale source-contract | Assertions now reflect measured-vs-pack callbacks while preserving selected-variant identity and quantity controls. |
| 21 | `test_repeat_order_aggregates_duplicate_product_variant_rows_before_stock_checks` | Stale source-contract | Aggregation map now carries a `measured` flag; only fixed-pack duplicate quantities use the 1,000-item cap. |
| 22 | `test_repeat_order_uses_normal_cart_then_checkout_requests_a_fresh_authoritative_quote` | Stale source-contract | Backend aggregate limit uses `MEASURED_QTY_LIMIT` (100,000); fixed packs are independently limited to 1,000 in line resolution. |
| 23 | `test_live_product_cards_offer_buy_now_and_keep_variant_selection_flow` | Stale source-contract | Measured items use base-unit add/increment callbacks; fixed-pack items use selected-variant handlers. |
| 24 | `test_customer_grocery_cancel_is_owner_scoped_and_only_cancels_unaccepted_unpaid_orders` | Stale source-contract | Updated cancellation allowlist assertion for `razorpay_pending`; customer ownership and transaction/stock restoration assertions remain. |

## Environment failures outside the 24

The unfiltered backend suite could not complete collection because three runtime suites import `test_preview_runtime_e2e.py`, which reads `/app/frontend/.env`. That absolute path is absent in this execution environment. These are environment/preview setup blockers, not application assertion failures:

- `test_batch_5task_runtime.py`
- `test_iter_notifications_admin_measured.py`
- `test_preview_runtime_e2e.py`

The 52-file offline/source-contract suite excludes exactly these three runtime suites and passes in full.

## Remaining gaps

- Full TypeScript typecheck: blocked because `frontend/node_modules` and `expo/tsconfig.base` are absent. The command was attempted after adding the script; diagnostics are dominated by missing modules/configuration and cannot be treated as a valid semantic typecheck.
- Web build: blocked because the Expo CLI is not installed (`expo: not found`).
- MongoDB replica-set transactions, refund persistence, restore drill: not run; no DB tools/connection used.
- Razorpay TEST provider, payment/cancellation/refund/webhook synchronization: not run; no owner-approved TEST credentials used.
- Expo preview and physical device checks: not run.
- Password reset code exists but SMTP delivery is not verified. Phone OTP is not active/configured. No logout-all endpoint or server-side all-session revocation flow was found; these remain Task 16 gaps.
- Automatic Grocery provider refunds and refund-specific in-app notification synchronization remain Task 11 gaps.

No test was suppressed, skipped, or marked xfail to obtain the green offline result.
