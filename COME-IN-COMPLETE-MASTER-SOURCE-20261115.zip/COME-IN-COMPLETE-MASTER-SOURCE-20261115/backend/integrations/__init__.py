"""Provider boundaries for COME-IN integrations. No external provider is activated here."""
