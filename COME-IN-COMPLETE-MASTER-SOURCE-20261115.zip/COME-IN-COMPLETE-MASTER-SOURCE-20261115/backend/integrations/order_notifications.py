"""Notification provider boundary; disabled by default and never claims delivery."""
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class NotificationResult:
    accepted: bool
    provider_message_id: str | None = None
    status: str = "not_sent"
    reason: str | None = None


class OrderNotificationProvider(Protocol):
    async def send_order_event(self, *, event_id: str, recipient_id: str,
                               event_type: str, payload: dict) -> NotificationResult: ...


class UnconfiguredOrderNotificationProvider:
    """Fail-closed default; does not send SMS, email, or push messages."""
    async def send_order_event(self, *, event_id: str, recipient_id: str,
                               event_type: str, payload: dict) -> NotificationResult:
        return NotificationResult(
            accepted=False,
            status="not_sent",
            reason="No verified order-notification provider is configured.",
        )
