"""Safe delivery-partner adapter boundary; deliberately no fake rider or ETA."""
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Protocol


@dataclass(frozen=True)
class DeliveryTracking:
    available: bool
    status: str
    latitude: float | None = None
    longitude: float | None = None
    location_updated_at: str | None = None
    eta_minutes: int | None = None
    reason: str | None = None


class DeliveryProvider(Protocol):
    async def get_tracking(self, *, order_id: str, customer_id: str) -> DeliveryTracking: ...


class UnconfiguredDeliveryProvider:
    """Fail-closed default until a verified partner and credentials are configured."""
    async def get_tracking(self, *, order_id: str, customer_id: str) -> DeliveryTracking:
        return DeliveryTracking(
            available=False,
            status="unavailable",
            reason="No verified delivery-partner provider is configured.",
        )


def is_fresh_location(updated_at: str | None, *, max_age_seconds: int = 180,
                      now: datetime | None = None) -> bool:
    """Reject absent, malformed, naive, future, or stale timestamps."""
    if not updated_at:
        return False
    try:
        stamp = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            return False
        current = now or datetime.now(timezone.utc)
        age = (current - stamp.astimezone(timezone.utc)).total_seconds()
        return 0 <= age <= max_age_seconds
    except (TypeError, ValueError, OverflowError):
        return False
