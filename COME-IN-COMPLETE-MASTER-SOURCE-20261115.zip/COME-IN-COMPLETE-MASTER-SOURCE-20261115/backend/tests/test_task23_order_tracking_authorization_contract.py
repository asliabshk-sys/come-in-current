"""Task 23 order tracking authorization regressions; source-contract only."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
TREE = ast.parse(SERVER)


def function_source(name):
    node = next(
        n for n in TREE.body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
    )
    return ast.get_source_segment(SERVER, node)


def test_customer_can_read_own_order_but_historical_seller_owner_requires_current_role():
    source = function_source("_tracking_can_read")
    assert 'order.get("customer_id") == user.get("id")' in source
    assert 'user.get("role") != "shopkeeper"' in source
    assert 'order.get("restaurant_owner_id") != user.get("id")' in source
    assert 'restaurant.get("owner_id") == user.get("id")' in source
    assert 'shop.get("owner_id") == user.get("id")' in source


def test_tracking_location_write_requires_current_seller_role_and_current_ownership():
    source = function_source("update_order_tracking_location")
    assert 'user.get("role") != "admin"' in source
    assert 'user.get("role") != "shopkeeper"' in source
    assert '_restaurant_owner(restaurant, user)' in source
    assert '_assert_shop_owner(shop, user)' in source
    assert 'Only the authorized order operator can update delivery location' in source


def test_tracking_read_remains_authenticated_and_terminal_orders_do_not_expose_location():
    source = function_source("get_order_tracking")
    assert 'Depends(get_current_user)' in source
    assert '_tracking_can_read(order, kind, user)' in source
    assert 'point = order.get("delivery_location") if active else None' in source
    assert '"eta_minutes": None' in source and '"map_provider": None' in source


def test_tracking_location_write_remains_limited_to_active_non_pickup_delivery():
    source = function_source("update_order_tracking_location")
    assert 'order.get("status") != "out_for_delivery"' in source
    assert 'order.get("fulfillment", "delivery") == "pickup"' in source
    assert '"status": "out_for_delivery", "fulfillment": {"$ne": "pickup"}' in source
