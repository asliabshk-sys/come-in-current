from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HOME = ROOT / "frontend/app/(tabs)/index.tsx"
SHOPS = ROOT / "frontend/app/shops.tsx"
CATALOG = ROOT / "frontend/src/data/catalog.ts"


def test_mode_cards_use_compact_consistent_artwork_dimensions():
    source = HOME.read_text(encoding="utf-8")
    assert 'flexBasis: "46%", flexGrow: 1, minWidth: 0, minHeight: 88' in source
    assert "modeArtwork: { width: 40, height: 44" in source
    assert 'testID="online-shops-card"' in source
    assert 'testID="offline-shops-card"' in source


def test_shop_registration_is_not_offered_from_online_or_offline_browse_pages():
    source = SHOPS.read_text(encoding="utf-8")
    account = (ROOT / "frontend/app/(tabs)/account.tsx").read_text(encoding="utf-8")
    assert 'testID="register-offline-shop"' not in source
    assert "Add Your Shop / Register Your Shop" not in source
    assert 'pathname: "/become-seller"' not in source
    assert 'label: "Add Your Shop"' in account
    assert 'params: { type: "online" }' in account
    assert 'params: { type: "offline" }' in account


def test_browse_only_catalog_items_get_category_or_product_relevant_illustration_without_fake_price():
    source = CATALOG.read_text(encoding="utf-8")
    assert "image: referenceProductImage(categoryId, name)" in source
    assert "function referenceProductImage(categoryId: string, name: string)" in source
    assert "price: 0," in source
    assert "source: \"catalog\" as const" in source
    assert "rice|basmati|poha|puffed rice" in source
    assert "dal|dhal|lentil|chana|chickpea" in source


def test_shop_registration_validates_phone_and_upi_before_saving():
    seller = (ROOT / "frontend/app/become-seller.tsx").read_text(encoding="utf-8")
    assert "Enter a valid contact phone number" in seller
    assert "Enter a valid UPI ID such as shop@upi" in seller
    assert "if (saving) return" in seller
    assert "requestedShopType" in seller
