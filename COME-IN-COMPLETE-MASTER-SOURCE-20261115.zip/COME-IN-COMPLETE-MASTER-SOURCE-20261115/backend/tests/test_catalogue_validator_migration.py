"""Disposable-only persistent validator guard (no MongoDB connection)."""
import importlib.util
from pathlib import Path
import pytest

path = Path(__file__).parents[2] / 'scripts/mongo/catalogue_audit_validator.py'
spec = importlib.util.spec_from_file_location('catalogue_audit_validator', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_production_or_unconfirmed_target_fails_closed():
    for env, db, confirm in (
        ({'APP_ENV': 'production', 'MONGO_URL': 'mongodb://localhost:27017'}, 'comein_disposable_test_1', 'comein_disposable_test_1'),
        ({'APP_ENV': 'test', 'MONGO_URL': 'mongodb://localhost:27017'}, 'comein_production', 'comein_production'),
        ({'APP_ENV': 'test', 'MONGO_URL': 'mongodb://localhost:27017'}, 'comein_disposable_test_1', 'wrong'),
        ({'APP_ENV': 'test'}, 'comein_disposable_test_1', 'comein_disposable_test_1'),
        ({'APP_ENV': 'test', 'MONGO_URL': 'mongodb://private.example:27017'}, 'comein_disposable_test_1', 'comein_disposable_test_1'),
    ):
        with pytest.raises(ValueError):
            module.validate_disposable_target(env, db, confirm)
    module.validate_disposable_target({'APP_ENV': 'test', 'MONGO_URL': 'mongodb://localhost:27017'},
                                      'comein_disposable_test_1', 'comein_disposable_test_1')


def test_new_audit_schema_requires_provenance_count_product_ids_and_time():
    spec = module.SCHEMA
    assert {'apply_key', 'shop_id', 'seller_id', 'job_id', 'record_count', 'product_ids', 'created_at'} <= set(spec['required'])
    assert spec['properties']['created_at']['bsonType'] == 'date'
    assert spec['properties']['product_ids']['items']['bsonType'] == 'string'


def test_never_overwrite_existing_nonempty_audit_collection():
    class Db:
        def list_collection_names(self): return ['catalogue_import_audit']
        def __getitem__(self, _name): return self
        def count_documents(self, _query): return 1
        def command(self, _command): raise AssertionError('collMod must not run')
    with pytest.raises(RuntimeError):
        module.install_validator(Db())


def test_create_audit_collection_with_strict_error_validation():
    class Db:
        def list_collection_names(self): return []
        def create_collection(self, name, **options):
            self.created = (name, options)
    db = Db()
    assert module.install_validator(db)['created'] is True
    assert db.created[1]['validationAction'] == 'error'
    assert db.created[1]['validationLevel'] == 'strict'
