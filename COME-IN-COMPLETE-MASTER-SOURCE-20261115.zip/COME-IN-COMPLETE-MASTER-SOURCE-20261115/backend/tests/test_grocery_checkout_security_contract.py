"""Grocery security/contract checks; these do not connect to MongoDB."""
import ast
from pathlib import Path

SERVER_PATH = Path(__file__).parents[1] / "server.py"
SOURCE = SERVER_PATH.read_text()
TREE = ast.parse(SOURCE)


def function_source(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


def test_product_schema_supports_stable_variants_and_rejects_duplicate_ids():
    assert "class ProductVariantIn(BaseModel)" in SOURCE
    assert "id: str = Field(min_length=1, max_length=80, pattern=r\"^[A-Za-z0-9._-]+$\")" in SOURCE
    assert "Variant IDs must be unique within a product" in SOURCE
    assert 'doc["variants"] = doc.get("variants") or []' in SOURCE


def test_quote_is_guest_session_bound_and_ten_minutes():
    quote = function_source("create_grocery_quote")
    assert 'request.headers.get("x-comein-guest-session")' in quote
    assert '"scope": scope' in quote
    assert 'timedelta(minutes=GROCERY_QUOTE_TTL_MINUTES)' in quote
    assert "GROCERY_QUOTE_TTL_MINUTES = 10" in SOURCE
    assert '"expires_at", expireAfterSeconds=0' in SOURCE


def test_order_requires_quote_and_idempotency_and_ignores_client_prices():
    order = function_source("create_order")
    assert 'if not body.quote_token' in order
    assert 'if not body.idempotency_key' in order
    assert '"grocery_idempotency_scope": idem_scope' in order
    assert '"grocery_idempotency_scope", unique=True, sparse=True' in SOURCE
    assert "_resolve_grocery_lines(current_lines_in, check_stock=True, session=session)" in order
    assert "await run_transaction(client, apply)" in order
    assert "prior_response is not None" in order
    assert '"stock_changed"' in order
    assert 'stock_at_quote' in order


def test_stock_decrement_is_atomic_and_conditional_for_base_and_variant():
    fn = function_source("_atomic_decrement_line")
    assert '"stock": {"$gte": qty}' in fn
    assert '"variants": {"$elemMatch"' in fn
    assert '"$inc": {"variants.$.stock": -qty}' in fn
    assert '"$inc": {"stock": -qty}' in fn


def test_mixed_shop_and_invalid_demo_ids_are_rejected_by_server_resolver():
    resolver = function_source("_resolve_grocery_lines")
    assert '"invalid_product_id"' in resolver
    assert '"mixed_shops"' in resolver
    assert '"status": "approved"' in resolver
    assert 'product.get("available", True)' in resolver


def test_delivery_fee_rule_is_authoritative_and_boundary_based():
    totals = function_source("_quote_totals")
    assert "GROCERY_DELIVERY_FEE_THRESHOLD = 199.0" in SOURCE
    assert "GROCERY_DELIVERY_FEE = 29.0" in SOURCE
    assert "subtotal >= GROCERY_DELIVERY_FEE_THRESHOLD" in totals
    assert "GROCERY_DELIVERY_FEE" in totals


def test_delivery_fee_boundaries_execute_authoritative_quote_totals():
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "_quote_totals")
    node.decorator_list = []
    class FakeHTTPException(Exception):
        def __init__(self, status_code, detail):
            self.status_code = status_code
            self.detail = detail
    line_amount_node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "_line_amount")
    namespace = {
        "GROCERY_DELIVERY_FEE_THRESHOLD": 199.0,
        "GROCERY_DELIVERY_FEE": 29.0,
        "MEASURED_QTY_LIMIT": 100000,
        "List": list,
        "HTTPException": FakeHTTPException,
    }
    exec(compile(ast.Module(body=[line_amount_node, node], type_ignores=[]), str(SERVER_PATH), "exec"), namespace)
    totals = namespace["_quote_totals"]
    try:
        totals([])
        assert False, "empty cart should reject"
    except FakeHTTPException as exc:
        assert exc.status_code == 422
    assert totals([{"price": 198.99, "qty": 1}]) == {"subtotal": 198.99, "delivery_fee": 29.0, "total": 227.99}
    assert totals([{"price": 199, "qty": 1}]) == {"subtotal": 199, "delivery_fee": 0.0, "total": 199.0}


def test_legacy_seller_product_update_preserves_variants_when_omitted():
    update = function_source("update_product")
    assert 'if body.variants is None:' in update
    assert 'patch.pop("variants", None)' in update


def test_grocery_checkout_allows_configured_manual_methods_but_fails_closed_for_unconfigured_gateways():
    order = function_source("create_order")
    assert 'body.payment_method not in enabled_methods' in order
    assert 'if body.payment_method == "online_stripe":' in order
    assert 'if body.payment_method == "online_razorpay":' in order
    assert 'if not _grocery_razorpay_keys():' in order
    assert '"payment_method_unavailable"' in order
    assert '"awaiting_upi_payment"' in order


def test_frontend_persists_grocery_idempotency_key_for_same_cart_retry():
    checkout = (SERVER_PATH.parents[1] / "frontend/app/checkout.tsx").read_text()
    assert 'const IDEMPOTENCY_KEY_STORAGE = "@comein_grocery_idempotency_v1"' in checkout
    assert 'saved?.fingerprint === cartFingerprint' in checkout
    assert 'storage.setItem(IDEMPOTENCY_KEY_STORAGE' in checkout
    assert 'storage.removeItem(IDEMPOTENCY_KEY_STORAGE)' in checkout


def test_frontend_live_variant_mapper_excludes_nonpositive_stock():
    mapper = (SERVER_PATH.parents[1] / "frontend/src/data/useCatalogProducts.ts").read_text()
    assert '.filter((v: ProductVariant) => v.available !== false && Number(v.stock ?? 0) > 0)' in mapper


def test_quote_is_claimed_once_inside_transaction_before_stock_and_order_writes():
    order = function_source("create_order")
    assert 'quote_claim = await db.grocery_quotes.update_one(' in order
    assert 'if quote_claim.modified_count != 1:' in order
    assert '"code": "quote_already_consumed"' in order
    assert order.index('if quote_claim.modified_count != 1:') < order.index('for line in latest_lines:')
    assert 'session=session' in order[order.index('quote_claim = await db.grocery_quotes.update_one('):order.index('if quote_claim.modified_count != 1:')]


def test_concurrent_duplicate_idempotency_key_returns_existing_order():
    order = function_source("create_order")
    assert 'except DuplicateKeyError as exc:' in order
    assert 'prior = await db.orders.find_one({"grocery_idempotency_scope": idem_scope})' in order
    assert 'if prior:' in order
    assert 'return doc_out(prior)' in order
    assert '"code": "duplicate_order_submission"' in order



def test_duplicate_cart_rows_are_aggregated_by_product_and_variant_before_stock_check():
    resolver = function_source("_resolve_grocery_lines")
    aggregate = function_source("_aggregate_grocery_quote_lines")
    assert "lines = _aggregate_grocery_quote_lines(lines)" in resolver
    assert "key = (product_id, variant_id)" in aggregate
    assert "quantity = aggregated.get(key, 0) + int(line.qty)" in aggregate
    assert '"quantity_limit_exceeded"' in aggregate


def test_duplicate_cart_rows_aggregate_without_merging_distinct_variants():
    node = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "_aggregate_grocery_quote_lines")

    class FakeHTTPException(Exception):
        def __init__(self, status_code, detail):
            self.status_code = status_code
            self.detail = detail

    class FakeObjectId:
        def __init__(self, value):
            if not isinstance(value, str) or len(value) != 24 or any(ch not in "0123456789abcdefABCDEF" for ch in value):
                raise ValueError("invalid ObjectId")
            self.value = value.lower()

        def __str__(self):
            return self.value

    class FakeQuoteLineIn:
        def __init__(self, product_id, qty, variant_id=None):
            self.product_id = product_id
            self.qty = qty
            self.variant_id = variant_id

    namespace = {"List": list, "Optional": __import__("typing").Optional, "QuoteLineIn": FakeQuoteLineIn, "ObjectId": FakeObjectId, "HTTPException": FakeHTTPException, "MEASURED_QTY_LIMIT": 100000}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(SERVER_PATH), "exec"), namespace)
    aggregate = namespace["_aggregate_grocery_quote_lines"]
    product = "64b000000000000000000001"
    rows = aggregate([
        FakeQuoteLineIn(product, 2, "pack-1"),
        FakeQuoteLineIn(product, 3, "pack-1"),
        FakeQuoteLineIn(product, 4, "pack-2"),
        FakeQuoteLineIn(product, 1, None),
        FakeQuoteLineIn(product, 2, ""),
    ])
    assert [(row.product_id, row.variant_id, row.qty) for row in rows] == [
        (product, "pack-1", 5), (product, "pack-2", 4), (product, None, 3)
    ]
    try:
        aggregate([FakeQuoteLineIn(product, 70000), FakeQuoteLineIn(product, 30001)])
        assert False, "combined measured quantity above 100000 must be rejected"
    except FakeHTTPException as exc:
        assert exc.status_code == 422
        assert exc.detail["code"] == "quantity_limit_exceeded"


def test_checkout_shop_revalidation_uses_the_active_transaction_session():
    shop_lookup = function_source("_get_shop_or_404")
    order = function_source("create_order")
    assert "async def _get_shop_or_404(shop_id: str, session=None)" in shop_lookup
    assert 'db.shops.find_one({"_id": oid}, session=session)' in shop_lookup
    assert "_get_shop_or_404(latest_shop_id, session=session)" in order


def test_grocery_payment_capture_updates_payment_and_order_in_one_transaction():
    capture = function_source("_mark_grocery_paid")
    assert "run_transaction(client, commit)" in capture
    assert "db.grocery_payments.find_one" in capture
    assert "db.grocery_payments.update_one" in capture
    assert "db.orders.update_one" in capture
    assert "session=session" in capture
    assert "payment_reconciliation_required" in capture
