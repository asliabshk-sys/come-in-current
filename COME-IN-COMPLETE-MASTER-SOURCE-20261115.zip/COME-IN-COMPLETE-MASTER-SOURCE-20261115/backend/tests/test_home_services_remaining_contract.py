from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text()
SERVICES = (ROOT / "frontend" / "app" / "services.tsx").read_text()
ADMIN = (ROOT / "frontend" / "app" / "admin.tsx").read_text()


def test_atomic_slot_reservation_and_unique_index_are_present():
    assert 'db.home_service_slot_reservations.create_index([("provider_id", 1), ("slot_key", 1)], unique=True)' in SERVER
    assert 'await db.home_service_slot_reservations.insert_one(reservation)' in SERVER
    assert 'except DuplicateKeyError:' in SERVER
    assert 'Appointment changed concurrently; refresh and try again' in SERVER


def test_reservation_release_and_reschedule_guards_are_present():
    assert 'db.home_service_slot_reservations.delete_one' in SERVER
    assert 'The new time slot is already reserved' in SERVER
    assert 'Rescheduled time must include timezone and be in the future' in SERVER


def test_fee_policy_is_admin_configurable_and_snapshotted():
    assert '@api.get("/home-services/fee-policy")' in SERVER
    assert '@api.patch("/admin/home-services/fee-policy")' in SERVER
    assert 'effective_home_visit_fee(provider, policy)' in SERVER
    assert '"visit_fee_policy": policy.get("mode", "provider")' in SERVER
    assert 'admin-home-service-fees' in ADMIN
    assert 'Save home-visit fee policy' in ADMIN


def test_provider_photo_uses_owned_existing_upload_storage():
    assert '@api.patch("/home-services/providers/{provider_id}/photo")' in SERVER
    assert 'file_record = await db.files.find_one({"storage_path": path, "owner_id": user["id"], "is_deleted": False})' in SERVER
    assert 'await api.upload(file,file.name)' in SERVICES
    assert '/photo`' in SERVICES


def test_customer_and_provider_dashboards_explain_status_and_payment():
    assert '/home-services/appointments/mine' in SERVICES
    assert '/home-services/appointments/provider' in SERVICES
    assert 'Request sent; provider has not confirmed yet.' in SERVICES
    assert 'Payment: {a.payment_status||"not_charged"}' in SERVICES
    assert 'Accept' in SERVICES and 'Reject' in SERVICES and 'Reschedule' in SERVICES


def test_existing_provider_approval_and_private_fields_remain_guarded():
    assert 'filt = {"status": "approved", "is_active": True}' in SERVER
    assert 'You can only change your own provider photo' in SERVER
    assert 'You can only edit your own provider profile' in SERVER
    assert 'if is_customer and not is_admin and body.status != "cancelled"' in SERVER

SHOP_DETAIL = (ROOT / "frontend" / "app" / "shop" / "[id].tsx").read_text()
SHOP_FORM = (ROOT / "frontend" / "app" / "become-seller.tsx").read_text()
RESTAURANT_DASHBOARD = (ROOT / "frontend" / "app" / "restaurant" / "dashboard.tsx").read_text()

def test_offline_shop_payment_options_are_configured_and_publicly_explained():
    assert '"cash_shop"' in SERVER
    assert 'validate_shop_payment_methods' in SERVER
    assert 'Enter a valid public UPI handle' in SERVER
    assert 'PAYMENT OPTIONS CONFIGURED BY THIS SHOP' in SHOP_DETAIL
    assert 'shopType === "offline"' in SHOP_DETAIL
    assert 'Cash at Shop / Pickup' in SHOP_FORM
    assert 'A UPI handle or payment-app launch is not proof of payment' in SHOP_FORM

def test_home_service_call_and_supported_payment_preferences_are_explicit():
    assert 'payment_preferences: List[Literal["cash_after_service", "cash_visit_fee"]]' in SERVER
    assert '"payment_preferences": provider.get("payment_preferences"' in SERVER
    assert 'Linking.openURL(`tel:${p.phone}`)' in SERVICES
    assert 'Cash after service' in SERVICES
    assert 'No online payment is collected by this appointment request.' in SERVICES

def test_restaurant_owner_can_edit_profile_and_upload_image():
    assert 'async function updateProfile()' in RESTAURANT_DASHBOARD
    assert 'api.patch<R>(`/restaurants/${selected.id}`' in RESTAURANT_DASHBOARD
    assert 'async function uploadLogo' in RESTAURANT_DASHBOARD
    assert 'image_url:imageURL||undefined' in RESTAURANT_DASHBOARD
