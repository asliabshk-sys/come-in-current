from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")
CHAND = (ROOT / "frontend" / "app" / "chand.tsx").read_text(encoding="utf-8")
ADMIN = (ROOT / "frontend" / "app" / "admin.tsx").read_text(encoding="utf-8")


def test_feedback_requires_authenticated_customer_and_validated_payload():
    assert 'class ChandFeedbackIn(BaseModel)' in SERVER
    assert 'rating: Literal["positive", "negative"]' in SERVER
    assert 'conversation_ref: str = Field(min_length=8, max_length=80' in SERVER
    assert '@api.post("/chand/feedback")' in SERVER
    assert 'user: dict = Depends(get_current_user)' in SERVER
    assert 'recent_count >= 5' in SERVER
    assert '"request_id": body.request_id' in SERVER
    assert 'unique=True' in SERVER


def test_feedback_minimizes_personal_data_and_redacts_common_secrets():
    assert '"user_id": 0' in SERVER
    assert '_redact_chand_feedback_comment' in SERVER
    assert '[email hidden]' in SERVER
    assert '[phone hidden]' in SERVER
    assert '[credential hidden]' in SERVER
    assert 'history' in SERVER
    assert 'conversation_ref' in SERVER


def test_admin_feedback_endpoints_are_role_protected_and_status_limited():
    assert '@api.get("/admin/chand/feedback")' in SERVER
    assert 'Depends(require_role("admin"))' in SERVER
    assert '@api.patch("/admin/chand/feedback/{feedback_id}")' in SERVER
    assert 'Invalid Chand feedback status transition' in SERVER


def test_chand_ui_submits_feedback_without_sending_transcript():
    assert 'testID="chand-feedback-positive"' in CHAND
    assert 'testID="chand-feedback-negative"' in CHAND
    assert 'testID="chand-feedback-submit"' in CHAND
    assert 'conversation_ref: lastAssistant.id' in CHAND
    assert 'comment: feedbackComment.trim()' in CHAND
    assert 'history:' not in CHAND[CHAND.find('submitChandFeedback'):CHAND.find('submitChandFeedback') + 900]


def test_admin_has_feedback_review_queue_and_status_actions():
    assert 'chandFeedback' in ADMIN
    assert '/admin/chand/feedback' in ADMIN
    assert 'Start review' in ADMIN
    assert 'Resolve' in ADMIN
    assert 'Close' in ADMIN


def test_budget_plan_supports_live_packs_variants_measured_items_and_existing_cart():
    assert 'type ChandPlanLine = { product: Product; quantity: number; variantId?: string; verifiedTotal?: number; partyNeed?: PartyNeed }' in CHAND
    assert 'product.source !== "live"' in CHAND
    assert 'product.variants?.length' in CHAND
    assert 'isMeasured(product)' in CHAND
    assert 'planTotal' in CHAND
    assert 'planTotal > budgetCap' in CHAND
    assert 'addProduct(line.product, line.variantId)' in CHAND
    assert 'setAmount(line.product, line.quantity)' in CHAND
    assert '"/catalog/products"' in CHAND
    assert '"/grocery/measured-price"' in CHAND
    assert 'testID="chand-plan-transfer-cart"' in CHAND
    assert 'existing COME-IN Cart' in CHAND
    assert 'server checkout quote' in CHAND


def test_assistant_context_has_per_actor_minute_rate_limit_and_ttl_cleanup():
    assert 'request: Request, user: Optional[dict] = Depends(get_current_user_optional)' in SERVER
    assert 'assistant_rate_limits.update_one' in SERVER
    assert 'minute_bucket = int(now_utc().timestamp() // 60)' in SERVER
    assert ' > 20' in SERVER
    assert 'create_index("expires_at", expireAfterSeconds=0)' in SERVER
    assert 'hashlib.sha256' in SERVER


def test_party_planner_builds_catalog_search_and_reuses_budget_list():
    assert 'testID="chand-party-planner"' in CHAND
    assert 'testID="chand-party-guests"' in CHAND
    assert 'testID="chand-party-budget"' in CHAND
    assert 'testID="chand-party-generate"' in CHAND
    assert 'buildPartyPlanGroups(liveProducts, guests, partyServing)' in CHAND
    assert 'setBudgetCap(budget)' in CHAND
    assert 'Calculate party quantities' in CHAND
    assert 'Use another catalog match' in CHAND
    helper = (ROOT / 'frontend' / 'src' / 'lib' / 'chand-party-planner.ts').read_text(encoding='utf-8')
    assert 'guests * assumptions.snacksGramsPerGuest' in helper
    assert 'guests * assumptions.drinksMlPerGuest' in helper
    assert 'guests * assumptions.bakeryPiecesPerGuest' in helper
    assert 'guests * assumptions.fruitGramsPerGuest' in helper
    assert 'PARTY_OCCASION_SERVING_ASSUMPTIONS' in helper
    assert 'setPartyServing(PARTY_OCCASION_SERVING_ASSUMPTIONS[occasion])' in CHAND
    assert 'product.source !== "live"' in helper
    assert 'Math.ceil(requiredAmount / measure.step) * measure.step' in helper
    assert 'Math.ceil(requiredAmount / packSize)' in helper


def test_admin_feedback_summary_is_role_protected_and_aggregate_only():
    assert '@api.get("/admin/chand/feedback/summary")' in SERVER
    summary = SERVER[SERVER.find('async def admin_chand_feedback_summary'):SERVER.find('@api.patch("/admin/chand/feedback/{feedback_id}")')]
    assert 'Depends(require_role("admin"))' in summary
    assert '"$group"' in summary
    assert 'user_id' not in summary
    assert 'row.get("comment")' not in summary
    assert 'row.get("user_id")' not in summary
