"""Focused tests for the public Grocery catalog contract; no live MongoDB used."""
import ast
import asyncio
import copy
from pathlib import Path

SERVER = Path(__file__).parents[1] / "server.py"
TREE = ast.parse(SERVER.read_text())


def _catalog_function():
    fn = copy.deepcopy(next(
        node for node in TREE.body
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "list_catalog_products"
    ))
    # Execute the actual route body without importing server.py (which creates a
    # Mongo client and requires optional runtime dependencies/configuration).
    fn.decorator_list = []
    module = ast.Module(body=[fn], type_ignores=[])
    return compile(module, str(SERVER), "exec")


class FakeCursor:
    def __init__(self, rows):
        self.rows = list(rows)

    def sort(self, field, direction):
        reverse = direction < 0
        self.rows.sort(key=lambda row: row.get(field, ""), reverse=reverse)
        return self

    def __aiter__(self):
        self._iter = iter(self.rows)
        return self

    async def __anext__(self):
        try:
            return next(self._iter)
        except StopIteration:
            raise StopAsyncIteration


class FakeCollection:
    def __init__(self, rows, kind):
        self.rows = rows
        self.kind = kind
        self.last_query = None

    def find(self, query):
        self.last_query = query
        if self.kind == "shops":
            result = [row for row in self.rows if row.get("status") == query.get("status")]
        else:
            shop_ids = query["shop_id"]["$in"]
            def eligible(row):
                if row.get("shop_id") not in shop_ids or row.get("available") is not query["available"]:
                    return False
                variants = row.get("variants") or []
                base_eligible = row.get("stock", 0) > 0 and not variants
                variant_eligible = any(v.get("available", True) and v.get("stock", 0) > 0 for v in variants)
                return base_eligible or variant_eligible
            result = [row for row in self.rows if eligible(row)]
        return FakeCursor(result)


class FakeDB:
    def __init__(self, shops, products):
        self.shops = FakeCollection(shops, "shops")
        self.products = FakeCollection(products, "products")


def _run_catalog(shops, products):
    db = FakeDB(shops, products)
    namespace = {
        "db": db,
        "doc_out": lambda row: {**row, "id": str(row.get("_id", ""))},
    }
    exec(_catalog_function(), namespace)
    result = asyncio.run(namespace["list_catalog_products"]())
    return result, db


def test_catalog_includes_eligible_products_from_approved_online_and_offline_shops():
    shops = [
        {"_id": "online-1", "name": "Online Shop", "status": "approved", "online": True, "shop_type": "online"},
        {"_id": "offline-1", "name": "Offline Shop", "status": "approved", "online": False, "shop_type": "offline"},
        {"_id": "pending-1", "name": "Pending Shop", "status": "pending", "online": True, "shop_type": "both"},
    ]
    products = [
        {"_id": "p1", "shop_id": "online-1", "name": "Online Item", "available": True, "stock": 4, "created_at": "2026-01-02"},
        {"_id": "p2", "shop_id": "offline-1", "name": "Offline Item", "available": True, "stock": 1, "created_at": "2026-01-01"},
        {"_id": "p3", "shop_id": "pending-1", "name": "Pending Item", "available": True, "stock": 9},
        {"_id": "p4", "shop_id": "online-1", "name": "Unavailable Item", "available": False, "stock": 9},
        {"_id": "p5", "shop_id": "online-1", "name": "Out of Stock Item", "available": True, "stock": 0},
        {"_id": "p6", "shop_id": "offline-1", "name": "Real Variant Product", "available": True, "stock": 0, "variants": [{"id": "pack-1", "unit": "1 kg", "price": 80, "stock": 4, "available": True}]},
    ]

    result, db = _run_catalog(shops, products)

    assert [row["name"] for row in result] == ["Online Item", "Offline Item", "Real Variant Product"]
    assert result[0]["shop_name"] == "Online Shop"
    assert result[0]["shop_type"] == "online"
    assert result[1]["shop_name"] == "Offline Shop"
    assert db.shops.last_query == {"status": "approved"}
    assert db.products.last_query["shop_id"] == {"$in": ["online-1", "offline-1"]}
    assert db.products.last_query["available"] is True
    assert "$or" in db.products.last_query


def test_catalog_returns_empty_without_approved_shops_and_does_not_query_products():
    result, db = _run_catalog(
        [{"_id": "pending-1", "status": "pending", "name": "Pending"}],
        [{"_id": "p1", "shop_id": "pending-1", "available": True, "stock": 3}],
    )

    assert result == []
    assert db.products.last_query is None


def test_catalog_route_is_public_get_route_and_does_not_filter_online_status():
    routes = []
    for node in ast.walk(TREE):
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "list_catalog_products":
            for decorator in node.decorator_list:
                if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute):
                    if isinstance(decorator.func.value, ast.Name) and decorator.func.value.id == "api":
                        routes.append((decorator.func.attr.upper(), decorator.args[0].value))
    assert routes == [("GET", "/catalog/products")]
    source = ast.get_source_segment(SERVER.read_text(), next(
        node for node in TREE.body
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "list_catalog_products"
    ))
    assert '"status": "approved"' in source
    assert '"available": True' in source
    assert '"stock": {"$gt": 0}' in source
    assert '"online":' not in source


def test_imported_products_need_approval_and_application_while_legacy_products_remain_visible():
    shops = [{"_id": "s1", "name": "Shop", "status": "approved"}]
    products = [
        {"_id": "legacy", "shop_id": "s1", "name": "Legacy", "available": True, "stock": 3},
        {"_id": "staged", "shop_id": "s1", "name": "Staged", "available": True, "stock": 3, "catalogue_import_job_id": "job1"},
        {"_id": "approved-only", "shop_id": "s1", "name": "Approved only", "available": True, "stock": 3, "catalogue_import_job_id": "job2", "catalogue_import_approved": True},
        {"_id": "published", "shop_id": "s1", "name": "Published", "available": True, "stock": 3, "catalogue_import_job_id": "job3", "catalogue_import_approved": True, "catalogue_import_applied": True},
    ]
    result, _ = _run_catalog(shops, products)
    names = {row["name"] for row in result}
    assert names == {"Legacy", "Published"}


def test_catalogue_visibility_guard_preserves_stock_and_available_filters():
    assert '"available": True' in SERVER.read_text()
    assert '"stock": {"$gt": 0}' in SERVER.read_text()
    assert '"catalogue_import_approved") is True and product.get("catalogue_import_applied") is True' in SERVER.read_text()
