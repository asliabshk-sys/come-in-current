from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHAND_SCREEN = ROOT / "frontend" / "app" / "chand.tsx"
HOME_SCREEN = ROOT / "frontend" / "app" / "(tabs)" / "index.tsx"


def test_chand_brand_disclosure_and_live_catalog_connection_are_present():
    source = CHAND_SCREEN.read_text(encoding="utf-8")
    server = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")
    assert "CHAND" in source
    assert "आपका अपना स्मार्ट साथी" in source
    assert "chand.demo" in source
    assert 'api.post<AssistantContext>("/assistant/context"' in source
    assert '@api.post("/assistant/context")' in server
    assert 'context["answer"] = None' in server
    assert "COMEIN_AI_API_KEY" in server


def test_chand_has_four_explicit_role_modes_and_prompt_sets():
    source = CHAND_SCREEN.read_text(encoding="utf-8")
    for role in ("customer", "shopkeeper", "restaurant", "services"):
        assert f'{role}: "' in source
        assert f"{role}: [" in source


def test_chand_chat_uses_live_catalog_or_safe_fallback_and_does_not_mutate_orders_or_payments():
    source = CHAND_SCREEN.read_text(encoding="utf-8")
    assert "Deterministic local response" in source
    assert 'api.post<AssistantContext>("/assistant/context"' in source
    assert 'router.push("/orders")' in source
    assert 'api.post("/orders"' not in source
    assert 'api.post("/restaurant/orders"' not in source
    assert 'api.post("/admin/restaurant/orders/' not in source


def test_chand_support_uses_authenticated_existing_support_api_only():
    source = CHAND_SCREEN.read_text(encoding="utf-8")
    assert 'api.get<any[]>("/orders/mine")' in source
    assert 'api.get<any[]>("/restaurant/orders/mine")' in source
    assert 'api.get<any[]>("/restaurant/support/mine")' in source
    assert 'api.post<SupportTicket>("/restaurant/support", payload)' in source
    assert 'if (selectedOrder) { payload.order_id = selectedOrder.id; payload.order_kind = selectedOrder.kind; }' in source
    assert 'No customer-facing refund request API exists' in source


def test_chand_does_not_trigger_real_refund_and_distinguishes_request_from_payment():
    source = CHAND_SCREEN.read_text(encoding="utf-8")
    assert 'api.post("/admin/restaurant/orders/' not in source
    assert "not a refund approval or payment" in source
    assert "actual refund execution is admin-only" in source


def test_chand_support_has_confirmation_and_status_disclosures():
    source = CHAND_SCREEN.read_text(encoding="utf-8")
    assert 'testID="chand-support-submit"' in source
    assert 'testID="chand-support-confirm"' in source
    assert 'setConfirmSupport(true)' in source
    assert 'testID="chand-support-submit"' in source and 'testID="chand-support-confirm"' in source
    assert "Current status: ${created.status}" in source
    assert "Actual case status: {ticket.status}" in source
    assert "Never share passwords, OTPs or payment credentials" in source

def test_existing_home_screen_links_to_chand_without_replacing_modes():
    source = HOME_SCREEN.read_text(encoding="utf-8")
    assert 'router.push("/chand")' in source
    assert 'router.push("/restaurant")' in source
    assert 'router.push("/services")' in source


def test_refund_execution_remains_admin_only_and_customer_refund_api_is_absent():
    server = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")
    assert '@api.post("/admin/restaurant/orders/{order_id}/refund")' in server
    assert 'async def admin_refund_restaurant_order(order_id: str, _: dict = Depends(require_role("admin")))' in server
    assert '@api.post("/restaurant/refund' not in server
    assert '@api.post("/refund' not in server


def test_existing_support_api_scopes_tickets_to_authenticated_user_and_checks_order_ownership():
    server = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")
    assert '@api.post("/restaurant/support")' in server
    assert 'async def create_restaurant_support(body: RestaurantSupportIn, user: dict = Depends(get_current_user))' in server
    assert '"customer_id":user["id"]' in server
    assert 'db.restaurant_support.find({"user_id":user["id"]})' in server


def test_existing_refund_flow_checks_paid_order_and_duplicate_refund_status():
    server = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")
    refund_start = server.index('async def admin_refund_restaurant_order')
    refund_end = server.index('@api.get("/admin/restaurant/orders")', refund_start)
    refund_route = server[refund_start:refund_end]
    assert 'order.get("payment_status") != "paid"' in refund_route
    assert 'amount_to_paise(order.get("total"))' in refund_route
    assert 'blocked_refund_states' in refund_route
    assert '_claim_restaurant_refund_for_gateway(' in refund_route
    assert 'run_transaction(client, claim)' in server
    assert '_fetch_razorpay_refunds' in refund_route
    assert 'refund_status' in refund_route and 'refund_uncertain' in refund_route


def test_chand_demo_has_safe_guidance_for_common_support_issues_and_unknown_requests():
    source = CHAND_SCREEN.read_text(encoding="utf-8")
    for phrase in (
        "Duplicate payment",
        "Missing item",
        "Delayed order",
        "Wrong ya damaged item",
        "Cancellation ke liye",
        "Actual refund status",
        "refund approval ya completed payment nahi hota",
        "I will not",
    ):
        if phrase == "I will not":
            assert "I will not" in source or "information invent nahi karunga" in source
        else:
            assert phrase in source
    assert "No customer-facing refund request API exists" in source
    assert "OTP, PIN, CVV ya password share na karein" in source
