"""Executable offline transaction fault-injection; fake driver is NOT a live MongoDB test."""
import ast
import asyncio
import copy
import itertools
import math
import re
from pathlib import Path
from types import SimpleNamespace
from typing import List, Optional, Literal

import pytest
from fastapi import HTTPException
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator
from mongo_transactions import run_transaction

SOURCE = (Path(__file__).parents[1] / 'server.py').read_text()
TREE = ast.parse(SOURCE)
IDS = itertools.count(1)


class ObjId:
    @staticmethod
    def is_valid(value):
        return isinstance(value, str) and len(value) == 24

    def __new__(cls, value):
        return value


class Collection:
    def __init__(self):
        self.docs = []
        self.fail_at_insert = None
        self.insert_count = 0
        self.fail_update = False

    def _match(self, document, query):
        for key, value in query.items():
            if key == '$or':
                if not any(self._match(document, subquery) for subquery in value):
                    return False
                continue
            observed = document.get(key)
            if isinstance(value, dict):
                if '$in' in value and observed not in value['$in']:
                    return False
                if '$nin' in value and observed in value['$nin']:
                    return False
                if '$ne' in value and observed == value['$ne']:
                    return False
                if '$exists' in value and (key in document) != value['$exists']:
                    return False
            elif observed != value:
                return False
        return True

    async def find_one(self, query, projection=None, session=None):
        for document in self.docs:
            if self._match(document, query):
                return copy.deepcopy(document)
        return None

    async def update_one(self, query, patch, session=None):
        if self.fail_update:
            raise RuntimeError('injected DB update failure')
        for document in self.docs:
            if self._match(document, query):
                for key, value in patch.get('$set', {}).items():
                    document[key] = copy.deepcopy(value)
                for key, value in patch.get('$inc', {}).items():
                    document[key] = document.get(key, 0) + value
                for key, value in patch.get('$push', {}).items():
                    document.setdefault(key, []).append(copy.deepcopy(value))
                return SimpleNamespace(modified_count=1, matched_count=1)
        return SimpleNamespace(modified_count=0, matched_count=0)

    async def insert_one(self, record, session=None):
        self.insert_count += 1
        if self.fail_at_insert == self.insert_count:
            raise RuntimeError('injected DB insert failure')
        document = copy.deepcopy(record)
        document['_id'] = f'{next(IDS):024d}'
        self.docs.append(document)
        return SimpleNamespace(inserted_id=document['_id'])


class FakeDatabase:
    def __init__(self, jobs):
        self.catalogue_import_jobs = Collection()
        self.catalogue_import_jobs.docs.extend(copy.deepcopy(jobs))
        self.products = Collection()
        self.catalogue_import_audit = Collection()
        self.shops = Collection()
        self.shops.docs.append({'_id': 's1', 'owner_id': 'seller1'})


class Session:
    def __init__(self, db, transient_once=False, ambiguous_commit=False):
        self.db = db
        self.transient_once = transient_once
        self.ambiguous_commit = ambiguous_commit
        self.attempts = 0

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def with_transaction(self, callback):
        while True:
            self.attempts += 1
            snapshot = {key: copy.deepcopy(getattr(self.db, key).docs)
                        for key in ('catalogue_import_jobs', 'products', 'catalogue_import_audit', 'shops',
                                    'restaurant_orders', 'restaurant_payments', 'orders', 'grocery_payments', 'financial_ledger') if hasattr(self.db, key)}
            try:
                result = await callback(self)
                if self.transient_once:
                    self.transient_once = False
                    raise Transient()
            except Exception as exc:
                for key, documents in snapshot.items():
                    getattr(self.db, key).docs = documents
                if isinstance(exc, Transient):
                    continue
                raise
            if self.ambiguous_commit:
                # Commit occurred on the fake database; caller must reconcile.
                self.ambiguous_commit = False
                raise RuntimeError('unknown commit result after commit')
            return result


class Transient(Exception):
    pass


class Client:
    def __init__(self, db, **kwargs):
        self.db = db
        self.kwargs = kwargs
        self.sessions = []

    async def start_session(self):
        session = Session(self.db, **self.kwargs)
        self.sessions.append(session)
        return session


def make_job(count=2, sku_prefix='SKU', seller='seller1', job_id='j1'):
    records = []
    for i in range(count):
        records.append({
            'review_status': 'APPROVED', 'approved_by': seller,
            'normalized': {'name': f'Rice {i}', 'brand': '', 'unit': 'kg', 'price': '80',
                           'stock': '1000', 'category_id': 'grocery', 'description': 'Rice',
                           'sku': f'{sku_prefix}{i}'},
            'source_file': 'catalog.csv', 'source_location': str(i + 1), 'source_sha256': 'a' * 64,
        })
    return {'_id': f'j{job_id}', 'job_id': job_id, 'shop_id': 's1', 'seller_id': seller,
            'records': records, 'status': 'NEEDS_SELLER_REVIEW', 'applied': False}


def load_functions(db, client):
    names = {'_catalogue_record_fields', '_catalogue_record_validation', '_import_measure',
             '_catalogue_applied_result', '_apply_catalogue_import_job_transactionally',
             'confirm_catalogue_import_apply'}
    classes = {'MeasureIn', 'ProductIn', 'ProductVariantIn'}
    nodes = []
    for node in TREE.body:
        if isinstance(node, ast.ClassDef) and node.name in classes:
            nodes.append(copy.deepcopy(node))
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names:
            node = copy.deepcopy(node)
            node.decorator_list = []
            nodes.append(node)
    namespace = {
        'BaseModel': BaseModel, 'Field': Field, 'ValidationError': ValidationError,
        'field_validator': field_validator, 'model_validator': model_validator,
        'MEASURED_SELL_BY': {'weight': ('g', 'kg'), 'volume': ('ml', 'L')},
        'MEASURED_QTY_LIMIT': 100000, 'Optional': Optional, 'List': List, 'Literal': Literal,
        'math': math, 're': re, 'HTTPException': HTTPException, 'ObjectId': ObjId,
        'db': db, 'client': client, 'now_utc': lambda: 'test-time',
        '_reject_directory_only_product': lambda _category: None,
        'run_transaction': run_transaction,
        'Depends': lambda _arg: None, 'get_current_user': lambda: None,
        'DuplicateKeyError': type('DuplicateKeyError', (Exception,), {}),
        'logger': SimpleNamespace(error=lambda *args: None),
    }
    async def shop_or_404(shop_id, session=None):
        shop = await db.shops.find_one({'_id': shop_id})
        if shop is None:
            raise HTTPException(status_code=404)
        return shop
    async def owned_job(shop_id, job_id, user):
        job = await db.catalogue_import_jobs.find_one({'shop_id': shop_id, 'job_id': job_id, 'seller_id': user['id']})
        if job is None:
            raise HTTPException(status_code=404)
        return job
    namespace['_get_shop_or_404'] = shop_or_404
    namespace['_owned_catalogue_import_job'] = owned_job
    namespace['_assert_shop_owner'] = lambda shop, user: None
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), '<actual-server-ast>', 'exec'), namespace)
    return namespace


def call(fn, *args):
    return asyncio.run(fn(*args))


def test_atomic_import_commit_and_idempotent_repeat_returns_existing_ids():
    db = FakeDatabase([make_job()])
    client = Client(db)
    env = load_functions(db, client)
    result = call(env['confirm_catalogue_import_apply'], 's1', 'j1', {'confirm': True}, {'id': 'seller1', 'role': 'shopkeeper'})
    assert result['status'] == 'APPLIED' and len(result['product_ids']) == 2
    assert len(db.products.docs) == 2 and len(db.catalogue_import_audit.docs) == 1
    assert db.catalogue_import_jobs.docs[0]['applied'] is True
    assert all(row['available'] is False and row['stock'] == 1000 and row['catalogue_import_applied']
               for row in db.products.docs)
    repeat = call(env['confirm_catalogue_import_apply'], 's1', 'j1', {'confirm': True}, {'id': 'seller1', 'role': 'shopkeeper'})
    assert repeat['product_ids'] == result['product_ids'] and len(db.products.docs) == 2


def test_partial_insert_error_rolls_back_job_product_stock_and_audit():
    db = FakeDatabase([make_job()])
    client = Client(db)
    env = load_functions(db, client)
    db.products.fail_at_insert = 2
    with pytest.raises(HTTPException) as exc:
        call(env['confirm_catalogue_import_apply'], 's1', 'j1', {'confirm': True}, {'id': 'seller1'})
    assert exc.value.status_code == 503
    assert db.products.docs == [] and db.catalogue_import_audit.docs == []
    assert db.catalogue_import_jobs.docs[0]['status'] == 'NEEDS_SELLER_REVIEW'
    db.products.fail_at_insert = None
    assert call(env['confirm_catalogue_import_apply'], 's1', 'j1', {'confirm': True}, {'id': 'seller1'})['applied']


def test_transient_retry_starts_clean_and_commits_only_once():
    db = FakeDatabase([make_job()])
    client = Client(db, transient_once=True)
    env = load_functions(db, client)
    result = call(env['_apply_catalogue_import_job_transactionally'], 's1', 'j1', 'seller1')
    assert len(result['product_ids']) == 2 and len(db.products.docs) == 2
    assert client.sessions[0].attempts == 2


def test_unknown_commit_is_reconciled_without_second_inventory_insert():
    db = FakeDatabase([make_job()])
    client = Client(db, ambiguous_commit=True)
    env = load_functions(db, client)
    result = call(env['confirm_catalogue_import_apply'], 's1', 'j1', {'confirm': True}, {'id': 'seller1'})
    assert result['applied'] and len(db.products.docs) == 2 and len(db.catalogue_import_audit.docs) == 1


def test_sku_conflict_with_another_import_is_refused_without_partial_writes():
    db = FakeDatabase([make_job(count=1), make_job(count=1, job_id='j2')])
    client = Client(db)
    env = load_functions(db, client)
    call(env['_apply_catalogue_import_job_transactionally'], 's1', 'j1', 'seller1')
    with pytest.raises(HTTPException) as exc:
        call(env['_apply_catalogue_import_job_transactionally'], 's1', 'j2', 'seller1')
    assert exc.value.status_code == 409
    assert len(db.products.docs) == 1 and db.catalogue_import_jobs.docs[1]['applied'] is False


def test_ownership_is_rechecked_inside_transaction():
    db = FakeDatabase([make_job()])
    db.shops.docs[0]['owner_id'] = 'different-owner'
    env = load_functions(db, Client(db))
    with pytest.raises(HTTPException) as exc:
        call(env['_apply_catalogue_import_job_transactionally'], 's1', 'j1', 'seller1')
    assert exc.value.status_code == 403
    assert db.products.docs == []


def test_legacy_pending_emergent_import_can_finish_without_changing_review():
    job = make_job(count=1)
    job.update({'status': 'APPLY_PENDING_EMERGENT', 'seller_confirmed_by': 'seller1'})
    db = FakeDatabase([job])
    env = load_functions(db, Client(db))
    assert call(env['_apply_catalogue_import_job_transactionally'], 's1', 'j1', 'seller1')['applied']
