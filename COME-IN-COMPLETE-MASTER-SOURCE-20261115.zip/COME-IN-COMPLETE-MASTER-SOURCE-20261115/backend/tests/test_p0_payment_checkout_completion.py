from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_grocery_checkout_exposes_only_configured_shop_payment_methods():
    source = (ROOT / "frontend/app/checkout.tsx").read_text()
    assert 'testID="pm-cod"' in source
    assert 'testID="pm-upi"' in source
    assert 'testID="pm-cash-shop"' in source
    assert "shopOptions.publicUpi" in source
    assert "paymentAvailable" in source
    assert 'Linking.openURL(placed.payment_uri)' in source


def test_grocery_upi_order_is_pending_until_shopkeeper_confirms_receipt():
    server = (ROOT / "backend/server.py").read_text()
    assert '"payment_status": ("cod_pending" if body.payment_method == "cod" else "awaiting_upi_payment"' in server
    assert '"payment_uri"] = "upi://pay?" + urlencode(upi_params)' in server
    assert '@api.post("/orders/{order_id}/confirm-upi-payment")' in server
    assert '"payment_status": "paid", "status": "pending"' in server
    assert "Shopkeeper confirmed UPI receipt after checking bank statement" in server


def test_seller_can_confirm_upi_only_from_owner_orders_screen():
    source = (ROOT / "frontend/app/seller/orders.tsx").read_text()
    assert 'api.post(`/orders/${orderId}/confirm-upi-payment`, {})' in source
    assert "Confirm UPI received (verify bank first)" in source


def test_restaurant_registration_saves_selected_payment_methods():
    source = (ROOT / "frontend/app/restaurant/dashboard.tsx").read_text()
    assert "setPaymentMethods" in source
    assert "payment_methods:paymentMethods" in source
    assert "Online payment (Razorpay)" in source
    checkout = (ROOT / "frontend/app/restaurant/checkout.tsx").read_text()
    assert "restaurantPaymentMethods.includes('cod')" in checkout
    assert "restaurantPaymentMethods.includes('pickup')" in checkout
    assert "payment_method: chosenMethod" in checkout
