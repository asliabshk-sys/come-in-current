from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text()
ENV = (ROOT / "backend" / ".env.example").read_text()
SETUP = (ROOT / "docs" / "COME-IN-CHAND-SETUP-2026-10-19.md").read_text()

def test_chand_supports_native_ollama_without_cloud_api_key():
    assert 'os.environ.get("COMEIN_AI_PROVIDER")' in SERVER
    assert 'ai_provider == "ollama"' in SERVER
    assert '"/api/chat"' in SERVER
    assert '"stream": False' in SERVER
    assert '"message", {}).get("content")' in SERVER

def test_ollama_timeout_and_fallback_are_bounded():
    assert 'timeout=30 if ai_provider == "ollama" else 12' in SERVER
    assert '"temporarily_unavailable"' in SERVER
    assert 'Leave `COMEIN_AI_API_KEY` blank' in SETUP

def test_provider_configuration_and_safety_docs_are_present():
    assert "COMEIN_AI_PROVIDER=\n" in ENV
    assert 'os.environ.get("COMEIN_AI_PROVIDER") or "openai_compatible"' in SERVER
    assert "COMEIN_AI_BASE_URL=" in ENV
    assert "COMEIN_AI_API_KEY=" in ENV
    assert "COMEIN_AI_MODEL=" in ENV
    assert "Optional open-source local AI (Ollama)" in SETUP
    assert "model licence" in SETUP.lower()
