from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")


def test_import_workflow_endpoints_are_shop_scoped_and_separate_from_legacy_import():
    for route in ("/catalogue-import/jobs\"", "/catalogue-import/categories\"", "/bulk-approve\"", "/confirm-apply\""):
        assert route in SERVER
    assert "_assert_shop_owner(shop, user)" in SERVER
    assert '"seller_id": user["id"]' in SERVER


def test_record_approval_requires_validation_and_bulk_skips_uncertain_ai():
    assert "_catalogue_record_validation(record)" in SERVER
    assert 'bool(chand.get("uncertain_fields"))' in SERVER
    assert '"uncertain AI suggestions require individual review"' in SERVER


def test_confirm_apply_transactions_only_approved_products_and_never_publishes():
    apply = SERVER[SERVER.find("async def _apply_catalogue_import_job_transactionally"):SERVER.find("@api.post(\"/shops/{shop_id}/catalogue-import/jobs/{job_id}/confirm-apply\")")]
    endpoint = SERVER[SERVER.find("async def confirm_catalogue_import_apply"):SERVER.find("@api.post(\"/shops/{shop_id}/products/import\")")]
    assert 'body.get("confirm") is not True' in endpoint
    assert 'await _apply_catalogue_import_job_transactionally' in endpoint
    assert '"review_status") == "APPROVED"' in apply
    assert '"available": False' in apply
    assert '"catalogue_import_applied": True' in apply
    assert 'db.products.insert_one(product, session=session)' in apply
    assert 'db.catalogue_import_audit.insert_one(' in apply
    assert 'return await run_transaction(client, apply)' in apply
    assert 'catalogue_import_lock_version' in apply
    assert '"status": "APPLIED"' in apply
    assert 'db.inventory' not in apply


def test_legacy_products_keep_backward_compatible_visibility_but_imported_require_approval():
    assert 'if product.get("catalogue_import_job_id") or product.get("catalogue_import_source")' in SERVER
    assert 'product.get("catalogue_import_approved") is True and product.get("catalogue_import_applied") is True' in SERVER
    assert "_catalogue_publication_allowed(product)" in SERVER
    assert '"code": "product_unapproved"' in SERVER


def test_cart_quote_rejects_unapproved_import_before_pricing_and_stock_checks():
    start = SERVER.find("async def _resolve_grocery_lines")
    end = SERVER.find("@api.post(\"/grocery/quote\")", start)
    block = SERVER[start:end]
    assert '_catalogue_publication_allowed(product)' in block
    assert block.index('_catalogue_publication_allowed(product)') < block.index('_price_for(product, line.variant_id)')
    assert '"code": "product_unapproved"' in block


def test_checkout_reuses_quote_line_resolver_and_task5_contract_is_retained():
    assert 'await _resolve_grocery_lines' in SERVER
    assert 'MEASURED_SELL_BY' in SERVER
    assert 'catalogue_import_jobs' in SERVER


def test_review_actions_lock_after_seller_apply_confirmation():
    assert "def _assert_catalogue_job_review_open(job: dict)" in SERVER
    assert '"APPLY_PENDING_EMERGENT"' in SERVER
    for function_name in (
        "edit_catalogue_import_record", "approve_catalogue_import_record",
        "reject_catalogue_import_record", "bulk_approve_catalogue_import_records",
    ):
        start = SERVER.find(f"async def {function_name}(")
        end = SERVER.find("\n@api.", start)
        block = SERVER[start:end]
        assert "_assert_catalogue_job_review_open(job)" in block
