from pathlib import Path


def test_seller_panel_has_real_master_search_and_variant_link_flow():
    source = Path(__file__).resolve().parents[2].joinpath("frontend", "app", "seller", "products.tsx").read_text()
    assert 'testID="seller-master-catalog"' in source
    assert 'api.get<MasterProduct[]>(`/catalog/master-products?q=${encodeURIComponent(query)}&limit=50`)' in source
    assert 'api.post(`/shops/${shopId}/master-products/${selectedMaster.id}/link`' in source
    assert 'testID="master-link-submit"' in source
    assert "selectedMaster.variants" in source
    assert "setProducts" in source


def test_seller_master_flow_handles_loading_empty_and_expected_errors():
    source = Path(__file__).resolve().parents[2].joinpath("frontend", "app", "seller", "products.tsx").read_text()
    for marker in (
        "masterLoading", "No matching active master products", "already linked", "session expired",
        "not authorized", "Could not link product", "Check your connection",
    ):
        assert marker.lower() in source.lower()


def test_shop_specific_price_stock_and_availability_are_sent_to_backend():
    source = Path(__file__).resolve().parents[2].joinpath("frontend", "app", "seller", "products.tsx").read_text()
    assert "variant_id: selectedVariantId, price, mrp, stock, available: linkAvailable" in source
    assert "Number.isInteger(stock)" in source
    assert "mrp < price" in source
