"""Task 22 checkout lifecycle regression contracts; no live API/DB."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHECKOUT = (ROOT / "frontend/app/checkout.tsx").read_text()
STORE = (ROOT / "frontend/src/store/cart.tsx").read_text()
BACKEND = (ROOT / "backend/server.py").read_text()


def test_buy_now_selection_is_cleared_when_checkout_blurs_by_any_navigation_path():
    assert 'import { useFocusEffect, useRouter } from "expo-router";' in CHECKOUT
    assert "useFocusEffect(useCallback(() => () => clearBuyNow(), [clearBuyNow]));" in CHECKOUT
    assert "if (buyNowLine) clearBuyNow();\n      else clear();" in CHECKOUT


def test_buy_now_is_separate_from_persisted_cart_and_checkout_selects_only_one_mode():
    assert "const [buyNowLine, setBuyNowLine] = useState<CartLine | null>(null);" in STORE
    assert "const checkoutLines = buyNowLine ? [buyNowLine] : cartLines;" in CHECKOUT
    assert "if (buyNowLine) clearBuyNow();\n      else clear();" in CHECKOUT


def test_checkout_uses_quote_token_and_idempotency_key_not_client_totals_as_authority():
    assert 'api.post<GroceryQuote>("/grocery/quotes"' in CHECKOUT
    assert "items: checkoutLines.map((line) => ({ product_id: line.product.id, variant_id: line.variant?.id, qty: line.qty }))" in CHECKOUT
    assert "quote_token: quote.quote_token" in CHECKOUT
    assert "idempotency_key: idempotencyKey" in CHECKOUT
    assert "current_lines_in = [QuoteLineIn(product_id=x[\"product_id\"], qty=x[\"qty\"], variant_id=x.get(\"variant_id\")) for x in quote[\"items\"]]" in BACKEND


def test_backend_keeps_quote_claim_stock_decrement_and_order_insert_in_one_transaction():
    start = BACKEND.index("async def create_order(body: OrderIn, request: Request):")
    end = BACKEND.index("@api.post(\"/orders/{order_id}/confirm-upi-payment\")", start)
    order_source = BACKEND[start:end]
    assert "await run_transaction(client, apply)" in order_source
    assert '"status": "open"' in order_source
    assert '"status": "consumed"' in order_source
    assert "await _atomic_decrement_line(session, line)" in order_source
    assert "await db.orders.insert_one(order_doc, session=session)" in order_source
    assert "non-transactional fallback" in order_source


def test_pickup_fee_is_zero_and_grocery_online_gateways_remain_disabled():
    assert '0.0 if fulfillment == "pickup"' in BACKEND
    assert 'if body.payment_method == "online_stripe":' in BACKEND
    assert 'if body.payment_method == "online_razorpay":' in BACKEND
    assert 'if not _grocery_razorpay_keys():' in BACKEND
    assert "payment_method_unavailable" in BACKEND
