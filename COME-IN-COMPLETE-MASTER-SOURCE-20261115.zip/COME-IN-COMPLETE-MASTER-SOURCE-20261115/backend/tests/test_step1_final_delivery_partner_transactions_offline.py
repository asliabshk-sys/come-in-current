"""Delivery Partner atomic status/audit tests using an in-memory transactional fake.

This does NOT verify OTP, Aadhaar/PAN vendors, MongoDB replica-set concurrency,
real encryption storage, or real user authorization middleware.
"""
import ast
import asyncio
import copy
import re
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from mongo_transactions import run_transaction
from test_catalogue_transaction_apply_offline import Collection, ObjId, Transient

SOURCE = (Path(__file__).parents[1] / 'server.py').read_text()
TREE = ast.parse(SOURCE)


class CollectionWithUpsert(Collection):
    async def update_one(self, query, patch, upsert=False, session=None):
        result = await super().update_one(query, patch, session=session)
        if result.matched_count or not upsert:
            return result
        doc = {k: v for k, v in query.items() if not isinstance(v, dict)}
        doc.update(patch.get('$setOnInsert', {}))
        await self.insert_one(doc, session=session)
        return SimpleNamespace(matched_count=0, modified_count=0, upserted_id=self.docs[-1]['_id'])


class Database:
    def __init__(self):
        self.delivery_partner_applications = CollectionWithUpsert()
        self.delivery_partner_audit = CollectionWithUpsert()
        self.delivery_partner_referrals = CollectionWithUpsert()


class Session:
    def __init__(self, db, transient_once=False):
        self.db = db
        self.transient_once = transient_once
        self.attempts = 0

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return False

    async def with_transaction(self, callback):
        while True:
            self.attempts += 1
            snapshot = {name: copy.deepcopy(collection.docs) for name, collection in vars(self.db).items()}
            try:
                value = await callback(self)
                if self.transient_once:
                    self.transient_once = False
                    raise Transient()
            except Exception as exc:
                for name, state in snapshot.items():
                    getattr(self.db, name).docs = state
                if isinstance(exc, Transient):
                    continue
                raise
            return value


class Client:
    def __init__(self, db, **opts):
        self.db = db
        self.opts = opts
        self.sessions = []

    async def start_session(self):
        session = Session(self.db, **self.opts)
        self.sessions.append(session)
        return session


def load(db, client):
    names = {'_dp_public', 'save_delivery_partner_application', 'submit_delivery_partner_application',
             'admin_decide_delivery_partner_application'}
    nodes = []
    for node in TREE.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names:
            node = copy.deepcopy(node)
            node.decorator_list = []
            nodes.append(node)
    env = {'db': db, 'client': client, 'run_transaction': run_transaction,
           'HTTPException': HTTPException, 'ObjectId': ObjId,
           'DeliveryPartnerDraftIn': object, 'DeliveryPartnerDecisionIn': object,
           'Depends': lambda *args: None, 'get_current_user': lambda: None,
           'require_role': lambda *args: None,
           'now_utc': lambda: 'now', '_dp_encrypt': lambda s: f'encrypted:{s}',
           '_dp_safe_reason': lambda s: re.sub(r'\d', 'X', s),
           'secrets': SimpleNamespace(token_urlsafe=lambda n: 'new_referral_'),
           'logger': SimpleNamespace(error=lambda *args: None)}
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])),
                 '<delivery-partner-source>', 'exec'), env)
    return env


def application(status='PENDING_ADMIN_APPROVAL', verified=True, referrer=None):
    return {'_id': 'a1', 'user_id': 'customer1', 'status': status,
            'phone_verified': verified, 'aadhaar_verified': verified,
            'pan_verified': verified, 'documents_status': 'VERIFIED' if verified else 'NOT_SUBMITTED',
            'referrer_application_id': referrer, 'referral_code': 'SAMPLE'}


def run(fn, *args):
    return asyncio.run(fn(*args))


def test_admin_approval_status_audit_referral_commit_together():
    db = Database()
    db.delivery_partner_applications.docs = [application(referrer='ref1')]
    fns = load(db, Client(db))
    result = run(fns['admin_decide_delivery_partner_application'], 'a1',
                 SimpleNamespace(decision='approve', reason='Reviewed'), {'id': 'admin1'})
    assert result['status'] == 'APPROVED'
    assert len(db.delivery_partner_audit.docs) == 1
    assert len(db.delivery_partner_referrals.docs) == 1
    assert db.delivery_partner_referrals.docs[0]['status'] == 'REGISTERED_APPROVED'


def test_admin_referral_write_failure_rolls_back_approval_and_audit():
    db = Database()
    db.delivery_partner_applications.docs = [application(referrer='ref1')]
    db.delivery_partner_referrals.fail_at_insert = 1
    fns = load(db, Client(db))
    with pytest.raises(HTTPException) as error:
        run(fns['admin_decide_delivery_partner_application'], 'a1',
            SimpleNamespace(decision='approve', reason='Reviewed'), {'id': 'admin1'})
    assert error.value.status_code == 503
    assert db.delivery_partner_applications.docs[0]['status'] == 'PENDING_ADMIN_APPROVAL'
    assert db.delivery_partner_audit.docs == []


def test_duplicate_admin_approval_conflicts_and_does_not_duplicate_audit():
    db = Database()
    db.delivery_partner_applications.docs = [application()]
    fn = load(db, Client(db))['admin_decide_delivery_partner_application']
    body = SimpleNamespace(decision='approve', reason='Reviewed')
    run(fn, 'a1', body, {'id': 'admin1'})
    with pytest.raises(HTTPException) as error:
        run(fn, 'a1', body, {'id': 'admin1'})
    assert error.value.status_code == 409
    assert len(db.delivery_partner_audit.docs) == 1


def test_submission_rolls_back_status_if_audit_insert_fails():
    db = Database()
    db.delivery_partner_applications.docs = [application(status='DRAFT')]
    db.delivery_partner_audit.fail_at_insert = 1
    fn = load(db, Client(db))['submit_delivery_partner_application']
    with pytest.raises(HTTPException) as error:
        run(fn, {'id': 'customer1'})
    assert error.value.status_code == 503
    assert db.delivery_partner_applications.docs[0]['status'] == 'DRAFT'


def test_submission_requires_verified_documents_even_on_transaction_retry():
    db = Database()
    db.delivery_partner_applications.docs = [application(status='DRAFT', verified=False)]
    fn = load(db, Client(db))['submit_delivery_partner_application']
    with pytest.raises(HTTPException) as error:
        run(fn, {'id': 'customer1'})
    assert error.value.status_code == 409
    assert db.delivery_partner_audit.docs == []


def test_transient_retry_does_not_duplicate_approval_audit():
    db = Database()
    db.delivery_partner_applications.docs = [application()]
    client = Client(db, transient_once=True)
    fn = load(db, client)['admin_decide_delivery_partner_application']
    run(fn, 'a1', SimpleNamespace(decision='approve', reason='Reviewed'), {'id': 'admin1'})
    assert client.sessions[0].attempts == 2
    assert len(db.delivery_partner_audit.docs) == 1


def test_draft_persists_only_encrypted_fields_and_its_audit_atomically():
    db = Database()
    fn = load(db, Client(db))['save_delivery_partner_application']
    body = SimpleNamespace(full_name='Person', mobile='9876543210', residential_address='Private Address',
                           alternate_contact='9123456780', referral_code=None)
    result = run(fn, body, {'id': 'customer1', 'role': 'customer'})
    assert result['status'] == 'DRAFT'
    saved = db.delivery_partner_applications.docs[0]
    assert 'full_name' not in saved and saved['full_name_enc'] == 'encrypted:Person'
    assert len(db.delivery_partner_audit.docs) == 1


def test_seller_account_cannot_create_delivery_partner_draft():
    db = Database()
    fn = load(db, Client(db))['save_delivery_partner_application']
    with pytest.raises(HTTPException) as error:
        run(fn, SimpleNamespace(), {'id': 'seller1', 'role': 'shopkeeper'})
    assert error.value.status_code == 403
    assert db.delivery_partner_applications.docs == []
