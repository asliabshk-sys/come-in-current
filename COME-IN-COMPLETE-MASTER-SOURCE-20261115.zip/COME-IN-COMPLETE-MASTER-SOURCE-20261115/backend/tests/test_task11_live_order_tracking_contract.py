"""Task 11 tracking regression contracts; no live database/provider is used."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
TREE = ast.parse(SERVER)

def function_source(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SERVER, node)

def test_tracking_endpoint_returns_persisted_status_timeline_for_both_order_kinds():
    source = function_source("get_order_tracking")
    assert '"status_history": [' in source
    assert 'entry.get("status")' in source and 'entry.get("at")' in source
    assert '_tracking_can_read(order, kind, user)' in source

def test_restaurant_status_transition_uses_compare_and_set_to_reject_stale_concurrent_updates():
    source = function_source("update_restaurant_order_status")
    assert 'status_before = order.get("status")' in source
    assert '{"_id": oid, "status": status_before}' in source
    assert 'if changed.modified_count != 1:' in source
    assert 'status changed; refresh before trying again' in source

def test_customer_tracking_screen_renders_restaurant_timeline_and_drops_stale_data_on_error():
    screen = (ROOT / "frontend/app/order-tracking.tsx").read_text()
    assert 'status_history?: { status: string; at: string; note?: string }[]' in screen
    assert 'tracking.status_history?.length' in screen
    assert 'setTracking(null);' in screen and 'setOrder(null);' in screen
    assert 'setInterval(() => { void load(); }, 10000)' in screen

def test_tracking_never_fabricates_eta_or_gps_location():
    source = function_source("get_order_tracking")
    assert '"eta_minutes": None' in source and '"map_provider": None' in source
    screen = (ROOT / "frontend/app/order-tracking.tsx").read_text()
    assert 'No driver movement, route, or ETA is simulated' in screen
