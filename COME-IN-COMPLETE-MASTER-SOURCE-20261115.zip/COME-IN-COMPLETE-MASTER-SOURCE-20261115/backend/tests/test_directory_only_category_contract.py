from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend/server.py").read_text()


def test_medical_and_stationery_are_blocked_when_creating_or_updating_online_products():
    assert "_reject_directory_only_product(body.category_id)" in SERVER
    assert '@api.post("/shops/{shop_id}/products")' in SERVER
    assert '@api.patch("/products/{product_id}")' in SERVER
    assert "directory_only_category" in SERVER


def test_checkout_rejects_legacy_or_malicious_directory_only_product_records():
    assert 'if _is_directory_only_category(product.get("category_id"))' in SERVER
    assert "Medical Stores and Stationery are directory-only and cannot be ordered online." in SERVER


def test_guard_uses_category_identifier_not_product_name_guessing():
    assert "def _normalized_category_token(value: object) -> str:" in SERVER
    assert "def _is_directory_only_category(value: object) -> bool:" in SERVER
    assert "_DIRECTORY_ONLY_CATEGORY_TOKENS" in SERVER
