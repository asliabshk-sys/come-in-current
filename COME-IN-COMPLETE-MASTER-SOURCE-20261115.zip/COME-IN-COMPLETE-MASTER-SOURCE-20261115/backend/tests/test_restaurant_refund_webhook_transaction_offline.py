"""Signed refund *DB helper* rollback/idempotency with in-memory fake sessions.

No real MongoDB, Razorpay webhook, signature, or external provider is used here.
"""
import ast
import asyncio
import copy
import re
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from refund_rules import amount_to_paise, summarize_provider_refunds
from mongo_transactions import run_transaction
from test_catalogue_transaction_apply_offline import Collection, Client

SOURCE = (Path(__file__).parents[1] / 'server.py').read_text()
TREE = ast.parse(SOURCE)


def setup(ambiguous_commit=False):
    class Ledger(Collection):
        async def update_one(self, query, patch, upsert=False, session=None):
            existing = await self.find_one(query, session=session)
            if existing:
                return SimpleNamespace(matched_count=1, modified_count=0)
            if upsert:
                return await self.insert_one(patch['$setOnInsert'], session=session)
            return SimpleNamespace(matched_count=0, modified_count=0)

    class DB:
        restaurant_payments = Collection()
        restaurant_orders = Collection()
        financial_ledger = Ledger()
    db = DB()
    db.restaurant_orders.docs = [{'_id': 'o1', 'total': 120.0, 'payment_status': 'paid'}]
    db.restaurant_payments.docs = [{'_id': 'p1', 'order_id': 'o1', 'status': 'paid',
                                     'gateway_payment_id': 'pay_live_fake'}]
    client = Client(db, ambiguous_commit=ambiguous_commit)
    namespace = {'db': db, 'client': client, 're': re,
                 'amount_to_paise': amount_to_paise, 'summarize_provider_refunds': summarize_provider_refunds,
                 'HTTPException': HTTPException, 'now_utc': lambda: 'now', 'run_transaction': run_transaction,
                 'logger': SimpleNamespace(error=lambda *args: None)}
    from financial_rules import money
    namespace['money'] = money
    nodes = [copy.deepcopy(n) for n in TREE.body
             if isinstance(n, ast.AsyncFunctionDef) and n.name in {
                 '_apply_restaurant_refund_webhook_transactionally', '_record_refund_reversal'}]
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), '<server-refund-helper>', 'exec'), namespace)
    return db, namespace['_apply_restaurant_refund_webhook_transactionally']


def call(helper, event='processed', amount=12000, rid='rf_1'):
    return asyncio.run(helper('p1', 'o1', rid, amount, event))


def test_processed_refund_commits_both_documents_and_repeat_is_idempotent():
    db, fn = setup()
    assert call(fn)['status'] == 'refunded'
    assert call(fn)['status'] == 'refunded'
    assert len(db.restaurant_payments.docs[0]['provider_refunds']) == 1
    assert db.restaurant_payments.docs[0]['refunded_amount_paise'] == 12000
    assert db.restaurant_orders.docs[0]['refunded_amount_paise'] == 12000


def test_second_document_write_failure_rolls_back_first_document():
    db, fn = setup()
    db.restaurant_orders.fail_update = True
    with pytest.raises(HTTPException) as err:
        call(fn)
    assert err.value.status_code == 503
    assert 'provider_refunds' not in db.restaurant_payments.docs[0]
    assert 'refund_status' not in db.restaurant_orders.docs[0]
    db.restaurant_orders.fail_update = False
    assert call(fn)['status'] == 'refunded'


def test_out_of_order_failed_event_cannot_downgrade_provider_confirmed_completion():
    db, fn = setup()
    call(fn)
    assert call(fn, 'failed')['status'] == 'refunded'
    assert db.restaurant_payments.docs[0]['provider_refunds']['rf_1']['status'] == 'processed'


def test_pending_then_processed_moves_both_documents_together():
    db, fn = setup()
    assert call(fn, 'pending')['status'] == 'refund_pending'
    assert db.restaurant_orders.docs[0]['refund_pending_amount_paise'] == 12000
    assert call(fn, 'processed')['status'] == 'refunded'
    assert db.restaurant_orders.docs[0]['refund_pending_amount_paise'] == 0


def test_conflicting_duplicate_refund_id_flags_both_for_reconciliation():
    db, fn = setup()
    call(fn, 'pending')
    assert call(fn, 'processed', 11999)['status'] == 'refund_reconciliation_required'
    assert db.restaurant_orders.docs[0]['refund_status'] == 'refund_reconciliation_required'
    assert db.restaurant_payments.docs[0]['refund_status'] == 'refund_reconciliation_required'
    assert db.restaurant_payments.docs[0]['provider_refunds']['rf_1']['amount'] == 12000


def test_oversized_provider_total_fails_closed_without_partial_writes():
    db, fn = setup()
    assert call(fn, 'processed', amount=12500)['status'] == 'refund_reconciliation_required'
    assert 'provider_refunds' not in db.restaurant_payments.docs[0]
    assert db.restaurant_orders.docs[0]['refund_status'] == 'refund_reconciliation_required'


def test_failed_status_does_not_count_toward_refunded_total():
    db, fn = setup()
    assert call(fn, 'failed')['status'] == 'refund_failed'
    assert db.restaurant_orders.docs[0]['refunded_amount_paise'] == 0
    assert db.restaurant_payments.docs[0]['refunded_amount_paise'] == 0


def test_unknown_commit_does_not_make_second_provider_call_or_double_refund():
    db, fn = setup(ambiguous_commit=True)
    assert call(fn)['status'] == 'refunded'  # reconciled after fake ambiguous commit
    assert db.restaurant_orders.docs[0]['refund_status'] == 'refunded'
    assert call(fn)['status'] == 'refunded'
    assert len(db.restaurant_payments.docs[0]['provider_refunds']) == 1


def test_ledger_failure_aborts_payment_and_order_updates_together():
    db, fn = setup()
    db.financial_ledger.docs = [
        {'_id': 'original_ledger', 'idempotency_key': 'order:restaurant:o1:finalized:v1',
         'beneficiary_type': 'restaurant', 'beneficiary_id': 'r1', 'beneficiary_user_id': 'seller1',
         'gross_merchandise': 100, 'commission_amount': 5, 'platform_service_fee': 3,
         'platform_retained_delivery_fee': 0, 'platform_earnings': 8, 'shopkeeper_payable': 92}
    ]
    db.financial_ledger.fail_at_insert = 1
    with pytest.raises(HTTPException) as error:
        call(fn)
    assert error.value.status_code == 503
    assert db.restaurant_payments.docs[0].get('refund_status') is None
    assert db.restaurant_orders.docs[0].get('refund_status') is None
    assert len(db.financial_ledger.docs) == 1
    db.financial_ledger.fail_at_insert = None
    assert call(fn)['status'] == 'refunded'
    assert len(db.financial_ledger.docs) == 2
    assert db.financial_ledger.docs[1]['event_type'] == 'refund_reversal'
    assert call(fn)['status'] == 'refunded'
    assert len(db.financial_ledger.docs) == 2
