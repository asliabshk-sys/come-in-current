"""Source-contract coverage for the targeted roadmap implementation.

These tests prove source wiring/contracts only; live Mongo and browser behavior
require the separately configured integration environment.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_task9_cart_has_explicit_remove_and_user_selected_same_shop_replacements():
    cart = (ROOT / "frontend/app/(tabs)/cart.tsx").read_text()
    store = (ROOT / "frontend/src/store/cart.tsx").read_text()
    assert 'testID={`remove-cart-line-${line.key}`}' in cart
    assert 'testID={`replace-${line.key}-with-${candidate.id}`}' in cart
    assert "replaceLine(line.product.id, line.variant?.id, candidate, variant?.id, line.qty)" in cart
    assert 'replacement.source !== "live"' in store
    assert "delete next[oldKey]" in store


def test_task12_import_is_owner_scoped_preview_first_and_idempotent_by_sku():
    server = (ROOT / "backend/server.py").read_text()
    seller = (ROOT / "frontend/app/seller/products.tsx").read_text()
    assert '@api.post("/shops/{shop_id}/products/import")' in server
    assert "_assert_shop_owner(shop, user)" in server
    assert 'if not apply:' in server
    assert '"sku_key": row["sku"].casefold()' in server
    assert 'testID="seller-import-catalog"' in seller
    assert 'testID="seller-import-apply"' in seller
    assert 'required = {"name", "unit", "price", "stock", "category_id", "description"}' in server
    assert '"code": "invalid_import_columns"' in server


def test_task15_admin_master_catalog_requires_source_reference_and_admin_role():
    server = (ROOT / "backend/server.py").read_text()
    admin = (ROOT / "frontend/app/admin.tsx").read_text()
    assert '@api.post("/admin/master-products")' in server
    assert 'Depends(require_role("admin"))' in server
    assert 'source_reference: str = Field(min_length=4, max_length=500)' in server
    assert 'testID="admin-master-catalog"' in admin
    assert 'testID="admin-master-create"' in admin
    assert '@api.post("/admin/announcements")' in server
    assert 'Depends(require_role("admin"))' in server
    assert 'testID="admin-announcement-create"' in admin


def test_task21_comparison_uses_exact_master_variant_and_approved_available_offers():
    server = (ROOT / "backend/server.py").read_text()
    product = (ROOT / "frontend/app/product/[id].tsx").read_text()
    assert '@api.get("/catalog/price-comparison")' in server
    assert '"master_variant_id": variant_id' in server
    assert 'db.shops.find({"status": "approved"})' in server
    assert '"stock": {"$gt": 0}' in server
    assert 'offers.sort(key=lambda offer: (offer["price"], offer["shop_name"].casefold()))' in server
    assert 'testID="price-comparison-panel"' in product
    assert 'masterProductId' in product and 'masterVariantId' in product


def test_task18_preview_environment_example_exists_without_secrets():
    env = (ROOT / "frontend/.env.example").read_text()
    assert "EXPO_PUBLIC_BACKEND_URL=http://localhost:8001" in env
    assert "API_KEY=" not in env and "PASSWORD=" not in env


def test_offline_specialty_shop_types_are_supported_without_changing_online_mode():
    source = (Path(__file__).resolve().parents[1] / "server.py").read_text()
    assert 'offline_shop_type: Literal["grocery_kirana", "chicken", "meat", "fish", "momos", "burger", "pizza", "chinese_food", "chaat_golgappa", "other_food"]' in source
    assert 'shop_type: Literal["online", "offline", "both"] = "offline"' in source


def test_offline_specialty_filter_stays_inside_existing_shops_screen():
    root = Path(__file__).resolve().parents[2]
    shops = (root / "frontend/app/shops.tsx").read_text()
    seller = (root / "frontend/app/become-seller.tsx").read_text()
    assert 'offline-type-${value}' in shops
    assert 'setOfflineShopType(value as OfflineShopType | "all")' in shops
    assert 'field("offline_shop_type", value)' in seller
    assert 'router.push("/shops")' not in shops  # no parallel module navigation added


def test_grocery_checkout_supports_shop_configured_pickup_and_delivery():
    source = (Path(__file__).resolve().parents[1] / "server.py").read_text()
    checkout = (Path(__file__).resolve().parents[2] / "frontend/app/checkout.tsx").read_text()
    assert 'fulfillment: Literal["delivery", "pickup"] = "delivery"' in source
    assert 'if body.fulfillment == "pickup" and not shop.get("pickup_available", False)' in source
    assert 'if body.fulfillment == "delivery" and not shop.get("delivery_available", False)' in source
    assert '"fulfillment": body.fulfillment' in source
    assert 'testID="fulfillment-pickup"' in checkout
    assert 'delivery_address: fulfillment === "delivery" ? address : ""' in checkout


def test_product_image_fallbacks_are_bundled_and_seller_suggestions_require_real_listing_details():
    root = Path(__file__).resolve().parents[2]
    catalog = (root / "frontend/src/data/catalog.ts").read_text()
    cards = (root / "frontend/src/components/ProductCard.tsx").read_text()
    seller = (root / "frontend/app/seller/products.tsx").read_text()
    for slug in ["atta-rice-dal", "dairy-breakfast", "fruits-veggies", "snacks", "beverages", "household", "bakery", "personal-care", "masalas-oils"]:
        assert (root / f"frontend/assets/images/placeholders/{slug}.png").is_file()
        assert f"{slug}.png" in catalog
    assert "onError={() => setImageFailed(true)}" in cards
    assert "COMMON_PRODUCT_SUGGESTIONS" in seller
    assert "Sellers must enter their real unit, price" in seller
