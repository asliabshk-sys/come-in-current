"""Task 20 source-contract checks; no MongoDB connection is made."""
import ast
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER_PATH = ROOT / "backend" / "server.py"
SOURCE = SERVER_PATH.read_text()
TREE = ast.parse(SOURCE)


def class_source(name):
    node = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


def function_source(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


def test_product_variant_price_mrp_and_stock_have_finite_business_bounds():
    schema = class_source("ProductVariantIn")
    assert "price: float = Field(gt=0, le=100000000)" in schema
    assert "mrp: Optional[float] = Field(default=None, ge=0, le=100000000)" in schema
    assert "stock: int = Field(default=0, ge=0, le=100000000)" in schema
    assert "Variant MRP cannot be less than selling price" in schema


def test_master_link_price_mrp_and_stock_use_same_upper_bounds():
    schema = class_source("MasterLinkIn")
    assert "price: float = Field(ge=0, le=100000000)" in schema
    assert "mrp: Optional[float] = Field(default=None, ge=0, le=100000000)" in schema
    assert "stock: int = Field(default=0, ge=0, le=100000000)" in schema
    assert "MRP cannot be less than price" in schema


def test_product_catalog_exposes_only_approved_available_in_stock_products_and_variants():
    endpoint = function_source("list_catalog_products")
    assert 'db.shops.find({"status": "approved"})' in endpoint
    assert '"available": True' in endpoint
    assert '"stock": {"$gt": 0}' in endpoint
    assert '"$elemMatch": {"available": True, "stock": {"$gt": 0}}' in endpoint
    assert 'row["shop_name"]' in endpoint
    assert 'row["shop_type"]' in endpoint


def test_quote_resolves_variant_identity_and_authoritative_server_price_and_stock():
    price = function_source("_price_for")
    resolver = function_source("_resolve_grocery_lines")
    assert 'v.get("id") == variant_id' in price
    assert 'variant.get("price", 0)' in price
    assert 'variant.get("stock", 0)' in price
    assert 'not variant.get("available", True)' in price
    assert 'pricing = _price_for(product, line.variant_id)' in resolver
    assert 'pricing["stock"] < line.qty' in resolver


def test_checkout_keeps_transactional_conditional_variant_stock_decrement_and_server_totals():
    decrement = function_source("_atomic_decrement_line")
    order = function_source("create_order")
    assert '"$elemMatch": {"id": variant_id, "available": True, "stock": {"$gte": qty}}' in decrement
    assert '"$inc": {"variants.$.stock": -qty}' in decrement
    assert 'current_totals = _quote_totals(current_lines, body.fulfillment)' in order
    assert 'await run_transaction(client, apply)' in order
    assert 'quote_claim.modified_count != 1' in order
    assert 'except DuplicateKeyError as exc:' in order


def test_import_stays_store_scoped_validated_and_transactional():
    importer = function_source("import_shop_products")
    assert '_assert_shop_owner(shop, user)' in importer
    assert '0 < price <= 100000000' in importer
    assert 'stock_number > 100000000' in importer
    assert 'await run_transaction(client, apply)' in importer
    assert '"_id": ObjectId(row["product_id"]), "shop_id": shop_id' in importer


def test_product_update_preserves_variant_identity_and_checks_actual_owner():
    update = function_source("update_product")
    assert '_assert_shop_owner(shop, user)' in update
    assert 'product.get("owner_id") != user["id"]' in update
    assert 'if body.variants is None:' in update
    assert 'patch.pop("variants", None)' in update
