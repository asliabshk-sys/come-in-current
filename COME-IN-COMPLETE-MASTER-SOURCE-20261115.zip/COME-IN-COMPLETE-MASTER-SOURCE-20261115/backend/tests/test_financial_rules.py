from datetime import datetime, timezone
from decimal import Decimal
import pytest
from financial_rules import money, order_financials, parse_date_range


def test_money_uses_decimal_half_up_not_binary_float_arithmetic():
    assert money("10.005") == Decimal("10.01")
    assert money("1000.00") == Decimal("1000.00")
    with pytest.raises(ValueError):
        money("NaN")


def test_platform_commission_is_not_gross_merchandise_value():
    row = order_financials({"_id": "order-1", "subtotal": 1000, "total": 1100, "delivery_fee": 100, "status": "delivered", "payment_status": "paid", "created_at": datetime(2026, 10, 19, 12, tzinfo=timezone.utc)}, {"commission_rate_percent": 5, "platform_service_fee_inr": 0, "delivery_fee_beneficiary": "shopkeeper", "financial_policy_updated_at": datetime(2026, 10, 19, 11, tzinfo=timezone.utc)}, "grocery")
    assert row["gross_merchandise"] == 1000.0
    assert row["commission"] == 50.0
    assert row["platform_earnings"] == 50.0
    assert row["shopkeeper_payable"] == 1050.0  # configured delivery beneficiary is shopkeeper
    assert row["platform_earnings"] != 1100.0  # the source order total includes amounts not earned by the platform


def test_missing_commission_policy_is_unavailable_not_assumed_zero():
    row = order_financials({"_id": "o", "subtotal": 1000, "status": "delivered"}, {}, "grocery")
    assert row["commission"] is None
    assert row["shopkeeper_payable"] is None
    assert row["platform_earnings"] is None
    assert row["financial_state"] == "pending_calculation"


def test_cancelled_and_refunded_orders_do_not_count_as_completed_platform_income():
    policy = {"commission_rate_percent": 5, "platform_service_fee_inr": 0, "delivery_fee_beneficiary": "not_applicable", "financial_policy_updated_at": datetime(2026, 10, 19, 11, tzinfo=timezone.utc)}
    cancelled = order_financials({"_id": "c", "subtotal": 1000, "status": "cancelled", "payment_status": "cancelled", "created_at": datetime(2026, 10, 19, 12, tzinfo=timezone.utc)}, policy, "grocery")
    refunded = order_financials({"_id": "r", "subtotal": 1000, "status": "delivered", "payment_status": "refunded", "refund_status": "completed", "created_at": datetime(2026, 10, 19, 12, tzinfo=timezone.utc)}, policy, "grocery")
    assert cancelled["platform_earnings"] is None
    assert cancelled["eligible_completed_sale"] is False
    assert refunded["platform_earnings"] is None
    assert refunded["shopkeeper_payable"] == 0.0
    assert refunded["commission_reversal"] == 50.0


def test_date_range_uses_inclusive_local_dates_and_exclusive_next_day_boundary():
    start, end, tz_name = parse_date_range("2026-10-19", "2026-10-19", "Asia/Kolkata", now=datetime(2026, 10, 19, 12, tzinfo=timezone.utc))
    assert tz_name == "Asia/Kolkata"
    assert start.isoformat() == "2026-10-18T18:30:00+00:00"
    assert end.isoformat() == "2026-10-19T18:30:00+00:00"
    with pytest.raises(ValueError):
        parse_date_range("2026-10-20", "2026-10-19", "Asia/Kolkata")


def test_new_policy_is_not_applied_retroactively_to_older_orders():
    row = order_financials({"_id": "old", "subtotal": 1000, "status": "delivered", "created_at": datetime(2026, 10, 18, 12, tzinfo=timezone.utc)}, {"commission_rate_percent": 5, "platform_service_fee_inr": 0, "delivery_fee_beneficiary": "not_applicable", "financial_policy_updated_at": datetime(2026, 10, 19, 11, tzinfo=timezone.utc)}, "grocery")
    assert row["commission"] is None
    assert row["shopkeeper_payable"] is None
    assert row["financial_state"] == "pending_calculation"


def test_delivered_cash_orders_need_explicit_collection_attestation_before_payable():
    order = {"_id": "cod", "subtotal": 1000, "status": "delivered", "payment_status": "cod_pending", "created_at": datetime(2026, 10, 19, 12, tzinfo=timezone.utc)}
    policy = {"commission_rate_percent": 5, "platform_service_fee_inr": 0, "delivery_fee_beneficiary": "not_applicable", "financial_policy_updated_at": datetime(2026, 10, 19, 11, tzinfo=timezone.utc)}
    pending = order_financials(order, policy, "grocery")
    assert pending["eligible_completed_sale"] is False
    assert pending["shopkeeper_payable"] is None
    order["payment_status"] = "cash_collected"
    collected = order_financials(order, policy, "grocery")
    assert collected["eligible_completed_sale"] is True
    assert collected["shopkeeper_payable"] == 950.0


def test_delivery_fee_beneficiary_changes_only_the_documented_party_split():
    order = {"_id": "delivery", "subtotal": 1000, "total": 1100, "delivery_fee": 100, "status": "delivered", "payment_status": "paid", "created_at": datetime(2026, 10, 19, 12, tzinfo=timezone.utc)}
    policy_base = {"commission_rate_percent": 5, "platform_service_fee_inr": 0, "financial_policy_updated_at": datetime(2026, 10, 19, 11, tzinfo=timezone.utc)}
    shop_policy = {**policy_base, "delivery_fee_beneficiary": "shopkeeper"}
    platform_policy = {**policy_base, "delivery_fee_beneficiary": "platform"}
    shop = order_financials(order, shop_policy, "grocery")
    platform = order_financials(order, platform_policy, "grocery")
    assert shop["shopkeeper_payable"] == 1050.0
    assert shop["platform_earnings"] == 50.0
    assert platform["shopkeeper_payable"] == 950.0
    assert platform["platform_earnings"] == 150.0
