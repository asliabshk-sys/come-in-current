from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SHOPS_UI = (ROOT / "frontend/app/shops.tsx").read_text()
ACCOUNT_UI = (ROOT / "frontend/app/(tabs)/account.tsx").read_text()
SERVICES_UI = (ROOT / "frontend/app/services.tsx").read_text()
SELLER_PRODUCTS_UI = (ROOT / "frontend/app/seller/products.tsx").read_text()
SELLER_ORDERS_UI = (ROOT / "frontend/app/seller/orders.tsx").read_text()
SERVER = (ROOT / "backend/server.py").read_text()


def test_online_and_offline_browsing_has_no_shop_registration_entrypoint():
    # Online and Offline browsing share this screen. No registration button,
    # registration label, or become-seller navigation may live on this screen.
    assert 'testID="register-offline-shop"' not in SHOPS_UI
    assert "Add Your Shop / Register Your Shop" not in SHOPS_UI
    assert 'router.push("/become-seller")' not in SHOPS_UI
    assert 'pathname: "/become-seller"' not in SHOPS_UI
    assert 'router.push("/become-seller")' not in SELLER_PRODUCTS_UI
    assert 'router.push("/become-seller")' not in SELLER_ORDERS_UI


def test_approved_shop_browsing_and_existing_filters_remain():
    assert 'api.get<any[]>("/shops")' in SHOPS_UI
    assert "setLiveShops(normalized)" in SHOPS_UI
    assert "const merged = [...liveShops, ...SHOPS.filter" in SHOPS_UI
    assert 'testID="shops-list"' in SHOPS_UI
    assert 'router.push(`/shop/${item.id}`)' in SHOPS_UI
    assert 'testID="shops-search"' in SHOPS_UI
    assert 'testID={`shops-tab-${key}`}' in SHOPS_UI
    assert "TAB_ORDER: TabKey[] = [\"all\", \"online\", \"offline\"]" in SHOPS_UI


def test_account_is_the_shop_registration_entrypoint_and_exposes_four_modes():
    assert 'label: "Add Your Shop"' in ACCOUNT_UI
    assert 'testID={`account-add-shop-mode-${mode.id}`}' in ACCOUNT_UI
    for mode in ('"Online Shop"', '"Offline Shop"', '"Restaurant"', '"Home Services"'):
        assert mode in ACCOUNT_UI
    assert 'pathname: "/become-seller", params: { type: "online" }' in ACCOUNT_UI
    assert 'pathname: "/become-seller", params: { type: "offline" }' in ACCOUNT_UI
    assert 'router.push("/restaurant/dashboard")' in ACCOUNT_UI
    assert 'params: { openRegistration: "1" }' in ACCOUNT_UI
    assert 'params.openRegistration === "1"' in SERVICES_UI


def test_shop_registration_requires_login_and_shop_approval_is_admin_only():
    assert '@api.post("/shops")' in SERVER
    assert 'async def create_shop(body: ShopIn, user: dict = Depends(get_current_user))' in SERVER
    assert '@api.patch("/admin/shops/{shop_id}/status")' in SERVER
    assert 'body: ShopApprovalIn, _: dict = Depends(require_role("admin"))' in SERVER
    assert '@api.post("/restaurants")' in SERVER
    assert 'async def create_restaurant(body: RestaurantIn, user: dict = Depends(get_current_user))' in SERVER
    assert '@api.patch("/admin/restaurants/{restaurant_id}/status")' in SERVER
