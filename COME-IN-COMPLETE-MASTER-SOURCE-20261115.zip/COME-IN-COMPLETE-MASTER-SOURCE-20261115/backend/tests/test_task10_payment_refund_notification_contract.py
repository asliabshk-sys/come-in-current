"""Task 10 focused source contracts; no live provider or notification delivery."""
import ast
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER_TEXT = (ROOT / "backend" / "server.py").read_text()
SERVER = ast.parse(SERVER_TEXT)


def fn(name):
    node = next(n for n in SERVER.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SERVER_TEXT, node)


def test_refund_is_admin_only_and_requires_verified_paid_gateway_payment():
    source = fn("admin_refund_restaurant_order")
    assert 'Depends(require_role("admin"))' in source
    assert 'order.get("payment_status") != "paid"' in source
    assert 'payment.get("gateway_payment_id")' in source


def test_refund_claim_prevents_concurrent_duplicate_and_blocks_ambiguous_retry():
    source = fn("admin_refund_restaurant_order")
    claim = fn('_claim_restaurant_refund_for_gateway')
    assert '"refund_status": "refund_requested"' in claim
    assert '_claim_restaurant_refund_for_gateway(' in source
    assert 'db.restaurant_payments.update_one(' in claim
    assert 'db.restaurant_orders.update_one(' in claim
    assert 'run_transaction(client, claim)' in claim
    assert '"refund_uncertain"' in source
    assert 'Do not retry; reconcile the payment/refund in the provider dashboard first.' in source
    assert '"refund_requested_failed"' in source  # legacy ambiguous state remains blocked


def test_refund_completion_requires_provider_status_and_id():
    source = fn("admin_refund_restaurant_order")
    assert 'provider_status not in {"pending", "processed", "refunded", "failed"}' in source
    assert 'refund.get("amount") != eligible_paise' in source
    assert '_apply_restaurant_refund_webhook_transactionally(' in source
    assert '"provider_refunds": refunds' in fn("_apply_restaurant_refund_webhook_transactionally")
    assert 'persisted = await _apply_restaurant_refund_webhook_transactionally(' in source
    assert '_record_refund_reversal(order, "restaurant", refund_id, session=session)' in fn("_apply_restaurant_refund_webhook_transactionally")


def test_payment_verification_and_webhook_still_require_server_confirmation():
    verify = fn("verify_restaurant_payment")
    webhook = fn("razorpay_webhook")
    assert 'hmac.compare_digest(expected,body.razorpay_signature)' in verify
    assert 'gateway_payment.get("status") != "captured"' in verify
    assert 'gateway_payment.get("amount") != expected_paise' in verify
    assert 'hmac.compare_digest(expected,signature)' in webhook
    assert '"duplicate": True' in webhook


def test_notification_provider_fails_closed_without_claiming_delivery():
    source = (ROOT / "backend" / "integrations" / "order_notifications.py").read_text()
    assert 'class UnconfiguredOrderNotificationProvider' in source
    assert 'accepted=False' in source
    assert 'status="not_sent"' in source
