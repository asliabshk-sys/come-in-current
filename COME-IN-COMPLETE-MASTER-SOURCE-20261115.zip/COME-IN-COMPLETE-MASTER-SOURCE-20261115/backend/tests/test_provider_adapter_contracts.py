from datetime import datetime, timedelta, timezone
import asyncio

from integrations.delivery_provider import UnconfiguredDeliveryProvider, is_fresh_location
from integrations.order_notifications import UnconfiguredOrderNotificationProvider


def test_unconfigured_delivery_provider_never_fabricates_rider_coordinates_or_eta():
    result = asyncio.run(UnconfiguredDeliveryProvider().get_tracking(order_id="order-1", customer_id="customer-1"))
    assert result.available is False
    assert result.latitude is None and result.longitude is None and result.eta_minutes is None
    assert result.status == "unavailable"


def test_tracking_freshness_rejects_missing_stale_future_and_naive_timestamps():
    now = datetime.now(timezone.utc)
    assert is_fresh_location((now - timedelta(seconds=30)).isoformat(), now=now)
    assert not is_fresh_location(None, now=now)
    assert not is_fresh_location((now - timedelta(seconds=181)).isoformat(), now=now)
    assert not is_fresh_location((now + timedelta(seconds=5)).isoformat(), now=now)
    assert not is_fresh_location("2026-10-17T12:00:00", now=now)


def test_unconfigured_notifications_never_claim_sent_or_delivered():
    result = asyncio.run(UnconfiguredOrderNotificationProvider().send_order_event(
        event_id="evt-1", recipient_id="customer-1", event_type="order.placed", payload={}
    ))
    assert result.accepted is False
    assert result.status == "not_sent"
    assert result.provider_message_id is None
