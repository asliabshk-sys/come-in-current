"""Source-extracted Restaurant capture helper against an isolated in-memory fake DB.

NOT an actual Motor or MongoDB replica-set transaction test.
"""
import ast
import asyncio
import copy
import re
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from mongo_transactions import run_transaction
from test_catalogue_transaction_apply_offline import Collection, Client

SERVER = (Path(__file__).parents[1] / 'server.py').read_text()
TREE = ast.parse(SERVER)


def environment(status='pending_payment', payment_status='pending', ambiguous_commit=False):
    class DB:
        restaurant_payments = Collection()
        restaurant_orders = Collection()
    db = DB()
    db.restaurant_orders.docs.append({'_id': 'o1', 'total': 225.50, 'status': status,
                                      'payment_status': payment_status, 'status_history': []})
    db.restaurant_payments.docs.append({'_id': 'p1', 'order_id': 'o1', 'amount': 225.50, 'status': 'created'})
    client = Client(db, ambiguous_commit=ambiguous_commit)
    namespace = {'re': re, 'db': db, 'client': client, 'HTTPException': HTTPException, 'run_transaction': run_transaction,
                 'now_utc': lambda: 'now', 'logger': SimpleNamespace(error=lambda *args: None)}
    names = {'_commit_restaurant_capture', '_mark_restaurant_payment_failed', '_claim_restaurant_refund_for_gateway'}
    functions = [copy.deepcopy(n) for n in TREE.body if isinstance(n, ast.AsyncFunctionDef) and n.name in names]
    exec(compile(ast.fix_missing_locations(ast.Module(body=functions, type_ignores=[])), '<restaurant-server-source>', 'exec'), namespace)
    return db, namespace['_commit_restaurant_capture'], namespace


def call(fn, payment_id='pay_1'):
    return asyncio.run(fn('o1', {'_id': 'p1'}, payment_id, 'signed capture'))


def test_capture_commits_payment_and_order_once():
    db, fn, _ = environment()
    assert call(fn)['status'] == 'placed'
    assert db.restaurant_payments.docs[0]['gateway_payment_id'] == 'pay_1'
    assert db.restaurant_orders.docs[0]['payment_status'] == 'paid'
    assert len(db.restaurant_orders.docs[0]['status_history']) == 1
    assert call(fn)['status'] == 'placed'
    assert len(db.restaurant_orders.docs[0]['status_history']) == 1


def test_failed_order_update_aborts_payment_write():
    db, fn, _ = environment()
    db.restaurant_orders.fail_update = True
    with pytest.raises(HTTPException) as exc:
        call(fn)
    assert exc.value.status_code == 503
    assert db.restaurant_payments.docs[0]['status'] == 'created'
    assert db.restaurant_orders.docs[0]['payment_status'] == 'pending'
    db.restaurant_orders.fail_update = False
    assert call(fn)['status'] == 'placed'


def test_captured_after_cancellation_never_resurrects_order():
    db, fn, _ = environment(status='cancelled', payment_status='failed')
    assert call(fn)['status'] == 'cancelled'
    order = db.restaurant_orders.docs[0]
    assert order['payment_status'] == 'paid' and order['payment_reconciliation_required'] is True


def test_unknown_commit_reconciles_stored_payment_and_order():
    db, fn, _ = environment(ambiguous_commit=True)
    assert call(fn)['payment_status'] == 'paid'
    assert len(db.restaurant_orders.docs[0]['status_history']) == 1


def test_failed_restaurant_payment_transaction_rolls_back_and_does_not_unpay_captured_order():
    db, _, funcs = environment()
    fail = funcs['_mark_restaurant_payment_failed']
    asyncio.run(fail('p1', 'o1'))
    assert db.restaurant_payments.docs[0]['status'] == 'failed'
    assert db.restaurant_orders.docs[0]['payment_status'] == 'failed'
    db2, capture, funcs2 = environment()
    call(capture)
    asyncio.run(funcs2['_mark_restaurant_payment_failed']('p1', 'o1'))
    assert db2.restaurant_payments.docs[0]['status'] == 'paid'
    assert db2.restaurant_orders.docs[0]['payment_status'] == 'paid'


def test_failed_payment_second_write_error_aborts_all():
    db, _, funcs = environment()
    db.restaurant_orders.fail_update = True
    with pytest.raises(RuntimeError):
        asyncio.run(funcs['_mark_restaurant_payment_failed']('p1', 'o1'))
    assert db.restaurant_payments.docs[0]['status'] == 'created'
    assert db.restaurant_orders.docs[0]['payment_status'] == 'pending'


def test_refund_claim_is_atomic_and_before_any_provider_action():
    db, _, funcs = environment(status='placed', payment_status='paid')
    db.restaurant_payments.docs[0]['status'] = 'paid'
    db.restaurant_payments.docs[0]['gateway_payment_id'] = 'pay_1'
    claim = funcs['_claim_restaurant_refund_for_gateway']
    asyncio.run(claim('o1', 'p1', {'refund_requested', 'refunded'}))
    assert db.restaurant_payments.docs[0]['refund_status'] == 'refund_requested'
    assert db.restaurant_orders.docs[0]['refund_status'] == 'refund_requested'
    with pytest.raises(HTTPException) as exc:
        asyncio.run(claim('o1', 'p1', {'refund_requested', 'refunded'}))
    assert exc.value.status_code == 409


def test_refund_claim_partial_update_aborts_without_provider_request():
    db, _, funcs = environment(status='placed', payment_status='paid')
    db.restaurant_payments.docs[0]['status'] = 'paid'
    db.restaurant_orders.fail_update = True
    with pytest.raises(HTTPException) as exc:
        asyncio.run(funcs['_claim_restaurant_refund_for_gateway']('o1', 'p1', {'refund_requested'}))
    assert exc.value.status_code == 503
    assert db.restaurant_payments.docs[0].get('refund_status') is None
    assert db.restaurant_orders.docs[0].get('refund_status') is None


def test_different_gateway_payment_cannot_replace_captured_id():
    db, fn, _ = environment()
    call(fn)
    with pytest.raises(HTTPException) as exc:
        call(fn, 'pay_2')
    assert exc.value.status_code == 409
    assert db.restaurant_payments.docs[0]['gateway_payment_id'] == 'pay_1'
