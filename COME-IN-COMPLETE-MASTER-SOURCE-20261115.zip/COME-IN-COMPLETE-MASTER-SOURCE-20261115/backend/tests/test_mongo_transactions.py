"""Offline classification tests; live transaction retries require a replica set."""
import asyncio
import ast
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))

from mongo_transactions import has_transaction_error_label, proven_insufficient_stock_conflict


class LabeledError(Exception):
    def __init__(self, *labels):
        self.labels = set(labels)

    def has_error_label(self, label):
        return label in self.labels


class BusinessError(Exception):
    def __init__(self, status_code, detail):
        self.status_code = status_code
        self.detail = detail


def test_error_label_classification_is_explicit_and_conservative():
    assert has_transaction_error_label(LabeledError("TransientTransactionError"), "TransientTransactionError")
    assert not has_transaction_error_label(LabeledError("UnknownTransactionCommitResult"), "TransientTransactionError")
    assert not has_transaction_error_label(RuntimeError("WriteConflict"), "TransientTransactionError")


def test_transient_checkout_failure_maps_to_409_only_when_fresh_stock_read_proves_it():
    async def run():
        conflict = BusinessError(409, {"code": "insufficient_stock"})

        async def short_stock():
            raise conflict

        result = await proven_insufficient_stock_conflict(LabeledError("TransientTransactionError"), short_stock)
        assert result is conflict

        async def enough_stock():
            return [{"stock": 2}]

        result = await proven_insufficient_stock_conflict(LabeledError("TransientTransactionError"), enough_stock)
        assert result is None

        result = await proven_insufficient_stock_conflict(LabeledError("UnknownTransactionCommitResult"), short_stock)
        assert result is None

        async def read_failed():
            raise RuntimeError("database unavailable")

        result = await proven_insufficient_stock_conflict(LabeledError("TransientTransactionError"), read_failed)
        assert result is None

    asyncio.run(run())


def test_every_direct_database_operation_inside_explicit_transaction_passes_session():
    source_path = Path(__file__).parents[1] / "server.py"
    source = source_path.read_text()
    tree = ast.parse(source)
    operations = {"find_one", "find", "insert_one", "insert_many", "update_one", "update_many", "delete_one", "delete_many", "replace_one", "count_documents"}
    # No manual transaction scopes remain. The driver retries only DB-only
    # callbacks, with every MongoDB call explicitly bound to the session.
    assert not any(
        isinstance(node, ast.AsyncWith)
        and any(isinstance(item.context_expr, ast.Call)
                and isinstance(item.context_expr.func, ast.Attribute)
                and item.context_expr.func.attr == "start_transaction"
                for item in node.items)
        for node in ast.walk(tree)
    )
    callbacks = []
    missing = []
    callback_names = {"apply", "claim", "commit", "persist", "save", "submit", "decide"}
    for function in ast.walk(tree):
        if not isinstance(function, ast.AsyncFunctionDef) or function.name not in callback_names:
            continue
        if not function.args.args or function.args.args[0].arg != "session":
            continue
        callbacks.append(function.lineno)
        for call in ast.walk(function):
            if not isinstance(call, ast.Call) or not isinstance(call.func, ast.Attribute) or call.func.attr not in operations:
                continue
            owner = call.func.value
            if isinstance(owner, ast.Attribute) and isinstance(owner.value, ast.Name) and owner.value.id == "db":
                if not any(keyword.arg == "session" for keyword in call.keywords):
                    missing.append((call.lineno, ast.get_source_segment(source, call.func)))
    assert len(callbacks) >= 19
    assert missing == []
    assert source.count("await run_transaction(client,") >= 19
