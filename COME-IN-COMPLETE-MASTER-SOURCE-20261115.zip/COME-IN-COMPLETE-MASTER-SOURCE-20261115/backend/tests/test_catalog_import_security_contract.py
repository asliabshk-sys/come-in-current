"""Static contract tests for the authenticated catalog-import workflow.

These guard authorization and safe matching contracts; live database transaction
behavior still requires a configured MongoDB replica set integration test.
"""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text()
TREE = ast.parse(SERVER)


def route(method, path):
    return any(
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and any(
            isinstance(dec, ast.Call)
            and isinstance(dec.func, ast.Attribute)
            and isinstance(dec.func.value, ast.Name)
            and dec.func.value.id == "api"
            and dec.func.attr.upper() == method
            and dec.args
            and isinstance(dec.args[0], ast.Constant)
            and dec.args[0].value == path
            for dec in node.decorator_list
        )
        for node in TREE.body
    )


def function_source(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SERVER, node)


def test_import_template_and_upload_are_authenticated_and_store_scoped():
    assert route("POST", "/shops/{shop_id}/products/import")
    assert route("GET", "/shops/{shop_id}/products/import-template")
    assert "user: dict = Depends(get_current_user)" in function_source("import_shop_products")
    assert "_assert_shop_owner(shop, user)" in function_source("import_shop_products")
    assert "_assert_shop_owner(shop, user)" in function_source("shop_product_import_template")
    assert '"shop_id": shop_id' in function_source("import_shop_products")


def test_global_import_history_and_price_audit_are_admin_only():
    assert "Depends(require_role(\"admin\"))" in function_source("admin_catalog_import_history")
    assert "Depends(require_role(\"admin\"))" in function_source("admin_catalog_price_audit")


def test_preview_has_no_writes_and_apply_is_explicit():
    source = function_source("import_shop_products")
    assert 'if not apply:' in source
    assert '"applied": False, "new_products": new_products' in source
    assert "async def apply(session):" in source
    assert "await run_transaction(client, apply)" in source
    assert '"old_price": float(existing.get("price", 0) or 0)' in source
    assert '"new_price": float(row["price"])' in source


def test_sku_matching_rejects_brand_or_pack_identity_conflicts():
    source = function_source("import_shop_products")
    assert '"SKU/product ID identity conflict: brand or pack/unit differs from the existing listing"' in source
    assert '"sku_key": row["sku"].casefold()' in source
    assert '"unit": row["unit"]' in source


def test_unsupported_file_and_invalid_duplicate_rows_are_reported():
    source = function_source("import_shop_products")
    assert 'filename.endswith(".xls")' in source
    assert '"duplicate SKU within import file"' in source
    assert '"invalid_import_columns"' in source
    assert '"mode": "apply" if apply else "preview"' in source


def test_import_rejects_duplicate_headers_identifiers_and_duplicate_targets():
    source = function_source("import_shop_products")
    assert '"code": "invalid_import_headers"' in source
    assert '"duplicate product_id within import file"' in source
    assert '"multiple import rows resolve to the same existing product; keep one row per product"' in source
    assert '"create rows must not include product_id; use action=update for an existing listing"' in source
    assert '"update rows require product_id or an existing SKU"' in source


def test_seller_import_template_is_available_from_seller_products_ui():
    seller = (ROOT / "frontend" / "app" / "seller" / "products.tsx").read_text()
    assert 'testID="seller-import-template"' in seller
    assert 'api.downloadShopImportTemplate(shopId)' in seller
    assert 'testID="seller-import-apply"' in seller
    assert 'Existing variants are preserved; import does not create or edit variant definitions.' in seller


def test_import_requires_product_listing_fields_and_positive_bounded_price_stock():
    source = function_source("import_shop_products")
    assert 'required = {"name", "unit", "price", "stock", "category_id", "description"}' in source
    assert '0 < price <= 100000000' in source
    assert 'stock_number > 100000000' in source
    assert 'description is required and must be at most 1200 characters' in source
