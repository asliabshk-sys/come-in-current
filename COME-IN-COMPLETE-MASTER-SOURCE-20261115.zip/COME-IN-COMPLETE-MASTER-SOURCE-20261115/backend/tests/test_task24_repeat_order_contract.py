"""Task 24 Repeat Order source-contract regressions; no live API/DB."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ORDERS = (ROOT / "frontend/app/orders.tsx").read_text()
STORE = (ROOT / "frontend/src/store/cart.tsx").read_text()
CHECKOUT = (ROOT / "frontend/app/checkout.tsx").read_text()
BACKEND = (ROOT / "backend/server.py").read_text()


def test_repeat_order_is_customer_grocery_history_action_and_never_auto_submits():
    assert 'item.kind === "grocery" ? <View style={styles.actions}>' in ORDERS
    assert 'testID={`repeat-order-${item.id}`}' in ORDERS
    assert 'addProduct(line.product, line.variantId)' in ORDERS
    assert 'router.push("/(tabs)/cart")' in ORDERS
    assert 'api.post("/orders"' not in ORDERS
    assert 'api.post("/grocery/quotes"' not in ORDERS


def test_repeat_order_aggregates_duplicate_product_variant_rows_before_stock_checks():
    assert 'new Map<string, { productId: string; variantId?: string; qty: number; name: string; measured: boolean }>()' in ORDERS
    assert 'const key = JSON.stringify([productId, variantId || null]);' in ORDERS
    assert 'const combinedQty = (current?.qty || 0) + qty;' in ORDERS
    assert 'if (!savedMeasured && combinedQty > 1000)' in ORDERS


def test_repeat_order_resolves_current_live_product_and_exact_variant_not_old_price():
    assert 'p.id === saved.productId && p.shopId === shopId && p.source === "live"' in ORDERS
    assert 'product.variants?.length && !saved.variantId' in ORDERS
    assert 'product.variants?.find((v) => v.id === saved.variantId)' in ORDERS
    assert 'saved.variantId && (!variant || variant.available === false)' in ORDERS
    assert 'line.price' not in ORDERS
    assert 'only ${Math.max(0, available - alreadyInCart)} currently available' in ORDERS


def test_repeat_order_checks_existing_cart_stock_and_quantity_limit_without_partial_adds():
    assert 'saved.qty + alreadyInCart > 1000' in ORDERS
    assert 'available < saved.qty + alreadyInCart' in ORDERS
    assert 'if (unavailable.length)' in ORDERS
    assert 'Nothing was added so your cart stays unchanged.' in ORDERS
    assert 'resolved.forEach((line)' in ORDERS
    assert 'for (let unit = 0; unit < line.qty; unit += 1)' in ORDERS


def test_repeat_order_uses_normal_cart_then_checkout_requests_a_fresh_authoritative_quote():
    assert 'Checkout will recheck today’s prices and stock.' in ORDERS
    assert 'api.post<GroceryQuote>("/grocery/quotes"' in CHECKOUT
    assert 'items: checkoutLines.map((line) => ({ product_id: line.product.id, variant_id: line.variant?.id, qty: line.qty }))' in CHECKOUT
    assert 'const checkoutLines = buyNowLine ? [buyNowLine] : cartLines;' in CHECKOUT
    assert 'useFocusEffect(useCallback(() => () => clearBuyNow(), [clearBuyNow]));' in CHECKOUT
    assert 'if (buyNowLine) clearBuyNow();\n      else clear();' in CHECKOUT
    assert 'lines = _aggregate_grocery_quote_lines(lines)' in BACKEND
    assert 'quantity > MEASURED_QTY_LIMIT' in BACKEND
    assert 'elif line.qty > 1000' in BACKEND
