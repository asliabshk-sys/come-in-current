import io
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import zipfile
import pytest
from catalogue_import_engine import process_file, process_zip, validate_upload_metadata, MAX_FILE_BYTES


def test_csv_extracts_source_rows_without_inventing_fields():
    raw = b"Product Name,Brand,Price,Stock,Unit\nRice,Brand A,65,,kg\n"
    result = process_file("catalogue.csv", raw)
    assert result.detected_type == "csv"
    assert len(result.records) == 1
    row = result.records[0]
    assert row["normalized"]["name"] == "Rice"
    assert row["normalized"]["price"] == "65"
    assert row["normalized"]["stock"] is None
    assert row["status"] == "NEEDS_REVIEW"
    assert row["source_location"] == "row:2"


def test_csv_hindi_headers_are_recognized_as_aliases():
    result = process_file("items.csv", "उत्पाद,कीमत,मात्रा\nआटा,40,5\n".encode())
    normalized = result.records[0]["normalized"]
    assert normalized["name"] == "आटा"
    assert normalized["price"] == "40"
    assert normalized["stock"] == "5"


def test_extension_and_content_mismatch_is_rejected():
    with pytest.raises(ValueError, match="does not match"):
        process_file("fake.pdf", b"not a pdf")


def test_unsupported_file_is_rejected():
    with pytest.raises(ValueError, match="unsupported"):
        process_file("catalogue.psd", b"8BPSxxxx")


def test_upload_size_limit_is_enforced():
    with pytest.raises(ValueError, match="exceeds"):
        process_file("large.csv", b"x" * (MAX_FILE_BYTES + 1))


def test_pdf_text_adapter_preserves_page_provenance():
    pypdf = pytest.importorskip("pypdf")
    writer = pypdf.PdfWriter()
    page = writer.add_blank_page(width=300, height=300)
    # A blank PDF is valid but contains no selectable text.
    out = io.BytesIO(); writer.write(out)
    result = process_file("scan.pdf", out.getvalue())
    assert result.detected_type == "pdf"
    assert result.pages_or_sheets == 1
    assert result.records == []
    assert result.records == []
    assert result.warnings  # OCR unavailable/empty output is explicitly reported


def test_zip_batch_extracts_supported_members():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("shop/items.csv", "name,price\nSoap,30\n")
        z.writestr("notes.txt", "ignored")
    results = process_zip("batch.zip", buf.getvalue())
    assert len(results) == 1
    assert results[0].filename == "items.csv"
    assert results[0].records[0]["normalized"]["name"] == "Soap"


def test_zip_path_traversal_is_rejected():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("../escape.csv", "name,price\nX,1\n")
    with pytest.raises(ValueError, match="unsafe path"):
        process_zip("batch.zip", buf.getvalue())


def test_xlsx_processes_multiple_sheets_when_openpyxl_available():
    openpyxl = pytest.importorskip("openpyxl")
    wb = openpyxl.Workbook()
    first = wb.active; first.title = "Grocery"
    first.append(["Product Name", "Price", "Stock"])
    first.append(["Rice", 65, 10])
    second = wb.create_sheet("Household")
    second.append(["Product", "Selling Price"])
    second.append(["Soap", 30])
    out = io.BytesIO(); wb.save(out)
    result = process_file("catalogue.xlsx", out.getvalue())
    assert result.pages_or_sheets == 2
    assert len(result.records) == 2
    assert result.records[0]["source_location"] == "sheet:Grocery/row:2"
    assert result.records[1]["source_location"] == "sheet:Household/row:2"
    assert result.records[1]["normalized"]["stock"] is None


def test_image_ocr_extracts_visible_text_without_promoting_fields():
    pil = pytest.importorskip("PIL")
    pytest.importorskip("pytesseract")
    from PIL import Image, ImageDraw, ImageFont
    image = Image.new("RGB", (900, 240), "white")
    draw = ImageDraw.Draw(image)
    draw.text((25, 70), "Rice 65 rupees per kg", fill="black", font=ImageFont.load_default(size=42))
    out = io.BytesIO(); image.save(out, format="PNG")
    result = process_file("sample.png", out.getvalue())
    assert result.detected_type == "png"
    assert result.records[0]["status"] == "NEEDS_REVIEW"
    assert "Rice" in result.records[0]["raw_values"]["extracted_text"]
    assert result.records[0]["normalized"].get("price") is None
    assert result.records[0]["normalized"].get("stock") is None


def test_task5_measured_headers_are_preserved_as_source_values():
    from catalogue_import_engine import _normalize_row
    row = _normalize_row({"product name": "Rice", "sell_by": "weight", "dimension": "weight", "base_unit": "g", "price_basis": "per_kg", "min_qty": "250", "step": "250", "max_qty": "5000", "presets": "250;500"})
    assert row["name"] == "Rice"
    assert row["sell_by"] == "weight"
    assert row["dimension"] == "weight"
    assert row["base_unit"] == "g"
    assert row["min_qty"] == "250"
    assert row["max_qty"] == "5000"


def test_upload_metadata_rejects_mismatched_mime_and_control_filename():
    with pytest.raises(ValueError, match="MIME type"):
        validate_upload_metadata("items.csv", "image/png", b"name,price\nRice,20\n")
    with pytest.raises(ValueError, match="control characters"):
        validate_upload_metadata("bad\nname.csv", "text/csv", b"name,price\nRice,20\n")

def test_upload_metadata_accepts_browser_octet_stream_when_signature_matches():
    assert validate_upload_metadata("items.csv", "application/octet-stream", b"name,price\nRice,20\n") == "csv"

def test_csv_formula_like_cells_are_preserved_as_untrusted_source_text():
    payload = b"name,description\n=HYPERLINK(\"https://bad.invalid\",\"click\"),=cmd|\"/C calc\"\n"
    record = process_file("untrusted.csv", payload).records[0]
    assert record["raw_values"]["name"].startswith("=HYPERLINK")
    assert record["normalized"]["name"].startswith("=HYPERLINK")

def test_xls_signature_is_recognized_but_missing_xlrd_is_reported_cleanly():
    payload = bytes.fromhex("D0CF11E0A1B11AE1") + b"\x00" * 64
    with pytest.raises((RuntimeError, ValueError)):
        process_file("legacy.xls", payload)


def test_scanned_pdf_uses_optional_ocr_without_promoting_product_fields():
    fitz = pytest.importorskip("fitz")
    pil = pytest.importorskip("PIL")
    pytest.importorskip("pytesseract")
    from PIL import Image, ImageDraw, ImageFont
    image = Image.new("RGB", (1000, 260), "white")
    draw = ImageDraw.Draw(image)
    draw.text((25, 80), "Rice 65 rupees per kg", fill="black", font=ImageFont.load_default(size=44))
    image_bytes = io.BytesIO(); image.save(image_bytes, format="PNG")
    doc = fitz.open()
    page = doc.new_page(width=500, height=130)
    page.insert_image(page.rect, stream=image_bytes.getvalue())
    pdf_bytes = doc.tobytes(); doc.close()
    result = process_file("scanned.pdf", pdf_bytes)
    assert result.detected_type == "pdf"
    assert result.records
    assert result.records[0]["source_location"].endswith("/ocr")
    assert result.records[0]["normalized"].get("price") is None
    assert result.records[0]["normalized"].get("stock") is None
    assert result.records[0]["status"] == "NEEDS_REVIEW"
