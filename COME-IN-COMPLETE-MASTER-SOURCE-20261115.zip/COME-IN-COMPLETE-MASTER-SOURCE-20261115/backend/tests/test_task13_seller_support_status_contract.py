"""Task 13 seller support status contracts; no live database is used."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
TREE = ast.parse(SERVER)


def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.AsyncFunctionDef) and n.name == name)
    return ast.get_source_segment(SERVER, node)


def test_seller_status_endpoint_is_role_gated_and_validates_expected_state():
    source = fn("seller_update_order_support")
    assert 'Depends(require_role("shopkeeper", "restaurant"))' in source
    assert 'current_status != body.expected_status' in source
    assert '"open": "in_progress", "in_progress": "resolved"' in source


def test_seller_status_update_checks_order_kind_and_actual_shop_or_restaurant_ownership():
    source = fn("seller_update_order_support")
    assert 'order_kind not in {"grocery", "restaurant"}' in source
    assert 'db.shops.find_one' in source and '"owner_id": user["id"]' in source
    assert 'db.restaurants.find_one' in source and '"owner_id": user["id"]' in source


def test_seller_status_update_is_compare_and_set_and_records_actor_history():
    source = fn("seller_update_order_support")
    assert '"status": current_status' in source
    assert 'getattr(result, "modified_count", 0) != 1' in source
    assert '"updated_by": user["id"]' in source
    assert '"actor_role": user.get("role")' in source


def test_seller_status_endpoint_does_not_execute_refund_or_cancellation():
    source = fn("seller_update_order_support")
    assert "admin_refund_restaurant_order" not in source
    assert "_cancel_grocery_order" not in source
    assert "refund_status" not in source


def test_admin_and_customer_support_routes_remain_available_and_separate():
    assert 'async def my_restaurant_support' in SERVER
    assert 'Depends(get_current_user)' in fn("my_restaurant_support")
    assert 'async def admin_restaurant_support' in SERVER
    assert 'Depends(require_role("admin"))' in fn("admin_restaurant_support")
    assert 'async def admin_update_restaurant_support' in SERVER


def test_seller_status_model_rejects_unknown_and_terminal_status_values():
    model = SERVER[SERVER.index("class SellerSupportStatusIn"):SERVER.index('@api.patch("/seller/support/{ticket_id}")')]
    assert 'Literal["in_progress", "resolved"]' in model
    assert 'Literal["open", "in_progress"]' in model
