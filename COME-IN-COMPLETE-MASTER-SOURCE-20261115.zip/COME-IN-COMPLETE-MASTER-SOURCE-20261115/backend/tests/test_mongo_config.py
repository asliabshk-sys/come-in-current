"""Offline tests for safe MongoDB target validation and bounded client options."""
import pytest
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parents[1]))

from mongo_config import mongo_client_configuration


def base(**overrides):
    env = {
        "MONGO_URL": "mongodb://127.0.0.1:27018/?replicaSet=rs0",
        "DB_NAME": "comein_dev",
        "APP_ENV": "development",
    }
    env.update(overrides)
    return env


def test_development_configuration_sets_bounded_pool_timeouts_and_retry_options():
    uri, name, options = mongo_client_configuration(base())
    assert uri.startswith("mongodb://")
    assert name == "comein_dev"
    assert options["maxPoolSize"] == 50
    assert options["minPoolSize"] == 0
    assert options["serverSelectionTimeoutMS"] == 8000
    assert options["connectTimeoutMS"] == 5000
    assert options["retryReads"] is True
    assert options["retryWrites"] is True
    assert options["tz_aware"] is True


@pytest.mark.parametrize("overrides", [
    {"MONGO_URL": ""},
    {"DB_NAME": ""},
    {"APP_ENV": ""},
    {"DB_NAME": "admin"},
    {"DB_NAME": "bad/name"},
    {"MONGO_MAX_POOL_SIZE": "not-an-int"},
    {"MONGO_MIN_POOL_SIZE": "60"},
    {"APP_ENV": "unknown"},
])
def test_invalid_configuration_fails_closed(overrides):
    with pytest.raises(ValueError):
        mongo_client_configuration(base(**overrides))


def test_production_requires_expected_database_and_tls_without_exposing_uri():
    env = base(APP_ENV="production", DB_NAME="comein_prod", MONGO_EXPECTED_DB_NAME="comein_prod")
    with pytest.raises(ValueError, match="TLS"):
        mongo_client_configuration(env)
    env["MONGO_URL"] = "mongodb://user:secret@example.invalid:27017/?tls=true"
    uri, name, options = mongo_client_configuration(env)
    assert name == "comein_prod"
    assert options["retryWrites"] is True
    assert "secret" not in str(options)


def test_expected_database_name_must_match_actual_target():
    with pytest.raises(ValueError, match="does not match"):
        mongo_client_configuration(base(MONGO_EXPECTED_DB_NAME="comein_prod"))


def test_production_rejects_insecure_tls_certificate_options():
    env = base(APP_ENV="production", DB_NAME="comein_prod", MONGO_EXPECTED_DB_NAME="comein_prod",
               MONGO_URL="mongodb://user:secret@example.invalid:27017/?tls=true&tlsAllowInvalidCertificates=true")
    with pytest.raises(ValueError, match="certificate validation"):
        mongo_client_configuration(env)
