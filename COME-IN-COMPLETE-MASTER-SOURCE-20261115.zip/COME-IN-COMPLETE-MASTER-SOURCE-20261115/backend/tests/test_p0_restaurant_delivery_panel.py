from pathlib import Path


def test_restaurant_search_does_not_render_removed_delivery_area_panel():
    source = (Path(__file__).resolve().parents[2] / "frontend" / "app" / "restaurant" / "search.tsx").read_text()
    assert ">Delivery area<" not in source
    assert "Manage saved addresses" not in source
    # Restaurant discovery and its live search/filter controls remain present.
    assert "listLiveRestaurants(q" in source
    assert "Find your food" in source


def test_restaurant_categories_does_not_render_delivery_area_panel():
    source = (Path(__file__).resolve().parents[2] / "frontend" / "app" / "restaurant" / "categories.tsx").read_text()
    assert ">Delivery area<" not in source
    assert "Manage saved addresses" not in source
    assert "listLiveRestaurants" in source


def test_product_detail_has_distinct_buy_now_checkout_action():
    source = (Path(__file__).resolve().parents[2] / "frontend" / "app" / "product" / "[id].tsx").read_text()
    assert 'testID="buy-now-btn"' in source
    assert 'router.push("/checkout")' in source
    assert "addProduct(product, selectedVariant?.id)" in source
    assert "startBuyNow(product, selectedVariant?.id, buyQty)" in source
    assert "buyNowLine" in (Path(__file__).resolve().parents[2] / "frontend" / "app" / "checkout.tsx").read_text()


def test_shop_payment_settings_are_nonempty_and_cod_is_enforced_on_order():
    server = (Path(__file__).resolve().parents[1] / "server.py").read_text()
    assert "At least one supported shop payment method must be enabled" in server
    assert 'body.payment_method not in enabled_methods' in server
    assert 'body.payment_method not in latest_shop.get("payment_methods", ["cod"])' in server
    assert 'body.payment_method == "upi" and not shop.get("public_upi")' in server
    assert 'confirm-upi-payment' in server


def test_checkout_only_offers_shop_enabled_payment_methods_and_does_not_claim_gateway():
    checkout = (Path(__file__).resolve().parents[2] / "frontend" / "app" / "checkout.tsx").read_text()
    assert 'shopOptions?.paymentMethods.includes("cod")' in checkout
    assert 'shopOptions.paymentMethods.includes("cod")' in checkout
    assert 'testID="pm-upi"' in checkout
    assert 'paymentAvailable' in checkout
    assert "does not automatically receive bank confirmation" in checkout
