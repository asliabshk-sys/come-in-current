"""Task 19 seller/admin authorization regression contracts; no live DB required."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
TREE = ast.parse(SERVER)


def function_source(name: str) -> str:
    node = next(
        n for n in TREE.body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
    )
    return ast.get_source_segment(SERVER, node)


def test_grocery_order_status_requires_current_shopkeeper_role_or_admin_and_shop_ownership():
    source = function_source("update_order_status")
    assert 'if user.get("role") != "admin":' in source
    assert 'if user.get("role") != "shopkeeper":' in source
    assert 'raise HTTPException(status_code=403, detail="Shopkeeper role required")' in source
    assert '_get_shop_or_404(str(order.get("shop_id") or ""))' in source
    assert '_assert_shop_owner(shop, user)' in source
    assert 'db.orders.update_one({"_id": oid, "status": order.get("status")}, update)' in source


def test_every_admin_api_route_has_explicit_admin_role_dependency():
    source_tree = ast.parse(SERVER)
    for node in source_tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        route_paths = []
        for decorator in node.decorator_list:
            if not isinstance(decorator, ast.Call) or not isinstance(decorator.func, ast.Attribute):
                continue
            if not isinstance(decorator.func.value, ast.Name) or decorator.func.value.id != "api":
                continue
            if decorator.args and isinstance(decorator.args[0], ast.Constant):
                route_paths.append(str(decorator.args[0].value))
        if any(path.startswith("/admin/") for path in route_paths):
            body = ast.get_source_segment(SERVER, node) or ""
            assert 'Depends(require_role("admin"))' in body, f"Admin route lacks explicit admin dependency: {node.name}"


def test_product_and_import_writes_remain_shop_scoped():
    assert '_assert_shop_owner(shop, user)' in function_source("create_product")
    update = function_source("update_product")
    delete = function_source("delete_product")
    assert 'user.get("role") != "shopkeeper"' in update and 'product.get("owner_id") != user["id"]' in update
    assert 'user.get("role") != "shopkeeper"' in delete and 'product.get("owner_id") != user["id"]' in delete
    importer = function_source("import_shop_products")
    assert '_assert_shop_owner(shop, user)' in importer
    assert 'await run_transaction(client, apply)' in importer


def test_seller_support_stays_role_gated_and_order_owned():
    listing = function_source("seller_order_support")
    update = function_source("seller_update_order_support")
    assert 'Depends(require_role("shopkeeper", "restaurant"))' in listing
    assert 'Depends(require_role("shopkeeper", "restaurant"))' in update
    assert '"owner_id": user["id"]' in update
    assert '"status": current_status' in update
