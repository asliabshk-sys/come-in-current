"""Evidence-based regression contracts for functional blockers.

These source-level checks deliberately do not claim live DB, gateway, push, or GPS-device
integration. They protect the current fail-closed behavior until those dependencies exist.
"""
import ast
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER_TEXT = (ROOT / "backend" / "server.py").read_text()
SERVER = ast.parse(SERVER_TEXT)
FRONTEND = ROOT / "frontend"


def fn(name):
    node = next(n for n in SERVER.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SERVER_TEXT, node)


def routes():
    found = set()
    for node in ast.walk(SERVER):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute)
                    and isinstance(dec.func.value, ast.Name) and dec.func.value.id == "api"
                    and dec.args and isinstance(dec.args[0], ast.Constant)
                    and isinstance(dec.args[0].value, str)):
                found.add((dec.func.attr.upper(), dec.args[0].value))
    return found


def test_grocery_order_contract_requires_quote_idempotency_and_fails_closed_for_unconfigured_gateways():
    source = fn("create_order")
    assert 'if not body.quote_token:' in source
    assert 'if not body.idempotency_key:' in source
    assert 'body.payment_method not in enabled_methods' in source
    assert 'if body.payment_method == "online_stripe":' in source
    assert 'if body.payment_method == "online_razorpay":' in source
    assert 'if not _grocery_razorpay_keys():' in source
    assert '"payment_method_unavailable"' in source
    assert '"awaiting_upi_payment"' in source
    assert '"razorpay_pending"' in source
    assert 'db.orders.find_one({"grocery_idempotency_scope": idem_scope})' in source
    assert '"quote_invalid"' in source and '"quote_expired"' in source


def test_restaurant_payment_methods_enforce_fulfillment_and_gateway_configuration():
    source = fn("create_restaurant_order")
    assert 'Literal["cod", "pickup", "razorpay"]' in SERVER_TEXT
    assert 'body.payment_method not in restaurant.get("payment_methods", ["cod", "pickup"])' in source
    assert 'body.payment_method == "pickup" and body.fulfillment != "pickup"' in source
    assert 'body.payment_method == "razorpay" and not (os.environ.get("RAZORPAY_KEY_ID") and os.environ.get("RAZORPAY_KEY_SECRET"))' in source
    assert '"pay_at_pickup_pending"' in source and '"cod_pending"' in source


def test_restaurant_duplicate_order_retries_return_existing_order_and_unique_index_is_declared():
    source = fn("create_restaurant_order")
    assert 'db.restaurant_orders.find_one({"customer_id": user["id"], "idempotency_key": body.idempotency_key})' in source
    assert 'except Exception:' in source and 'if prior: return doc_out(prior)' in source
    assert 'db.restaurant_orders.create_index([("customer_id", 1), ("idempotency_key", 1)], unique=True)' in SERVER_TEXT


def test_razorpay_intent_verify_webhook_and_failure_paths_are_guarded():
    known = routes()
    assert ("POST", "/restaurant/orders/{order_id}/payment-intent") in known
    assert ("POST", "/restaurant/payments/verify") in known
    assert ("POST", "/restaurant/payments/razorpay-webhook") in known
    intent, verify, webhook, retry = (fn("create_restaurant_payment_intent"), fn("verify_restaurant_payment"), fn("razorpay_webhook"), fn("retry_restaurant_payment"))
    assert "Existing payment intent does not match the current order total" in intent
    assert '"status") != "captured"' in verify and '"currency") != "INR"' in verify
    assert '"status") != "captured"' in verify and '"gateway_payment_id"' in verify
    assert '"duplicate": True' in webhook
    capture = fn("_commit_restaurant_capture")
    assert 'await _commit_restaurant_capture(' in webhook
    assert '"payment_reconciliation_required": True' in capture
    assert 'order.get("status") == "pending_payment"' in capture
    assert 'return await run_transaction(client, commit)' in capture
    assert 'order.get("payment_status") not in {"failed","pending"}' in retry


def test_support_contract_validates_grocery_and_restaurant_order_ownership():
    known = routes()
    assert ("POST", "/restaurant/support") in known
    assert ("GET", "/restaurant/support/mine") in known
    source = fn("create_restaurant_support")
    assert 'order_kind: Literal["grocery", "restaurant"] = "restaurant"' in SERVER_TEXT
    assert 'order_collection = db.orders if body.order_kind == "grocery" else db.restaurant_orders' in source
    assert '"customer_id": user["id"]' in source
    assert '"order_kind":order_kind' in source
    assert '"order_ref":order_ref' in source


def test_shared_address_route_and_restaurant_compatibility_alias_are_present():
    shared = (FRONTEND / "app" / "addresses.tsx").read_text()
    alias = (FRONTEND / "app" / "restaurant" / "addresses.tsx").read_text()
    account = (FRONTEND / "app" / "(tabs)" / "account.tsx").read_text()
    checkout = (FRONTEND / "app" / "restaurant" / "checkout.tsx").read_text()
    assert "api.get<Address[]>('/addresses')" in shared
    assert "api.post('/addresses'" in shared
    assert 'Redirect href="/addresses"' in alias
    assert 'router.push("/addresses")' in account
    assert "Manage shared saved addresses" in checkout
    assert "selectedSavedAddress?.pincode" in checkout


def test_shared_orders_screen_combines_both_order_domains_without_merging_carts():
    orders = (FRONTEND / "app" / "orders.tsx").read_text()
    assert 'api.get<any[]>("/orders/mine")' in orders
    assert 'api.get<any[]>("/restaurant/orders/mine")' in orders
    assert 'item.kind === "restaurant"' in orders
    shopping = (FRONTEND / "src" / "store" / "cart.tsx").read_text()
    restaurant = (FRONTEND / "src" / "restaurant" / "cart.ts" ).read_text()
    assert '"@comein_cart_v1"' in shopping
    assert "'@comein_restaurant_cart_v1'" in restaurant


def test_notification_contract_is_fail_closed_and_no_token_registration_route_is_exposed():
    from integrations.order_notifications import UnconfiguredOrderNotificationProvider
    paths = {path for _, path in routes()}
    assert {"/notifications/mine", "/notifications/unread-count", "/notifications/read-all"}.issubset(paths)
    assert not any(any(marker in path.lower() for marker in ("push-token", "device-token", "push/register"))
                   for path in paths)
    provider = (ROOT / "backend" / "integrations" / "order_notifications.py").read_text()
    assert "class OrderNotificationProvider(Protocol)" in provider
    assert "class UnconfiguredOrderNotificationProvider" in provider
    assert 'status="not_sent"' in provider
    assert "No verified order-notification provider is configured." in provider


def test_shared_auth_and_address_contracts_remain_owner_scoped():
    assert '"/addresses"' in SERVER_TEXT
    assert 'db.addresses.find({"user_id": user["id"]})' in fn("list_addresses")
    assert '"user_id":user["id"]' in fn("update_address")
    assert '"user_id":user["id"]' in ''.join(fn("delete_address").split())
    assert '<AuthProvider>' in (FRONTEND / "app" / "_layout.tsx").read_text()
    assert 'TOKEN_KEY = "@comein_auth_token_v1"' in (FRONTEND / "src" / "lib" / "api.ts").read_text()


def test_shopping_and_restaurant_cart_persistence_remains_separate():
    shopping = (FRONTEND / "src" / "store" / "cart.tsx").read_text()
    restaurant = (FRONTEND / "src" / "restaurant" / "cart.ts").read_text()
    assert "@comein_cart_v1" in shopping
    assert "@comein_restaurant_cart_v1" in restaurant
    assert "@comein_cart_v1" not in restaurant
    assert "@comein_restaurant_cart_v1" not in shopping


def test_gps_permission_timeout_and_tracking_provider_unavailable_are_explicit():
    gps = (FRONTEND / "app" / "delivery-address.tsx").read_text()
    assert "Location permission was denied" in gps
    assert "Location request timed out" in gps
    assert "timeout: 12000" in gps
    assert "navigator.geolocation.getCurrentPosition" in gps
    assert "navigator.geolocation.watchPosition" not in gps
    provider = (ROOT / "backend" / "integrations" / "delivery_provider.py").read_text()
    assert "class UnconfiguredDeliveryProvider" in provider
    assert 'status="unavailable"' in provider
    assert "No verified delivery-partner provider is configured." in provider


def test_tracking_endpoint_never_exposes_location_after_terminal_order_status():
    tracking = fn("get_order_tracking")
    assert 'order.get("delivery_location") if active else None' in tracking
    assert 'if kind == "restaurant":' in fn("_tracking_order")
    assert 'if body.status in {"delivered", "cancelled"}' in fn("update_order_status")


def test_restaurant_checkout_requires_shared_saved_address_not_unvalidated_manual_text():
    checkout = (FRONTEND / "app" / "restaurant" / "checkout.tsx").read_text()
    assert "api.get<SavedAddress[]>('/addresses')" in checkout
    assert "selectedSavedAddress?.pincode || ''" in checkout
    assert "A manually typed address cannot be used for checkout." in checkout
    assert "address_id: fulfillment === 'delivery' && addressId ? addressId : undefined" in checkout
    assert "delivery_address:" not in checkout
    # Do not reintroduce an editable, unvalidated postal-address field in Restaurant checkout.
    assert '<TextInput value={address} onChangeText=' not in checkout
