from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text()
ADMIN = (ROOT / "frontend" / "app" / "admin.tsx").read_text()
API = (ROOT / "frontend" / "src" / "lib" / "api.ts").read_text()


def test_public_registration_never_accepts_a_role_field_and_defaults_to_customer():
    register_start = SERVER.index('async def register(body: RegisterIn, request: Request)')
    register_end = SERVER.index('@api.post("/auth/login"', register_start)
    block = SERVER[register_start:register_end]
    assert '"role": "customer"' in block
    assert 'body.role' not in block


def test_shop_mutations_require_shopkeeper_role_and_shop_ownership():
    assert 'if user.get("role") != "shopkeeper":' in SERVER
    assert 'if shop.get("owner_id") != user["id"]:' in SERVER
    assert '_assert_shop_owner(shop, user)' in SERVER
    assert '@api.post("/shops/{shop_id}/products/import")' in SERVER
    assert '@api.get("/shops/{shop_id}/products/import-template")' in SERVER


def test_restaurant_mutations_require_seller_role_and_ownership():
    assert 'def _restaurant_owner(restaurant: dict, user: dict):' in SERVER
    assert 'raise HTTPException(status_code=403, detail="Shopkeeper role required")' in SERVER
    assert '_restaurant_owner(restaurant, user)' in SERVER


def test_retail_import_is_admin_only_source_scoped_and_preview_first():
    route = SERVER[SERVER.index('@api.post("/admin/retail-price-import")'):SERVER.index('@api.get("/catalog/retail-prices")')]
    assert 'Depends(require_role("admin"))' in route
    assert 'if not apply:' in route
    assert 'db.retail_price_offers.update_one(key' in route
    assert 'retailer_key' in route and 'retailer_shop_id_key' in route and 'external_key' in route
    assert 'db.retail_price_import_history.insert_one' in route
    assert 'db.retail_price_price_audit.insert_one' in route


def test_retail_price_public_feed_labels_source_and_import_time():
    assert '@api.get("/catalog/retail-prices")' in SERVER
    assert '"status": "success"' in SERVER
    assert 'sort("imported_at", -1)' in SERVER


def test_admin_ui_exposes_retail_import_preview_template_and_history():
    assert 'label: "Retail Price Import"' in ADMIN
    assert 'Preview and validate' in ADMIN
    assert 'Confirm Retail Import' in ADMIN
    assert 'Download Retail CSV template' in ADMIN
    assert '/admin/retail-price-import/history' in ADMIN
    assert 'importRetailPrices' in API


def test_admin_role_management_is_backend_protected_and_cannot_remove_last_admin():
    assert '@api.get("/admin/users")' in SERVER
    assert '@api.patch("/admin/users/{user_id}/role")' in SERVER
    assert 'Depends(require_role("admin"))' in SERVER
    assert 'The last admin account cannot be demoted' in SERVER
    assert 'You cannot remove your own admin role from this session' in SERVER


def test_public_serialization_removes_internal_actor_ids():
    assert 'def public_doc(doc: dict' in SERVER
    assert '("owner_id", "updated_by", "uploader_id")' in SERVER
    assert 'row.pop("owner_id", None)' in SERVER
