"""Contract checks for the customer-facing, non-orderable reference catalog."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REFERENCE_FILE = ROOT / "frontend/src/data/catalog-reference.ts"
CATALOG_FILE = ROOT / "frontend/src/data/catalog.ts"
CATEGORY_SCREEN = ROOT / "frontend/app/(tabs)/categories.tsx"
CATEGORY_DETAIL = ROOT / "frontend/app/category/[slug].tsx"
PRODUCT_CARD = ROOT / "frontend/src/components/ProductCard.tsx"
PRODUCT_DETAIL = ROOT / "frontend/app/product/[id].tsx"
CART_STORE = ROOT / "frontend/src/store/cart.tsx"


def _reference_arrays():
    source = REFERENCE_FILE.read_text(encoding="utf-8")
    arrays = {}
    for category, body in re.findall(r'  "([^"]+)": \[\n(.*?)\n  \],', source, re.S):
        arrays[category] = [json.loads(line.strip().rstrip(",")) for line in body.splitlines() if line.strip()]
    return arrays


def test_reference_catalog_has_minimum_per_supported_category():
    arrays = _reference_arrays()
    assert len(arrays) == 17
    for category, names in arrays.items():
        keys = [" ".join(name.casefold().split()) for name in names]
        assert len(keys) == len(set(keys)), f"duplicate name in {category}"
        if category == "eggs":
            assert len(names) == 31  # Honest limit; do not invent dozens of egg types.
        else:
            assert len(names) >= 100, f"{category} has only {len(names)} references"


def test_all_reference_categories_are_visible_in_customer_category_cards():
    source = CATALOG_FILE.read_text(encoding="utf-8")
    for label in (
        "Grocery & Staples", "Cooking Essentials", "Snacks & Namkeen",
        "Biscuits, Cookies & Bakery", "Cold Drinks & Beverages", "Tea & Coffee",
        "Dairy Products", "Fruits", "Vegetables", "Personal Care",
        "Cleaning & Household", "Frozen Foods & Ice Cream", "Packaged Foods",
        "Eggs", "Stationery", "Baby Care", "Pet Supplies",
    ):
        assert f'name: "{label}"' in source, f"missing visible category {label}"
    category_cards = CATEGORY_SCREEN.read_text(encoding="utf-8")
    assert "data={CATEGORIES}" in category_cards
    assert "router.push(`/category/${item.id}`)" in category_cards


def test_reference_products_are_not_fake_shop_offers_or_orderable():
    source = CATALOG_FILE.read_text(encoding="utf-8")
    assert 'source: "catalog" as const' in source
    assert 'price: 0,' in source  # browse-only references never invent a price
    assert "image: referenceProductImage(categoryId, name)" in source  # imagery is presentation-only, not offer data
    card = PRODUCT_CARD.read_text(encoding="utf-8")
    detail = PRODUCT_DETAIL.read_text(encoding="utf-8")
    cart = CART_STORE.read_text(encoding="utf-8")
    assert 'product.source === "catalog" ? "Price set by shop"' in card
    assert 'product.source === "catalog" ? "Price set by shop"' in detail
    assert 'if (!product || product.source !== "live") return;' in cart
    assert 'imageFailed ? getProductPlaceholder(product.categoryId) : product.image' in card
    assert 'imageFailed ? getProductPlaceholder(product.categoryId) : product.image' in detail
    assert 'testID="catalog-live-listings"' in detail
    assert 'matchingLiveListings.length === 0' in detail
    assert 'router.push(`/product/${listing.id}`)' in detail


def test_category_count_does_not_claim_reference_items_are_in_stock():
    source = CATEGORY_DETAIL.read_text(encoding="utf-8")
    assert "catalog items · live price and stock depend on the shop" in source
    assert "products available" not in source


def test_reference_catalog_names_are_not_duplicated_across_categories_and_placeholders_are_bundled():
    arrays = _reference_arrays()
    owners = {}
    for category, names in arrays.items():
        for name in names:
            key = " ".join(name.casefold().split())
            assert key not in owners, f"{name} duplicated in {owners.get(key)} and {category}"
            owners[key] = category
    catalog = CATALOG_FILE.read_text(encoding="utf-8")
    for filename in ("fruits.png", "tea-coffee.png", "frozen-foods.png", "packaged-foods.png", "eggs.png", "stationery.png", "baby-care.png", "pet-supplies.png"):
        assert (ROOT / "frontend/assets/images/placeholders" / filename).is_file()
        assert f'placeholders/{filename}' in catalog
