from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text()
AUTH = (ROOT / "frontend" / "app" / "auth.tsx").read_text()
ACCOUNT = (ROOT / "frontend" / "app" / "(tabs)" / "account.tsx").read_text()
DASH = (ROOT / "frontend" / "app" / "referral-dashboard.tsx").read_text()
LANDING = (ROOT / "frontend" / "app" / "referral.tsx").read_text()


def test_backend_referral_code_and_attribution_are_server_generated_and_indexed():
    assert 'create_index("referral_code", unique=True, sparse=True)' in SERVER
    assert 'create_index("referred_user_id", unique=True)' in SERVER
    assert 'create_index("reward_key", unique=True)' in SERVER
    assert 'create_index("qualifying_order_id", unique=True, partialFilterExpression=' in SERVER
    assert 'referral_code: Optional[str]' in SERVER or 'referral_code: Optional[str] = Field' in SERVER
    register_block = SERVER[SERVER.index('async def register'):SERVER.index('@api.post("/auth/login", response_model=AuthOut)')]
    assert 'body.referrer_id' not in register_block and 'body.referrer_user_id' not in register_block


def test_referral_attribution_and_reward_are_backend_authoritative():
    assert 'await _validate_referral_code(body.referral_code)' in SERVER
    assert 'await _record_referral_registration(referrer, str(res.inserted_id)' in SERVER
    assert 'await _refresh_referral_order_candidate(fresh, "grocery")' in SERVER
    assert 'await _refresh_referral_order_candidate(fresh_order, "restaurant")' in SERVER
    assert 'await _maybe_create_referral_reward(referrer_id)' in SERVER
    assert 'body.refund_return_checks_passed' in SERVER
    assert 'Depends(require_role("admin"))' in SERVER
    assert 'reward-credit:' in SERVER and 'referral_audit' in SERVER


def test_account_referral_and_registration_capture_are_wired():
    assert 'Referral & Earn' in ACCOUNT and 'router.push("/referral-dashboard")' in ACCOUNT
    assert 'comein.pendingReferralCode' in AUTH
    assert 'referral_code: referralCode' in (ROOT / "frontend" / "src" / "store" / "auth.tsx").read_text()
    assert '/referral/validate' in LANDING
    assert 'referral-copy-link' in DASH and 'referral-share-link' in DASH and 'referral-whatsapp' in DASH
    assert 'navigator.clipboard' in DASH and 'Share.share' in DASH and 'whatsapp://send' in DASH


def test_no_client_supplied_reward_amount_or_eligibility_count_is_trusted_for_reward_credit():
    reward_endpoint = SERVER[SERVER.index('@api.patch("/admin/referral-rewards/{reward_id}")'):SERVER.index('@api.get("/auth/me")')]
    assert 'REFERRAL_REWARD_INR' in reward_endpoint
    assert 'body.amount' not in reward_endpoint
    assert 'eligible_count' not in reward_endpoint
