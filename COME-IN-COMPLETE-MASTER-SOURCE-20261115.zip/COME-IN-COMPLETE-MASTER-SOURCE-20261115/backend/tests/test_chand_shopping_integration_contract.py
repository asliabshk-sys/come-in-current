from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHAND = (ROOT / "frontend" / "app" / "chand.tsx").read_text(encoding="utf-8")
HOME = (ROOT / "frontend" / "app" / "(tabs)" / "index.tsx").read_text(encoding="utf-8")
ACCOUNT = (ROOT / "frontend" / "app" / "(tabs)" / "account.tsx").read_text(encoding="utf-8")
SERVER = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")


def test_chand_uses_real_catalog_product_metadata_and_existing_product_cards():
    assert '"image_url": row.get("image_url")' in SERVER
    assert '"sell_by": row.get("sell_by", "pack")' in SERVER
    assert '"measure": row.get("measure")' in SERVER
    assert '"shop_delivery_available": bool(shop.get("delivery_available", False))' in SERVER
    assert '"shop_pickup_available": bool(shop.get("pickup_available", True))' in SERVER
    assert '"id": str(v.get("id", v.get("_id", "")))' in SERVER
    assert 'from "@/src/components/ProductCard"' in CHAND
    assert 'testID="chand-product-recommendations"' in CHAND
    assert 'source: "live"' in CHAND


def test_chand_preserves_task5_measured_product_contract_for_product_cards():
    assert 'sellBy: item.sell_by || "pack"' in CHAND
    assert 'measure: item.measure' in CHAND
    assert 'router.push(`/product/${product.id}`)' in (ROOT / "frontend" / "src" / "components" / "ProductCard.tsx").read_text(encoding="utf-8")


def test_chand_sends_bounded_session_history_without_persisting_conversations():
    assert 'history: List[AssistantTurn] = Field(default_factory=list, max_length=8)' in SERVER
    assert 'body.history[-8:]' in SERVER
    assert 'const history = [...messages.slice(-7)' in CHAND
    assert 'history }, false)' in CHAND


def test_home_account_and_header_voice_shortcuts_open_one_chand_route():
    assert 'testID="chand-home-entry"' in HOME
    assert 'router.push("/chand?voice=1")' in HOME
    assert 'Voice search unavailable' not in HOME
    assert 'label: "CHAND AI"' in ACCOUNT
    assert 'hint: "Your Smart Shopping Assistant"' in ACCOUNT
    assert 'onPress: () => router.push("/chand")' in ACCOUNT
    assert 'router.push("/request")' not in HOME
    assert 'router.push("/request")' not in ACCOUNT


def test_voice_typing_requires_user_to_review_and_send_transcript():
    assert 'testID="chand-voice-typing"' in CHAND
    assert 'messageInputRef.current?.focus()' in CHAND
    assert 'No audio is sent automatically.' in CHAND
    assert 'testID="chand-voice-start"' in CHAND
    assert 'testID="chand-voice-stop"' in CHAND
    assert 'testID="chand-voice-cancel"' in CHAND
    assert 'chand-voice-language-${value}' in CHAND
    assert 'api.chandTranscribe' in CHAND
    assert 'onPress={() => send()}' in CHAND


def test_provider_prompt_limits_chand_to_comein_and_grounded_budget_data():
    assert 'only the shopping, local services and application assistant for COME-IN' in SERVER
    assert 'For budget lists, use only returned catalog items and their actual prices' in SERVER
    assert 'Do not claim to place orders, change prices, book services, cancel, refund, pay, or change account data.' in SERVER


def test_chand_reports_transport_failure_and_offers_retry_without_fake_live_data():
    assert 'Could not reach the live COME-IN catalog service' in CHAND
    assert 'testID="chand-retry"' in CHAND
    assert 'setRetryQuery(clean)' in CHAND
    assert 'Offline guidance only' in CHAND or 'offline guidance only' in CHAND


def test_chand_discloses_shop_type_and_shop_declared_fulfillment_separately():
    assert 'product.shopType === "online"' in CHAND
    assert 'Shop declares delivery' in CHAND
    assert 'Shop declares pickup' in CHAND


def test_legacy_pickup_drop_service_is_preserved_but_no_longer_branded_request_anything():
    request_screen = (ROOT / "frontend" / "app" / "request.tsx").read_text(encoding="utf-8")
    assert 'api.post<any>(\n        "/requests/anything"' in request_screen
    assert 'Pickup & Drop Request' in request_screen
    assert 'router.push("/request")' in CHAND
