"""Focused Task 09 source-contract tests; these do not require a live MongoDB."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = ROOT / "backend/server.py"
SOURCE = SERVER.read_text()
TREE = ast.parse(SOURCE)


def function_source(name: str) -> str:
    node = next(
        n for n in TREE.body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
    )
    return ast.get_source_segment(SOURCE, node)


def test_customer_grocery_cancel_is_owner_scoped_and_only_cancels_unaccepted_unpaid_orders():
    route = function_source("cancel_grocery_order")
    cancel = function_source("_cancel_grocery_order")
    restore = function_source("_restore_grocery_order_stock")
    assert 'user.get("role") != "customer"' in route
    assert '{"_id": oid, "customer_id": user["id"]}' in route
    assert 'order.get("status") not in {"pending", "pending_payment"}' in cancel
    assert 'order.get("payment_status") not in {"cod_pending", "awaiting_upi_payment", "pay_at_pickup_pending", "pay_at_shop_pending", "razorpay_pending"}' in cancel
    assert 'return await run_transaction(client, apply)' in cancel
    assert 'await _restore_grocery_order_stock(session, order)' in cancel
    assert '"status": "cancelled", "payment_status": "cancelled"' in cancel
    assert 'result.modified_count != 1' in cancel
    assert '"$inc": {"variants.$.stock": qty}' in restore
    assert '"$inc": {"stock": qty}' in restore


def test_grocery_cancel_accepts_canonical_and_legacy_pay_at_shop_without_widening_protected_states():
    cancel = function_source("_cancel_grocery_order")
    allowed = {"cod_pending", "awaiting_upi_payment", "pay_at_pickup_pending", "pay_at_shop_pending"}
    assert all(f'"{state}"' in cancel for state in allowed)
    assert 'order.get("payment_status") not in {' in cancel
    # Paid/collected/refund-related states are intentionally not admitted.
    assert '"paid"' not in cancel
    assert '"cash_collected"' not in cancel
    assert '"refund_pending"' not in cancel
    assert '"refunded"' not in cancel
    # The cancellation path marks the order cancelled; it never marks it paid.
    assert '"status": "cancelled", "payment_status": "cancelled"' in cancel
    assert '"payment_status": "paid"' not in cancel


def test_grocery_seller_status_changes_enforce_transition_map_and_atomic_compare():
    source = function_source("update_order_status")
    assert '"pending": {"accepted"}' in source
    assert '"accepted": {"preparing"}' in source
    assert '"preparing": {"ready"}' in source
    assert '"out_for_delivery": {"delivered"}' in source
    assert 'body.status not in allowed_transitions.get(order.get("status"), set())' in source
    assert 'db.orders.update_one({"_id": oid, "status": order.get("status")}, update)' in source
    assert 'if changed.modified_count != 1' in source


def test_customer_history_exposes_repeat_and_cancel_only_for_grocery_with_live_catalog_revalidation():
    screen = (ROOT / "frontend/app/orders.tsx").read_text()
    assert 'api.post<any>(`/orders/${encodeURIComponent(order.id)}/cancel`, {})' in screen
    assert 'testID={`cancel-order-${item.id}`}' in screen
    assert 'testID={`repeat-order-${item.id}`}' in screen
    assert 'p.id === saved.productId && p.shopId === shopId && p.source === "live"' in screen
    assert 'available < saved.qty + alreadyInCart' in screen
    assert 'combinedQty > 1000' in screen
    assert 'router.push("/(tabs)/cart")' in screen
    assert 'Checkout will recheck today’s prices and stock.' in screen
    assert 'item.kind === "grocery"' in screen


def test_grocery_order_detail_endpoint_uses_existing_customer_shop_owner_admin_authorization():
    route = function_source("get_grocery_order_details")
    permission = function_source("_tracking_can_read")
    assert '@api.get("/orders/{order_id}")' in SOURCE
    assert '_tracking_order(order_id, "grocery")' in route
    assert 'await _tracking_can_read(order, "grocery", user)' in route
    assert 'user.get("role") == "admin" or order.get("customer_id") == user.get("id")' in permission
    assert 'shop.get("owner_id") == user.get("id")' in permission


def test_grocery_order_details_screen_displays_items_amounts_and_status_history():
    screen = (ROOT / "frontend/app/order-tracking.tsx").read_text()
    assert 'api.get<GroceryOrderDetails>(`/orders/${encodeURIComponent(id)}`)' in screen
    assert 'order.items.map((line, index)' in screen
    assert 'order.status_history?.length' in screen
    assert 'Total ₹{order.total}' in screen


def test_existing_customer_selected_same_shop_cart_replacement_remains_intact():
    cart = (ROOT / "frontend/app/(tabs)/cart.tsx").read_text()
    store = (ROOT / "frontend/src/store/cart.tsx").read_text()
    assert 'testID={`replace-${line.key}-with-${candidate.id}`}' in cart
    assert 'replaceLine(line.product.id, line.variant?.id, candidate, variant?.id, line.qty)' in cart
    assert 'replacement.source !== "live"' in store
    assert 'delete next[oldKey]' in store


def test_repeat_order_replays_original_quantity_and_rejects_unavailable_variants():
    screen = (ROOT / "frontend/app/orders.tsx").read_text()
    assert '(!variant || variant.available === false)' in screen
    assert 'for (let unit = 0; unit < line.qty; unit += 1) addProduct(line.product, line.variantId)' in screen
    assert 'Checkout will recheck today’s prices and stock.' in screen


def test_seller_can_decline_unaccepted_upi_order_before_payment_confirmation():
    source = function_source("update_order_status")
    seller_screen = (ROOT / "frontend/app/seller/orders.tsx").read_text()
    assert 'order.get("status") not in {"pending", "pending_payment"}' in source
    assert 'pending_payment: [{ label: "Decline", next: "cancelled" }]' in seller_screen
    assert 'await _cancel_grocery_order(oid, user, body.note or "Declined by shop")' in source


def test_cart_replacement_requires_same_shop_category_and_sufficient_stock():
    store = (ROOT / "frontend/src/store/cart.tsx").read_text()
    screen = (ROOT / "frontend/app/(tabs)/cart.tsx").read_text()
    assert 'original.shopId !== replacement.shopId || original.categoryId !== replacement.categoryId' in store
    assert 'Number(replacementVariant.stock ?? 0) < qty' in store
    assert 'Number(replacement.stock ?? 0) < qty' in store
    assert 'existingReplacementQty + qty > maxStock' in store
    assert 'Number(variant.stock ?? 0) >= line.qty + getQty(candidate.id, variant.id)' in screen
    assert 'Number(candidate.stock ?? 0) >= line.qty + getQty(candidate.id)' in screen
