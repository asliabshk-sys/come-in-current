"""Task 11: customer-facing Grocery refund wording must reflect persisted state."""
import ast
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER_PATH = ROOT / "backend" / "server.py"
TREE = ast.parse(SERVER_PATH.read_text())
NODE = next(node for node in TREE.body if isinstance(node, ast.FunctionDef) and node.name == "_refund_summary")
NAMESPACE = {}
exec(compile(ast.Module(body=[NODE], type_ignores=[]), str(SERVER_PATH), "exec"), NAMESPACE)
refund_summary = NAMESPACE["_refund_summary"]


def test_cancelled_before_payment_is_not_misrepresented_as_refunded():
    result = refund_summary({"status": "cancelled", "payment_status": "cancelled"})
    assert result["refund_status"] == "not_charged"
    assert "no refund is due" in result["message"]


def test_ambiguous_payment_activity_is_under_review_not_confirmed_refund():
    result = refund_summary({"status": "cancelled", "payment_status": "paid"})
    assert result["refund_status"] == "under_review"
    assert "No refund is confirmed" in result["message"]


def test_pending_partial_reconciliation_and_completed_states_are_distinct():
    expected = {
        "refund_pending": "settlement is still pending",
        "partially_refunded": "partial refund has been confirmed",
        "refund_reconciliation_required": "provider reconciliation",
        "refunded": "Full refund processed",
        "refund_failed": "Refund failed",
    }
    for state, phrase in expected.items():
        result = refund_summary({"refund_status": state, "payment_status": "paid"})
        assert result["refund_status"] == state
        assert phrase in result["message"]
