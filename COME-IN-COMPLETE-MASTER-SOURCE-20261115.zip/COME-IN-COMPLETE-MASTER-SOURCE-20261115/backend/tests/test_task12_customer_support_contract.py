"""Task 12 support request contracts; no live DB/provider is used."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
TREE = ast.parse(SERVER)

def fn(name):
    node = next(n for n in TREE.body if isinstance(n, ast.AsyncFunctionDef) and n.name == name)
    return ast.get_source_segment(SERVER, node)

def test_support_request_is_authenticated_and_linked_order_is_customer_owned():
    source = fn("create_restaurant_support")
    assert 'Depends(get_current_user)' in source
    assert '"customer_id": user["id"]' in source
    assert 'raise HTTPException(status_code=404, detail="Order not found for this account")' in source
    assert 'order_kind = body.order_kind if body.order_id else None' in source

def test_support_request_deduplicates_by_customer_and_request_id():
    source = fn("create_restaurant_support")
    assert '{"user_id": user["id"], "request_id": body.request_id}' in source
    assert 'getattr(exc, "code", None) == 11000' in source
    assert 'partialFilterExpression={"request_id": {"$type": "string"}}' in SERVER

def test_support_categories_cover_customer_order_help_reasons():
    model = SERVER[SERVER.index('class RestaurantSupportIn'):SERVER.index('@api.post("/restaurant/support")')]
    for category in ("order_late", "wrong_or_missing_item", "damaged_item", "cancellation_help", "payment_issue", "refund_status", "other"):
        assert category in model

def test_support_creation_does_not_trigger_cancellation_or_refund():
    source = fn("create_restaurant_support")
    assert "admin_refund_restaurant_order" not in source
    assert "_cancel_grocery_order" not in source
    assert '"status":"open"' in source


def test_customer_support_ui_requires_backend_confirmation_and_keeps_retry_key():
    screen = (ROOT / "frontend/app/chand.tsx").read_text()
    assert 'api.post<SupportTicket>("/restaurant/support", payload)' in screen
    assert 'Support request submitted. Reference:' in screen
    assert 'supportRequestId' in screen
    assert 'setSupportRequestId("")' in screen
    assert 'Order late' in screen and 'Wrong / missing item' in screen and 'Refund status' in screen

def test_seller_support_is_role_gated_and_scoped_to_owned_shop_or_restaurant_orders():
    source = fn("seller_order_support")
    assert 'Depends(require_role("shopkeeper", "restaurant"))' in source
    assert 'db.shops.find({"owner_id": user["id"]}' in source
    assert 'db.restaurants.find({"owner_id": user["id"]}' in source
    assert '"order_id": {"$in": list(owned_order_ids)}' in source

def test_combined_order_history_opens_help_with_exact_order_kind_and_id():
    screen = (ROOT / "frontend/app/orders.tsx").read_text()
    assert 'testID={`order-help-${item.id}`}' in screen
    assert 'openHelp: "1", order_id: item.id, order_kind: item.kind' in screen
