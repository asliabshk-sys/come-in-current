"""Exercise the actual measured CSV parser/model without importing the DB server."""
import ast
import math
import re
from pathlib import Path
from typing import List, Optional

import pytest
from pydantic import BaseModel, Field, ValidationError, model_validator

ROOT = Path(__file__).parents[2]
SERVER_PATH = ROOT / "backend" / "server.py"
TREE = ast.parse(SERVER_PATH.read_text())
NODES = []
for node in TREE.body:
    if isinstance(node, ast.Assign):
        names = [target.id for target in node.targets if isinstance(target, ast.Name)]
        if {"MEASURED_SELL_BY", "MEASURED_QTY_LIMIT"}.intersection(names):
            NODES.append(node)
    elif isinstance(node, ast.ClassDef) and node.name == "MeasureIn":
        NODES.append(node)
    elif isinstance(node, ast.FunctionDef) and node.name == "_import_measure":
        NODES.append(node)
assert len(NODES) == 4, "Measured import constants/model/parser must remain present"
NAMESPACE = {
    "BaseModel": BaseModel,
    "Field": Field,
    "List": List,
    "Optional": Optional,
    "ValidationError": ValidationError,
    "model_validator": model_validator,
    "math": math,
    "re": re,
}
exec(compile(ast.Module(body=NODES, type_ignores=[]), str(SERVER_PATH), "exec"), NAMESPACE)
import_measure = NAMESPACE["_import_measure"]


def test_legacy_pack_rows_remain_unchanged():
    assert import_measure({}) == (None, None)
    assert import_measure({"sell_by": "pack"}) == ("pack", None)
    assert import_measure({"sell_by": "fixed_pack"}) == ("pack", None)


def test_weight_import_normalizes_stock_basis_and_presets():
    sell_by, measure = import_measure({
        "sell_by": "measured", "dimension": "weight", "base_unit": "g",
        "price_basis": "per_kg", "min_qty": "250", "step": "250",
        "max_qty": "5000", "presets": "1000;250;500;250",
    })
    assert sell_by == "weight"
    assert measure == {"min_qty": 250, "step": 250, "max_qty": 5000, "presets": [250, 500, 1000]}


def test_volume_import_accepts_ml_stock_and_per_litre_price():
    sell_by, measure = import_measure({
        "sell_by": "volume", "dimension": "volume", "base_unit": "ml",
        "price_basis": "per_L", "min_qty": "250", "step": "50",
        "max_qty": "10000", "presets": "250,500,1000",
    })
    assert sell_by == "volume"
    assert measure["presets"] == [250, 500, 1000]


@pytest.mark.parametrize("row", [
    {"sell_by": "weight", "dimension": "volume", "base_unit": "g", "min_qty": "250", "step": "250", "max_qty": "5000"},
    {"sell_by": "weight", "dimension": "weight", "base_unit": "kg", "min_qty": "250", "step": "250", "max_qty": "5000"},
    {"sell_by": "weight", "dimension": "weight", "base_unit": "g", "price_basis": "per_piece", "min_qty": "250", "step": "250", "max_qty": "5000"},
    {"sell_by": "weight", "dimension": "weight", "base_unit": "g", "min_qty": "250.5", "step": "250", "max_qty": "5000"},
    {"sell_by": "weight", "dimension": "weight", "base_unit": "g", "min_qty": "500", "step": "250", "max_qty": "250"},
    {"sell_by": "weight", "dimension": "weight", "base_unit": "g", "min_qty": "250", "step": "250", "max_qty": "5000", "presets": "600"},
])
def test_invalid_measured_import_rows_fail_closed(row):
    with pytest.raises(ValueError):
        import_measure(row)
