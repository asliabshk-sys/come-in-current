from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text(encoding="utf-8")
ENV = (ROOT / "backend" / ".env.example").read_text(encoding="utf-8")
API_CLIENT = (ROOT / "frontend" / "src" / "lib" / "api.ts").read_text(encoding="utf-8")

def test_health_diagnostic_never_exposes_provider_credentials_or_claims_live_probe():
    assert '@api.get("/assistant/health")' in SERVER
    block = SERVER[SERVER.find('async def assistant_health'):SERVER.find('@api.post("/assistant/transcribe")')]
    assert '"live_probe": False' in block
    assert '"api_key":' not in block.split('return {', 1)[-1]
    assert '"vision_capability": "unverified"' in block
    assert '"speech_to_text_configured"' in block
    assert 'COMEIN_AI_API_KEY' in SERVER

def test_transcription_is_authenticated_bounded_and_ephemeral():
    block = SERVER[SERVER.find('@api.post("/assistant/transcribe")'):SERVER.find('@api.post("/assistant/vision")')]
    assert 'Depends(get_current_user)' in block
    assert '_CHAND_AUDIO_MAX_BYTES = 12 * 1024 * 1024' in SERVER
    assert 'audio/transcriptions' in block
    assert 'stored": False' in block
    assert 'COMEIN_STT_MODEL' in block

def test_photo_vision_validates_content_calls_provider_and_searches_live_catalog():
    block = SERVER[SERVER.find('@api.post("/assistant/vision")'):SERVER.find('# Directory-only categories')]
    assert 'Depends(get_current_user)' in block
    assert '_CHAND_IMAGE_MAX_BYTES = 5 * 1024 * 1024' in SERVER
    assert 'image/jpeg' in block and 'image/png' in block and 'image/webp' in block
    assert 'assistant_context(' in block
    assert 'match_status' in block
    assert 'image_stored": False' in block
    assert 'f"data:{content_type};base64,{encoded}"' in block

def test_upload_rate_limits_are_separate_and_expire():
    block = SERVER[SERVER.find('async def _chand_upload_rate_limit'):SERVER.find('@api.get("/assistant/health")')]
    assert 'assistant_rate_limits.update_one' in block
    assert 'expires_at' in block
    assert 'scope' in block


def test_frontend_api_client_has_authenticated_multipart_adapters():
    assert 'import { uploadForm, type LocalFile } from "@/src/utils/upload"' in API_CLIENT
    assert 'chandTranscribe(file: LocalFile' in API_CLIENT
    assert 'chandVision(file: LocalFile' in API_CLIENT
    assert 'assistant/transcribe' in API_CLIENT
    assert 'assistant/vision' in API_CLIENT
    assert 'withAuthHeaders()' in API_CLIENT


def test_native_photo_and_voice_mobile_integration_is_wired_to_existing_adapters():
    chand = (ROOT / "frontend" / "app" / "chand.tsx").read_text(encoding="utf-8")
    package = (ROOT / "frontend" / "package.json").read_text(encoding="utf-8")
    app_config = (ROOT / "frontend" / "app.json").read_text(encoding="utf-8")
    assert '"expo-image-picker": "~58.0.10"' in package
    assert '"expo-audio": "~58.0.12"' in package
    assert 'expo-image-picker' in app_config and 'expo-audio' in app_config
    assert 'requestCameraPermissionsAsync' in chand
    assert 'requestMediaLibraryPermissionsAsync' in chand
    assert 'launchCameraAsync' in chand and 'launchImageLibraryAsync' in chand
    assert 'testID="chand-photo-cancel"' in chand
    assert 'testID="chand-photo-replace"' in chand
    assert 'api.chandVision' in chand
    assert 'AudioModule.requestRecordingPermissionsAsync' in chand
    assert 'audioRecorder.prepareToRecordAsync()' in chand
    assert 'audioRecorder.record({ forDuration: 90 })' in chand
    assert 'audioRecorder.stop()' in chand
    assert 'api.chandTranscribe' in chand
    assert 'testID={`chand-photo-confirm-${product.id}`}' in chand
