import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = (ROOT / "backend" / "server.py").read_text()
TREE = ast.parse(SOURCE)


def source(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


def has_route(method, path):
    return any(
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        and any(isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute)
                and isinstance(d.func.value, ast.Name) and d.func.value.id == "api"
                and d.func.attr.upper() == method and d.args
                and isinstance(d.args[0], ast.Constant) and d.args[0].value == path
                for d in node.decorator_list)
        for node in TREE.body
    )


def test_job_create_and_retrieve_routes_are_authenticated_and_shop_scoped():
    assert has_route("POST", "/shops/{shop_id}/catalogue-import/jobs")
    assert has_route("GET", "/shops/{shop_id}/catalogue-import/jobs/{job_id}")
    create = source("create_catalogue_import_job")
    get = source("get_catalogue_import_job")
    assert "Depends(get_current_user)" in create and "_assert_shop_owner(shop, user)" in create
    assert '"seller_id": user["id"]' in create and '"shop_id": shop_id' in create
    assert "Depends(get_current_user)" in get and "_assert_shop_owner(shop, user)" in get
    assert '"seller_id": user["id"]' in get and '"shop_id": shop_id' in get


def test_job_preview_is_staged_and_does_not_publish_products():
    create = source("create_catalogue_import_job")
    assert "db.catalogue_import_jobs.insert_one(job)" in create
    assert "CATALOGUE_IMPORT_MAX_BATCH_BYTES" in create
    assert "db.products.insert" not in create and "db.products.update" not in create
    assert '"applied": False' in create
    assert '"approval_status": "PENDING"' in create


def test_existing_csv_xlsx_import_endpoint_remains_present():
    assert has_route("POST", "/shops/{shop_id}/products/import")
