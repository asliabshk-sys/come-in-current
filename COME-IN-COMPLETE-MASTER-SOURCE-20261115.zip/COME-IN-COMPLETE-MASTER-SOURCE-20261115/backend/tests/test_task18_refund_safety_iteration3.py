"""Task 18 QA Iteration 3: refund bounds and checkout messaging.

These tests are database-free. They do not import backend.server, connect to
MongoDB, call Razorpay, or use production data.
"""
import ast
from pathlib import Path

import pytest

from refund_rules import amount_to_paise, summarize_provider_refunds

ROOT = Path(__file__).parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
CHECKOUT = (ROOT / "frontend/app/checkout.tsx").read_text()
ORDERS = (ROOT / "frontend/app/orders.tsx").read_text()
ADMIN = (ROOT / "frontend/app/admin.tsx").read_text()


def test_amount_to_paise_uses_decimal_half_up():
    assert amount_to_paise("125.50") == 12550
    assert amount_to_paise("12.345") == 1235


def test_refund_summary_counts_pending_and_completed_against_captured_amount():
    summary = summarize_provider_refunds(
        [
            {"id": "rfnd_a", "status": "processed", "amount": 2500},
            {"id": "rfnd_b", "status": "pending", "amount": 1500},
        ],
        10000,
    )
    assert summary["consumed_paise"] == 4000
    assert summary["remaining_paise"] == 6000
    assert summary["status"] == "refund_pending"


def test_failed_provider_refund_does_not_consume_captured_amount():
    summary = summarize_provider_refunds(
        [{"id": "rfnd_failed", "status": "failed", "amount": 10000}],
        10000,
    )
    assert summary["consumed_paise"] == 0
    assert summary["remaining_paise"] == 10000
    assert summary["status"] == "not_refunded"


def test_full_provider_refund_is_recognized_as_already_refunded():
    summary = summarize_provider_refunds(
        [{"id": "rfnd_full", "status": "refunded", "amount": 10000}],
        10000,
    )
    assert summary["status"] == "refunded"
    assert summary["remaining_paise"] == 0


def test_refund_total_above_captured_amount_fails_closed():
    with pytest.raises(ValueError, match="exceed"):
        summarize_provider_refunds(
            [
                {"id": "rfnd_a", "status": "processed", "amount": 7000},
                {"id": "rfnd_b", "status": "pending", "amount": 4000},
            ],
            10000,
        )


@pytest.mark.parametrize(
    "records",
    [
        [
            {"id": "same", "status": "processed", "amount": 100},
            {"id": "same", "status": "pending", "amount": 100},
        ],
        [{"id": "bad", "status": "unknown", "amount": 100}],
        [{"id": "bad", "status": "processed", "amount": True}],
        [{"id": "bad", "status": "processed", "amount": 0}],
    ],
)
def test_malformed_or_duplicate_provider_refund_records_fail_closed(records):
    with pytest.raises(ValueError):
        summarize_provider_refunds(records, 10000)


def test_admin_refund_checks_provider_history_and_claims_once_before_posting():
    tree = ast.parse(SERVER)
    route = next(
        node for node in tree.body
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "admin_refund_restaurant_order"
    )
    source = ast.get_source_segment(SERVER, route)
    assert "_fetch_razorpay_refunds" in source
    assert "summarize_provider_refunds" in source
    assert "eligible_paise != captured_paise" in source
    assert '_claim_restaurant_refund_for_gateway(' in source
    assert source.index('_claim_restaurant_refund_for_gateway(') < source.index('_fetch_razorpay_refunds') < source.index('requests.post(')
    claim_fn = next(node for node in tree.body if isinstance(node, ast.AsyncFunctionDef)
                    and node.name == '_claim_restaurant_refund_for_gateway')
    claim_source = ast.get_source_segment(SERVER, claim_fn)
    assert 'db.restaurant_payments.update_one(' in claim_source
    assert 'db.restaurant_orders.update_one(' in claim_source
    assert 'run_transaction(client, claim)' in claim_source
    assert '"amount": eligible_paise' in source
    assert "refund_reconciliation_required" in source


def test_refund_webhook_accumulates_refund_ids_and_only_reverses_full_refunds():
    tree = ast.parse(SERVER)
    webhook = next(
        node for node in tree.body
        if isinstance(node, ast.AsyncFunctionDef) and node.name == "razorpay_webhook"
    )
    source = ast.get_source_segment(SERVER, webhook)
    # Webhook now delegates all payment+order updates to a session-bound helper.
    assert '_apply_restaurant_refund_webhook_transactionally(' in source
    assert '_record_refund_reversal(order, "restaurant", refund_id, session=session)' in SERVER
    assert 'await run_transaction(client, apply)' in SERVER
    assert source.count("_record_refund_reversal(") == 0  # ledger write is inside transaction helper
    helper = next(node for node in tree.body if isinstance(node, ast.AsyncFunctionDef)
                  and node.name == '_apply_restaurant_refund_webhook_transactionally')
    helper_source = ast.get_source_segment(SERVER, helper)
    assert 'refunds[refund_id]' in helper_source
    assert 'summarize_provider_refunds(' in helper_source
    assert 'db.restaurant_payments.update_one(' in helper_source
    assert 'db.restaurant_orders.update_one(' in helper_source
    assert helper_source.count('session=session') >= 4
    assert 'run_transaction(client, apply)' in helper_source
    assert '"refund_reconciliation_required"' in helper_source


def test_checkout_explains_unavailable_fulfillment_and_suppresses_empty_cart_payment_error():
    assert 'testID="fulfillment-unavailable"' in CHECKOUT
    assert 'testID="fulfillment-options-error"' in CHECKOUT
    assert 'loadFailed: true' in CHECKOUT
    assert 'checkoutLines.length > 0 && shopOptions && !shopOptions.loadFailed && !onlineAvailable' in CHECKOUT
    assert 'testID="no-supported-payment"' in CHECKOUT


def test_grocery_pickup_order_does_not_show_delivery_address_copy():
    assert 'item.fulfillment === "pickup" ? "Pickup from shop"' in ORDERS


def test_admin_refund_ui_reports_provider_state_and_hides_retry_for_blocked_states():
    assert 'const result = await api.post<any>(`/admin/restaurant/orders/${id}/refund`, {});' in ADMIN
    assert "Provider-confirmed refunded:" in ADMIN
    assert "Provider refund pending:" in ADMIN
    assert '"partially_refunded"' in ADMIN
    assert '"refund_reconciliation_required"' in ADMIN
    assert 'await load();' in ADMIN[ADMIN.index("const requestRefund"):ADMIN.index("const setReqStatus")]
