"""Delivery tracking security/contract tests; deliberately do not connect to MongoDB."""
import ast
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER_PATH = ROOT / "backend" / "server.py"
SOURCE = SERVER_PATH.read_text()
TREE = ast.parse(SOURCE)


def function_source(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SOURCE, node)


def test_location_update_coordinates_are_bounded_and_finite():
    assert 'latitude: float = Field(ge=-90, le=90)' in SOURCE
    assert 'longitude: float = Field(ge=-180, le=180)' in SOURCE
    assert 'accuracy_m: Optional[float] = Field(default=None, ge=0, le=100000)' in SOURCE
    validator = next(n for n in ast.walk(TREE) if isinstance(n, ast.FunctionDef) and n.name == "finite_coordinate")
    assert "math.isfinite(value)" in ast.get_source_segment(SOURCE, validator)


def test_tracking_read_is_authenticated_and_order_scoped():
    source = function_source("get_order_tracking")
    assert 'Depends(get_current_user)' in source
    assert '_tracking_order(order_id, kind)' in source
    assert '_tracking_can_read(order, kind, user)' in source
    assert 'status_code=403' in source


def test_location_update_requires_authorized_operator_and_out_for_delivery():
    source = function_source("update_order_tracking_location")
    assert 'Depends(get_current_user)' in source
    assert 'user.get("role") != "admin"' in source
    assert 'status") != "out_for_delivery"' in source
    assert 'status_code=403' in source and 'status_code=409' in source
    assert '"updated_by": user["id"]' in source


def test_tracking_stops_exposing_location_after_terminal_status():
    grocery = function_source("update_order_status")
    restaurant = function_source("update_restaurant_order_status")
    assert 'body.status in {"delivered", "cancelled"}' in grocery
    assert 'body.status in {"delivered", "cancelled", "rejected", "picked_up"}' in restaurant
    tracking = function_source("get_order_tracking")
    assert 'point = order.get("delivery_location") if active else None' in tracking


def test_frontend_location_is_explicit_one_shot_with_manual_fallback():
    screen = (ROOT / "frontend" / "app" / "delivery-address.tsx").read_text()
    assert 'navigator.geolocation.getCurrentPosition' in screen
    assert 'Location permission was denied' in screen
    assert 'could not determine a location' in screen
    assert 'enter an address manually' in screen.lower()
    assert 'watchPosition' not in screen
    assert 'background' in screen.lower()


def test_customer_tracking_screen_polls_only_authenticated_order_endpoint_and_never_fabricates_eta():
    screen = (ROOT / "frontend" / "app" / "order-tracking.tsx").read_text()
    assert 'api.get<Tracking>(`/orders/${encodeURIComponent(id)}/tracking?kind=${orderKind}`)' in screen
    assert 'setInterval(() => { void load(); }, 10000)' in screen
    assert 'No driver movement, route, or ETA is simulated' in screen
    assert 'tracking.location.latitude.toFixed(5)' in screen


def test_customer_cancellation_clears_any_stored_restaurant_delivery_location():
    source = function_source("cancel_restaurant_order")
    assert '"status":"cancelled"' in source
    assert '"$unset":{"delivery_location":""}' in source


def test_tracking_update_is_atomic_against_order_status_changes():
    source = function_source("update_order_tracking_location")
    assert '"status": "out_for_delivery", "fulfillment": {"$ne": "pickup"}' in source
    assert "if result.modified_count != 1" in source
    assert "Location updates are allowed only while a delivery is out for delivery" in source


def test_project_has_no_delivery_partner_role_or_assignment_in_tracking_api():
    source = function_source("update_order_tracking_location")
    assert 'user.get("role") != "admin"' in source
    assert "Only the authorized order operator can update delivery location" in source
    assert "delivery_partner_id" not in source
    assert "rider_id" not in source


def test_tracking_update_atomic_filter_excludes_pickup_and_terminal_status_races():
    source = function_source("update_order_tracking_location")
    assert '"fulfillment": {"$ne": "pickup"}' in source
    assert '"status": "out_for_delivery"' in source
    assert "if result.modified_count != 1" in source


def test_current_location_ui_explains_timeout_and_does_not_background_track():
    screen = (ROOT / "frontend" / "app" / "delivery-address.tsx").read_text()
    assert "Location request timed out" in screen
    assert "timeout: 12000" in screen
    assert "navigator.geolocation.getCurrentPosition" in screen
    assert "navigator.geolocation.watchPosition" not in screen


def test_tracking_read_permissions_are_scoped_to_customer_or_related_operator():
    source = function_source("_tracking_can_read")
    assert 'order.get("customer_id") == user.get("id")' in source
    assert 'user.get("role") != "shopkeeper"' in source
    assert 'order.get("restaurant_owner_id") != user.get("id")' in source
    assert 'restaurant.get("owner_id") == user.get("id")' in source
    assert 'shop.get("owner_id") == user.get("id")' in source
    assert 'user.get("role") == "admin"' in source
