"""Delivery Partner onboarding isolation/security contracts; no Mongo or provider calls."""
import ast
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER = (ROOT / "backend" / "server.py").read_text()
TREE = ast.parse(SERVER)
SCREEN = (ROOT / "frontend" / "app" / "delivery-partner.tsx").read_text()
ADMIN_SCREEN = (ROOT / "frontend" / "app" / "admin-delivery-partners.tsx").read_text()


def fn(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SERVER, node)


def test_delivery_partner_draft_is_separate_and_rejects_seller_role():
    source = fn("save_delivery_partner_application")
    assert 'user.get("role") == "shopkeeper"' in source
    assert 'db.delivery_partner_applications' in source
    assert 'db.shops' not in source


def test_sensitive_fields_are_encrypted_before_database_write():
    source = fn("save_delivery_partner_application")
    for field in ("full_name", "mobile", "residential_address", "alternate_contact"):
        assert f'"{field}_enc": _dp_encrypt(body.{field})' in source
        assert f'"{field}": body.{field}' not in source
    assert "DELIVERY_PARTNER_DATA_ENCRYPTION_KEY" in SERVER


def test_public_application_projection_never_returns_sensitive_fields():
    source = fn("_dp_public")
    for value in ("full_name_enc", "mobile_enc", "residential_address_enc", "alternate_contact_enc", "full_name", "residential_address", "alternate_contact"):
        assert value not in source


def test_submit_and_approval_fail_closed_without_all_verified_requirements():
    submit = fn("submit_delivery_partner_application")
    decide = fn("admin_decide_delivery_partner_application")
    for check in ("phone_verified", "aadhaar_verified", "pan_verified", 'documents_status'):
        assert check in submit
        assert check in decide
    assert '"PENDING_ADMIN_APPROVAL"' in submit


def test_admin_review_routes_are_role_protected_and_audited():
    assert 'Depends(require_role("admin"))' in fn("admin_delivery_partner_applications")
    detail = fn("admin_delivery_partner_application_detail")
    assert 'Depends(require_role("admin"))' in detail
    assert '"ADMIN_VIEWED_PII"' in detail
    decision = fn("admin_decide_delivery_partner_application")
    assert 'Depends(require_role("admin"))' in decision
    assert '"actor_id": admin["id"]' in decision


def test_otp_and_identity_provider_absence_never_simulates_success():
    assert 'raise HTTPException(status_code=503' in fn("delivery_partner_otp_request")
    assert 'raise HTTPException(status_code=503' in fn("delivery_partner_otp_verify")
    assert 'raise HTTPException(status_code=503' in fn("delivery_partner_identity_start")


def test_approved_state_is_required_for_delivery_partner_access():
    source = fn("delivery_partner_access")
    assert 'd.get("status") != "APPROVED"' in source
    assert 'status_code=403' in source


def test_partner_referral_sharing_is_approval_gated_and_no_rewards_are_auto_granted():
    source = fn("delivery_partner_referral")
    assert 'approved = app_doc.get("status") == "APPROVED"' in source
    assert '"code": app_doc["referral_code"] if approved else None' in source
    assert '"reward_status": "NOT_CONFIGURED"' in source


def test_onboarding_frontend_is_separate_and_never_collects_raw_aadhaar_pan():
    assert '"/delivery-partner/application"' in SCREEN
    assert 'Do not enter Aadhaar or PAN numbers here' in SCREEN
    assert "Share.share" in SCREEN
    assert "api.post(\"/delivery-partner/otp/request\"" in SCREEN


def test_admin_screen_uses_delivery_partner_api_and_not_seller_approval_api():
    assert "/delivery-partner/admin/applications" in ADMIN_SCREEN
    assert "/admin/shops" not in ADMIN_SCREEN
    assert '"approve" | "reject" | "correction" | "suspend" | "reactivate"' in ADMIN_SCREEN


def test_admin_reason_is_redacted_before_audit_or_application_storage():
    assert "[identity-redacted]" in fn("_dp_safe_reason")
    assert "[phone-redacted]" in fn("_dp_safe_reason")
    decision = fn("admin_decide_delivery_partner_application")
    assert 'safe_reason = _dp_safe_reason(body.reason.strip())' in decision
    assert '"reason": safe_reason' in decision


def test_admin_state_transition_is_atomic_against_concurrent_review():
    decision = fn("admin_decide_delivery_partner_application")
    assert 'if changed.modified_count != 1' in decision
    assert 'Application state changed during review' in decision


def test_account_entry_is_customer_only_and_admin_review_is_separate():
    account = (ROOT / "frontend" / "app" / "(tabs)" / "account.tsx").read_text()
    assert 'user?.role === "customer" ? [{ icon: "truck"' in account
    assert 'router.push("/delivery-partner")' in account
    assert 'router.push("/admin-delivery-partners")' in account
