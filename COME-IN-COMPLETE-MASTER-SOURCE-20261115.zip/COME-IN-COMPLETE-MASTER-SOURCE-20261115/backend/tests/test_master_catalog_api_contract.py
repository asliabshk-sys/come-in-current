from pathlib import Path


def test_master_catalog_routes_are_admin_gated_and_authenticated():
    source = Path(__file__).resolve().parents[1].joinpath("server.py").read_text()
    assert '@api.post("/admin/master-products")' in source
    assert 'Depends(require_role("admin"))' in source
    assert '@api.get("/catalog/master-products")' in source
    assert 'Depends(get_current_user)' in source


def test_master_link_enforces_shop_ownership_variant_and_duplicate_guard():
    source = Path(__file__).resolve().parents[1].joinpath("server.py").read_text()
    assert '@api.post("/shops/{shop_id}/master-products/{master_product_id}/link")' in source
    assert "_assert_shop_owner(shop, user)" in source
    assert '"code": "invalid_variant"' in source
    assert '"code": "duplicate_link"' in source
    assert '"master_product_id": str(master_oid)' in source


def test_directory_only_categories_rejected_for_master_creation_and_linking():
    source = Path(__file__).resolve().parents[1].joinpath("server.py").read_text()
    assert "_reject_directory_only_product(body.category_id)" in source
    assert '_reject_directory_only_product(master.get("category_id", ""))' in source
