"""Backup *script* safety tests with a mocked mongodump binary; no real DB connected."""
import hashlib
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).parents[2]


def test_backup_creates_unique_never_overwritten_outputs_with_private_mode(tmp_path):
    bin_dir = tmp_path / 'bin'
    bin_dir.mkdir()
    stub = bin_dir / 'mongodump'
    stub.write_text('''#!/usr/bin/env python3
import os, pathlib, sys
archive = next(x.split('=',1)[1] for x in sys.argv if x.startswith('--archive='))
config = next(x.split('=',1)[1] for x in sys.argv if x.startswith('--config='))
assert (os.stat(config).st_mode & 0o777) == 0o600
with open(archive, 'xb') as out:
    out.write(b'FAKE_ARCHIVE_NOT_REAL_DATABASE\\n')
''')
    stub.chmod(0o755)
    backup_dir = tmp_path / 'backups'
    env = {**os.environ, 'PATH': f'{bin_dir}:{os.environ["PATH"]}',
           'MONGO_URL': 'mongodb://127.0.0.1:27017',
           'DB_NAME': 'comein_disposable_test_mock_backup', 'BACKUP_DIR': str(backup_dir)}
    for _ in range(2):
        result = subprocess.run(['bash', str(ROOT / 'scripts/backup-db.sh')],
                                env=env, text=True, capture_output=True, check=False)
        assert result.returncode == 0, result.stderr
    archives = sorted(backup_dir.rglob('*.archive.gz'))
    assert len(archives) == 2 and archives[0] != archives[1]
    for archive in archives:
        assert archive.read_bytes() == b'FAKE_ARCHIVE_NOT_REAL_DATABASE\n'
        assert archive.with_name(archive.name + '.sha256').exists()
        assert hashlib.sha256(archive.read_bytes()).hexdigest() in archive.with_name(archive.name + '.sha256').read_text()
        assert archive.stat().st_mode & 0o077 == 0


def test_restore_refuses_production_or_same_source_names_before_tool_invocation(tmp_path):
    file = tmp_path / 'test.archive.gz'
    file.write_bytes(b'NOT_AN_ARCHIVE')
    env = {**os.environ, 'MONGO_URL': 'mongodb://127.0.0.1:27017',
           'DB_NAME': 'production_data', 'TARGET_DB': 'production_data'}
    result = subprocess.run(['bash', str(ROOT / 'scripts/restore-db.sh'), str(file)],
                            env=env, text=True, capture_output=True, check=False)
    assert result.returncode == 2
    assert 'Refusing to restore into the configured source database' in result.stderr
    env['TARGET_DB'] = 'customer_records'
    result = subprocess.run(['bash', str(ROOT / 'scripts/restore-db.sh'), str(file)],
                            env=env, text=True, capture_output=True, check=False)
    assert result.returncode == 2
    assert 'TARGET_DB must start' in result.stderr
