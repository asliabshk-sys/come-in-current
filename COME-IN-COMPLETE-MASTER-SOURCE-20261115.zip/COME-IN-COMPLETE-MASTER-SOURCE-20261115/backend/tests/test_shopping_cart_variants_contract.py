from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CATALOG = (ROOT / "frontend/src/data/catalog.ts").read_text()
CART = (ROOT / "frontend/src/store/cart.tsx").read_text()
CART_SCREEN = (ROOT / "frontend/app/(tabs)/cart.tsx").read_text()
PRODUCT_DETAILS = (ROOT / "frontend/app/product/[id].tsx").read_text()
PRODUCT_CARD = (ROOT / "frontend/src/components/ProductCard.tsx").read_text()


def test_catalog_declares_explicit_stable_variant_fields():
    assert "export type ProductVariant" in CATALOG
    assert "id: string;" in CATALOG
    assert "variants?: ProductVariant[];" in CATALOG
    assert "stock?: number;" in CATALOG


def test_variant_cart_keys_are_separate_and_legacy_keys_are_preserved():
    assert 'const VARIANT_KEY_SEPARATOR = "::variant::"' in CART
    assert "getCartItemKey(productId: string, variantId?: string)" in CART
    assert "return variantId ? `${productId}${VARIANT_KEY_SEPARATOR}${variantId}` : productId;" in CART
    assert "if (!variant) return null;" in CART


def test_cart_line_price_comes_from_selected_variant_and_subtotal_uses_line_price():
    assert "unit: variant.unit, price: variant.price, mrp: variant.mrp" in CART
    assert "lineAmount(line.product, line.qty)" in CART
    assert "price: variant.price" in CART


def test_cart_screen_uses_unique_line_identity_for_multiple_variants():
    assert "key={line.key}" in CART_SCREEN
    assert "increment(line.product.id, line.variant?.id)" in CART_SCREEN
    assert "decrement(line.product.id, line.variant?.id)" in CART_SCREEN


def test_product_details_selects_variant_and_uses_variant_specific_values():
    assert "setSelectedVariantId(variant.id)" in PRODUCT_DETAILS
    assert "getQty(product.id, selectedVariant?.id)" in PRODUCT_DETAILS
    assert "addProduct(product, selectedVariant?.id)" in PRODUCT_DETAILS
    assert "displayedProduct.price" in PRODUCT_DETAILS
    assert "displayedProduct.unit" in PRODUCT_DETAILS
    assert "variant.stock !== undefined && variant.stock <= 0" in PRODUCT_DETAILS


def test_variant_products_route_to_options_instead_of_adding_ambiguous_base_item():
    assert "const hasVariants = Boolean(product.variants?.length)" in PRODUCT_CARD
    assert "choose-variant-${product.id}" in PRODUCT_CARD
    assert "OPTIONS" in PRODUCT_CARD


def test_legacy_persisted_cart_shape_remains_supported():
    assert "Keep accepting the legacy productId -> qty persisted cart shape." in CART
    assert 'const STORAGE_KEY = "@comein_cart_v1"' in CART
    assert "typeof stored === \"string\"" in CART or 'typeof stored === "string"' in CART
