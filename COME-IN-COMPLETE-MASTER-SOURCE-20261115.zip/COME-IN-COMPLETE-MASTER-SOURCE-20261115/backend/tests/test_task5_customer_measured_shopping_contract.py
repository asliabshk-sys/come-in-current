"""Source-contract coverage for Task 5 Phase 4 customer measured shopping.

These tests inspect the checked-in source and pure validation logic. They do not
replace Expo/device or MongoDB replica-set runtime verification.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
MEASURE = (ROOT / "frontend/src/lib/measure.ts").read_text()
PICKER = (ROOT / "frontend/src/components/MeasuredQuantityPicker.tsx").read_text()
DETAIL = (ROOT / "frontend/app/product/[id].tsx").read_text()
CART = (ROOT / "frontend/src/store/cart.tsx").read_text()
CART_SCREEN = (ROOT / "frontend/app/(tabs)/cart.tsx").read_text()
CHECKOUT = (ROOT / "frontend/app/checkout.tsx").read_text()


def test_measured_modes_keep_weight_and_volume_base_units_distinct_from_pack():
    assert 'MEASURED_SELL_BY = {"weight": ("g", "kg"), "volume": ("ml", "L")}' in SERVER
    assert 'weight: { small: "g", big: "kg" }' in MEASURE
    assert 'volume: { small: "ml", big: "L" }' in MEASURE
    assert 'sell_by: Optional[Literal["pack", "weight", "volume"]]' in SERVER
    # Piece remains a fixed-pack unit; whole-piece produce was excluded from
    # the first measured release by the approved business decisions.
    assert 'return "pack"' in SERVER


def test_customer_picker_is_live_product_only_and_requests_server_quote():
    assert 'api.post<ServerPrice>("/grocery/measured-price", { product_id: product.id, qty: amount })' in PICKER
    assert 'server.qty === amount' in PICKER
    assert 'server.line_total.toFixed(2)' in PICKER
    assert 'testID="measured-server-price"' in PICKER
    assert 'if (!product || product.source !== "live") return;' in CART


def test_customer_picker_exposes_seller_min_step_max_and_safe_invalid_state():
    assert 'min: formatAmount(product, m.min_qty)' in PICKER
    assert 'max: formatAmount(product, m.max_qty)' in PICKER
    assert 'step: m.step' in PICKER
    assert 'amountError(product, amount' in PICKER
    assert 'disabled={Boolean(error)}' in PICKER
    assert 'testID="measured-error"' in PICKER


def test_quantity_validation_requires_integer_min_max_step_and_available_stock():
    assert 'if (!Number.isInteger(qty) || qty < m.min_qty || qty > m.max_qty)' in MEASURE
    assert 'if ((qty - m.min_qty) % m.step)' in MEASURE
    assert 'if (p.stock !== undefined && qty > p.stock)' in MEASURE
    assert 'if line.qty < lo or line.qty > hi or (line.qty - lo) % step:' in SERVER
    assert 'qty: int = Field(ge=1, le=MEASURED_QTY_LIMIT)' in SERVER


def test_customer_product_detail_identifies_measured_and_fixed_pack_units():
    assert 'isMeasured(product)' in DETAIL
    assert 'MeasuredQuantityPicker product={product}' in DETAIL
    assert 'measured ? t(product.sellBy === "volume" ? "m.soldByVolume" : "m.soldByWeight"' in DETAIL
    assert 'measured ? `₹${lineAmount(product, qty).toFixed(2)}`' in DETAIL
    assert 'displayedProduct.unit' in DETAIL


def test_measured_quantity_is_preserved_as_base_unit_amount_in_cart():
    assert 'setAmount: (product: Product, qty: number)' in CART
    assert 'const error = amountError(product, qty)' in CART
    assert 'setItems((prev) => ({ ...prev, [product.id]: qty }))' in CART
    assert 'const STORAGE_KEY = "@comein_cart_v1"' in CART
    assert 'storage.setItem(STORAGE_KEY, JSON.stringify(items))' in CART
    assert 'Math.floor(qty)' in CART


def test_measured_and_variant_pack_cart_lines_have_distinct_stable_identity():
    assert 'const VARIANT_KEY_SEPARATOR = "::variant::"' in CART
    assert 'return variantId ? `${productId}${VARIANT_KEY_SEPARATOR}${variantId}` : productId;' in CART
    assert 'key={line.key}' in CART_SCREEN
    assert 'increment(line.product.id, line.variant?.id)' in CART_SCREEN
    assert 'decrement(line.product.id, line.variant?.id)' in CART_SCREEN


def test_buy_now_validates_measured_amount_without_mutating_normal_cart():
    assert 'startBuyNow: (product: Product, variantId: string | undefined, qty: number) => boolean' in CART
    assert 'if (variantId || amountError(product, qty)) return false;' in CART
    assert 'setBuyNowLine({ key: product.id, product, qty });' in CART
    assert 'const buyQty = measured ? qty : Math.max(1, qty)' in DETAIL
    assert 'startBuyNow(product, selectedVariant?.id, buyQty)' in DETAIL


def test_backend_quote_resolves_measured_line_and_uses_decimal_server_total():
    assert 'Decimal(str(price)) * qty / 1000' in SERVER
    assert 'ROUND_HALF_UP' in SERVER
    assert 'line_total": _measured_line_total(pricing["price"], line.qty)' in SERVER
    assert '@api.post("/grocery/measured-price")' in SERVER
    assert '@api.post("/grocery/quotes")' in SERVER


def test_backend_rejects_invalid_or_unavailable_measured_quantities():
    assert '"code": "measured_quantity_invalid"' in SERVER
    assert '"code": "insufficient_stock"' in SERVER
    assert '"code": "quantity_limit_exceeded"' in SERVER
    assert '"code": "variant_unavailable"' in SERVER


def test_order_uses_transaction_for_quote_claim_stock_deduction_and_insert():
    assert 'await run_transaction(client, apply)' in SERVER
    assert '"status": "consumed"' in SERVER
    assert 'await _atomic_decrement_line(session, line)' in SERVER
    assert 'await db.orders.insert_one(order_doc, session=session)' in SERVER
    assert 'Never decrement stock outside the transaction.' in SERVER
    assert 'non-transactional fallback' in SERVER


def test_checkout_displays_and_submits_server_confirmed_quote_before_order():
    assert 'api.post<GroceryQuote>("/grocery/quotes"' in CHECKOUT
    assert 'setQuote(created)' in CHECKOUT
    assert 'quote?.subtotal ?? subtotal' in CHECKOUT
    assert 'quote?.total ?? total' in CHECKOUT
    assert 'items: quote.items.map((line) =>' in CHECKOUT
    assert 'quote_token: quote.quote_token' in CHECKOUT
