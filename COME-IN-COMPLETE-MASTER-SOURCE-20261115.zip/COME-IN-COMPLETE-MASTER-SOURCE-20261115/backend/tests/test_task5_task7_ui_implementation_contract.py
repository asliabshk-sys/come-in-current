from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_live_product_cards_offer_buy_now_and_keep_variant_selection_flow():
    card = (ROOT / "frontend/src/components/ProductCard.tsx").read_text()
    detail = (ROOT / "frontend/app/product/[id].tsx").read_text()
    assert 'testID={`buy-now-card-${product.id}`}' in card
    assert 'router.push("/checkout")' in card
    assert 'router.push(`/product/${product.id}`)' in card
    assert 'testID="buy-now-btn"' in detail
    assert 'variant-option-${variant.id}' in detail
    assert 'onInc={measured ? () => { increment(product.id, undefined, product); setCartMessage(""); } : incrementSelected}' in detail
    assert "increment(product.id, selectedVariant?.id, product)" in detail
    assert 'onAdd={measured ? () => { addProduct(product); setCartMessage(""); } : addSelectedToCart}' in detail


def test_referral_home_banner_is_customer_only_and_uses_server_side_one_time_claim():
    home = (ROOT / 'frontend/app/(tabs)/index.tsx').read_text()
    server = (ROOT / "backend/server.py").read_text()
    assert 'user?.role === "customer"' in home
    assert 'referral-first-login-banner' in home
    assert 'referral-returning-banner' in home
    assert 'router.push("/referral-dashboard")' in home
    assert 'api.post<{ show_prominent: boolean }>("/referrals/home-banner-claim", {})' in home
    assert '"first_home_banner_pending": True' in server
    assert '@api.post("/referrals/home-banner-claim")' in server
    assert '"first_home_banner_pending": True' in server
