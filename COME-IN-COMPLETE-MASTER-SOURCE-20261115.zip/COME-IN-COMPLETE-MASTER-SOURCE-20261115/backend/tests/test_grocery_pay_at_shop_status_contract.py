"""Focused source contracts for Grocery Pay-at-Shop legacy compatibility.

These tests do not claim a live FastAPI/MongoDB or seller-device workflow.
"""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER_TEXT = (ROOT / "backend" / "server.py").read_text()
SERVER = ast.parse(SERVER_TEXT)
SELLER_UI = (ROOT / "frontend" / "app" / "seller-earnings.tsx").read_text()


def function_source(name: str) -> str:
    node = next(
        n for n in SERVER.body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name
    )
    return ast.get_source_segment(SERVER_TEXT, node)


def test_new_grocery_cash_shop_and_pickup_orders_use_pickup_specific_pending_state():
    source = function_source("create_order")
    assert '"payment_status": ("cod_pending" if body.payment_method == "cod" else "awaiting_upi_payment" if body.payment_method == "upi" else "razorpay_pending" if body.payment_method == "online_razorpay" else "pay_at_pickup_pending")' in source
    assert 'body.payment_method in {"cash_shop", "pickup"} and body.fulfillment != "pickup"' in source
    assert '"cod_pending"' in source


def test_grocery_cash_collection_accepts_legacy_state_but_restaurant_does_not_expand_it():
    source = function_source("confirm_manual_cash_collection")
    assert 'allowed_cash_states = {"cod_pending", "pay_at_pickup_pending"}' in source
    assert 'if kind == "grocery":' in source
    assert 'allowed_cash_states.add("pay_at_shop_pending")' in source
    assert 'order.get("payment_status") not in allowed_cash_states' in source


def test_cash_confirmation_requires_explicit_attestation_and_completed_fulfillment():
    source = function_source("confirm_manual_cash_collection")
    assert 'if not body.confirmed:' in source
    assert '"delivered", "picked_up"' in source
    assert '"payment_status": "cash_collected"' in source
    assert '"cash_collection_confirmed_by": user["id"]' in source
    assert '"cash_collection_confirmed_at": now' in source
    assert '"manual_cash_collection_confirmed"' in source
    assert '"paid"' not in source


def test_seller_earnings_shows_cash_confirmation_for_legacy_and_canonical_grocery_states():
    assert '["cod_pending","pay_at_pickup_pending","pay_at_shop_pending"].includes(o.payment_status)' in SELLER_UI
    assert 'Confirm cash physically received' in SELLER_UI


def test_grocery_cancellation_accepts_new_and_legacy_pay_at_shop_states_without_changing_cod():
    cancellation = function_source("_cancel_grocery_order")
    assert 'order.get("payment_status") not in {"cod_pending", "awaiting_upi_payment", "pay_at_pickup_pending", "pay_at_shop_pending", "razorpay_pending"}' in cancellation
    assert '"cod_pending"' in cancellation
    assert '"pay_at_pickup_pending"' in cancellation
    assert '"pay_at_shop_pending"' in cancellation


def test_grocery_cancellation_keeps_protected_payment_states_outside_allowlist():
    cancellation = function_source("_cancel_grocery_order")
    # Cancellation is fail-closed: only the explicit unpaid allowlist passes.
    assert 'order.get("payment_status") not in {"cod_pending", "awaiting_upi_payment", "pay_at_pickup_pending", "pay_at_shop_pending", "razorpay_pending"}' in cancellation
    assert 'Payment may already have been collected or used' in cancellation
    assert '"status": "cancelled", "payment_status": "cancelled"' in cancellation
    assert '"paid"' not in cancellation
    assert '"cash_collected"' not in cancellation
