"""Static frontend contracts; runtime behavior still needs Expo/device testing."""
from pathlib import Path

ROOT = Path(__file__).parents[2]

def test_expo_public_backend_url_is_documented_and_used():
    api = (ROOT / "frontend/src/lib/api.ts").read_text()
    env = (ROOT / "frontend/.env.example").read_text()
    assert "process.env.EXPO_PUBLIC_BACKEND_URL" in api
    assert "EXPO_PUBLIC_BACKEND_URL=http://localhost:8001" in env
    assert "Backend URL is not configured" in api
    assert 'if (window.location.port === "3000") return ""' in api

def test_auth_token_uses_secure_storage_consistently():
    api = (ROOT / "frontend/src/lib/api.ts").read_text()
    auth = (ROOT / "frontend/src/store/auth.tsx").read_text()
    cart = (ROOT / "frontend/src/restaurant/cart.ts").read_text()
    assert "storage.secureGet<string>(TOKEN_KEY" in api
    assert "storage.secureSet(TOKEN_KEY, token)" in auth
    assert "storage.secureRemove(TOKEN_KEY)" in auth
    assert "storage.secureGet<string>(TOKEN_KEY" in cart

def test_frontend_exposes_typecheck_and_production_web_build_scripts():
    import json
    package = json.loads((ROOT / "frontend/package.json").read_text())
    assert package["scripts"]["typecheck"] == "tsc --noEmit"
    assert package["scripts"]["build:web"] == "expo export --platform web"


def test_restaurant_checkout_never_creates_local_demo_orders():
    checkout = (ROOT / "frontend/app/restaurant/checkout.tsx").read_text()
    assert "No order was created" in checkout
    assert "ORDERS_KEY" not in checkout
    assert "storage.setItem" not in checkout
    assert "createLiveOrder" in checkout
    assert "new Set(lines.map((line) => line.restaurantId)).size !== 1" in checkout


def test_auth_persistence_failure_is_not_silently_accepted():
    auth = (ROOT / "frontend/src/store/auth.tsx").read_text()
    assert "const saved = await storage.secureSet(TOKEN_KEY, token)" in auth
    assert "could not save the session securely" in auth
    assert "Keep an already-hydrated user signed in through transient network/5xx errors" in auth


def test_upload_handles_missing_backend_and_network_errors():
    api = (ROOT / "frontend/src/lib/api.ts").read_text()
    upload = api.split('async upload(', 1)[1].split('\n  },', 1)[0]
    assert "if (!API_BASE)" in upload
    assert "Could not upload the image" in upload


def test_app_does_not_globally_suppress_runtime_diagnostics():
    layout = (ROOT / "frontend/app/_layout.tsx").read_text()
    assert "LogBox.ignoreAllLogs(true)" not in layout


def test_shopping_and_restaurant_carts_use_distinct_storage_keys():
    shopping = (ROOT / "frontend/src/store/cart.tsx").read_text()
    restaurant = (ROOT / "frontend/src/restaurant/cart.ts").read_text()
    assert '"@comein_cart_v1"' in shopping
    assert "'@comein_restaurant_cart_v1'" in restaurant


def test_shopping_home_theme_contract_and_separate_mode_routes():
    home = (ROOT / "frontend/app/(tabs)/index.tsx").read_text()
    theme = (ROOT / "frontend/src/theme.ts").read_text()
    tabs = (ROOT / "frontend/app/(tabs)/_layout.tsx").read_text()
    shops = (ROOT / "frontend/app/shops.tsx").read_text()
    for marker in (
        'testID="home-filter-button"',
        'testID="online-shops-card"',
        'testID="offline-shops-card"',
        'testID="restaurant-mode-card"',
        'testID="home-services-card"',
        'testID="request-anything-card"',
        '{CATEGORIES.map((item) => (',
        'testID="header-language"',
        'testID="header-voice-search"',
        'testID="fresh-groceries-banner"',
        'router.push("/restaurant")',
        'router.push("/services")',
    ):
        assert marker in home
    assert 'brandHeader: "#FFE34F"' in theme
    assert 'surface: "#EFFBF5"' in theme
    # Match the reference hierarchy: yellow brand row, then mint search surface.
    assert home.index("{/* Sticky Header */}") < home.index("{/* Search sits on the mint page surface")
    assert 'testID="location-selector"' in home
    assert 'styles.searchArea' in home
    assert "discoveryTitle" not in home
    assert 'backgroundColor: colors.brandForest' in tabs
    assert 'useLocalSearchParams<{ type?: string }>()' in shops
    assert 'params.type === "online" || params.type === "offline"' in shops


def test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest():
    catalog = (ROOT / "frontend/src/data/catalog.ts").read_text()
    home = (ROOT / "frontend/app/(tabs)/index.tsx").read_text()
    assert 'id: "bakery"' in catalog
    assert 'id: "p-bakery-bread"' not in catalog
    assert 'name: "Fresh Bread Loaf"' not in catalog
    assert 'Voice search unavailable' in home
    assert 'Speech recognition is not configured for this app.' in home

def test_bakery_category_uses_catalog_filter_and_existing_empty_state():
    catalog = (ROOT / "frontend/src/data/catalog.ts").read_text()
    category_screen = (ROOT / "frontend/app/category/[slug].tsx").read_text()
    assert "export function getProductsByCategory(categoryId: string): Product[]" in catalog
    assert "PRODUCTS.filter((p) => p.categoryId === categoryId)" in catalog
    assert 'filter((p) => p.categoryId === slug)' in category_screen
    assert 'products.length === 0 ? (' in category_screen
    assert 'No products in this category.' in category_screen
    # No current catalog item claims to be Bakery inventory.
    product_data = catalog.split("const DEMO_PRODUCTS: Product[] = [", 1)[1].split("// Local catalog is intentionally preview-only", 1)[0]
    assert 'categoryId: "bakery"' not in product_data


def test_shopping_search_and_cart_contracts_remain_separate_from_restaurant_mode():
    catalog = (ROOT / "frontend/src/data/catalog.ts").read_text()
    search = (ROOT / "frontend/app/(tabs)/search.tsx").read_text()
    shopping_cart = (ROOT / "frontend/src/store/cart.tsx").read_text()
    restaurant_cart = (ROOT / "frontend/src/restaurant/cart.ts").read_text()
    assert "export function searchProducts(query: string): Product[]" in catalog
    assert 'allProducts.filter' in search
    assert 'useCatalogProducts' in search
    assert '"@comein_cart_v1"' in shopping_cart
    assert "'@comein_restaurant_cart_v1'" in restaurant_cart


def test_account_notification_payment_and_help_rows_have_real_routes_and_honest_status_screens():
    account = (ROOT / "frontend/app/(tabs)/account.tsx").read_text()
    notifications = (ROOT / "frontend/app/notifications.tsx").read_text()
    payments = (ROOT / "frontend/app/payment-methods.tsx").read_text()
    assert 'label: t("account.notifications"), onPress: () => router.push("/notifications")' in account
    assert 'label: t("account.paymentMethods"), onPress: () => router.push("/payment-methods")' in account
    assert 'label: t("account.help"), onPress: () => router.push("/chand")' in account
    assert 't("n.pushOff")' in notifications
    assert "Push delivery is not configured" in notifications
    server = (ROOT / "backend/server.py").read_text()
    assert '"push_configured": False' in server
    assert "requestPermissionsAsync" not in notifications
    assert "scheduleNotificationAsync" not in notifications
    assert "grocery checkout currently supports COD" in payments
    assert "customer-facing gateway checkout is not integrated here" in payments
    assert 'router.push("/notifications")' in account and 'router.push("/payment-methods")' in account


def test_restaurant_account_route_redirects_to_the_single_shared_account_screen():
    restaurant_account = (ROOT / "frontend/app/restaurant/account.tsx").read_text()
    shopping_account = (ROOT / "frontend/app/(tabs)/account.tsx").read_text()
    layout = (ROOT / "frontend/app/_layout.tsx").read_text()
    assert 'return <Redirect href="/(tabs)/account" />' in restaurant_account
    assert "export default function AccountScreen()" in shopping_account
    assert "<AuthProvider>" in layout
    assert "Sign in / create account" not in restaurant_account
    assert "useAuth" not in restaurant_account


def test_restaurant_login_and_account_links_preserve_shared_auth_and_address_contracts():
    auth = (ROOT / "frontend/src/store/auth.tsx").read_text()
    api = (ROOT / "frontend/src/lib/api.ts").read_text()
    restaurant_addresses = (ROOT / "frontend/app/restaurant/addresses.tsx").read_text()
    assert 'export function useAuth()' in auth
    assert 'storage.secureSet(TOKEN_KEY, token)' in auth
    assert 'storage.secureRemove(TOKEN_KEY)' in auth
    assert 'Redirect href="/addresses"' in restaurant_addresses
    assert "api.post('/addresses'" in (ROOT / "frontend/app/addresses.tsx").read_text()
    assert "Authorization" in api
    assert "<LocationProvider>" in (ROOT / "frontend/app/_layout.tsx").read_text()


def test_restaurant_account_alias_keeps_existing_links_compatible():
    nav = (ROOT / "frontend/src/restaurant/RestaurantNav.tsx").read_text()
    confirmation = (ROOT / "frontend/app/restaurant/order-confirmation.tsx").read_text()
    assert "['/restaurant/account','Account','user']" in nav
    assert "router.replace('/restaurant/orders'" in confirmation
    assert "'/restaurant/account'" in nav
    route = (ROOT / "frontend/app/restaurant/account.tsx").read_text()
    assert 'Redirect href="/(tabs)/account"' in route


def test_shared_payment_methods_screen_links_only_to_supported_checkout_flows():
    screen = (ROOT / "frontend/app/payment-methods.tsx").read_text()
    assert 'router.push("/(tabs)/cart")' in screen
    assert 'router.push("/restaurant/cart")' in screen
    assert "does not store card or bank details" in screen
    assert "customer-facing gateway checkout is not integrated" in screen


def test_restaurant_account_and_address_routes_are_shared_compatibility_aliases():
    account = (ROOT / "frontend/app/restaurant/account.tsx").read_text()
    addresses = (ROOT / "frontend/app/restaurant/addresses.tsx").read_text()
    assert 'Redirect href="/(tabs)/account"' in account
    assert 'Redirect href="/addresses"' in addresses


def test_restaurant_support_route_redirects_to_shared_chand_with_order_context():
    route = (ROOT / "frontend/app/restaurant/support.tsx").read_text()
    detail = (ROOT / "frontend/app/restaurant/orders/[id].tsx").read_text()
    assert "Redirect" in route and "openHelp=1" in route
    assert "order_kind === 'grocery' ? 'grocery' : 'restaurant'" in route
    assert "order_id:order.id,order_kind:'restaurant'" in detail
