"""Source-level safety contracts for checkout reward redemption."""
import ast
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER_PATH = ROOT / "backend" / "server.py"
SERVER = SERVER_PATH.read_text()
CHECKOUT = (ROOT / "frontend" / "app" / "checkout.tsx").read_text()
TREE = ast.parse(SERVER)


def source_of(name):
    node = next(n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    return ast.get_source_segment(SERVER, node)


def test_reward_redemption_is_opt_in_customer_only_and_server_calculated():
    quote = source_of("create_grocery_quote")
    assert "use_rewards: bool = False" in SERVER
    assert 'user.get("role") != "customer"' in quote
    assert "_available_shopping_reward_balance(user[\"id\"])" in quote
    assert 'shopping_reward_discount(totals["total"], available_balance)' in quote
    assert 'totals["reward_discount"] = reward_discount' in quote


def test_order_revalidates_and_consumes_rewards_inside_inventory_transaction():
    order = source_of("create_order")
    assert 'quote.get("customer_id") != user.get("id")' in order
    assert '"reward_balance_changed"' in order
    assert "await run_transaction(client, apply)" in order
    assert "_consume_shopping_reward(session, user[\"id\"], reward_discount, str(res.inserted_id), now)" in order
    assert '"shopping-reward:{order_id}"' in source_of("_consume_shopping_reward")
    assert '"$inc": {"redeemed_amount": take}' in source_of("_consume_shopping_reward")


def test_checkout_has_customer_only_reward_toggle_and_displays_server_discount():
    assert 'api.get<any>("/referrals/me")' in CHECKOUT
    assert 'testID="checkout-use-referral-rewards"' in CHECKOUT
    assert "use_rewards: useRewards" in CHECKOUT
    assert "quote?.reward_discount" in CHECKOUT
    assert "Referral rewards" in CHECKOUT
