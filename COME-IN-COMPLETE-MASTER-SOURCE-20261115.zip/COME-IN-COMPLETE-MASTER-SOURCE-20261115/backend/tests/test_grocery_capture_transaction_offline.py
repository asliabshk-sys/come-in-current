"""Actual Grocery capture callback executed with fake session rollback/retry.

These tests do not establish live MongoDB transaction behavior.
"""
import ast
import asyncio
import copy
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Optional

import pytest
from fastapi import HTTPException
from mongo_transactions import run_transaction
from test_catalogue_transaction_apply_offline import Collection, Client

SERVER = (Path(__file__).parents[1] / 'server.py').read_text()
TREE = ast.parse(SERVER)


def environment(status='pending_payment', payment_status='razorpay_pending', ambiguous_commit=False, transient=False):
    class DB:
        grocery_payments = Collection()
        orders = Collection()
    db = DB()
    db.orders.docs.append({'_id': 'o1', 'ref': 'GR-TEST', 'customer_id': 'u1', 'status': status,
                           'payment_status': payment_status, 'status_history': []})
    db.grocery_payments.docs.append({'_id': 'p1', 'order_id': 'o1', 'status': 'created'})
    client = Client(db, ambiguous_commit=ambiguous_commit, transient_once=transient)
    notices = []
    async def notify(*args):
        notices.append(args)
    namespace = {'re': re, 'db': db, 'client': client, 'Optional': Optional, 'HTTPException': HTTPException,
                 'run_transaction': run_transaction, '_notify': notify,
                 'now_utc': lambda: 'now', 'logger': SimpleNamespace(error=lambda *args: None)}
    node = next(copy.deepcopy(n) for n in TREE.body if isinstance(n, ast.AsyncFunctionDef) and n.name == '_mark_grocery_paid')
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), '<grocery-server-source>', 'exec'), namespace)
    return db, namespace['_mark_grocery_paid'], notices, client


def call(fn, payment_id='pay_1'):
    return asyncio.run(fn('o1', {'_id': 'p1'}, payment_id, 'verified captured payment'))


def test_grocery_capture_atomic_and_post_commit_notification_once():
    db, fn, notices, _ = environment()
    assert call(fn)['payment_status'] == 'paid'
    assert db.grocery_payments.docs[0]['gateway_payment_id'] == 'pay_1'
    assert len(notices) == 1
    assert call(fn)['payment_status'] == 'paid'
    assert len(notices) == 1


def test_grocery_order_failure_aborts_payment_and_no_notification():
    db, fn, notices, _ = environment()
    db.orders.fail_update = True
    with pytest.raises(HTTPException) as exc:
        call(fn)
    assert exc.value.status_code == 503
    assert db.grocery_payments.docs[0]['status'] == 'created'
    assert db.orders.docs[0]['payment_status'] == 'razorpay_pending'
    assert notices == []


def test_grocery_transient_retry_and_unknown_commit_reconciliation():
    db, fn, notices, client = environment(transient=True)
    assert call(fn)['payment_status'] == 'paid'
    assert client.sessions[0].attempts == 2
    assert len(notices) == 1
    db2, fn2, notices2, _ = environment(ambiguous_commit=True)
    assert call(fn2)['payment_status'] == 'paid'
    assert len(db2.orders.docs[0]['status_history']) == 1
    assert notices2 == []  # ambiguous commit response; do not issue speculative notification


def test_grocery_late_capture_marks_review_and_does_not_reopen_cancelled_order():
    db, fn, notices, _ = environment(status='cancelled', payment_status='razorpay_pending')
    order = call(fn)
    assert order['status'] == 'cancelled' and order['refund_status'] == 'under_review'
    assert db.grocery_payments.docs[0]['status'] == 'paid'
    assert notices == []


def test_grocery_conflicting_gateway_capture_rejected():
    db, fn, notices, _ = environment()
    call(fn)
    with pytest.raises(HTTPException) as exc:
        call(fn, 'pay_2')
    assert exc.value.status_code == 409 and len(notices) == 1
