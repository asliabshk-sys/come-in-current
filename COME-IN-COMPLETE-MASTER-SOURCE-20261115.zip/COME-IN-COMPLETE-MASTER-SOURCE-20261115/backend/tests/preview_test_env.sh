# Disposable PREVIEW test accounts only. Not secrets; never reuse in production.
export COMEIN_TEST_ADMIN_EMAIL=admin@comein-preview.com
export COMEIN_TEST_ADMIN_PASSWORD='ComeInAdminPreview2026!'
export COMEIN_TEST_CUSTOMER_EMAIL=test.customer@comein-preview.com
export COMEIN_TEST_CUSTOMER_PASSWORD='TestCustomer2026!'
export COMEIN_TEST_SELLER_EMAIL=test.seller@comein-preview.com
export COMEIN_TEST_SELLER_PASSWORD='TestSeller2026!'
export COMEIN_TEST_RESTO_EMAIL=test.resto@comein-preview.com
export COMEIN_TEST_RESTO_PASSWORD='TestResto2026!'
