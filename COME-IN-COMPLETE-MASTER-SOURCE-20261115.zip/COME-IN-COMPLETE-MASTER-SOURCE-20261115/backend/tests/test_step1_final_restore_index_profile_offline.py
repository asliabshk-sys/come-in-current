"""Read-only safety and fake-data restore/index/profile checks; NO real DB."""
import importlib.util
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
from scripts.mongo import comein_mongo, verify_disposable_restore

ROOT = Path(__file__).parents[2]


def load_legacy_profile():
    sys.path.insert(0, str(ROOT / 'scripts/mongo'))
    try:
        spec = importlib.util.spec_from_file_location('test_legacy_profile', ROOT / 'scripts/mongo/legacy_profile_disposable.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        sys.path.pop(0)


def local_test_env():
    return {'APP_ENV': 'test', 'MONGO_URL': 'mongodb://localhost:27017/?replicaSet=rs0',
            'DB_NAME': 'comein_disposable_test_source',
            'TARGET_DB': 'comein_disposable_test_restored'}


def test_restore_refuses_remote_server_and_missing_confirmation_without_tools(tmp_path):
    archive = tmp_path / 'mock.archive.gz'
    archive.write_bytes(b'NOT_REAL_MONGO_ARCHIVE')
    env = {**os.environ, **local_test_env(), 'MONGO_URL': 'mongodb://remote.example.invalid:27017',
           'CONFIRM_DISPOSABLE_RESTORE_DB': 'comein_disposable_test_restored'}
    result = subprocess.run(['bash', str(ROOT / 'scripts/restore-db.sh'), str(archive)],
                            env=env, capture_output=True, text=True, check=False)
    assert result.returncode != 0 and 'only an unauthenticated localhost' in result.stderr
    env['MONGO_URL'] = local_test_env()['MONGO_URL']
    env.pop('CONFIRM_DISPOSABLE_RESTORE_DB')
    result = subprocess.run(['bash', str(ROOT / 'scripts/restore-db.sh'), str(archive)],
                            env=env, capture_output=True, text=True, check=False)
    assert result.returncode != 0 and 'confirm exact TARGET_DB' in result.stderr


def test_restore_refuses_non_disposable_source_and_non_test_environment(tmp_path):
    archive = tmp_path / 'mock.archive.gz'
    archive.write_bytes(b'FAKE')
    env = {**os.environ, **local_test_env(),
           'CONFIRM_DISPOSABLE_RESTORE_DB': 'comein_disposable_test_restored'}
    env['APP_ENV'] = 'production'
    result = subprocess.run(['bash', str(ROOT / 'scripts/restore-db.sh'), str(archive)],
                            env=env, capture_output=True, text=True, check=False)
    assert 'APP_ENV=test required' in result.stderr
    env['APP_ENV'] = 'test'
    env['DB_NAME'] = 'customers_live'
    result = subprocess.run(['bash', str(ROOT / 'scripts/restore-db.sh'), str(archive)],
                            env=env, capture_output=True, text=True, check=False)
    assert 'source DB must be disposable' in result.stderr


def test_restore_verification_comparison_detects_document_count_and_index_drift():
    class DB:
        def __init__(self, count, indexes):
            self.count = count
            self.indexes = indexes
        def list_collection_names(self):
            return ['orders']
        def __getitem__(self, name):
            return SimpleNamespace(count_documents=lambda _q: self.count,
                                   list_indexes=lambda: iter(self.indexes))
    index = [{'name': '_id_', 'key': [(' _id', 1)]}, {'name': 'scope', 'key': [('scope', 1)], 'unique': True}]
    assert verify_disposable_restore.check_restore(DB(2, index), DB(2, index))['verified']
    bad = verify_disposable_restore.check_restore(DB(2, index), DB(1, index[:1]))
    assert not bad['verified']
    assert {'document_count', 'index_specification'} <= {item['type'] for item in bad['issues']}


def test_empty_source_is_not_called_successful_restore():
    class DB:
        def list_collection_names(self): return []
    assert not verify_disposable_restore.check_restore(DB(), DB())['verified']


def test_index_creation_preflight_blocks_mutation_when_unique_duplicates_present(monkeypatch):
    class DB:
        def __init__(self):self.created = []
        def list_collection_names(self): return []
        def create_collection(self, name): self.created.append(name)
    db = DB()
    monkeypatch.setattr(comein_mongo, 'preflight_unique_indexes',
                        lambda _db: {'ok': False, 'duplicates': [{'duplicate_groups_found': 1}]})
    with pytest.raises(RuntimeError, match='no index migration started'):
        comein_mongo.init_db(db)
    assert db.created == []


def test_disposable_legacy_profile_guard_refuses_unconfirmed_or_remote_target():
    profiler = load_legacy_profile()
    env = {**local_test_env(), 'CONFIRM_DISPOSABLE_PROFILE_DB': 'comein_disposable_test_source'}
    assert profiler.check_target(env) == 'comein_disposable_test_source'
    for key, value in [('APP_ENV', 'production'), ('DB_NAME', 'real_customer_db'),
                       ('MONGO_URL', 'mongodb://remote.example.invalid:27017'),
                       ('CONFIRM_DISPOSABLE_PROFILE_DB', 'different')]:
        invalid = dict(env, **{key: value})
        with pytest.raises(ValueError):
            profiler.check_target(invalid)
