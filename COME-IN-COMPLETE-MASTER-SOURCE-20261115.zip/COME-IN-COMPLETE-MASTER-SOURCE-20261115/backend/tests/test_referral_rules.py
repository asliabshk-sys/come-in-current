from referral_rules import (
    REFERRAL_MIN_ORDER_INR, REFERRAL_REWARD_INR, REFERRAL_TARGET,
    new_referral_code, normalize_referral_code, valid_referral_code_format,
    order_is_referral_candidate, reward_threshold_reached, shopping_reward_discount,
)


def test_generated_codes_are_formatted_and_unique_in_sample():
    codes = [new_referral_code() for _ in range(1000)]
    assert all(valid_referral_code_format(code) for code in codes)
    assert len(set(codes)) == len(codes)
    assert all(len(code) == 14 for code in codes)


def test_invalid_codes_are_rejected_by_format():
    for code in ("", "COME123", "COME" + "Z" * 10, "COME" + "A" * 10 + "!", "user@example.com"):
        assert not valid_referral_code_format(code)
    assert valid_referral_code_format("  come" + "a" * 10 + "  ")
    assert normalize_referral_code(" comeabcdef0123 ") == "COMEABCDEF0123"


def test_purchase_below_100_does_not_qualify():
    assert not order_is_referral_candidate({"total": 99.99, "status": "delivered", "payment_status": "paid"})
    assert not order_is_referral_candidate({"total": 100, "status": "pending", "payment_status": "paid"})


def test_100_or_more_only_becomes_a_candidate_after_delivery_and_not_blocked():
    assert order_is_referral_candidate({"total": 100, "status": "delivered", "payment_status": "paid"})
    assert order_is_referral_candidate({"total": 250, "status": "delivered", "payment_status": "cod_pending"})
    for payment_status in ("refunded", "refund_pending", "disputed", "failed", "cancelled"):
        assert not order_is_referral_candidate({"total": 500, "status": "delivered", "payment_status": payment_status})
    assert not order_is_referral_candidate({"total": 500, "status": "delivered", "payment_status": "paid", "refund_status": "pending"})
    assert not order_is_referral_candidate({"total": 500, "status": "delivered", "payment_status": "paid", "return_status": "requested"})
    assert not order_is_referral_candidate({"total": 500, "status": "delivered", "payment_status": "paid", "dispute_status": "open"})


def test_ten_customer_reward_threshold_is_exactly_ten_or_more():
    assert not reward_threshold_reached(9)
    assert reward_threshold_reached(10)
    assert reward_threshold_reached(11)
    assert REFERRAL_TARGET == 10
    assert REFERRAL_REWARD_INR == 500.0
    assert REFERRAL_MIN_ORDER_INR == 100.0


def test_shopping_reward_discount_never_exceeds_total_or_available_balance():
    assert shopping_reward_discount(120, 500) == 120.0
    assert shopping_reward_discount(900, 125.55) == 125.55
    assert shopping_reward_discount(0, 500) == 0.0
    assert shopping_reward_discount(100, -2) == 0.0
    assert shopping_reward_discount(-1, 500) == 0.0
