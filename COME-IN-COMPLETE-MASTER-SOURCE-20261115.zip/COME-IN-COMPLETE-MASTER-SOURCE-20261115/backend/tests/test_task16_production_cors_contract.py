"""Task 16: production CORS must be explicit; development preview stays compatible."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))

import pytest

from security_config import cors_origins_from_env


def test_development_keeps_legacy_wildcard_default():
    assert cors_origins_from_env({}) == ["*"]
    assert cors_origins_from_env({"APP_ENV": "development", "CORS_ORIGINS": ""}) == ["*"]


def test_production_requires_explicit_origins():
    with pytest.raises(ValueError, match="CORS_ORIGINS"):
        cors_origins_from_env({"APP_ENV": "production"})
    with pytest.raises(ValueError, match="CORS_ORIGINS"):
        cors_origins_from_env({"ENVIRONMENT": "prod", "CORS_ORIGINS": "  "})


def test_production_rejects_wildcard_even_when_mixed_with_explicit_origin():
    with pytest.raises(ValueError, match="Wildcard CORS"):
        cors_origins_from_env({"APP_ENV": "production", "CORS_ORIGINS": "https://app.example.com,*"})


def test_production_accepts_trimmed_explicit_origins():
    assert cors_origins_from_env({"APP_ENV": "production", "CORS_ORIGINS": " https://app.example.com, https://admin.example.com "}) == [
        "https://app.example.com",
        "https://admin.example.com",
    ]


def test_fastapi_server_uses_guarded_origins_and_documents_environment():
    root = Path(__file__).parents[2]
    server = (root / "backend" / "server.py").read_text()
    example = (root / "backend" / ".env.example").read_text()
    assert "cors_origins = cors_origins_from_env(os.environ)" in server
    assert "APP_ENV=development" in example
