from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SERVER = (ROOT / "server.py").read_text()
ADMIN_UI = (ROOT.parent / "frontend/app/admin-earnings.tsx").read_text()
SELLER_UI = (ROOT.parent / "frontend/app/seller-earnings.tsx").read_text()


def route_source(name):
    start = SERVER.find(f"async def {name}(")
    assert start >= 0, f"Missing route function {name}"
    ends = [pos for pos in (SERVER.find("\n@api.", start), SERVER.find("\nasync def ", start + 1), SERVER.find("\ndef ", start + 1)) if pos >= 0]
    end = min(ends) if ends else -1
    return SERVER[start:end if end >= 0 else len(SERVER)]


def test_admin_financial_endpoints_require_server_side_admin_role():
    for name in ("admin_earnings", "admin_earnings_transactions", "admin_earnings_ledger", "admin_platform_bank_account", "save_admin_platform_bank_account", "admin_settlement_list", "admin_settlement_decision", "admin_set_financial_policy"):
        assert 'Depends(require_role("admin"))' in route_source(name)


def test_shopkeeper_earnings_and_bank_routes_check_server_side_ownership():
    earnings = route_source("shopkeeper_earnings")
    assert 'if user.get("role") != "shopkeeper"' in earnings
    assert 'db.shops.find({"owner_id": user["id"]})' in earnings
    assert 'db.restaurants.find({"owner_id": user["id"]})' in earnings
    assert 'if shop_id not in all_ids' in earnings
    assert 'raise HTTPException(status_code=403' in earnings
    assert '_assert_shop_owner(shop, user)' in route_source("get_shop_bank_account")
    assert '_assert_shop_owner(shop, user)' in route_source("save_shop_bank_account")
    assert '_restaurant_owner(restaurant, user)' in route_source("get_restaurant_bank_account")
    assert '_restaurant_owner(restaurant, user)' in route_source("save_restaurant_bank_account")


def test_bank_storage_fails_closed_without_encryption_key_and_never_returns_plaintext():
    assert 'BANK_DATA_ENCRYPTION_KEY' in SERVER
    assert 'Secure bank storage is not configured' in SERVER
    masked = route_source("_masked_bank_account")
    assert 'account_number_masked' in masked
    assert 'account_number_encrypted' not in masked
    assert 'ifsc_encrypted' in route_source("_save_bank_account")


def test_cash_collection_requires_shopkeeper_role_ownership_and_completed_order():
    source = route_source("confirm_manual_cash_collection")
    assert 'if user.get("role") != "shopkeeper"' in source
    assert '_assert_shop_owner(shop, user)' in source
    assert '_restaurant_owner(restaurant, user)' in source
    assert '"delivered", "picked_up"' in source
    assert '"manual_cash_collection_confirmed"' in source


def test_manual_settlement_requires_reference_and_confirmation_to_mark_paid():
    source = route_source("admin_settlement_decision")
    assert 'body.manual_payment_confirmed' in source
    assert 'body.payout_reference' in source
    assert 'No transfer provider is configured' in source
    assert 'idempotency_key' in route_source("request_shop_settlement")
    assert 'settlement_order_allocations.insert_one' in route_source("request_shop_settlement")


def test_frontend_has_separate_admin_and_shopkeeper_earnings_routes():
    assert 'Owner Earnings' in ADMIN_UI
    assert '/admin/earnings' in ADMIN_UI
    assert 'My Shop Earnings' in SELLER_UI
    assert '/earnings/mine' in SELLER_UI
    assert '_record_finalized_order_ledger' in SERVER
    assert '_record_refund_reversal' in SERVER
    assert 'financial_ledger.create_index("idempotency_key", unique=True)' in SERVER
    assert 'bank-account' in SELLER_UI
