from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CHAND = (ROOT / "frontend" / "app" / "chand.tsx").read_text(encoding="utf-8")
TRANSLATIONS = (ROOT / "frontend" / "src" / "i18n" / "translations.ts").read_text(encoding="utf-8")
I18N = (ROOT / "frontend" / "src" / "i18n" / "index.tsx").read_text(encoding="utf-8")


def test_chand_uses_shared_global_language_context_and_persisted_preference():
    assert 'import { useT } from "@/src/i18n"' in CHAND
    assert 'const { lang, t } = useT()' in CHAND
    assert 'LANGUAGE_STORAGE_KEY = "@comein_language_v1"' in I18N
    assert 'storage.setItem(LANGUAGE_STORAGE_KEY, code)' in I18N


def test_core_chand_ui_keys_have_english_hindi_and_punjabi_values():
    keys = [
        "chand.subtitle", "chand.demo", "chand.mode", "chand.role.customer",
        "chand.role.shopkeeper", "chand.role.restaurant", "chand.role.services",
        "chand.input.placeholder", "chand.send", "chand.loading", "chand.disclaimer",
        "chand.help", "chand.help.heading", "chand.noresults", "chand.providerunavailable",
        "chand.provider.note", "chand.results.products", "chand.results.shops",
        "chand.results.restaurants", "chand.results.services", "chand.results.categories",
    ]
    for key in keys:
        assert TRANSLATIONS.count(f"'{key}'") == 3, f"Expected EN/HI/PA translations for {key}"


def test_chand_fetches_live_context_and_does_not_claim_unconfigured_ai_is_live():
    assert '"/assistant/context"' in CHAND
    assert 'COMEIN_AI_API_KEY' not in CHAND
    assert "chand.provider.note" in CHAND
