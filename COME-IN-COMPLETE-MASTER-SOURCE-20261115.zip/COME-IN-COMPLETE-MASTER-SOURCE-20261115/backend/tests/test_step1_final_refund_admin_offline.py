"""Atomic admin post-provider refund persistence; fake-driver tests, not live MongoDB."""
import ast
import asyncio
import copy
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from mongo_transactions import run_transaction
from test_catalogue_transaction_apply_offline import Client, Collection

SOURCE = (Path(__file__).parents[1] / 'server.py').read_text()
TREE = ast.parse(SOURCE)


def setup(ambiguous_commit=False):
    class DB:
        restaurant_payments = Collection()
        restaurant_orders = Collection()
    db = DB()
    db.restaurant_orders.docs = [{'_id': 'o1', 'total': 125, 'payment_status': 'paid', 'refund_status': 'refund_requested'}]
    db.restaurant_payments.docs = [{'_id': 'p1', 'order_id': 'o1', 'status': 'paid', 'refund_status': 'refund_requested'}]
    client = Client(db, ambiguous_commit=ambiguous_commit)
    logger = SimpleNamespace(error=lambda *args: None)
    globals = {'db': db, 'client': client, 'run_transaction': run_transaction,
               'HTTPException': HTTPException, 'now_utc': lambda: 'now', 'logger': logger}
    fn = next(copy.deepcopy(n) for n in TREE.body if isinstance(n, ast.AsyncFunctionDef)
              and n.name == '_persist_restaurant_admin_refund_state')
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])), 'server-helper', 'exec'), globals)
    return db, globals[fn.name]


def call(fn, state='refund_uncertain', payment_fields=None, order_fields=None):
    return asyncio.run(fn('p1', 'o1', state, payment_fields, order_fields))


def test_refund_state_updates_both_documents_in_single_transaction():
    db, fn = setup()
    call(fn, 'refund_pending', {'refund_pending_amount_paise': 12500}, {'refund_pending_amount_paise': 12500})
    assert db.restaurant_payments.docs[0]['refund_status'] == 'refund_pending'
    assert db.restaurant_orders.docs[0]['refund_pending_amount_paise'] == 12500


def test_second_write_failure_rolls_back_first_write():
    db, fn = setup()
    db.restaurant_orders.fail_update = True
    with pytest.raises(HTTPException) as error:
        call(fn)
    assert error.value.status_code == 503
    assert db.restaurant_payments.docs[0]['refund_status'] == 'refund_requested'
    db.restaurant_orders.fail_update = False
    call(fn)
    assert db.restaurant_orders.docs[0]['refund_status'] == 'refund_uncertain'


def test_unknown_commit_is_reconciled_using_both_committed_records():
    db, fn = setup(ambiguous_commit=True)
    call(fn, 'refunded', {'refunded_amount_paise': 12500}, {'refunded_amount_paise': 12500})
    assert db.restaurant_payments.docs[0]['refunded_amount_paise'] == 12500
    assert db.restaurant_orders.docs[0]['refund_status'] == 'refunded'


def test_concurrent_webhook_advance_cannot_be_downgraded_by_admin():
    db, fn = setup()
    db.restaurant_payments.docs[0]['refund_status'] = 'refunded'
    db.restaurant_orders.docs[0]['refund_status'] = 'refunded'
    with pytest.raises(HTTPException) as error:
        call(fn, 'refund_uncertain')
    assert error.value.status_code == 409
    assert db.restaurant_payments.docs[0]['refund_status'] == 'refunded'


def test_missing_payment_order_link_rejects_without_mutations():
    db, fn = setup()
    db.restaurant_payments.docs[0]['order_id'] = 'not-our-order'
    with pytest.raises(HTTPException) as error:
        call(fn)
    assert error.value.status_code == 409
    assert db.restaurant_orders.docs[0]['refund_status'] == 'refund_requested'


def test_refund_route_never_places_provider_call_in_retried_callback():
    route = next(n for n in TREE.body if isinstance(n, ast.AsyncFunctionDef)
                 and n.name == 'admin_refund_restaurant_order')
    source = ast.get_source_segment(SOURCE, route)
    assert '_persist_restaurant_admin_refund_state(' in source
    assert '_apply_restaurant_refund_webhook_transactionally(' in source
    assert 'requests.post(' in source
    for n in ast.walk(TREE):
        if isinstance(n, ast.AsyncFunctionDef) and n.name in {'persist', 'apply'}:
            fragment = ast.get_source_segment(SOURCE, n)
            assert 'requests.post(' not in fragment
