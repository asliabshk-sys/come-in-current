"""Task 21 customer shopping flow source-contract regressions (no live API/DB)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STORE = (ROOT / "frontend/src/store/cart.tsx").read_text()
CARD = (ROOT / "frontend/src/components/ProductCard.tsx").read_text()
DETAIL = (ROOT / "frontend/app/product/[id].tsx").read_text()
CHECKOUT = (ROOT / "frontend/app/checkout.tsx").read_text()
CART_SCREEN = (ROOT / "frontend/app/(tabs)/cart.tsx").read_text()


def test_buy_now_is_an_isolated_checkout_line_and_does_not_replace_persisted_cart():
    assert "buyNowLine: CartLine | null" in STORE
    assert "startBuyNow: (product: Product, variantId: string | undefined, qty: number) => boolean" in STORE
    assert 'product.source !== "live" || !product.shopId' in STORE
    assert "if (isMeasured(product))" in STORE
    assert "amountError(product, qty)" in STORE
    assert "if (qty > 1000) return false" in STORE
    assert "setBuyNowLine({ key: getCartItemKey(product.id, variantId)" in STORE
    assert "const checkoutLines = buyNowLine ? [buyNowLine] : cartLines;" in CHECKOUT
    assert "if (buyNowLine) clearBuyNow();\n      else clear();" in CHECKOUT


def test_product_detail_keeps_variant_identity_and_quantity_controls_connected():
    assert 'variant-option-${variant.id}' in DETAIL
    assert "setSelectedVariantId(variant.id)" in DETAIL
    assert "getQty(product.id, selectedVariant?.id)" in DETAIL
    assert 'onAdd={measured ? () => { addProduct(product); setCartMessage(""); } : addSelectedToCart}' in DETAIL
    assert 'onInc={measured ? () => { increment(product.id, undefined, product); setCartMessage(""); } : incrementSelected}' in DETAIL
    assert 'testID="buy-now-btn"' in DETAIL
    assert "startBuyNow(product, selectedVariant?.id, buyQty)" in DETAIL
    assert "Only ${selectedStock} pack(s) are currently available." in DETAIL


def test_product_card_buy_now_uses_isolated_checkout_and_variants_route_to_detail():
    assert 'startBuyNow(product, undefined, Math.max(1, qty))' in CARD
    assert 'router.push("/checkout")' in CARD
    assert 'router.push(`/product/${product.id}`)' in CARD
    assert 'testID={`buy-now-card-${product.id}`}' in CARD


def test_checkout_quotes_only_the_selected_buy_now_line_or_normal_cart_lines():
    assert "items: checkoutLines.map((line) => ({ product_id: line.product.id, variant_id: line.variant?.id, qty: line.qty }))" in CHECKOUT
    assert "const cartFingerprint = JSON.stringify(checkoutLines.map" in CHECKOUT
    assert "quote_token: quote.quote_token" in CHECKOUT
    assert 'fulfillment === "pickup" ? 0 : deliveryFee' in CHECKOUT
    assert "idempotency_key: idempotencyKey" in CHECKOUT
    assert "Your cart has been preserved." in CHECKOUT


def test_existing_cart_variant_identity_and_checkout_error_handling_remain_present():
    assert 'key={line.key}' in CART_SCREEN
    assert "increment(line.product.id, line.variant?.id)" in CART_SCREEN
    assert "decrement(line.product.id, line.variant?.id)" in CART_SCREEN
    assert 'detail?.code === "insufficient_stock"' in CHECKOUT
    assert 'detail?.code === "stock_changed"' in CHECKOUT
    assert "current >= 1000" in STORE
    assert "line.qty >= 1000" in CART_SCREEN
    assert "Only ${available} pack(s) are currently available." in CART_SCREEN
