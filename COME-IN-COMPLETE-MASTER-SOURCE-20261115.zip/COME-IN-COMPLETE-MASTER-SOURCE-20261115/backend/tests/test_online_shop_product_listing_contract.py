"""Source-level regression contracts for Online Shop product listings.

These tests intentionally avoid importing server.py because the full runtime
requires deployment secrets, bcrypt and a live MongoDB configuration.
"""
from pathlib import Path

ROOT = Path(__file__).parents[2]
SERVER = (ROOT / "backend/server.py").read_text()
SELLER_UI = (ROOT / "frontend/app/seller/products.tsx").read_text()
PRODUCT_CARD = (ROOT / "frontend/src/components/ProductCard.tsx").read_text()
PRODUCT_DETAIL = (ROOT / "frontend/app/product/[id].tsx").read_text()
CATALOG_HOOK = (ROOT / "frontend/src/data/useCatalogProducts.ts").read_text()


def test_product_api_requires_positive_price_category_and_description():
    schema = SERVER.split("class ProductIn(BaseModel):", 1)[1].split("# Orders", 1)[0]
    assert 'price: float = Field(gt=0, le=100000000)' in schema
    assert 'category_id: str = Field(min_length=1, max_length=40)' in schema
    assert 'description: str = Field(min_length=1, max_length=1200)' in schema
    assert 'Product name is required' in schema
    assert 'Product category is required' in schema
    assert 'Product description is required' in schema
    assert 'MRP cannot be less than selling price' in schema


def test_pending_shop_products_are_private_but_owner_can_manage_drafts():
    route = SERVER.split('@api.get("/shops/{shop_id}/products")', 1)[1].split('@api.get("/catalog/products")', 1)[0]
    assert 'Depends(get_current_user_optional)' in route
    assert 'shop.get("status") != "approved"' in route
    assert 'shop.get("owner_id") != user.get("id")' in route
    assert 'detail="Shop not available"' in route


def test_public_catalog_only_uses_approved_shop_records_and_eligible_stock():
    route = SERVER.split('@api.get("/catalog/products")', 1)[1].split('@api.patch("/products/{product_id}")', 1)[0]
    assert 'db.shops.find({"status": "approved"})' in route
    assert '"available": True' in route
    assert '"stock": {"$gt": 0}' in route
    assert 'row["shop_name"] = shop.get("name", "")' in route
    assert 'row.pop("owner_id", None)' in route


def test_seller_form_explains_price_and_requires_valid_listing_fields():
    assert 'Description / Why is this product priced this way?' in SELLER_UI
    assert 'genuine reason the price may be lower or higher' in SELLER_UI
    assert 'हम सीधे निर्माता से सामान खरीदते हैं' in SELLER_UI
    assert '!editing.category_id.trim()' in SELLER_UI
    assert '!editing.description.trim()' in SELLER_UI
    assert 'editing.price <= 0' in SELLER_UI
    assert 'uploadImage' in SELLER_UI
    assert 'api.patch<Product>(`/products/${editing.id}`' in SELLER_UI
    assert 'api.post<Product>(`/shops/${shopId}/products`' in SELLER_UI


def test_customer_catalog_shows_saved_description_and_full_detail_uses_text_rendering():
    assert 'description: String(row.description || "")' in CATALOG_HOOK
    assert 'product.description?.trim()' in PRODUCT_CARD
    assert 'numberOfLines={2}' in PRODUCT_CARD
    assert 'style={styles.description}>{product.description}</Text>' in PRODUCT_DETAIL
    # React Native Text rendering is used; no HTML injection renderer is introduced.
    assert 'dangerouslySetInnerHTML' not in PRODUCT_DETAIL


def test_checkout_price_is_resolved_server_side_not_from_client_snapshot():
    assert 'ignored; server resolves authoritative price' in SERVER
    assert 'price: Optional[float] = Field(default=None, ge=0)' in SERVER
