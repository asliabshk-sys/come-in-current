from restaurant_serviceability import check_restaurant_serviceability, configured_pincodes, normalize_pincode


def test_pincode_normalization_accepts_only_six_digit_indian_pincodes():
    assert normalize_pincode(" 110001 ") == "110001"
    assert normalize_pincode("000001") is None
    assert normalize_pincode("1234") is None
    assert normalize_pincode("12A456") is None
    assert normalize_pincode(None) is None


def test_missing_coverage_fails_closed_without_fabricating_radius():
    result = check_restaurant_serviceability({"delivery_available": True}, "110001")
    assert result["status"] == "unconfigured"
    assert result["serviceable"] is False


def test_explicit_configured_pincode_controls_delivery_eligibility():
    restaurant = {"delivery_available": True, "delivery_serviceable_pincodes": ["110001", "110002"]}
    assert check_restaurant_serviceability(restaurant, "110001")["serviceable"] is True
    assert check_restaurant_serviceability(restaurant, "110003")["status"] == "outside_configured_area"
    assert check_restaurant_serviceability(restaurant, "bad")["status"] == "invalid_address"


def test_delivery_disabled_overrides_configured_coverage():
    restaurant = {"delivery_available": False, "delivery_serviceable_pincodes": ["110001"]}
    assert check_restaurant_serviceability(restaurant, "110001")["status"] == "unavailable"


def test_configured_coverage_discards_invalid_legacy_values():
    assert configured_pincodes({"delivery_serviceable_pincodes": ["110001", "bad"]}) == {"110001"}
