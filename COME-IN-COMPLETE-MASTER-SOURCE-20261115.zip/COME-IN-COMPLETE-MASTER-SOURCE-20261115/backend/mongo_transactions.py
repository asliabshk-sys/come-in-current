"""Small, conservative MongoDB transaction error classifiers."""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any


def has_transaction_error_label(error: BaseException, label: str) -> bool:
    """Return a driver error label without relying on exception class names/codes."""
    checker = getattr(error, "has_error_label", None)
    if not callable(checker):
        return False
    try:
        return bool(checker(label))
    except Exception:
        return False


async def proven_insufficient_stock_conflict(
    transaction_error: BaseException,
    fresh_stock_check: Callable[[], Awaitable[Any]],
) -> BaseException | None:
    """Return an HTTP/business error only when a labeled transient abort is followed
    by a fresh read that explicitly proves insufficient stock. Any diagnostic failure
    is inconclusive and therefore returns None (the caller keeps the infrastructure 503).
    """
    if not has_transaction_error_label(transaction_error, "TransientTransactionError"):
        return None
    try:
        await fresh_stock_check()
    except Exception as check_error:
        detail = getattr(check_error, "detail", None)
        code = detail.get("code") if isinstance(detail, dict) else None
        if getattr(check_error, "status_code", None) == 409 and code == "insufficient_stock":
            return check_error
    return None


async def run_transaction(client: Any, callback: Callable[[Any], Awaitable[Any]]) -> Any:
    """Use the Motor/PyMongo transaction manager for driver-managed retries.

    Callbacks MUST contain only session-bound database operations and MUST be
    safe to re-execute: the driver can retry the whole callback on transient
    transaction errors or retry commit on UnknownTransactionCommitResult.
    There is intentionally no DIY unbounded retry loop or provider API call.
    """
    async with await client.start_session() as session:
        return await session.with_transaction(callback)
