"""Fail-closed restaurant delivery serviceability using explicitly configured pincodes.

This deliberately does not geocode addresses or invent delivery radii. A restaurant
owner/admin must configure verified six-digit Indian postal pincodes before delivery
can be confirmed. Coordinates alone are not treated as proof of coverage.
"""
import re
from typing import Any

PINCODE_RE = re.compile(r"^[1-9][0-9]{5}$")


def normalize_pincode(value: Any) -> str | None:
    if value is None:
        return None
    candidate = re.sub(r"\s+", "", str(value))
    return candidate if PINCODE_RE.fullmatch(candidate) else None


def configured_pincodes(restaurant: dict) -> set[str]:
    values = restaurant.get("delivery_serviceable_pincodes") or []
    return {normalized for value in values if (normalized := normalize_pincode(value))}


def check_restaurant_serviceability(restaurant: dict, pincode: Any) -> dict:
    normalized = normalize_pincode(pincode)
    if not restaurant.get("delivery_available", False):
        return {"status": "unavailable", "serviceable": False, "reason": "Restaurant delivery is disabled."}
    coverage = configured_pincodes(restaurant)
    if not coverage:
        return {"status": "unconfigured", "serviceable": False,
                "reason": "This restaurant has not configured verified delivery pincodes."}
    if not normalized:
        return {"status": "invalid_address", "serviceable": False,
                "reason": "A valid six-digit delivery pincode is required."}
    if normalized not in coverage:
        return {"status": "outside_configured_area", "serviceable": False,
                "reason": "This pincode is outside the restaurant's configured delivery area."}
    return {"status": "serviceable", "serviceable": True,
            "reason": "Pincode matches the restaurant's configured delivery coverage."}
