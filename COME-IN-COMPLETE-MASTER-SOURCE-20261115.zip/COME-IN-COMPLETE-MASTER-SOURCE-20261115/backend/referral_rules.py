"""Pure, dependency-free policy helpers for COME-IN Referral & Earn."""
import re
import secrets
from typing import Any

REFERRAL_TARGET = 10
REFERRAL_REWARD_INR = 500.0
REFERRAL_MIN_ORDER_INR = 100.0
REFERRAL_CODE_PATTERN = re.compile(r"COME[A-F0-9]{10}\Z")


def new_referral_code() -> str:
    """Create a random, non-PII referral identifier."""
    return "COME" + secrets.token_hex(5).upper()


def normalize_referral_code(code: str) -> str:
    return (code or "").strip().upper()


def valid_referral_code_format(code: str) -> bool:
    return bool(REFERRAL_CODE_PATTERN.fullmatch(normalize_referral_code(code)))


def order_is_referral_candidate(order: dict[str, Any]) -> bool:
    """A delivered >=₹100 order is only a review candidate, never auto-qualified."""
    try:
        total = float(order.get("total", 0) or 0)
    except (TypeError, ValueError):
        return False
    status = str(order.get("status", "")).lower()
    payment_status = str(order.get("payment_status", "")).lower()
    blocked_payment_states = {"refunded", "refund_pending", "disputed", "failed", "cancelled"}
    if total < REFERRAL_MIN_ORDER_INR or status != "delivered" or payment_status in blocked_payment_states:
        return False
    for field in ("refund_status", "return_status", "dispute_status"):
        state = str(order.get(field, "") or "").strip().lower()
        if state and state not in {"none", "not_requested", "not_applicable", "clear", "passed"}:
            return False
    return True


def reward_threshold_reached(eligible_count: int) -> bool:
    return int(eligible_count) >= REFERRAL_TARGET


def shopping_reward_discount(order_total: float, available_balance: float) -> float:
    """Apply only a nonnegative, available reward balance and never exceed checkout total."""
    try:
        total = max(0.0, float(order_total))
        balance = max(0.0, float(available_balance))
    except (TypeError, ValueError):
        return 0.0
    return round(min(total, balance), 2)
