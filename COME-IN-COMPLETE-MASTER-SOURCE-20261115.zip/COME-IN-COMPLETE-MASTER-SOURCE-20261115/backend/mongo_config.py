"""Validated MongoDB client settings shared by the FastAPI backend.

This module deliberately never includes the connection URI or credentials in errors.
"""
from __future__ import annotations

import re
from urllib.parse import parse_qs, urlsplit


DEFAULTS = {
    "MONGO_MAX_POOL_SIZE": (50, 1, 500),
    "MONGO_MIN_POOL_SIZE": (0, 0, 100),
    "MONGO_MAX_CONNECTING": (4, 1, 50),
    "MONGO_SERVER_SELECTION_TIMEOUT_MS": (8000, 1000, 120000),
    "MONGO_CONNECT_TIMEOUT_MS": (5000, 1000, 120000),
    "MONGO_SOCKET_TIMEOUT_MS": (20000, 1000, 300000),
    "MONGO_WAIT_QUEUE_TIMEOUT_MS": (10000, 1000, 120000),
}


def _bounded_int(env: dict, key: str) -> int:
    default, minimum, maximum = DEFAULTS[key]
    raw = env.get(key)
    try:
        value = default if raw in (None, "") else int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{key} must be an integer") from exc
    if not minimum <= value <= maximum:
        raise ValueError(f"{key} must be between {minimum} and {maximum}")
    return value


def mongo_client_configuration(env: dict | None = None) -> tuple[str, str, dict]:
    """Validate DB target and return (URI, database name, PyMongo/Motor options)."""
    env = env if env is not None else __import__("os").environ
    uri = (env.get("MONGO_URL") or "").strip()
    db_name = (env.get("DB_NAME") or "").strip()
    app_env = (env.get("APP_ENV") or "").strip().lower()

    if not uri:
        raise ValueError("MONGO_URL is required")
    if not db_name:
        raise ValueError("DB_NAME is required")
    if not app_env:
        raise ValueError("APP_ENV is required; select development, test, staging, or production explicitly")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,63}", db_name):
        raise ValueError("DB_NAME contains unsupported characters or is too long")
    if db_name.lower() in {"admin", "local", "config"}:
        raise ValueError("DB_NAME cannot target a MongoDB system database")
    if app_env not in {"development", "test", "staging", "production"}:
        raise ValueError("APP_ENV must be development, test, staging, or production")

    parsed = urlsplit(uri)
    if parsed.scheme not in {"mongodb", "mongodb+srv"} or not parsed.hostname:
        raise ValueError("MONGO_URL must be a valid mongodb:// or mongodb+srv:// URI")

    expected = (env.get("MONGO_EXPECTED_DB_NAME") or "").strip()
    if expected and expected != db_name:
        raise ValueError("DB_NAME does not match MONGO_EXPECTED_DB_NAME")
    if app_env == "production" and not expected:
        raise ValueError("MONGO_EXPECTED_DB_NAME is required in production")

    query = {key.lower(): values[-1].lower() for key, values in parse_qs(parsed.query).items() if values}
    uri_tls = query.get("tls", query.get("ssl"))
    explicit_tls = (env.get("MONGO_TLS") or "").strip().lower()
    if explicit_tls and explicit_tls not in {"true", "false", "1", "0", "yes", "no"}:
        raise ValueError("MONGO_TLS must be a boolean")
    uri_tls_enabled = parsed.scheme == "mongodb+srv" or uri_tls in {"true", "1", "yes"}
    if explicit_tls:
        explicit_tls_enabled = explicit_tls in {"true", "1", "yes"}
        if parsed.scheme == "mongodb+srv" and not explicit_tls_enabled:
            raise ValueError("MONGO_TLS cannot disable TLS for mongodb+srv URIs")
        if uri_tls is not None and explicit_tls_enabled != (uri_tls in {"true", "1", "yes"}):
            raise ValueError("MONGO_TLS conflicts with the TLS setting in MONGO_URL")
        tls_enabled = explicit_tls_enabled
    else:
        tls_enabled = uri_tls_enabled
    if app_env == "production" and not tls_enabled:
        raise ValueError("MongoDB TLS is required in production")
    if app_env == "production" and (query.get("tlsallowinvalidcertificates") in {"true", "1", "yes"} or query.get("tlsinsecure") in {"true", "1", "yes"}):
        raise ValueError("Insecure MongoDB TLS certificate validation is forbidden in production")

    max_pool = _bounded_int(env, "MONGO_MAX_POOL_SIZE")
    min_pool = _bounded_int(env, "MONGO_MIN_POOL_SIZE")
    if min_pool > max_pool:
        raise ValueError("MONGO_MIN_POOL_SIZE cannot exceed MONGO_MAX_POOL_SIZE")

    options = {
        "maxPoolSize": max_pool,
        "minPoolSize": min_pool,
        "maxConnecting": _bounded_int(env, "MONGO_MAX_CONNECTING"),
        "serverSelectionTimeoutMS": _bounded_int(env, "MONGO_SERVER_SELECTION_TIMEOUT_MS"),
        "connectTimeoutMS": _bounded_int(env, "MONGO_CONNECT_TIMEOUT_MS"),
        "socketTimeoutMS": _bounded_int(env, "MONGO_SOCKET_TIMEOUT_MS"),
        "waitQueueTimeoutMS": _bounded_int(env, "MONGO_WAIT_QUEUE_TIMEOUT_MS"),
        "retryReads": True,
        "retryWrites": True,
        "tz_aware": True,
    }
    if explicit_tls in {"true", "1", "yes"}:
        options["tls"] = True
    elif explicit_tls in {"false", "0", "no"}:
        options["tls"] = False
    return uri, db_name, options
