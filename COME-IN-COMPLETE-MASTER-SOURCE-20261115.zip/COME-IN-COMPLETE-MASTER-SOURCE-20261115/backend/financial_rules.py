"""Pure money/date helpers for COME-IN earnings reports.

Money is calculated with Decimal from stringified stored values; callers must
still distinguish unavailable commission policy from a configured 0% rate.
"""
from datetime import datetime, date, time, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from zoneinfo import ZoneInfo

CENT = Decimal("0.01")


def money(value) -> Decimal:
    try:
        result = Decimal(str(value if value is not None else "0"))
        if not result.is_finite():
            raise InvalidOperation
        return result.quantize(CENT, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Invalid monetary value")


def money_str(value) -> str:
    return format(money(value), ".2f")


def parse_date_range(start: str | None, end: str | None, tz_name: str = "Asia/Kolkata", now: datetime | None = None):
    """Return inclusive local start and exclusive local end, both UTC-aware."""
    try:
        tz = ZoneInfo(tz_name)
    except Exception as exc:
        raise ValueError("Invalid timezone") from exc
    local_now = (now or datetime.now(timezone.utc)).astimezone(tz)
    start_day = date.fromisoformat(start) if start else local_now.date()
    end_day = date.fromisoformat(end) if end else start_day
    if end_day < start_day:
        raise ValueError("End date must be on or after start date")
    start_local = datetime.combine(start_day, time.min, tzinfo=tz)
    end_local = datetime.combine(end_day + timedelta(days=1), time.min, tzinfo=tz)
    return start_local.astimezone(timezone.utc), end_local.astimezone(timezone.utc), tz.key


def order_financials(order: dict, policy: dict | None, order_kind: str) -> dict:
    """Return source-grounded financial breakdown; never invent missing policy."""
    subtotal = money(order.get("subtotal", order.get("items_subtotal", 0)))
    delivery = money(order.get("delivery_fee", 0))
    tax = money(order.get("tax", 0))
    status = str(order.get("status", "unknown")).lower()
    payment_status = str(order.get("payment_status", "unknown")).lower()
    refund_status = str(order.get("refund_status", "") or "").lower()
    delivered = status in {"delivered", "picked_up"}
    cancelled = status in {"cancelled", "canceled", "rejected"}
    refunded = refund_status in {"succeeded", "completed", "refunded", "processed"} or payment_status == "refunded"
    unresolved_refund = refund_status not in {"", "none", "not_requested", "not_applicable", "failed", "rejected", "cancelled"}
    return_status = str(order.get("return_status", "") or "").lower()
    dispute_status = str(order.get("dispute_status", "") or "").lower()
    unresolved_return = return_status not in {"", "none", "not_requested", "not_applicable", "rejected", "cancelled", "closed_without_refund"}
    unresolved_dispute = dispute_status not in {"", "none", "closed", "resolved", "not_applicable"}
    payment_confirmed = payment_status in {"paid", "succeeded", "captured", "cash_collected", "cod_collected", "pay_at_pickup_paid"}
    # Never apply a newly configured policy retroactively to older orders. The
    # current schema has no immutable per-order fee snapshot, so historical orders
    # before the policy timestamp remain explicitly unavailable for final payable.
    policy_timestamp = (policy or {}).get("financial_policy_updated_at")
    order_timestamp = order.get("created_at")
    policy_applies = bool(policy and policy_timestamp and order_timestamp)
    if policy_applies:
        if getattr(policy_timestamp, "tzinfo", None) is None:
            policy_timestamp = policy_timestamp.replace(tzinfo=timezone.utc)
        if getattr(order_timestamp, "tzinfo", None) is None:
            order_timestamp = order_timestamp.replace(tzinfo=timezone.utc)
        policy_applies = order_timestamp.astimezone(timezone.utc) >= policy_timestamp.astimezone(timezone.utc)
    rate = None if not policy_applies or policy.get("commission_rate_percent") is None else money(policy["commission_rate_percent"])
    commission = None if rate is None else money(subtotal * rate / Decimal("100"))
    fee = money(policy.get("platform_service_fee_inr", 0)) if policy_applies else Decimal("0.00")
    fee_configured = bool(policy_applies and policy.get("platform_service_fee_inr") is not None)
    delivery_beneficiary = (policy or {}).get("delivery_fee_beneficiary") if policy_applies else None
    platform_delivery = delivery if delivery_beneficiary == "platform" else Decimal("0.00") if delivery_beneficiary in {"shopkeeper", "third_party", "not_applicable"} else None
    eligible = delivered and not cancelled and payment_confirmed and not refunded and not unresolved_refund and not unresolved_return and not unresolved_dispute and not bool(order.get("payment_reconciliation_required"))
    if refunded:
        commission_reversal = commission if commission is not None else None
        payable = Decimal("0.00")
    elif eligible and commission is not None:
        commission_reversal = Decimal("0.00")
        shopkeeper_delivery = delivery if delivery_beneficiary == "shopkeeper" else Decimal("0.00")
        payable = max(Decimal("0.00"), subtotal + shopkeeper_delivery - commission - fee)
    else:
        commission_reversal = Decimal("0.00") if commission is not None else None
        payable = None
    return {
        "order_id": str(order.get("_id", order.get("id", ""))),
        "order_ref": order.get("ref") or str(order.get("_id", order.get("id", ""))),
        "order_kind": order_kind,
        "status": status,
        "payment_status": payment_status,
        "payment_method": str(order.get("payment_method", "unknown")).lower(),
        "refund_status": refund_status or "not_recorded",
        "created_at": order.get("created_at"),
        "currency": order.get("currency", "INR"),
        "gross_merchandise": float(subtotal),
        "delivery_fee": float(delivery),
        "tax": float(tax),
        "commission_rate_percent": float(rate) if rate is not None else None,
        "commission": float(commission) if commission is not None else None,
        "platform_service_fee": float(fee) if fee_configured else None,
        "platform_delivery_fee": float(platform_delivery) if platform_delivery is not None else None,
        "commission_reversal": float(commission_reversal) if commission_reversal is not None else None,
        "platform_earnings": float((commission or Decimal("0")) + (fee if fee_configured else Decimal("0")) + (platform_delivery or Decimal("0"))) if eligible and commission is not None and fee_configured and platform_delivery is not None else None,
        "shopkeeper_payable": float(payable) if payable is not None else None,
        "eligible_completed_sale": bool(eligible),
        "financial_state": "refunded" if refunded else "cancelled" if cancelled else "pending_review" if unresolved_refund or unresolved_return or unresolved_dispute else "finalized" if eligible and payable is not None else "pending_calculation",
        "policy_available": commission is not None and fee_configured and platform_delivery is not None,
    }
