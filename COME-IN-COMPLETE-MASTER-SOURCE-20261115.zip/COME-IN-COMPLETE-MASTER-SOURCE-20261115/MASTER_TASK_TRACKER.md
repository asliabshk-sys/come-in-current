# COME-IN — Master Task Tracker (Codex continuation view, 2026-11-14)

Canonical detailed tracker (unchanged history): `COME_IN_MASTER_TASK_TRACKER.md` / `.json` / `.xlsx`.
This file consolidates current status and adds the 2026-11-14 verification evidence. Status changes only where new evidence exists.

## 22-task roadmap
| # | Task | Status | Evidence (latest) | Remaining |
|---:|---|---|---|---|
| 1 | Existing Project Audit | COMPLETED | Historical audit; 2026-11-14 discovery audit `reports/audit/` | – |
| 2 | Theme and Design | COMPLETED | THEME reports in `project-reports/` | Device visual check |
| 3 | Home Screen and Navigation | COMPLETED | Source + historical UI E2E | KI-1/KI-2 contract drift (owner decision) |
| 4 | Categories and Catalog | COMPLETED | Live e2e PASS 2026-11-14 | – |
| 5 | Quantity, Variants and Units (Fixed-Pack + Measured) | COMPLETED (preview scope) | T5 live Mongo 9/9 PASS 2026-11-11 and again 2026-11-14 | Native device check |
| 6 | Search and Filters | COMPLETED | Historical | KI search relevance ("atta") |
| 7 | Cart and Checkout | COMPLETED | Live checkout PASS 2026-11-14 | – |
| 8 | Repeat Order | COMPLETED | Measured repeat order live PASS 2026-11-14 | – |
| 9 | Out-of-Stock Replacement | COMPLETED | Historical TASK25 | – |
| 10 | Live Tracking | COMPLETED | Live e2e tracking PASS 2026-11-14 | – |
| 11 | Order Help and Refund Status | PARTIAL | Offline tests PASS | Automatic Grocery provider refunds, refund notifications |
| 12 | Excel/CSV Price and Stock Import | COMPLETED | Transaction-backed import apply/rollback live PASS 2026-11-14 | – |
| 13 | Login and Account | COMPLETED | Live login/register PASS | OTP login not implemented |
| 14 | Seller/Shop/Restaurant Panel | COMPLETED | Live seller/restaurant flows PASS | TS errors in seller/products.tsx |
| 15 | Admin Panel | COMPLETED | Live admin flows PASS | – |
| 16 | Backend, Database and Security | PARTIAL | Prod CORS guard, rate limits; backup/restore drill PASS 2026-11-14 (preview DB) | SMTP, OTP, logout-all, external audit |
| 17 | Payments and Notifications | PARTIAL | Razorpay gated | Razorpay TEST keys, native payment sheet, push |
| 18 | Testing and Bug Fixes | PARTIAL | 2026-11-14: 70/70 live, 408/415 offline, web build PASS | 29 TS errors, 54 lint errors, 3 offline failures, device E2E |
| 19 | Production Build and Launch | BLOCKED | – | Owner approval, production secrets, deployment |
| 20 | Smart Notification System | PARTIAL | In-app 12/12 live PASS 2026-11-14 | Push (Firebase + native build) |
| 21 | Smart Price Comparison | PARTIAL | Source + UI | Linked-master live data, distance source |
| 22 | Home Services Logo/Icon and Tile | COMPLETED | Historical | – |

Note: the summary table at the top of `COME_IN_MASTER_TASK_TRACKER.md` still lists Task 5 as PARTIAL while its row says COMPLETED; this file treats Task 5 as COMPLETED (preview scope) based on the live evidence.

## Add-on modules
| Module | Status | Next step |
|---|---|---|
| Chand AI (Phases 2–5) | PARTIAL | Configure `COMEIN_AI_*` provider in a non-production env; verify chat/STT/vision |
| Universal Catalogue Import | PARTIAL | NT-1, then NT-2 (transactional apply) |
| Delivery Partner onboarding | PARTIAL | Select authorized OTP / Aadhaar / PAN / document-storage providers (owner decision) |

## Next tasks (in order)
| ID | Task | Files | Gate |
|---|---|---|---|
| NT-1 | Fix CSV delimiter sniffing in catalogue import engine | `backend/catalogue_import_engine.py`, `backend/tests/test_universal_catalogue_import_engine.py` | offline suite 409+ pass |
| NT-2 | Transactional catalogue-import apply (no product writes today) | `backend/server.py` (~1978–2243), `backend/catalogue_import_engine.py`, tests | live tests on disposable replica set |
| NT-3 | Fix 29 TypeScript errors without visual change | see `reports/testing/frontend-typecheck-2026-11-14.log` | `yarn typecheck` PASS |
| NT-4 | Fix 54 lint errors (non-visual) | `reports/testing/frontend-lint-2026-11-14.log` | `yarn lint` PASS |
| NT-5 | Update legacy `backend/tests/backend_test.py` to current product/auth contracts | `backend/tests/backend_test.py` | live PASS |
| NT-6 | Owner decision on KI-1/KI-2 Home contract drift | `frontend/app/(tabs)/index.tsx`, `backend/tests/test_frontend_contracts.py` | owner authorization required |

---
## Dedicated MongoDB completion mission — 2026-11-14

This is a database infrastructure workstream, not a new application roadmap task. Status is **PARTIAL / NOT PRODUCTION READY**.

| Area | Status | Evidence / remaining gate |
|---|---|---|
| Mongo connection config and startup topology | PARTIAL | Config validation and startup checks implemented; no live connection in current workspace |
| Index source inventory | COMPLETE | 65 declarations across all FastAPI startup handlers (59 + 6); 50 application collections |
| Index init/drift/restore tooling | PARTIAL | Offline tests pass; live DB verification and duplicate preflight not run |
| Transaction session propagation | PARTIAL | 11 transaction scopes statically audited; offline session contract passes; live retry/concurrency tests blocked |
| Grocery payment/order atomicity | PARTIAL | Capture writes now share transaction; no live callback-race test |
| Restaurant payment/webhook/refund atomicity | PARTIAL | Compare-and-set/idempotency controls exist; multi-document updates need live fault-injection and reconciliation review |
| Schema validators | BLOCKED | Collection plan created; no live document profiling, so no persistent validator installed |
| Universal Catalogue Import final Product/stock apply | BLOCKED | Newer Emergent source/report not available; current source only stages `APPLY_PENDING_EMERGENT` |
| Financial/stock integrity scan | BLOCKED | Requires read-only access to disposable clone; no live DB service available |
| Backup/restore | PARTIAL | Sanitized archive checksum verified; restore script hardened; independent restore not rerun |
| Security/production operations | PARTIAL | TLS/DB target guard and URI redaction implemented; least privilege, network, key rotation and production recovery remain unverified |
| Live MongoDB acceptance | BLOCKED | mongod, mongosh, MongoDB tools, Motor and PyMongo unavailable in current workspace |

Offline targeted regression: 92 passed. Full evidence and exact commands: `reports/MONGODB_FINAL_TEST_EVIDENCE.md`. Do not start another COME-IN roadmap task until this matrix is reviewed and external blockers are resolved.
