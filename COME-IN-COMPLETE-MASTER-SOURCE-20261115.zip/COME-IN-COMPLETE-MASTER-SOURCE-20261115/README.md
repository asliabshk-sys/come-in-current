> ## ▶ Codex / new developers: start with [`CODEX_START_HERE.md`](CODEX_START_HERE.md), then [`CODEX_HANDOFF.md`](CODEX_HANDOFF.md), [`PROJECT_MANIFEST.json`](PROJECT_MANIFEST.json) and [`MASTER_TASK_TRACKER.md`](MASTER_TASK_TRACKER.md).
> This folder (`COME-IN-MASTER-PROJECT/`) is the single project root of the existing COME-IN app. Frontend: `frontend/` · Backend: `backend/` · MongoDB: `backend/.env` + `scripts/mongo/` + `infra/mongodb/`.
> Status below this banner is historical; current status lives in `PROJECT_STATUS.md` (2026-11-14).

# COME-IN — Existing App (Portable Preview Package)

This ZIP contains the existing COME-IN Expo Router frontend and FastAPI backend. It is a source package, not a compiled app or a promise that all external integrations are configured. The original logo, screens, routing, theme, and application modules are preserved; this preparation focuses on import/run instructions and dependency-startup clarity.

## Project structure

- `frontend/` — Expo SDK / Expo Router / React Native Web application.
- `backend/` — FastAPI APIs, MongoDB Motor integration, authentication, and backend tests.
- `scripts/replit-install.sh` — installs using the frontend's declared Yarn package manager and `backend/requirements.txt`.
- `scripts/replit-run.sh` — existing Replit workflow; starts Expo Web and starts the API only when required backend Secrets are present.
- `scripts/preview.sh` — one-command, frontend-only cloud-workspace preview launcher; checks prerequisites, installs with the declared Yarn/Corepack manager if needed, then starts Expo Web. It does not start a fake backend or enable paid integrations.
- `.replit` — existing Replit Run workflow and port mappings.
- `.env.example` — safe placeholders only; do not use the sample secret in a real environment.
- `IMPLEMENTATION_STATUS.md` and test reports — documented scope and limitations.

## Prerequisites

- Node.js compatible with the Expo SDK in `frontend/package.json`; Corepack or Yarn 1.22.22.
- Python compatible with `backend/requirements.txt`.
- Network access to the configured npm/Yarn and Python package registries for a first install.
- MongoDB and backend secrets only for API-backed features; the frontend can start without backend configuration.

## Replit: import and Preview

1. Import/upload this ZIP so that `.replit`, `frontend/`, `backend/`, and `scripts/` are at the project root (the ZIP has one `COME-IN/` top-level folder; if the importer opens that folder as the project root, use it directly).
2. In the Replit Shell, run once:

   ```bash
   bash ./scripts/replit-install.sh
   ```

3. Press **Run**. The configured command is `bash ./scripts/replit-run.sh`.
4. Open the workspace's **Preview** for the frontend port 3000 (configured external port 80). Do not use a public Deployment URL as a substitute for the development Preview.
5. Backend/API features need `MONGO_URL`, `DB_NAME`, and a unique `JWT_SECRET` in Replit Secrets. Set `EXPO_PUBLIC_BACKEND_URL` to the externally reachable backend origin before starting Expo if browser API requests are required. `localhost:8000` is generally not reachable from a browser on a separate device/workspace origin.

## Emergent: import and Preview

1. Import the updated ZIP/source into an existing supported development workspace and open the extracted project root (the directory containing `frontend/`, `backend/`, and `scripts/`).
2. Run this single command in the workspace terminal:

   ```bash
   bash ./scripts/preview.sh
   ```

3. Open the workspace's Preview for the port shown in the log (default `3000`). The command uses the existing Expo Router frontend. It will resolve dependencies only if Expo is not installed, using the package manager already declared by the project.
4. Main route: `/`; Restaurant Mode: `/restaurant`; CHAND UI: `/chand`. These are existing source routes; successful browser rendering still needs to be confirmed in the target workspace. CHAND is explicitly Demo Mode unless its actual AI service is configured.
5. This frontend-only preview does not start a backend, perform real checkout/payment, or claim live GPS/tracking. For API-backed behavior, separately configure the existing backend and browser-reachable `EXPO_PUBLIC_BACKEND_URL`.

Platform-specific auto-run settings differ, so this package provides a real portable startup script rather than assuming an undocumented Emergent auto-start field. If Emergent has a workspace startup-command setting, set it to `bash ./scripts/preview.sh`; otherwise run that one command in its terminal.

### Existing Replit workflow

The existing `.replit` configuration remains unchanged. It runs `bash ./scripts/replit-run.sh`; use `bash ./scripts/replit-install.sh` first if dependencies are not installed. The Replit port mapping is not assumed to apply to Emergent.

## Local development commands

Install both sides:

```bash
bash ./scripts/replit-install.sh
```

Frontend-only cloud preview (recommended):

```bash
bash ./scripts/preview.sh
```

Direct frontend command after dependencies are installed:

```bash
cd frontend && yarn preview
```

Backend (requires environment variables and MongoDB):

```bash
cd backend && python -m uvicorn server:app --host 0.0.0.0 --port 8000
```

Backend tests (from project root):

```bash
cd backend && PYTHONPATH=. python -m pytest -c /dev/null -q tests
```

## Environment variables and service requirements

- Required to start the backend: `MONGO_URL`, `DB_NAME`, and a unique `JWT_SECRET`. The backend does not use a fake database when these are absent.
- Required for browser-to-backend calls: `EXPO_PUBLIC_BACKEND_URL` must point to a reachable backend origin and be set before Expo builds the client bundle.
- Optional integrations: SMTP settings for password reset email; Razorpay keys and webhook configuration for payment integration; `EMERGENT_LLM_KEY` for the existing object-storage integration described by the source. Each external service must be configured and tested separately.
- Do not put real credentials in `.env.example`, commit a real `.env`, or include private database contents in a backup.

## Troubleshooting

- **Registry/DNS failure:** if install reports `Could not resolve host`, `EAI_AGAIN`, or a package index connection error, stop retrying. Verify registry access from the target workspace; a DNS error in a different environment does not prove the target platform has the same problem.
- **Yarn/Corepack missing:** use a workspace image that includes Node.js/Corepack or install the declared Yarn version through the platform's supported package-manager mechanism.
- **Preview 404 / no previewable artifacts:** open the active development workspace's Preview, not a deployment URL. Confirm the Expo process is running and the workspace Preview is targeting frontend port 3000.
- **Port not reachable:** confirm the frontend logs show Expo started on port 3000 and configure the platform Preview port to that port. Do not point frontend Preview to backend port 8000.
- **Backend does not start:** configure MongoDB connectivity and the required Secrets. This should not by itself prevent the frontend UI process from starting.
- **UI opens but API requests fail:** set `EXPO_PUBLIC_BACKEND_URL` to a browser-reachable backend URL, configure exact `CORS_ORIGINS`, then restart Expo and the backend.
- **Blank screen or route error:** inspect Expo/Metro logs first. Root `frontend/app/index.tsx` redirects to the existing `/(tabs)` route; verify the route group files remain present.

## Verification status (2026-10-17)

- ZIP source integrity was checked before preparation; this package is created from that existing source.
- Backend tests in the available local environment: **25 passed, 23 skipped, 0 failed**.
- Frontend dependency installation, typecheck, web export, HTTP root route, and actual Replit/Emergent Preview were **not verified** in this environment because `registry.npmjs.org` DNS did not resolve. This is a local environment observation, not proof that Replit or Emergent has the same network issue.
- No production deployment or database migration was performed.

## Targeted implementation update — 2026-10-18

The recovered working copy includes targeted source changes for roadmap Tasks 9, 12, 15, 18, and 21. See `COME-IN-IMPLEMENTATION-REPORT.md`, `COME-IN-TEST-REPORT.md`, and `COME-IN-SETUP-GUIDE.md` for exact scope, test evidence, and limitations. The available backend/source-contract suite passed 127 tests with 23 remote integration tests skipped. Frontend dependency installation/typecheck/build and live database/browser behavior remain unverified in the current environment. This recovered baseline is not asserted to be the latest verified candidate.

## Customer catalog reference data

The customer catalog now includes 17 categories and a bundled reference dataset for browsing. Reference items are not shop inventory: they show no live price/stock and cannot be checked out until an approved shopkeeper creates a live listing. See `COME-IN-CATALOG-100-PER-CATEGORY-IMPLEMENTATION-REPORT.md` for exact per-category counts and the Eggs-category gap, and `COME-IN-CATALOG-100-PER-CATEGORY-TEST-REPORT.md` for verification limits.


## Chand AI

The existing Chand assistant is in `frontend/app/chand.tsx`. It uses the public `/assistant/context` endpoint and existing product/cart screens. See `docs/COME-IN-CHAND-SETUP-2026-10-19.md` and `project-reports/CHAND_AI_EXECUTION_REPORT_2026-11-12.md` for provider configuration, verified source integration and remaining limitations. Chand is currently PARTIAL; live provider, native voice, photo shopping, budget-list editing and feedback/Admin review are not complete.
