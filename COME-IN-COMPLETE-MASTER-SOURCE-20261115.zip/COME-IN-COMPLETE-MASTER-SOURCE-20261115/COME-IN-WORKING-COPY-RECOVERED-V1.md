COME-IN-WORKING-COPY-RECOVERED-V1
=================================
Type: NEW recovery working copy created from the Master Backup ZIP.
It is NOT the old active working copy (no older Come-In copy existed in this Emergent workspace).

Source ZIP (read-only, unchanged): /app/_master_backup/COME-IN-MASTER-BACKUP-v7.zip
ZIP SHA-256: e8151645e38e38e39324b877d4a99cc20ba60f9d816255bb410555f3e902a7df

Live paths (used by the preview services):
- /app/frontend  (Expo 57 + React Native Web + Expo Router)
- /app/backend   (FastAPI + MongoDB/Motor)
- /app/docs, /app/scripts, /app/previews, /app/tests
- Root reports/memory from the ZIP: /app/_master_backup/come-in-docs/
- Original Emergent template (moved aside): /app/_template_original/

Local-only files (not in ZIP, never commit): frontend/.env, backend/.env
