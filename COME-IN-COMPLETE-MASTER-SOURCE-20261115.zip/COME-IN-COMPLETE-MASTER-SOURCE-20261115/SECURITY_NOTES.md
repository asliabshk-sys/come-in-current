# COME-IN — Security Notes

- **No real secrets are included.** `backend/.env` / `frontend/.env` are excluded and git-ignored; only `.env.example` templates ship. A secret-pattern scan of the package is recorded in `reports/security/SECRET_SCAN_2026-11-14.md`.
- `backend/tests/preview_test_env.sh` contains **disposable preview test account passwords** (e.g. `admin@comein-preview.com`). They are not production credentials and must never be reused in production.
- The included database backup is **preview/test data only**; `users.password_hash` values, encrypted Delivery Partner PII, auth rate-limit records and grocery quote tokens were redacted/removed. Accounts in the backup cannot log in.
- Encryption: bank details use `BANK_DATA_ENCRYPTION_KEY`; Delivery Partner PII uses a distinct `DELIVERY_PARTNER_DATA_ENCRYPTION_KEY` (Fernet, no plaintext fallback — verified live 2026-11-14: stored fields are `*_enc` ciphertext). Keys must live in a secret manager; losing them makes data unrecoverable.
- Production guard: `APP_ENV=production` requires explicit non-wildcard `CORS_ORIGINS`.
- Admin seeding requires explicit `ADMIN_EMAIL` + `ADMIN_PASSWORD` (≥16 chars); no default admin.
- Aadhaar/PAN numbers are never collected; OTP/identity endpoints fail closed (503) until authorized providers are integrated.
- Razorpay online payments are disabled unless `GROCERY_ONLINE_PAYMENTS_ENABLED=true` and both server keys are present.
- Open items: SMTP reset delivery, OTP, logout-all session revocation, malware scanning for imports, key rotation, external security audit (Task 16).
- Prior reports: `reports/audit/previous-handoff-package-2026-11-12/SECURITY_AND_ENVIRONMENT/`, `docs/UNIVERSAL_CATALOGUE_IMPORT_SECURITY_REPORT.md`.
