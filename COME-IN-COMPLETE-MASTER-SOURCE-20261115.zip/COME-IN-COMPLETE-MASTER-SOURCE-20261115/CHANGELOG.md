# Changelog

## 2026-11-14 — Codex-ready master packaging
- Promoted `APPLICATION_SOURCE/COME-IN-WORKING-COPY-RECOVERED-V1/` to single root `COME-IN-MASTER-PROJECT/` (relative paths unchanged).
- No application source (`frontend/app`, `frontend/src`, `backend/*.py`) changed.
- `frontend/yarn.lock`: genuine `yarn install` added missing `expo-audio`, `expo-image-picker`, `expo-image-loader` entries (0 lines removed) so `--frozen-lockfile` works.
- `.gitignore`: added `.env*` (keeps `.env.example`) and Expo/pytest cache ignores.
- Added handoff docs (CODEX_START_HERE, CODEX_HANDOFF, PROJECT_MANIFEST.json, MASTER_TASK_TRACKER, PROJECT_STATUS, PROJECT_STRUCTURE, KNOWN_ISSUES, RESTORE_AND_SETUP, TESTING_GUIDE, SECURITY_NOTES), `docs/api/API_ROUTES.md`, `docs/architecture/`, `docs/deployment/`, `reports/`, `database-backup/`.
- Added tooling: `scripts/mongo/export_sanitized_preview_backup.py`, `scripts/delivery-partner-live-api-check.sh`.
- Verified live on isolated MongoDB 7.0.45 replica set: 70/70 live runtime tests, Delivery Partner API first live run, backup→restore PASS.
- Initialised Git baseline (received source had no history).


## 2026-11-12 — Chand AI source integration (PARTIAL)
- Added grounded catalog product-card rendering in the existing Chand screen, including actual product image/price/stock/variant/shop metadata and existing ProductCard actions.
- Extended `/assistant/context` with existing Task 5 measured fields, shop-declared fulfillment flags and bounded non-persistent session history.
- Connected Home, Account and header microphone shortcuts to the shared Chand route; header voice entry focuses the editable composer.
- Preserved the existing pickup/drop request API and form under a clearer label, linked from Chand.
- Added catalog transport retry state and COME-IN-specific multilingual provider instructions.
- Added focused Chand integration source-contract tests.
- Live provider, native speech recognition, photo shopping, budget list editor, feedback/Admin review, Expo runtime and full typecheck remain blocked/not implemented.

# CHANGELOG — COME-IN

Older history is in `project-reports/CHANGELOG-v7.md` and the `project-reports/*` task reports. Those files are preserved and were not edited.

## 2026-11-11 — New Emergent account: import + BATCH-02 (Tasks 15, 16, 20, 21, 18)

### Import
- Imported `COME_IN_MASTER_BACKUP_2026-11-11.zip`: integrity OK, 344 files, root `COME-IN-WORKING-COPY-RECOVERED-V1/`. The original was not modified.
- Source was placed on the account's Expo SDK 58 template (`package.json`, `metro.config.js` and `.env` kept from the template). Added `@react-native-vector-icons/feather`.
- Preview MongoDB was converted to a single-node replica set (`rs0`) so transactions work.

### Task 15 — Admin Panel
- New `GET /api/admin/dashboard` (admin only).
- `PATCH /api/admin/announcements/{id}` now edits title, body, audience and expires_at, with validation.
- `admin.tsx`: Overview tab, Referrals tab, announcement Edit / Cancel edit, load-error notice.

### Task 16 — Backend, Database and Security
- Mongo-backed auth rate limiting (`auth_rate_limits` with a TTL index) on login, register, forgot password and reset password.
- New index on notifications (`user_id`, `read`).

### Task 20 — In-App Notifications
- `_notify` records `channel` and `push_status`, and never fails the business action that triggered it.
- New-order notifications to the seller (grocery) and the restaurant owner.
- Restaurant order-status notifications to the customer.
- New `GET /api/notifications/unread-count`.
- Home bell opens Notifications and shows an unread badge. Seller deep links added.

### Task 21 — Customer Shopping Workflow
- Fixed the checkout crash (BUG-01).
- Added the price-comparison panel styles.
- Increased product-page bottom padding so the measured Save button is reachable.

### Task 18 — Testing and Bug Fixes
- Bugs BUG-01 to BUG-11 (see `COME_IN_BUG_FIX_LOG.md`).
- New runtime test suites and preview test-account seeding.

### Files — new
- `frontend/src/utils/alert.ts`
- `backend/tests/test_batch_5task_runtime.py`
- `backend/tests/test_iter_notifications_admin_measured.py` (by the testing agent)
- `backend/tests/seed_preview_test_accounts.py`
- `backend/tests/preview_test_env.sh`
- `backend/tests/STALE_CONTRACT_TESTS.txt`
- `project-reports/COME_IN_BATCH_02_TEST_REPORT.json`
- `project-reports/COME_IN_BATCH_02_TESTING_AGENT_iteration_1.json`
- `project-reports/batch-02/COME_IN_BATCH_02_IMPLEMENTATION.json`
- `docs/history/frontend-package-sdk57-from-previous-account.json`
- `COME_IN_MASTER_TASK_TRACKER.md`
- `COME_IN_PROJECT_CHECKPOINT.md`
- `COME_IN_DECISIONS_AND_BLOCKERS.md`
- `COME_IN_TEST_REPORT.md`
- `COME_IN_BUG_FIX_LOG.md`
- `COME_IN_MANUAL_TESTING_CHECKLIST.md`
- `COME_IN_RELEASE_READINESS.md`
- `CHANGELOG.md`

### Files — modified
- `backend/server.py`
- `backend/tests/test_role_security_retail_import_contract.py` (register signature)
- `frontend/app/admin.tsx`, `checkout.tsx`, `notifications.tsx`, `(tabs)/index.tsx`, `(tabs)/account.tsx`, `product/[id].tsx`, `seller/products.tsx`, `become-seller.tsx`, `payment-methods.tsx`, `shop/[id].tsx`, `services.tsx`, `admin-earnings.tsx`
- `frontend/src/theme.ts`
- `frontend/package.json`, `frontend/yarn.lock`
- `COME_IN_MASTER_TASK_TRACKER.json`, `COME_IN_MASTER_TASK_STATUS_REPORT.json`, `COME_IN_MASTER_HANDOFF.json`, `COME_IN_CURRENT_PROJECT_STATUS.md`, `COME_IN_NEXT_STEPS.md`
- `COME_IN_BACKUP_INCLUDED_FILES.txt`, `COME_IN_BACKUP_EXCLUDED_FILES.txt`, `COME_IN_BACKUP_MANIFEST.json`

### Files — deleted
- None. On import, the template placeholder files `frontend/app/index.tsx`, `_layout.tsx` and `+html.tsx` were replaced by the project's own versions (not project files).


## 2026-11-11 — Task 18 QA Iteration 3 (Codex handover)

- Extracted the uploaded 2026-11-11 Master ZIP into a separate working directory; original upload preserved.
- Added Restaurant refund safety: compare captured/order totals in paise, compare-and-set claim, provider refund-history reconciliation, cumulative webhook accounting, and full-refund-only ledger reversal.
- Added pure helper `backend/refund_rules.py`.
- Fixed checkout unavailability/empty-cart messaging, Grocery pickup wording in Orders, and Admin refund status/amount feedback.
- Added Task 18 refund safety tests and refreshed three stale checkout/payment contract test modules.
- Focused regression: 43 passed. Python compilation passed. Three TSX files transpiled with 0 syntax diagnostics.
- Runtime, MongoDB, Razorpay and native-device tests remain pending due missing runtime dependencies/services. See `COME_IN_QA_REPORT.md`.


## 2026-11-11 — Task 5 Phase 4 verification
- Added 11 customer measured-shopping source-contract tests; no application source logic changed because Phase 4 source was already present in the accepted baseline.
- Recorded 29 focused PASS, 344 offline PASS, compileall PASS and 8-file TS/TSX syntax transpilation PASS. Live Preview and MongoDB transaction verification remain blocked; Task 5 stays PARTIAL.


## 2026-11-11 — Task 5 remaining live verification follow-up
- Verified Final V2 ZIP and Excel checksums; preserved originals; ZIP 439 entries and internal manifest 437/437 PASS.
- Fresh focused tests 35 PASS, offline regression 345 PASS across 53 files, backend compileall PASS.
- Confirmed no disposable MongoDB replica-set or Expo Preview runtime can be provisioned in this session. All seven transaction scenarios and remaining live flows remain BLOCKED / NOT RUN.
- No Task 5 defect reproduced; no application source changed. Task 5 remains PARTIAL. See `COME_IN_TASK5_LIVE_VERIFICATION_2026-11-11.md`.


## 2026-11-11 — Task 5 live provisioning closure attempt
- Reverified only the specified live-verification baseline; extracted into a separate working directory and verified all 450 baseline manifest entries.
- Focused offline tests: 66 PASS; broad offline regression: 345 PASS, 23 skipped; compileall PASS.
- No approved local MongoDB replica-set runtime or Expo dependency environment; seven transaction scenarios and remaining live flows stay BLOCKED / NOT RUN.
- No application source changed; no defect reproduced; Task 5 remains PARTIAL. See `COME_IN_TASK5_LIVE_PROVISIONING_CLOSURE_2026-11-11.md`.


## 2026-11-11 — Task 5 live verification resumption
- Updated QA/tracker records with exact baseline verification and runtime provisioning findings.
- No application source changes. 43 focused offline tests and backend compileall passed; live Task 5 gates remain blocked.


## 2026-11-12 — Chand AI Phase 2 (PARTIAL)

- Added authenticated Chand feedback submission and admin review/status workflow with request idempotency, rate caps and common contact/credential-pattern redaction.
- Added assistant-context per-actor minute rate limiting with TTL cleanup.
- Added editable fixed-pack budget list sourced from live Chand catalog results; over-budget transfer is blocked and accepted items enter the existing Cart; basic birthday/family gathering/small-party guided search form added. Checkout remains authoritative.
- 115 focused Chand/Task 5/Restaurant/Cart/Checkout/Support regression tests pass; live provider, Expo runtime, native voice, photo/vision and MongoDB/device verification remain outstanding.

## 2026-11-14 — MongoDB master completion mission (PARTIAL)

- Added validated MongoDB configuration with bounded pool/timeouts, retryable reads/writes, production TLS and exact database-target guard; FastAPI startup now checks ping and replica-set/mongos topology.
- Made index discovery cover every FastAPI startup handler; source inventory is 65 indexes across 50 application collections. Added semantic drift checks, init verification, read-only index verification and unique-index duplicate preflight.
- Added conservative post-abort Grocery stock conflict classification and made Grocery payment/order capture updates atomic.
- Restricted restore script to disposable `comein_disposable_test_*` databases and added post-restore source-index verification.
- Added complete MongoDB collection/index/transaction/schema/security/backup documentation and test evidence.
- Offline targeted regression: 92 passed; compileall and shell syntax passed. Live MongoDB verification remains BLOCKED because mongod/tools, Motor and PyMongo are unavailable. Catalogue Import final apply remains BLOCKED pending newer Emergent source.
