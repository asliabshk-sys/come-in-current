# COME-IN — Bug Fix Log

| ID | Date | Bug | Root cause | Files changed | Fix applied | Regression result |
|---|---|---|---|---|---|---|
| BUG-01 | 2026-11-11 | The Checkout screen crashed on open | `total` used `fulfillment` before its `useState` declaration (ReferenceError) | `frontend/app/checkout.tsx` | Moved the `total` calculation below the `fulfillment` state | PASS: UI checkout E2E, T21-8 |
| BUG-02 | 2026-11-11 | Seller products screen did not compile | A stray `</View>` closed the variants wrapper early (JSX syntax error) | `frontend/app/seller/products.tsx` | Removed the stray tag | PASS: tsc has no syntax errors; seller form renders (T18-2) |
| BUG-03 | 2026-11-11 | On web, confirm dialogs did nothing: admin role change, CSV/retail import confirm, referral approvals, shop/services alerts | React Native Web `Alert.alert` is a no-op | New `frontend/src/utils/alert.ts`; imports switched in `admin.tsx`, `admin-earnings.tsx`, `services.tsx`, `shop/[id].tsx`, `(tabs)/index.tsx` | Native uses the system Alert; web uses `window.confirm`/`alert` | PASS: role change confirmed in E2E (T15-6) |
| BUG-04 | 2026-11-11 | Some screens' backgrounds and danger text had undefined colors | `colors.background` and `colors.danger` did not exist in the theme | `frontend/src/theme.ts` | Added aliases with the existing surface and error values | PASS: tsc |
| BUG-05 | 2026-11-11 | Unstyled UI: price comparison panel, Request Anything options/arrow, admin section headings, become-seller chips, seller import panel, payment-method buttons | Style keys were referenced but not defined. A loose `makeStyles` typing hid this. | `product/[id].tsx`, `(tabs)/index.tsx`, `admin.tsx`, `become-seller.tsx`, `seller/products.tsx`, `payment-methods.tsx`, `src/theme.ts` (typing) | Added the missing style keys with theme colors. Typed `makeStyles` so missing keys are caught. | PASS: tsc (no TS2339 style errors) |
| BUG-06 | 2026-11-11 | Account showed a "?" icon | Feather has no `store` icon | `frontend/app/(tabs)/account.tsx` | Replaced with `shopping-bag` / `home` | PASS: tsc |
| BUG-07 | 2026-11-11 | Admin Referrals review could not be reached | `referrals` was in the Tab type but missing from the tab list | `frontend/app/admin.tsx` | Added the tab | PASS: T15-5 |
| BUG-08 | 2026-11-11 | Home bell opened Orders and showed no unread state | Batch-01 notification center was never wired to the header | `frontend/app/(tabs)/index.tsx`, `backend/server.py` (`/notifications/unread-count`) | Bell routes to `/notifications` with an unread badge | PASS: T20-6 |
| BUG-09 | 2026-11-11 | Seller products header title squeezed to one character per line at 390 px | The header row did not wrap and the title had no minWidth | `frontend/app/seller/products.tsx` | Added `flexWrap` and `minWidth: 140` | Fixed after iteration_1. Visual re-check pending in the next UI pass. |
| BUG-10 | 2026-11-11 | Loose-quantity Save button hidden behind the sticky Add/Buy bar | Not enough bottom padding in the scroll area | `frontend/app/product/[id].tsx` | `paddingBottom` 140 → 200 | Fixed after iteration_1. Visual re-check pending. |
| BUG-11 | 2026-11-11 | (Found during the fix) First rate-limit design blocked legitimate repeated logins from a shared IP | Every attempt was counted, including successful ones | `backend/server.py` | Count only failed logins; per-IP allowance ×5 | PASS: runtime suites (61) plus the 429 test |

## Known open issues (not fixed in this batch)
- The sticky bar's ADD on a measured product adds the default amount when the user has not saved an amount (by design: the amount is saved with the picker's Save button). Needs owner UX decision.
- Shop page images show grey when a product has no uploaded image (honest empty state).
- 28 stale contract tests.
- 26 TypeScript strictness errors.


## Task 18 QA Iteration 3 — 2026-11-11
| ID | Bug / finding | Root cause from source review | Files changed | Fix applied | Verification |
|---|---|---|---|---|---|
| BUG-12 | Duplicate / over-cap Restaurant refund risk, including provider-side/manual refunds not represented in local status | Existing route checked local refund status but did not reconcile the provider's full refund history or cumulative paise amount before submitting a full refund. | `backend/server.py`, new `backend/refund_rules.py` | Compare captured amount with eligible order amount; CAS claim; page through provider refunds; fail closed on any active prior refund or unverifiable history; aggregate webhook refund IDs; reverse ledger only after full cumulative confirmation. | 14 new focused tests + source contracts in the 43-test batch; provider/DB runtime NOT TESTED. |
| BUG-13 | Checkout did not clearly explain when both delivery and pickup were unavailable | Fulfillment options could be empty without an explicit user-facing explanation. | `frontend/app/checkout.tsx` | Added explicit unavailable-service and options-loading messages. | TSX syntax transpilation: 0 diagnostics; source contract passed. UI runtime NOT TESTED. |
| BUG-14 | Empty cart displayed a payment-method configuration warning | The warning was rendered while no checkout lines existed and shop options were null. | `frontend/app/checkout.tsx` | Show the payment warning only when checkout has lines and shop options have loaded. | TSX syntax transpilation: 0 diagnostics; source contract passed. UI runtime NOT TESTED. |
| BUG-15 | Grocery pickup orders displayed delivery wording/address | Orders screen used delivery copy for every Grocery order. | `frontend/app/orders.tsx` | Pickup orders now display “Pickup from shop”. | TSX syntax transpilation: 0 diagnostics; source contract passed. UI runtime NOT TESTED. |
| BUG-16 | Admin refund notice always claimed pending and did not display confirmed/pending totals | UI ignored the provider response and existing order amount fields. | `frontend/app/admin.tsx` | Display actual provider status and separate confirmed/pending refund amounts; suppress retry for blocked states. | TSX syntax transpilation: 0 diagnostics; source contract passed. UI runtime NOT TESTED. |

## Open QA findings
- Atta product image/description: not changed; no verified/approved product asset in this ZIP.
- Notification preference switches: no corresponding switches found in the current frontend source; no new settings were invented.
- Task 18 runtime/provider/DB/device verification remains pending.


## Task 5 Phase 4 — verification blocker (not a confirmed product bug)
- **QA-T5-01 — Live measured-shopping and transaction verification unavailable.** The accepted baseline already contains customer measured picker/cart/Buy Now and backend quote/transaction source. Source/offline checks pass (29 focused; 344 offline). Live Expo Preview and seven MongoDB replica-set scenarios were not run because the environment has no Expo CLI/dependencies, `/app/frontend/.env`, MongoDB server/tools/drivers, or disposable replica set. No application defect was inferred from missing infrastructure. Keep Task 5 PARTIAL.


## Task 5 live verification follow-up — 2026-11-11 (environment blocker only)
- `QA-T5-01` remains **BLOCKED — VERIFICATION ONLY**, not a confirmed product defect.
- Fresh evidence: 35 focused tests PASS; 345 offline tests PASS across 53 files; Python compileall PASS.
- Seven replica-set transaction scenarios are individually BLOCKED / NOT RUN. Expo Preview, Seller/Customer UI, measured Repeat Order E2E and transaction-backed CSV/Excel import apply are BLOCKED / NOT RUN.
- Exact blockers: no mongod/mongosh/Docker/Podman, no Python motor/pymongo, no frontend/node_modules, no Yarn/Expo CLI, and no `/app/frontend/.env`.
- No defect reproduced and no application source fix applied. Detailed report: `COME_IN_TASK5_LIVE_VERIFICATION_2026-11-11.md`.


## Task 5 live provisioning follow-up — 2026-11-11
- `QA-T5-01` remains **BLOCKED — VERIFICATION ONLY**, not a confirmed application defect.
- Focused tests 66 PASS; broad offline regression 345 PASS / 23 skipped; backend compileall PASS.
- MongoDB provisioning and Expo Preview are unavailable with approved local capabilities. All seven transaction scenarios, Seller/Customer Preview, measured Repeat Order E2E and transaction-backed import apply remain BLOCKED / NOT RUN.
- No defect reproduced; no application source changed; no fix or regression test added. Detailed report: `COME_IN_TASK5_LIVE_PROVISIONING_CLOSURE_2026-11-11.md`.


## Task 5 live resumption — 2026-11-11
- Confirmed Task 5 runtime defects reproduced: 0. No application source files changed. Runtime gates remain BLOCKED / NOT RUN due missing authorized disposable MongoDB and pinned Expo/Yarn environment.
