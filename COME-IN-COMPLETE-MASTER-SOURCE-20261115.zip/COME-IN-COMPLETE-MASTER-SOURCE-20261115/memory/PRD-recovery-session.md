# Come-In — PRD / Working Notes

## Original problem statement (summary)
Find the existing Come-In working copy. If there is none, restore it from COME-IN-MASTER-BACKUP-v7.zip as a new copy without overwriting the ZIP. Install dependencies, run the preview and verify features at runtime (PASS / FAIL / BLOCKED / NOT TESTED). Do not change the existing UI, backend, auth or Restaurant Mode. Use an isolated test DB only.

## Architecture
- Frontend: Expo 57, React Native Web, Expo Router (TypeScript), in /app/frontend
- Backend: FastAPI with Motor/MongoDB, in /app/backend (server.py)
- The preview DB is a local single-node replica set at 127.0.0.1:27018 (rs0), DB test_database. Grocery checkout needs transactions.

## Done (2026-10-30)
- No old working copy existed. Created the recovery copy COME-IN-WORKING-COPY-RECOVERED-V1 from the v7 ZIP (269/272 manifest files are verified in place; the root README, .gitignore and .replit are kept in _master_backup/come-in-docs).
- yarn install --frozen-lockfile succeeded. pip install -r requirements.txt succeeded.
- Preview is running. Iteration 1 and 2 runtime tests: most flows pass, including grocery COD and Restaurant COD.
- Versioned backup: /app/backups/COME-IN-WORKING-COPY-RECOVERED-V1-20261030-0501-clean.zip

## Missing config (features blocked)
EMERGENT_LLM_KEY (uploads), RAZORPAY_* (online payment), SMTP_* (reset email), COMEIN_AI_* (generative CHAND)

## Backlog (existing bugs, reported, not yet fixed)
- P1: seller/orders.tsx confirmUpiPayment is out of scope, so the UPI confirm button throws an error
- P1: /restaurant/orders route is missing (it resolves to [id])
- P2: the tracking message says "Tracking ended" before dispatch
- P2: become-seller chips have no styles; the seller/products header wraps on mobile; the "Address saved" message is shown in red
