# COME-IN — PRD / Session memory

## Original problem statement (this session)
Additional mandatory phase — MongoDB portability + Master ZIP backup: reproducible MongoDB setup (docs, replica-set config, init/index scripts, schema/validation + transaction docs, env templates, connection config, versions, health-check, automated setup/verification, troubleshooting), secure config (no secrets in ZIP), portable environment (version-pinned deployment, reproducible rs init, disposable test DB + cleanup, transaction verification, Docker Compose if possible), Expo environment portability, immediate checkpoint ZIP "COME-IN-MONGODB-PORTABLE-CHECKPOINT", final Master ZIP after remaining Task 5 live tests, clean-environment restoration test.
User choices: local test MongoDB replica set in this workspace; checkpoint now + final after tests runnable here.

## Architecture
Expo 58.0.17 / RN 0.88 web (Expo Router) on :3000 · FastAPI + Motor on :8001 (/api) · MongoDB 7.0.45 single-node replica set rs0 on 127.0.0.1:27018 (supervisor program mongodb-rs0, data /root/mongo-rs0-data; platform standalone mongod stays on 27017).

## Implemented (2026-11-11)
- Restored user's Master ZIP into /app (baseline manifest 609/609 PASS); deps installed with frozen lockfile.
- Portability package: docs/mongodb/*, infra/mongodb/*, scripts/mongo/{setup.sh,start-replset.sh,comein_mongo.py}, scripts/verify-env.sh, scripts/release/{build_master_zip.py,update_tracker.py,restoration_test.sh}.
- Checkpoint ZIP + final ZIP served from frontend/public/downloads (sha256 sidecars).
- Task 5 live suite backend/tests/test_task5_live_mongo_transactions.py: 9/9 PASS. Expo customer/seller preview PASS. Regression 415 PASS.
- Fixes BUG-14..17 (measured picker invalid input, hint copy, testIDs, portable sugar fixture).

## Backlog
- P1: retry checkout transaction on TransientTransactionError (F-1: concurrent losers get 503 not 409).
- P2: Verify Docker Compose path on a Docker host; Atlas test cluster run; new-account restoration.
- P2: Razorpay TEST keys for online payment; native APK device checks.
- After pod restart: run `bash scripts/mongo/setup.sh`.
