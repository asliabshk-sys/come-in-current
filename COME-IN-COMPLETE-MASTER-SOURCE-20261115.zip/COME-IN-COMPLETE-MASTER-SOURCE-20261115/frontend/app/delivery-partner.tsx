import Feather from "@react-native-vector-icons/feather";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Alert, Pressable, ScrollView, Share, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { api } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { spacing, radius, useTheme } from "@/src/theme";

type Application = { id: string; status: string; phone_verified: boolean; aadhaar_verified: boolean; pan_verified: boolean; documents_status: string; referral_code?: string; correction_reason?: string; decision_reason?: string };
type Providers = { otp: string; aadhaar: string; pan: string; secure_document_storage: string };

export default function DeliveryPartnerOnboardingScreen() {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [application, setApplication] = useState<Application | null>(null);
  const [providers, setProviders] = useState<Providers | null>(null);
  const [fullName, setFullName] = useState(user?.name || "");
  const [mobile, setMobile] = useState(user?.phone || "");
  const [address, setAddress] = useState("");
  const [alternate, setAlternate] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [consent, setConsent] = useState(false);
  const [notice, setNotice] = useState("");
  const [busyProvider, setBusyProvider] = useState(false);

  const refresh = useCallback(async () => {
    if (!user) { setLoading(false); return; }
    try {
      const [mine, status] = await Promise.all([
        api.get<Application | null>("/delivery-partner/application/mine"),
        api.get<Providers>("/delivery-partner/provider-status"),
      ]);
      setApplication(mine);
      if (mine) { setFullName((mine as any).full_name || ""); setMobile((mine as any).mobile || ""); setAddress((mine as any).residential_address || ""); setAlternate((mine as any).alternate_contact || ""); }
      setProviders(status);
    } catch (e: any) { setNotice(e?.message || "Could not load your application."); }
    finally { setLoading(false); }
  }, [user]);
  useEffect(() => { void refresh(); }, [refresh]);

  const saveDraft = async () => {
    if (!consent) { setNotice("Please accept all required consent and declarations."); return; }
    setSaving(true); setNotice("");
    try {
      const saved = await api.put<Application>("/delivery-partner/application", {
        full_name: fullName, mobile, residential_address: address, alternate_contact: alternate,
        consent_identity_verification: true, consent_data_processing: true, consent_declaration: true,
        referral_code: referralCode.trim() || undefined,
      });
      setApplication(saved);
      setNotice("Draft saved securely. Identity verification is still pending.");
    } catch (e: any) { setNotice(e?.message || "Draft could not be saved."); }
    finally { setSaving(false); }
  };

  const startOtp = async () => {
    setBusyProvider(true); setNotice("");
    try { await api.post("/delivery-partner/otp/request", {}); setNotice("OTP request accepted by provider."); }
    catch (e: any) { setNotice(e?.message || "OTP provider is unavailable."); }
    finally { setBusyProvider(false); }
  };

  const shareReferral = async () => {
    if (!application?.referral_code) return;
    try { await Share.share({ message: `Join me on COME-IN as a Delivery Partner. Referral code: ${application.referral_code}` }); }
    catch { setNotice("Could not open the device share sheet."); }
  };

  if (!user) return <View style={[styles.root, { paddingTop: insets.top + 24 }]}><Text style={styles.title}>Delivery Partner</Text><Text style={styles.body}>Please sign in to start a separate Delivery Partner application.</Text></View>;
  if (loading) return <View style={[styles.root, { alignItems: "center", justifyContent: "center" }]}><ActivityIndicator color={colors.brandPrimary} /></View>;

  const status = application?.status || "NOT_STARTED";
  const locked = ["PENDING_VERIFICATION", "PENDING_ADMIN_APPROVAL", "APPROVED", "REJECTED", "SUSPENDED"].includes(status);
  const field = (label: string, value: string, setter: (v: string) => void, placeholder: string, keyboardType: "default" | "phone-pad" = "default", multiline = false) => (
    <View style={styles.field}><Text style={styles.label}>{label}</Text><TextInput value={value} onChangeText={setter} placeholder={placeholder} placeholderTextColor={colors.muted} keyboardType={keyboardType} multiline={multiline} editable={!locked} style={[styles.input, { color: colors.onSurface, borderColor: colors.border, minHeight: multiline ? 84 : 48 }]} /></View>
  );

  return <ScrollView style={[styles.root, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingTop: insets.top + spacing.md, paddingBottom: 48 }}>
    <View style={styles.header}><Feather name="truck" size={24} color={colors.brandPrimary} /><View style={{ flex: 1 }}><Text style={[styles.title, { color: colors.onSurface }]}>Become a Delivery Partner</Text><Text style={[styles.body, { color: colors.muted }]}>A separate application from Shop Seller registration.</Text></View></View>
    <View style={[styles.statusCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.label, { color: colors.muted }]}>APPLICATION STATUS</Text><Text style={[styles.status, { color: colors.brandPrimary }]}>{status.replace(/_/g, " ")}</Text><Text style={[styles.body, { color: colors.muted }]}>Only an approved and eligible account can access delivery-partner features.</Text>{application?.correction_reason ? <Text style={styles.warning}>Correction requested: {application.correction_reason}</Text> : null}{application?.decision_reason ? <Text style={styles.body}>Admin decision: {application.decision_reason}</Text> : null}</View>
    <Text style={[styles.section, { color: colors.onSurface }]}>1. Personal details</Text>
    {field("Full legal name", fullName, setFullName, "As shown on your identity document")}
    {field("Mobile number", mobile, setMobile, "10-digit mobile number", "phone-pad")}
    <Pressable disabled={busyProvider || !application} onPress={startOtp} style={[styles.secondary, { borderColor: colors.border }]}><Text style={[styles.buttonText, { color: colors.brandPrimary }]}>{busyProvider ? "Please wait…" : "Request mobile OTP"}</Text></Pressable>
    <Text style={[styles.body, { color: colors.muted }]}>OTP verification requires an authorized SMS provider. No OTP or verification is simulated.</Text>
    {field("Residential address", address, setAddress, "House / street, area, city, state and PIN", "default", true)}
    {field("Alternate family contact", alternate, setAlternate, "Different 10-digit mobile number", "phone-pad")}
    {field("Referral code (optional)", referralCode, setReferralCode, "Enter a partner referral code")}
    <Text style={[styles.section, { color: colors.onSurface }]}>2. Identity and document verification</Text>
    <View style={[styles.providerCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>{(["otp", "aadhaar", "pan", "secure_document_storage"] as const).map((key) => <View key={key} style={styles.providerRow}><Text style={[styles.body, { color: colors.onSurface }]}>{key === "otp" ? "Mobile OTP" : key === "aadhaar" ? "Authorized Aadhaar verification" : key === "pan" ? "Authorized PAN verification" : "Encrypted document storage"}</Text><Text style={[styles.providerState, { color: providers?.[key] === "CONFIGURED" ? colors.brandPrimary : colors.muted }]}>{providers?.[key] || "UNKNOWN"}</Text></View>)}</View>
    <Text style={[styles.body, { color: colors.muted }]}>Do not enter Aadhaar or PAN numbers here. Authorized provider integrations and secure document storage must be configured before these checks can run.</Text>
    <Text style={[styles.section, { color: colors.onSurface }]}>3. Consent and declaration</Text>
    <Pressable onPress={() => setConsent(!consent)} style={styles.consentRow}><Feather name={consent ? "check-square" : "square"} size={21} color={colors.brandPrimary} /><Text style={[styles.body, { color: colors.onSurface, flex: 1 }]}>I consent to identity verification and processing of the minimum required application data, and declare that the details provided are accurate.</Text></Pressable>
    {!locked ? <Pressable disabled={saving} onPress={saveDraft} style={[styles.primary, { backgroundColor: colors.brandPrimary }]}><Text style={styles.primaryText}>{saving ? "Saving…" : "Save application draft"}</Text></Pressable> : null}
    {application?.referral_code && application.status === "APPROVED" ? <Pressable onPress={shareReferral} style={[styles.secondary, { borderColor: colors.border }]}><Text style={[styles.buttonText, { color: colors.brandPrimary }]}>Share referral code · {application.referral_code}</Text></Pressable> : null}
    {notice ? <Text accessibilityRole="alert" style={styles.notice}>{notice}</Text> : null}
    <Text style={[styles.body, { color: colors.muted, marginTop: 14 }]}>Your application is private. Other delivery partners and customers cannot access your personal profile or documents.</Text>
  </ScrollView>;
}

const styles = StyleSheet.create({
  root: { flex: 1, paddingHorizontal: 18 }, header: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 18 }, title: { fontSize: 22, fontWeight: "800" }, body: { fontSize: 13, lineHeight: 19, marginTop: 5 }, section: { fontSize: 16, fontWeight: "800", marginTop: 22, marginBottom: 8 }, statusCard: { borderWidth: 1, borderRadius: radius.lg, padding: 15 }, status: { fontSize: 18, fontWeight: "800", marginTop: 4 }, warning: { color: "#A15C00", marginTop: 8, fontSize: 13 }, field: { marginTop: 12 }, label: { fontSize: 13, fontWeight: "700", marginBottom: 6 }, input: { borderWidth: 1, borderRadius: radius.md, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15 }, primary: { borderRadius: radius.md, padding: 14, alignItems: "center", marginTop: 18 }, primaryText: { color: "#FFFFFF", fontWeight: "800" }, secondary: { borderWidth: 1, borderRadius: radius.md, padding: 12, alignItems: "center", marginTop: 10 }, buttonText: { fontWeight: "700" }, providerCard: { borderWidth: 1, borderRadius: radius.md, padding: 12 }, providerRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 7 }, providerState: { fontSize: 11, fontWeight: "800" }, consentRow: { flexDirection: "row", gap: 10, alignItems: "flex-start", marginTop: 8 }, notice: { color: "#9A4D00", marginTop: 12, fontSize: 13, lineHeight: 19 },
});
