// Seller — Product management
import Feather from "@react-native-vector-icons/feather";
import { useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, resolveImage } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";
import { useT } from "@/src/i18n";
import { CATEGORIES, ProductVariant } from "@/src/data/catalog";
import { MeasureDraft, measureError, SellBy, SellerMeasuredFields } from "@/src/components/SellerMeasuredFields";

type MasterVariant = { id: string; unit: string };
type MasterProduct = { id: string; name: string; brand?: string; category_id: string; description?: string; image_url?: string; variants: MasterVariant[] };

type Product = {
  id: string;
  name: string;
  brand: string;
  unit: string;
  price: number;
  mrp?: number;
  stock: number;
  image_url?: string;
  category_id: string;
  description: string;
  available: boolean;
  variants?: ProductVariant[];
  sell_by?: SellBy;
  measure?: MeasureDraft | null;
};

const EMPTY: Product = {
  id: "",
  name: "",
  brand: "",
  unit: "",
  price: 0,
  stock: 0,
  category_id: "",
  description: "",
  available: true,
  variants: [],
  sell_by: "pack",
  measure: null,
};

// Name/category starting points only. Sellers must enter their real unit, price,
// stock and optional product photo before a listing can be saved or sold.
const COMMON_PRODUCT_SUGGESTIONS: Array<{ name: string; category_id: string }> = [
  ...["Moong Dal", "Masoor Dal", "Urad Dal", "Chana Dal", "Rajma", "Kabuli Chana", "Kala Chana", "Poha", "Sabudana", "Sooji / Rava", "Daliya", "Besan", "Maida", "Jaggery", "Sugar", "Whole Wheat Flour", "Basmati Rice", "Sona Masoori Rice"].map((name) => ({ name, category_id: "atta-rice-dal" })),
  ...["Mustard Oil", "Groundnut Oil", "Sunflower Oil", "Refined Cooking Oil", "Turmeric Powder", "Red Chilli Powder", "Coriander Powder", "Cumin Seeds", "Mustard Seeds", "Black Pepper", "Chaat Masala", "Pickle", "Tomato Ketchup", "Vinegar"].map((name) => ({ name, category_id: "masalas-oils" })),
  ...["Aloo Bhujia", "Plain Sev", "Ratlami Sev", "Laung Sev", "Mixture Namkeen", "Chivda", "Dal Moth", "Moong Dal Namkeen", "Masala Peanuts", "Banana Chips", "Khakhra", "Mathri", "Papad", "Popcorn", "Salted Potato Chips"].map((name) => ({ name, category_id: "snacks" })),
  ...["Glucose Biscuits", "Cream Biscuits", "Digestive Biscuits", "Cookies", "Crackers", "Rusk", "Bread", "Pav", "Burger Buns", "Cake"].map((name) => ({ name, category_id: "bakery" })),
  ...["Cola Soft Drink", "Lemon-Lime Soft Drink", "Orange Soft Drink", "Soda Water", "Packaged Drinking Water", "Mango Juice", "Mixed Fruit Juice", "Energy Drink"].map((name) => ({ name, category_id: "beverages" })),
  ...["Toned Milk", "Curd / Dahi", "Paneer", "Cheese Slices", "Butter", "Lassi", "Buttermilk / Chaach", "Flavoured Milk"].map((name) => ({ name, category_id: "dairy-breakfast" })),
  ...["Banana", "Orange", "Mango", "Grapes", "Pomegranate", "Lemon", "Potato", "Tomato", "Onion", "Green Chilli", "Spinach", "Cauliflower", "Carrot", "Cucumber"].map((name) => ({ name, category_id: "fruits-veggies" })),
  ...["Bath Soap", "Shampoo", "Toothpaste", "Toothbrush", "Hair Oil", "Face Wash"].map((name) => ({ name, category_id: "personal-care" })),
  ...["Laundry Detergent", "Dishwashing Bar", "Dishwashing Liquid", "Floor Cleaner", "Toilet Cleaner", "Garbage Bags", "Tissues", "Household Sponge"].map((name) => ({ name, category_id: "household" })),
];

export default function SellerProductsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  const { user } = useAuth();
  const [shopId, setShopId] = useState<string | null>(null);
  const [shopStatus, setShopStatus] = useState<string | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Product | null>(null);
  const [suggestionQuery, setSuggestionQuery] = useState("");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [masterOpen, setMasterOpen] = useState(false);
  const [masterQuery, setMasterQuery] = useState("");
  const [masterResults, setMasterResults] = useState<MasterProduct[]>([]);
  const [masterLoading, setMasterLoading] = useState(false);
  const [masterError, setMasterError] = useState<string | null>(null);
  const [selectedMaster, setSelectedMaster] = useState<MasterProduct | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState("");
  const [linkPrice, setLinkPrice] = useState("");
  const [linkMrp, setLinkMrp] = useState("");
  const [linkStock, setLinkStock] = useState("0");
  const [linkAvailable, setLinkAvailable] = useState(true);
  const [linkSellBy, setLinkSellBy] = useState<SellBy>("pack");
  const [linkMeasure, setLinkMeasure] = useState<MeasureDraft | null>(null);
  const [linkingMaster, setLinkingMaster] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const importRef = useRef<HTMLInputElement | null>(null);
  const catalogueImportRef = useRef<HTMLInputElement | null>(null);
  const [catalogueImporting, setCatalogueImporting] = useState(false);
  const [catalogueImportJob, setCatalogueImportJob] = useState<any | null>(null);
  const [catalogueImportJobs, setCatalogueImportJobs] = useState<any[]>([]);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importReport, setImportReport] = useState<any | null>(null);
  const [importing, setImporting] = useState(false);

  const load = async (sid: string) => {
    const list = await api.get<Product[]>(`/shops/${sid}/products`);
    setProducts(list);
    try { setCatalogueImportJobs(await api.listCatalogueImportJobs(sid)); } catch { setCatalogueImportJobs([]); }
  };

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }
    api.get<{ id: string; status?: string } | null>("/shops/mine").then(async (s) => {
      if (!s) return;
      setShopId(s.id);
      setShopStatus(s.status || "pending");
      await load(s.id);
    }).catch((e: any) => {
      setError(e?.message || "Could not load your shop products. Check your connection and try again.");
    }).finally(() => setLoading(false));
  }, [user]);

  const searchMasterCatalog = async () => {
    setMasterLoading(true);
    setMasterError(null);
    try {
      const query = masterQuery.trim();
      const result = await api.get<MasterProduct[]>(`/catalog/master-products?q=${encodeURIComponent(query)}&limit=50`);
      setMasterResults(Array.isArray(result) ? result : []);
    } catch (e: any) {
      setMasterError(e?.status === 401 ? "Sign in again to search the Master Catalog." : e?.status === 403 ? "You are not authorized to search the Master Catalog." : e?.message || "Could not load Master Catalog. Check your connection and try again.");
      setMasterResults([]);
    } finally {
      setMasterLoading(false);
    }
  };

  const openMasterCatalog = () => {
    setMasterOpen(true);
    setSelectedMaster(null);
    setSelectedVariantId("");
    setMasterQuery("");
    setMasterError(null);
    setMasterResults([]);
  };

  const linkMasterProduct = async () => {
    if (!shopId || !selectedMaster || !selectedVariantId) {
      setMasterError("Choose a catalog product and one of its valid variants.");
      return;
    }
    const price = Number(linkPrice);
    const mrp = linkMrp.trim() ? Number(linkMrp) : null;
    const stock = Number(linkStock);
    if (!Number.isFinite(price) || price < 0 || (mrp !== null && (!Number.isFinite(mrp) || mrp < price)) || !Number.isInteger(stock) || stock < 0) {
      setMasterError("Enter a valid selling price, MRP (at least the selling price), and whole-number stock of 0 or more.");
      return;
    }
    const linkMeasuredIssue = measureError(linkSellBy, linkMeasure);
    if (linkMeasuredIssue || (linkSellBy !== "pack" && price <= 0)) {
      setMasterError(linkMeasuredIssue || t("m.pricePer", { unit: linkSellBy === "volume" ? "L" : "kg" }));
      return;
    }
    setLinkingMaster(true);
    setMasterError(null);
    try {
      await api.post(`/shops/${shopId}/master-products/${selectedMaster.id}/link`, {
        variant_id: selectedVariantId, price, mrp, stock, available: linkAvailable,
        ...(linkSellBy !== "pack" ? { sell_by: linkSellBy, measure: linkMeasure } : {}),
      });
      await load(shopId);
      setMasterOpen(false);
      setSelectedMaster(null);
    } catch (e: any) {
      setMasterError(e?.status === 409 ? "This product variant is already linked to your shop." : e?.status === 401 ? "Your session expired. Sign in again." : e?.status === 403 ? "You are not authorized to link products to this shop." : e?.status === 404 ? "The shop or master product is no longer available. Refresh and try again." : e?.status === 422 ? `Invalid product or variant details: ${e?.message || "check your entries"}` : e?.message || "Could not link product. Check your connection and try again.");
    } finally {
      setLinkingMaster(false);
    }
  };

  const openNew = () => setEditing({ ...EMPTY, variants: [] });
  const openEdit = (p: Product) => setEditing({ ...p, sell_by: p.sell_by || "pack", measure: p.measure || null, variants: (p.variants || []).map((v) => ({ ...v })) });
  const close = () => setEditing(null);

  const downloadImportTemplate = async () => {
    if (!shopId) return;
    try {
      const blob = await api.downloadShopImportTemplate(shopId);
      if (typeof document === "undefined" || typeof URL === "undefined") {
        setError("Template download is supported in the web seller panel.");
        return;
      }
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "come-in-grocery-import-template.csv";
      anchor.click();
      URL.revokeObjectURL(url);
      setError("Seller product CSV template downloaded. Fill it in, then preview before applying.");
    } catch (e: any) {
      setError(e?.message || "Could not download the seller import template.");
    }
  };

  const uploadUniversalCatalogue = async (files: File[]) => {
    if (!shopId || !files.length) return;
    setCatalogueImporting(true);
    setCatalogueImportJob(null);
    setError(null);
    try {
      const created = await api.createCatalogueImportJob(shopId, files);
      const job = await api.getCatalogueImportJob(shopId, created.job_id);
      setCatalogueImportJob({ ...job, files_processed: created.files_processed, needs_review: created.needs_review, errors: created.errors || [] });
      setCatalogueImportJobs(await api.listCatalogueImportJobs(shopId));
      setError(`Import preview created: ${job.total_records || 0} record(s). Nothing has been published to the customer catalogue.`);
    } catch (e: any) {
      setError(e?.message || "Could not process the selected catalogue files.");
    } finally {
      setCatalogueImporting(false);
      if (catalogueImportRef.current) catalogueImportRef.current.value = "";
    }
  };

  const previewImport = async (file: File) => {
    if (!shopId) return;
    setImportFile(file);
    setImportReport(null);
    setImporting(true);
    setError(null);
    try {
      const report = await api.importShopProducts(shopId, file, file.name, false);
      setImportReport(report);
      if (report.errors?.length) setError(`Import preview found ${report.errors.length} row error(s). No rows were written.`);
    } catch (e: any) { setError(e?.message || "Could not validate this catalog file."); }
    finally { setImporting(false); if (importRef.current) importRef.current.value = ""; }
  };

  const applyImport = async () => {
    if (!shopId || !importFile || !importReport || importReport.errors?.length || !importReport.valid_rows) return;
    setImporting(true);
    setError(null);
    try {
      const report = await api.importShopProducts(shopId, importFile, importFile.name, true);
      setImportReport(report);
      if (report.applied) {
        await load(shopId);
        setError(report.errors?.length ? `Import finished with ${report.errors.length} row error(s). Review the report below.` : `Import complete: ${report.created} created, ${report.updated} updated, ${report.skipped} skipped.`);
        setImportFile(null);
      } else {
        setError(report.errors?.length ? `Import was not applied. Resolve ${report.errors.length} reported row error(s) and retry.` : "Import was not applied. Review the validation report and retry.");
      }
    } catch (e: any) { setError(e?.message || "Import could not be applied."); }
    finally { setImporting(false); }
  };

  const uploadImage = async (file: File) => {
    setUploading(true);
    try {
      const up = await api.upload(file, file.name);
      setEditing((prev) => (prev ? { ...prev, image_url: up.url } : prev));
    } catch (e: any) {
      setError(e?.message);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const save = async () => {
    if (!editing || !shopId) return;
    if (!editing.name.trim() || !editing.category_id.trim() || !editing.description.trim() || !Number.isFinite(editing.price) || editing.price <= 0) {
      setError("Product name, category, a positive selling price, and a description are required.");
      return;
    }
    if (!Number.isInteger(editing.stock) || editing.stock < 0 || (editing.mrp != null && (!Number.isFinite(editing.mrp) || editing.mrp < editing.price))) {
      setError("Enter whole-number stock of 0 or more and an optional MRP greater than or equal to the selling price.");
      return;
    }
    if ((editing.variants || []).some((v) => !v.id.trim() || !v.unit.trim() || !Number.isFinite(v.price) || v.price <= 0 || !Number.isInteger(v.stock) || v.stock < 0 || (v.mrp != null && (!Number.isFinite(v.mrp) || v.mrp < v.price)))) {
      setError("Each variant needs a unit, positive price, whole-number stock of 0 or more, and MRP at least equal to price.");
      return;
    }
    const measuredIssue = measureError(editing.sell_by || "pack", editing.measure);
    if (measuredIssue) { setError(measuredIssue); return; }
    setSaving(true);
    setError(null);
    try {
      const payload: any = { ...editing, sell_by: editing.sell_by || "pack" };
      delete payload.id;
      if (payload.sell_by === "pack") delete payload.measure;
      else payload.variants = [];
      let saved: Product;
      if (editing.id) saved = await api.patch<Product>(`/products/${editing.id}`, payload);
      else saved = await api.post<Product>(`/shops/${shopId}/products`, payload);
      await load(shopId);
      setEditing(null);
    } catch (e: any) {
      setError(e?.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (p: Product) => {
    try {
      await api.del(`/products/${p.id}`);
      if (shopId) await load(shopId);
    } catch (e: any) {
      setError(e?.message);
    }
  };

  if (!user) {
    return (
      <View style={styles.centered}>
        <Text style={styles.msg}>Please sign in to manage products.</Text>
        <Pressable style={styles.primary} onPress={() => router.push("/auth")}>
          <Text style={styles.primaryText}>Sign in</Text>
        </Pressable>
      </View>
    );
  }
  if (loading) return <View style={styles.centered}><ActivityIndicator color={colors.brandPrimary} /></View>;
  if (!shopId) {
    return (
      <View style={styles.centered}>
        <Text style={styles.msg}>No shop is linked to this account. Open Account and choose Add Your Shop to register.</Text>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} style={styles.iconBtn}>
          <Feather name="arrow-left" size={20} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1, minWidth: 140 }}>
          <Text style={styles.title} numberOfLines={1}>Your products</Text>
          <Text style={styles.sub}>{products.length} listed</Text>
        </View>
        <Pressable testID="seller-master-catalog" onPress={openMasterCatalog} style={[styles.addBtn, { backgroundColor: colors.surfaceTertiary }]}>
          <Feather name="search" size={15} color={colors.onSurface} />
          <Text style={[styles.addText, { color: colors.onSurface }]}>Master Catalog</Text>
        </Pressable>
        <Pressable testID="seller-add-product" onPress={openNew} style={styles.addBtn}>
          <Feather name="plus" size={16} color={colors.onBrandPrimary} />
          <Text style={styles.addText}>Add</Text>
        </Pressable>
        {Platform.OS === "web" && <>
          <Pressable testID="seller-import-template" onPress={() => { void downloadImportTemplate(); }} style={[styles.addBtn, { backgroundColor: colors.surfaceTertiary }]}>
            <Feather name="download" size={15} color={colors.onSurface} /><Text style={[styles.addText, { color: colors.onSurface }]}>CSV Template</Text>
          </Pressable>
          <Pressable testID="seller-import-catalog" onPress={() => importRef.current?.click()} style={[styles.addBtn, { backgroundColor: colors.surfaceTertiary }]}>
            <Feather name="upload" size={15} color={colors.onSurface} /><Text style={[styles.addText, { color: colors.onSurface }]}>CSV / Excel</Text>
          </Pressable>
          <Pressable testID="seller-universal-catalogue-import" onPress={() => catalogueImportRef.current?.click()} disabled={catalogueImporting} style={[styles.addBtn, { backgroundColor: colors.surfaceTertiary, opacity: catalogueImporting ? 0.5 : 1 }]}>
            <Feather name="folder-plus" size={15} color={colors.onSurface} /><Text style={[styles.addText, { color: colors.onSurface }]}>{catalogueImporting ? "Reading…" : "Import Catalogue"}</Text>
          </Pressable>
          {/* @ts-ignore */}
          <input ref={importRef as any} type="file" accept=".csv,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" style={{ display: "none" }} onChange={(e: any) => e.target.files?.[0] && previewImport(e.target.files[0])} />
          {/* @ts-ignore */}
          <input ref={catalogueImportRef as any} type="file" multiple accept=".csv,.xlsx,.pdf,.jpg,.jpeg,.png,.webp,.tif,.tiff,.bmp,.zip" style={{ display: "none" }} onChange={(e: any) => e.target.files?.length && uploadUniversalCatalogue(Array.from(e.target.files))} />
        </>}
      </View>
      {shopStatus && shopStatus !== "approved" && <View style={styles.importPanel} testID="shop-draft-status">
        <Text style={styles.pname}>{shopStatus === "suspended" ? "Shop suspended" : "Shop pending approval"}</Text>
        <Text style={styles.pmeta}>{shopStatus === "suspended" ? "Your product listings are not publicly available while this shop is suspended. Contact support for next steps." : "You can prepare draft product listings now. Customers will not see or order these products until the shop is approved."}</Text>
      </View>}
      {(catalogueImporting || catalogueImportJob) && !masterOpen && !editing && <View style={styles.importPanel} testID="seller-universal-import-panel">
        <Text style={styles.pname}>{catalogueImporting ? "Reading catalogue files…" : `Catalogue extraction: ${catalogueImportJob?.total_records || 0} record(s)`}</Text>
        <Text style={styles.pmeta}>Supported in this build: CSV, XLSX, text PDF, scanned PDF/image OCR where runtime support exists, and ZIP batches containing supported files. Extracted records remain staged for seller review; this preview does not create or publish products.</Text>
        {catalogueImportJobs.length > 0 && <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs }}><Text style={styles.pmeta}>Previous import jobs:</Text>{catalogueImportJobs.map((item: any) => <Pressable key={item.job_id} onPress={() => { if (!shopId) return; void api.getCatalogueImportJob(shopId, item.job_id).then(setCatalogueImportJob).catch((e: any) => setError(e?.message || "Could not load import job.")); }} style={styles.catChip}><Text style={styles.addText}>{item.status} · {item.total_records || 0}</Text></Pressable>)}</View>}
        {catalogueImportJob && <Text style={styles.pmeta}>Job: {catalogueImportJob.job_id} · Status: {catalogueImportJob.status} · CHAND: {catalogueImportJob.chand_status || "not configured"} · Records: {catalogueImportJob.total_records} · Errors: {catalogueImportJob.errors?.length || 0}</Text>}
        {catalogueImportJob?.records?.map((record: any, index: number) => {
          const fields = { ...(record.normalized || {}), ...(record.seller_edited_fields || {}) };
          const updateDraft = (key: string, value: string) => setCatalogueImportJob((previous: any) => ({ ...previous, records: previous.records.map((item: any, i: number) => i === index ? { ...item, seller_edited_fields: { ...(item.seller_edited_fields || {}), [key]: value } } : item) }));
          const saveDraft = async () => { if (!shopId) return; const edited = record.seller_edited_fields || {}; await api.editCatalogueImportRecord(shopId, catalogueImportJob.job_id, index, edited); const refreshed = await api.getCatalogueImportJob(shopId, catalogueImportJob.job_id); setCatalogueImportJob(refreshed); };
          const approve = async () => { if (!shopId) return; await api.approveCatalogueImportRecord(shopId, catalogueImportJob.job_id, index); setCatalogueImportJob(await api.getCatalogueImportJob(shopId, catalogueImportJob.job_id)); };
          const reject = async () => { if (!shopId) return; await api.rejectCatalogueImportRecord(shopId, catalogueImportJob.job_id, index); setCatalogueImportJob(await api.getCatalogueImportJob(shopId, catalogueImportJob.job_id)); };
          return <View key={`${record.source_file}-${record.source_location}-${index}`} style={[styles.card, { flexDirection: "column", alignItems: "stretch" }]} testID={`catalogue-import-record-${index}`}>
            <Text style={styles.pname}>Record {index + 1} · {record.review_status || record.status || "NEEDS_REVIEW"}</Text>
            <Text style={styles.pmeta}>Source: {record.source_file} · {record.source_location} · SHA: {(record.source_sha256 || "").slice(0, 12)}</Text>
            <Text style={styles.pmeta}>Original values: {JSON.stringify(record.raw_values || {})}</Text>
            <Text style={styles.pmeta}>CHAND suggestions (not verified): {JSON.stringify(record.chand?.suggested_fields || {})}</Text>
            <Text style={styles.pmeta}>Uncertain: {(record.uncertain_fields || record.chand?.uncertain_fields || []).join(", ") || "None reported"} · Confidence: {JSON.stringify(record.confidence || record.chand?.confidence || {})}</Text>
            <Text style={styles.pmeta}>Field evidence: {JSON.stringify(record.field_evidence || record.chand?.field_evidence || {})}</Text>
            <Text style={styles.pmeta}>Possible duplicates (review only): {JSON.stringify(record.duplicate_candidates || record.chand?.duplicate_candidates || [])}</Text>
            <TextInput accessibilityLabel={`Product name ${index + 1}`} value={String(fields.name ?? "")} onChangeText={(v) => updateDraft("name", v)} placeholder="Product name" style={styles.input} />
            <TextInput accessibilityLabel={`Brand ${index + 1}`} value={String(fields.brand ?? "")} onChangeText={(v) => updateDraft("brand", v)} placeholder="Brand (optional)" style={styles.input} />
            <TextInput accessibilityLabel={`Price ${index + 1}`} value={String(fields.price ?? "")} onChangeText={(v) => updateDraft("price", v)} placeholder="Price (seller verified)" keyboardType="decimal-pad" style={styles.input} />
            <TextInput accessibilityLabel={`MRP ${index + 1}`} value={String(fields.mrp ?? "")} onChangeText={(v) => updateDraft("mrp", v)} placeholder="MRP (optional)" keyboardType="decimal-pad" style={styles.input} />
            <TextInput accessibilityLabel={`Stock ${index + 1}`} value={String(fields.stock ?? "")} onChangeText={(v) => updateDraft("stock", v)} placeholder="Stock (seller verified)" keyboardType="numeric" style={styles.input} />
            <Text style={styles.pmeta}>Choose an existing category:</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs }}>{CATEGORIES.map((category) => <Pressable key={category.id} onPress={() => updateDraft("category_id", category.id)} style={[styles.catChip, fields.category_id === category.id && { backgroundColor: colors.brandPrimary }]}><Text style={styles.addText}>{category.name}</Text></Pressable>)}</View>
            <TextInput accessibilityLabel={`Category ID ${index + 1}`} value={String(fields.category_id ?? "")} onChangeText={(v) => updateDraft("category_id", v)} placeholder="Existing category ID" style={styles.input} />
            <TextInput accessibilityLabel={`Unit ${index + 1}`} value={String(fields.unit ?? "")} onChangeText={(v) => updateDraft("unit", v)} placeholder="Unit" style={styles.input} />
            <TextInput accessibilityLabel={`SKU ${index + 1}`} value={String(fields.sku ?? "")} onChangeText={(v) => updateDraft("sku", v)} placeholder="SKU (optional)" style={styles.input} />
            <TextInput accessibilityLabel={`Barcode ${index + 1}`} value={String(fields.barcode ?? "")} onChangeText={(v) => updateDraft("barcode", v)} placeholder="Barcode (optional)" style={styles.input} />
            <TextInput accessibilityLabel={`Sell by ${index + 1}`} value={String(fields.sell_by ?? "pack")} onChangeText={(v) => updateDraft("sell_by", v)} placeholder="pack / weight / volume" style={styles.input} />
            <TextInput accessibilityLabel={`Minimum quantity ${index + 1}`} value={String(fields.min_qty ?? "")} onChangeText={(v) => updateDraft("min_qty", v)} placeholder="Measured min quantity" keyboardType="numeric" style={styles.input} />
            <TextInput accessibilityLabel={`Quantity step ${index + 1}`} value={String(fields.step ?? "")} onChangeText={(v) => updateDraft("step", v)} placeholder="Measured quantity step" keyboardType="numeric" style={styles.input} />
            <TextInput accessibilityLabel={`Maximum quantity ${index + 1}`} value={String(fields.max_qty ?? "")} onChangeText={(v) => updateDraft("max_qty", v)} placeholder="Measured max quantity" keyboardType="numeric" style={styles.input} />
            <TextInput accessibilityLabel={`Description ${index + 1}`} value={String(fields.description ?? "")} onChangeText={(v) => updateDraft("description", v)} placeholder="Description" style={styles.input} />
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs }}>
              <Pressable onPress={() => { void saveDraft().catch((e: any) => setError(e?.message || "Could not save record edits.")); }} style={styles.catChip}><Text style={styles.addText}>Save edits</Text></Pressable>
              <Pressable disabled={record.review_status === "APPROVED"} onPress={() => { void (async () => { if (Object.keys(record.seller_edited_fields || {}).length) await saveDraft(); await approve(); })().catch((e: any) => setError(e?.message || "Record approval failed.")); }} style={styles.catChip}><Text style={styles.addText}>Approve</Text></Pressable>
              <Pressable onPress={() => { void reject().catch((e: any) => setError(e?.message || "Record rejection failed.")); }} style={styles.catChip}><Text style={styles.addText}>Reject</Text></Pressable>
            </View>
          </View>;
        })}
        {catalogueImportJob?.records?.length > 0 && <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }}>
          <Pressable onPress={() => { if (!shopId) return; void api.bulkApproveCatalogueImportJob(shopId, catalogueImportJob.job_id).then(() => api.getCatalogueImportJob(shopId, catalogueImportJob.job_id)).then(setCatalogueImportJob).catch((e: any) => setError(e?.message || "Bulk approval failed.")); }} style={styles.catChip}><Text style={styles.addText}>Bulk approve eligible</Text></Pressable>
          <Pressable onPress={() => { if (!shopId) return; void api.confirmCatalogueImportApply(shopId, catalogueImportJob.job_id).then((r) => setError(r.message)).catch((e: any) => setError(e?.message || "Apply confirmation failed.")); }} style={styles.catChip}><Text style={styles.addText}>Confirm approved import</Text></Pressable>
        </View>}
        {catalogueImportJob?.errors?.slice(0, 6).map((item: any, index: number) => <Text key={`${item.filename}-${index}`} style={styles.errorText}>{item.filename}: {item.error}</Text>)}
        {!catalogueImporting && <Pressable onPress={() => setCatalogueImportJob(null)} style={[styles.primary, { backgroundColor: colors.surfaceTertiary }]}><Text style={{ color: colors.onSurface, fontWeight: "700" }}>Dismiss extraction preview</Text></Pressable>}
      </View>}
      {(importing || importReport) && !masterOpen && !editing && <View style={styles.importPanel} testID="seller-import-panel">
        <Text style={styles.pname}>{importing ? "Validating catalog import…" : `Import preview: ${importReport?.valid_rows || 0} valid row(s)`}</Text>
        <Text style={styles.pmeta}>Required columns: name, unit, price, stock, category_id, description. Updates require product_id or an existing SKU; new rows require action=create and a stable SKU. Preview checks every row before any write. Existing variants are preserved; import does not create or edit variant definitions. Medical/Pharmacy and Stationery remain directory-only.</Text>
        {importReport && <Text style={styles.pmeta}>Created: {importReport.created} · Updated: {importReport.updated} · Skipped: {importReport.skipped} · Errors: {importReport.errors?.length || 0}</Text>}
        {importReport?.errors?.slice(0, 8).map((item: any) => <Text key={`${item.row}-${item.error}`} style={styles.errorText}>Row {item.row}: {item.error}</Text>)}
        {importFile && importReport && !importReport.errors?.length && importReport.valid_rows > 0 && <Pressable testID="seller-import-apply" onPress={() => { void applyImport(); }} disabled={importing} style={[styles.primary, importing && { opacity: 0.5 }]}><Text style={styles.primaryText}>Apply validated import</Text></Pressable>}
        {!importing && <Pressable onPress={() => { setImportFile(null); setImportReport(null); }} style={[styles.primary, { backgroundColor: colors.surfaceTertiary }]}><Text style={{ color: colors.onSurface, fontWeight: "700" }}>Dismiss import report</Text></Pressable>}
      </View>}

      {masterOpen ? (
        <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120, gap: spacing.sm }} keyboardShouldPersistTaps="handled">
          <Text style={styles.title}>Link from Master Catalog</Text>
          <Text style={styles.pmeta}>Search approved master products, select a catalog variant, then set this shop's price and stock. A product is linked only after the backend confirms success.</Text>
          <View style={{ flexDirection: "row", gap: spacing.sm, alignItems: "center" }}>
            <View style={{ flex: 1 }}><Field label="Search products" value={masterQuery} onChange={setMasterQuery} placeholder="Name or brand" /></View>
            <Pressable onPress={searchMasterCatalog} disabled={masterLoading} style={[styles.primary, { marginTop: spacing.sm, minWidth: 86 }]}>
              {masterLoading ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Text style={styles.primaryText}>Search</Text>}
            </Pressable>
          </View>
          {masterError && <Text accessibilityRole="alert" style={styles.errorText}>{masterError}</Text>}
          {!masterLoading && !masterError && masterResults.length === 0 && <Text style={styles.msg}>{masterQuery.trim() ? "No matching active master products. Try another name or brand." : "Enter a product name or brand and tap Search."}</Text>}
          {masterResults.map((item) => (
            <Pressable key={item.id} testID={`master-result-${item.id}`} onPress={() => { setSelectedMaster(item); setSelectedVariantId(item.variants?.[0]?.id || ""); setLinkPrice(""); setLinkMrp(""); setLinkStock("0"); setLinkAvailable(true); setLinkSellBy("pack"); setLinkMeasure(null); setMasterError(null); }} style={[styles.card, selectedMaster?.id === item.id && { borderColor: colors.brandPrimary, borderWidth: 2 }]}>
              <View style={styles.thumb}>{item.image_url ? <Image source={{ uri: resolveImage(item.image_url) }} style={{ width: "100%", height: "100%" }} /> : <Feather name="package" size={22} color={colors.muted} />}</View>
              <View style={{ flex: 1 }}><Text style={styles.pname}>{item.name}</Text><Text style={styles.pmeta}>{item.brand || "No brand"} · {item.category_id}</Text><Text style={styles.pmeta}>{item.variants?.length || 0} catalog variant(s)</Text></View>
              {selectedMaster?.id === item.id && <Feather name="check-circle" size={18} color={colors.brandPrimary} />}
            </Pressable>
          ))}
          {selectedMaster && (
            <View style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, gap: spacing.sm, marginTop: spacing.sm }}>
              <Text style={styles.pname}>{selectedMaster.name}</Text>
              <Text style={styles.pmeta}>{selectedMaster.description || "Set local selling details for this shop."}</Text>
              <Text style={styles.label}>Catalog variant *</Text>
              {(selectedMaster.variants || []).map((variant) => (
                <Pressable key={variant.id} onPress={() => setSelectedVariantId(variant.id)} style={[styles.card, selectedVariantId === variant.id && { borderColor: colors.brandPrimary, borderWidth: 2 }]}>
                  <View style={{ flex: 1 }}><Text style={styles.pname}>{variant.unit}</Text><Text style={styles.pmeta}>Variant ID: {variant.id}</Text></View>
                  <Feather name={selectedVariantId === variant.id ? "check-circle" : "circle"} size={18} color={colors.brandPrimary} />
                </Pressable>
              ))}
              <SellerMeasuredFields key={selectedMaster.id} sellBy={linkSellBy} measure={linkMeasure} stock={Number(linkStock) || 0} onChange={(next) => { setLinkSellBy(next.sell_by); setLinkMeasure(next.measure); if (next.stock !== undefined) setLinkStock(String(next.stock)); }} />
              <Field label={linkSellBy === "pack" ? "Shop selling price (₹) *" : t("m.pricePer", { unit: linkSellBy === "volume" ? "L" : "kg" })} value={linkPrice} onChange={setLinkPrice} keyboardType="decimal-pad" placeholder="Enter your price" />
              <Field label="Shop MRP (₹)" value={linkMrp} onChange={setLinkMrp} keyboardType="decimal-pad" placeholder="Optional; must be ≥ price" />
              {linkSellBy === "pack" && <Field label="Shop stock (whole units)" value={linkStock} onChange={setLinkStock} keyboardType="number-pad" />}
              <View style={styles.switchRow}><Text style={styles.switchLabel}>Available for sale</Text><Switch value={linkAvailable} onValueChange={setLinkAvailable} /></View>
              <Pressable testID="master-link-submit" onPress={linkMasterProduct} disabled={linkingMaster || !selectedVariantId} style={[styles.primary, (linkingMaster || !selectedVariantId) && { opacity: 0.6 }]}>
                {linkingMaster ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Text style={styles.primaryText}>Link to my shop</Text>}
              </Pressable>
            </View>
          )}
          <Pressable onPress={() => { setMasterOpen(false); setMasterError(null); }} style={[styles.primary, { backgroundColor: colors.surfaceTertiary }]}><Text style={{ color: colors.onSurface, fontWeight: "700" }}>Back to my products</Text></Pressable>
        </ScrollView>
      ) : editing ? (
        <ScrollView
          contentContainerStyle={{ padding: spacing.lg, paddingBottom: 160 }}
          keyboardShouldPersistTaps="handled"
        >
          <Pressable testID="prod-upload" onPress={() => fileRef.current?.click()} style={styles.logoRow}>
            <View style={styles.logoBox}>
              {uploading ? <ActivityIndicator /> : editing.image_url ? (
                <Image source={{ uri: resolveImage(editing.image_url) }} style={styles.logoImg} />
              ) : <Feather name="camera" size={22} color={colors.muted} />}
            </View>
            <Text style={styles.msg}>Product photo</Text>
          </Pressable>
          {Platform.OS === "web" && (
            // @ts-ignore
            <input ref={fileRef as any} type="file" accept="image/*" style={{ display: "none" }} onChange={(e: any) => e.target.files?.[0] && uploadImage(e.target.files[0])} />
          )}

          <Text style={styles.label}>Common item starting points (not live inventory)</Text>
          <Field label="Find a product name" value={suggestionQuery} onChange={setSuggestionQuery} placeholder="e.g. masoor dal, sev, curd" />
          <Text style={styles.pmeta}>Choose a name to prefill the form. No price, stock, brand or product photo is assumed; enter the actual details for your shop.</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs }}>
            {COMMON_PRODUCT_SUGGESTIONS.filter((item) => item.name.toLowerCase().includes(suggestionQuery.trim().toLowerCase())).slice(0, 12).map((item) => (
              <Pressable key={`${item.category_id}:${item.name}`} testID={`suggest-product-${item.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`} onPress={() => setEditing({ ...editing, name: item.name, category_id: item.category_id, brand: "", unit: "", price: 0, mrp: undefined, stock: 0, image_url: undefined, available: true })} style={[styles.catChip, editing.name === item.name && { backgroundColor: colors.brandPrimary }]}>
                <Text style={[styles.catChipText, editing.name === item.name && { color: colors.onBrandPrimary }]}>{item.name}</Text>
              </Pressable>
            ))}
          </View>
          <Field testID="prod-name" label="Name *" value={editing.name} onChange={(v) => setEditing({ ...editing, name: v })} />
          <Field testID="prod-brand" label="Brand" value={editing.brand} onChange={(v) => setEditing({ ...editing, brand: v })} />
          {(editing.sell_by || "pack") === "pack" && <Field testID="prod-unit" label="Unit" value={editing.unit} onChange={(v) => setEditing({ ...editing, unit: v })} placeholder="e.g. 1 kg" />}
          <SellerMeasuredFields key={editing.id || "new"} sellBy={editing.sell_by || "pack"} measure={editing.measure} stock={editing.stock} onChange={(next) => setEditing({ ...editing, ...next, stock: next.stock ?? editing.stock })} />
          <View style={{ flexDirection: "row", gap: spacing.sm }}>
            <View style={{ flex: 1 }}>
              <Field testID="prod-price" label={editing.sell_by === "weight" || editing.sell_by === "volume" ? t("m.pricePer", { unit: editing.sell_by === "volume" ? "L" : "kg" }) : "Price (₹) *"} value={String(editing.price)} onChange={(v) => setEditing({ ...editing, price: Number(v) || 0 })} keyboardType="decimal-pad" />
            </View>
            <View style={{ flex: 1 }}>
              <Field testID="prod-mrp" label="MRP (₹)" value={editing.mrp != null ? String(editing.mrp) : ""} onChange={(v) => setEditing({ ...editing, mrp: v ? Number(v) : undefined })} keyboardType="decimal-pad" />
            </View>
            {(editing.sell_by || "pack") === "pack" && <View style={{ width: 100 }}>
              <Field testID="prod-stock" label="Stock" value={String(editing.stock)} onChange={(v) => setEditing({ ...editing, stock: Number(v) || 0 })} keyboardType="number-pad" />
            </View>}
          </View>

          <Text style={styles.label}>Category *</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: spacing.sm, paddingVertical: 4 }}>
            {CATEGORIES.map((c) => {
              const active = c.id === editing.category_id;
              return (
                <Pressable key={c.id} onPress={() => setEditing({ ...editing, category_id: c.id })} style={[styles.catChip, active && { backgroundColor: colors.brandPrimary }]}>
                  <Text style={[styles.catChipText, active && { color: colors.onBrandPrimary }]}>{c.name}</Text>
                </Pressable>
              );
            })}
          </ScrollView>

          {(editing.sell_by || "pack") === "pack" && <View style={{ marginTop: spacing.lg, gap: spacing.sm }}>
              <Pressable onPress={() => setEditing({ ...editing, variants: [...(editing.variants || []), { id: `pack-${Date.now()}`, unit: "", price: 0, stock: 0, available: true }] })} style={styles.catChip}>
                <Text style={styles.catChipText}>+ Add variant</Text>
              </Pressable>
            {(editing.variants || []).map((variant, index) => (
              <View key={variant.id} style={{ borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.sm, gap: spacing.xs }}>
                <Text style={styles.pmeta}>Stable ID: {variant.id}</Text>
                <Field label="Variant unit / pack" value={variant.unit} onChange={(v) => setEditing({ ...editing, variants: (editing.variants || []).map((x, i) => i === index ? { ...x, unit: v } : x) })} placeholder="e.g. 500 ml" />
                <View style={{ flexDirection: "row", gap: spacing.sm }}>
                  <View style={{ flex: 1 }}><Field label="Variant price (₹)" value={String(variant.price)} onChange={(v) => setEditing({ ...editing, variants: (editing.variants || []).map((x, i) => i === index ? { ...x, price: Number(v) || 0 } : x) })} keyboardType="decimal-pad" /></View>
                  <View style={{ flex: 1 }}><Field label="Variant MRP (₹)" value={variant.mrp == null ? "" : String(variant.mrp)} onChange={(v) => setEditing({ ...editing, variants: (editing.variants || []).map((x, i) => i === index ? { ...x, mrp: v ? Number(v) : undefined } : x) })} keyboardType="decimal-pad" /></View>
                  <View style={{ width: 88 }}><Field label="Stock" value={String(variant.stock ?? 0)} onChange={(v) => setEditing({ ...editing, variants: (editing.variants || []).map((x, i) => i === index ? { ...x, stock: Math.max(0, Number(v) || 0) } : x) })} keyboardType="number-pad" /></View>
                </View>
                <View style={styles.switchRow}><Text style={styles.switchLabel}>Variant available</Text><Switch value={variant.available !== false} onValueChange={(v) => setEditing({ ...editing, variants: (editing.variants || []).map((x, i) => i === index ? { ...x, available: v } : x) })} /></View>
                <Pressable onPress={() => setEditing({ ...editing, variants: (editing.variants || []).filter((_, i) => i !== index) })}><Text style={{ color: colors.error, fontWeight: "700" }}>Remove variant</Text></Pressable>
              </View>
            ))}
            <Text style={styles.pmeta}>Only variants you explicitly save with real prices and stock appear in the live catalog. Products without variants keep the existing single-unit flow.</Text>
          </View>}

          <View style={{ gap: spacing.xs }} testID="product-price-explanation-field">
            <Field testID="prod-description" label="Description / Why is this product priced this way? *" value={editing.description} onChange={(v) => setEditing({ ...editing, description: v })} multiline placeholder="Write in Hindi, English or another supported language…" />
            <Text style={styles.pmeta}>Explain the genuine reason the price may be lower or higher than similar products: quality, material, freshness, brand, durability, manufacturing method, quantity, packaging or warranty. Do not add claims that you cannot verify.</Text>
            <Text style={styles.pmeta}>Examples only — edit to describe your actual product: “हम सीधे निर्माता से सामान खरीदते हैं, इसलिए हमारी कीमत कम है।” · “यह प्रीमियम क्वालिटी का उत्पाद है और इसमें बेहतर सामग्री इस्तेमाल की गई है।” · “इस पैक में अधिक मात्रा है, इसलिए इसकी कुल कीमत थोड़ी ज्यादा है।”</Text>
          </View>
          <View style={styles.switchRow}>
            <Text style={styles.switchLabel}>Available</Text>
            <Switch value={editing.available} onValueChange={(v) => setEditing({ ...editing, available: v })} />
          </View>

          {error && <Text style={styles.errorText}>{error}</Text>}
          <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.lg }}>
            <Pressable onPress={close} style={[styles.primary, { flex: 1, backgroundColor: colors.surfaceTertiary }]}><Text style={{ color: colors.onSurface, fontWeight: "700" }}>Cancel</Text></Pressable>
            <Pressable testID="prod-save" onPress={save} disabled={saving} style={[styles.primary, { flex: 2 }, saving && { opacity: 0.6 }]}>
              {saving ? <ActivityIndicator color={colors.onBrandPrimary} /> : <Text style={styles.primaryText}>{editing.id ? "Save changes" : "Add product"}</Text>}
            </Pressable>
          </View>
        </ScrollView>
      ) : (
        <ScrollView contentContainerStyle={{ padding: spacing.lg, gap: spacing.sm }}>
          {products.length === 0 && (
            <Text style={styles.msg}>You haven't added any products yet. Tap "Add" to list your first product.</Text>
          )}
          {products.map((p) => (
            <View key={p.id} style={styles.card}>
              <View style={styles.thumb}>
                {p.image_url ? <Image source={{ uri: resolveImage(p.image_url) }} style={{ width: "100%", height: "100%" }} /> : <Feather name="package" size={22} color={colors.muted} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.pname}>{p.name}</Text>
                <Text style={styles.pmeta}>{p.sell_by === "weight" || p.sell_by === "volume" ? `₹${p.price}/${p.unit} · sold by ${p.sell_by} · stock ${p.stock / 1000} ${p.unit}` : `₹${p.price} · ${p.unit || "–"} · stock ${p.stock}`}{!p.available && " · hidden"}</Text>
              </View>
              <Pressable onPress={() => openEdit(p)} hitSlop={10}><Feather name="edit-2" size={16} color={colors.brandPrimary} /></Pressable>
              <Pressable onPress={() => remove(p)} hitSlop={10}><Feather name="trash-2" size={16} color={colors.error} /></Pressable>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

function Field({ label, value, onChange, multiline, keyboardType, placeholder, testID }: any) {
  const styles = useStyles();
  const { colors } = useTheme();
  return (
    <View>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.inputWrap, multiline && { alignItems: "flex-start" }]}>
        <TextInput testID={testID} value={value} onChangeText={onChange} placeholder={placeholder} placeholderTextColor={colors.muted} style={[styles.input, multiline && { minHeight: 60 }]} multiline={multiline} keyboardType={keyboardType} />
      </View>
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  importPanel: { marginHorizontal: spacing.lg, marginTop: spacing.sm, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceSecondary, gap: spacing.xs },
  root: { flex: 1, backgroundColor: colors.surface },
  centered: { flex: 1, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", padding: spacing.xl, gap: spacing.md },
  header: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.lg, paddingBottom: spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  iconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  sub: { fontSize: 11, color: colors.muted },
  addBtn: { flexDirection: "row", gap: 4, backgroundColor: colors.brandPrimary, paddingHorizontal: 10, paddingVertical: 8, borderRadius: radius.pill },
  addText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 12 },
  card: { flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, backgroundColor: colors.surface },
  thumb: { width: 56, height: 56, borderRadius: radius.md, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  pname: { fontSize: 14, fontWeight: "700", color: colors.onSurface },
  pmeta: { fontSize: 11, color: colors.muted, marginTop: 2 },
  label: { marginTop: spacing.sm, marginBottom: 6, fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary },
  inputWrap: { backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: Platform.OS === "ios" ? 12 : 8 },
  input: { fontSize: 14, color: colors.onSurface, padding: 0 },
  switchRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: 10, marginTop: spacing.sm },
  switchLabel: { fontSize: 13, color: colors.onSurface },
  catChip: { paddingHorizontal: spacing.md, paddingVertical: 8, borderRadius: radius.pill, backgroundColor: colors.surfaceTertiary },
  catChipText: { fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary },
  logoRow: { flexDirection: "row", alignItems: "center", gap: spacing.md, marginVertical: spacing.sm },
  logoBox: { width: 72, height: 72, borderRadius: radius.md, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  logoImg: { width: "100%", height: "100%" },
  msg: { fontSize: 14, color: colors.onSurface },
  primary: { backgroundColor: colors.brandPrimary, paddingVertical: 12, paddingHorizontal: spacing.lg, borderRadius: radius.md, alignItems: "center" },
  primaryText: { color: colors.onBrandPrimary, fontWeight: "800" },
  errorText: { color: colors.error, fontSize: 12, marginTop: spacing.sm },
}));
