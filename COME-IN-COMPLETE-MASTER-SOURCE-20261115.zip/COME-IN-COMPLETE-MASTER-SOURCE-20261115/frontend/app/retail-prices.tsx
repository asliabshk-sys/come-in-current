import Feather from "@react-native-vector-icons/feather";
import { useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/lib/api";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

type RetailOffer = {
  id: string;
  retailer: string;
  retailer_shop_id: string;
  name: string;
  brand?: string;
  sku?: string;
  unit: string;
  price: number;
  stock: number;
  last_updated?: string | null;
  imported_at?: string;
  source_url?: string | null;
};

function formatTimestamp(value?: string | null) {
  if (!value) return "Source timestamp not provided";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

export default function RetailPricesScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const styles = useStyles();
  const [offers, setOffers] = useState<RetailOffer[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get<RetailOffer[]>("/catalog/retail-prices", false)
      .then((rows) => setOffers(Array.isArray(rows) ? rows : []))
      .catch((e: any) => setError(e?.message || "Retail price data is unavailable."))
      .finally(() => setLoading(false));
  }, []);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return offers;
    return offers.filter((row) => `${row.name} ${row.brand || ""} ${row.retailer} ${row.retailer_shop_id} ${row.sku || ""}`.toLowerCase().includes(q));
  }, [offers, query]);

  return (
    <View style={styles.root}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} style={styles.iconBtn} accessibilityLabel="Go back"><Feather name="arrow-left" size={20} color={colors.onSurface} /></Pressable>
        <View style={{ flex: 1 }}><Text style={styles.title}>Retail Price Compare</Text><Text style={styles.sub}>Imported retailer data · source and update time shown</Text></View>
      </View>
      <View style={styles.searchWrap}><Feather name="search" size={16} color={colors.muted} /><TextInput value={query} onChangeText={setQuery} placeholder="Search product, brand or retailer" placeholderTextColor={colors.muted} style={styles.search} /></View>
      <Text style={styles.note}>Prices are snapshots from the last successful authorized import, not guaranteed live prices. Verify source timestamp and stock before relying on them. Checkout prices for COME-IN shops remain independently verified.</Text>
      {loading ? <View style={styles.centered}><ActivityIndicator color={colors.brandPrimary} /></View> : error ? <Text style={styles.note}>{error}</Text> : <FlatList data={visible} keyExtractor={(item) => item.id} contentContainerStyle={{ padding: spacing.md, gap: spacing.sm }} ListEmptyComponent={<Text style={styles.note}>No successfully imported retailer prices are available yet.</Text>} renderItem={({ item }) => (
        <View style={styles.card}>
          <Text style={styles.product}>{item.name}</Text>
          <Text style={styles.meta}>{item.brand || "Brand not provided"} · {item.unit}</Text>
          <View style={styles.priceRow}><Text style={styles.price}>₹{Number(item.price).toFixed(2)}</Text><Text style={styles.stock}>{item.stock > 0 ? `Stock reported: ${item.stock}` : "Out of stock / no stock reported"}</Text></View>
          <Text style={styles.meta}>Source: {item.retailer} · Store ID: {item.retailer_shop_id}</Text>
          <Text style={styles.meta}>Retailer last updated: {formatTimestamp(item.last_updated)}</Text>
          <Text style={styles.meta}>Imported into COME-IN: {formatTimestamp(item.imported_at)}</Text>
          {item.source_url ? <Text style={styles.meta}>Source reference: {item.source_url}</Text> : null}
        </View>
      )} />}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surfaceSecondary },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.lg, paddingBottom: spacing.sm, backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  iconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 18, fontWeight: "800", color: colors.onSurface },
  sub: { fontSize: 11, color: colors.muted },
  searchWrap: { flexDirection: "row", alignItems: "center", gap: spacing.sm, margin: spacing.md, paddingHorizontal: spacing.md, borderRadius: radius.md, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  search: { flex: 1, minHeight: 44, color: colors.onSurface },
  note: { marginHorizontal: spacing.md, marginBottom: spacing.sm, color: colors.muted, fontSize: 11, lineHeight: 16 },
  centered: { flex: 1, alignItems: "center", justifyContent: "center" },
  card: { backgroundColor: colors.surface, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, gap: 4 },
  product: { fontSize: 14, fontWeight: "800", color: colors.onSurface },
  meta: { fontSize: 11, color: colors.muted },
  priceRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.sm, flexWrap: "wrap" },
  price: { fontSize: 18, fontWeight: "900", color: colors.brandPrimary },
  stock: { fontSize: 11, color: colors.muted },
}));
