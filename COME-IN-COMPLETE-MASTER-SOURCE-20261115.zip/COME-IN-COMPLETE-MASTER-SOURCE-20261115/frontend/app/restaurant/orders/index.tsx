import { useCallback, useState } from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';

import { api } from '@/src/lib/api';
import { useAuth } from '@/src/store/auth';
import { RestaurantPage, rs } from '@/src/restaurant/RestaurantPage';
import { restaurantTheme as t } from '@/src/restaurant/theme';

type RestaurantOrder = {
  id: string;
  ref: string;
  restaurant_name: string;
  status: string;
  payment_method: string;
  payment_status: string;
  total: number;
  created_at: string;
  items: Array<{ name?: string; quantity?: number }>;
  fulfillment: 'delivery' | 'pickup';
  delivery_address?: string;
};

export default function RestaurantOrdersScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const [orders, setOrders] = useState<RestaurantOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadOrders = useCallback(async (isActive: () => boolean = () => true) => {
    if (!user || user.role !== 'customer') {
      if (isActive()) {
        setOrders([]);
        setLoading(false);
      }
      return;
    }
    if (isActive()) {
      setLoading(true);
      setError('');
    }
    try {
      const rows = await api.get<RestaurantOrder[]>('/restaurant/orders/mine');
      if (isActive()) setOrders(Array.isArray(rows) ? rows : []);
    } catch (e: any) {
      if (isActive()) setError(e?.message || 'Restaurant order history could not be loaded. Please try again.');
    } finally {
      if (isActive()) setLoading(false);
    }
  }, [user?.id, user?.role]);

  useFocusEffect(useCallback(() => {
    let active = true;
    void loadOrders(() => active);
    return () => { active = false; };
  }, [loadOrders]));

  return (
    <RestaurantPage title="Your restaurant orders" subtitle="Your restaurant orders only · grocery orders are shown separately">
      {user === null ? (
        <View style={rs.card}>
          <ActivityIndicator color={t.primary} />
          <Text style={rs.muted}>Checking your account…</Text>
        </View>
      ) : !user ? (
        <View style={rs.card}>
          <Text style={rs.muted}>Sign in to view your restaurant order history.</Text>
          <Pressable style={rs.button} onPress={() => router.push({ pathname: '/auth', params: { next: '/restaurant/orders' } } as never)}>
            <Text style={rs.buttonText}>Sign in</Text>
          </Pressable>
        </View>
      ) : user.role !== 'customer' ? (
        <View style={rs.card}>
          <Text style={rs.muted}>Restaurant order history is available to customer accounts. Your restaurant incoming orders remain in the Restaurant Dashboard.</Text>
        </View>
      ) : loading ? (
        <View style={rs.card}>
          <ActivityIndicator color={t.primary} />
          <Text style={rs.muted}>Loading your restaurant orders…</Text>
        </View>
      ) : error ? (
        <View style={rs.card}>
          <Text style={rs.muted}>{error}</Text>
          <Pressable style={rs.button} onPress={() => { void loadOrders(); }}>
            <Text style={rs.buttonText}>Try again</Text>
          </Pressable>
        </View>
      ) : orders.length === 0 ? (
        <View style={rs.card}>
          <Text style={rs.heading}>No restaurant orders yet</Text>
          <Text style={rs.muted}>When you place a restaurant order, it will appear here. Grocery orders are kept in your separate order history.</Text>
          <Pressable style={rs.button} onPress={() => router.replace('/restaurant' as never)}>
            <Text style={rs.buttonText}>Explore restaurants</Text>
          </Pressable>
        </View>
      ) : (
        orders.map((order) => (
          <Pressable
            key={order.id}
            style={rs.card}
            onPress={() => router.push({ pathname: '/restaurant/orders/[id]', params: { id: order.id } } as never)}
            accessibilityRole="button"
            accessibilityLabel={`View restaurant order ${order.ref}`}
          >
            <View style={rs.row}>
              <Text style={[rs.heading, { flex: 1 }]}>{order.ref}</Text>
              <Text style={{ color: t.primary, fontSize: 11, fontWeight: '900' }}>{(order.status || 'unknown').replaceAll('_', ' ').toUpperCase()}</Text>
            </View>
            <Text style={rs.muted}>{order.restaurant_name} · ₹{order.total}</Text>
            <Text style={rs.muted}>{order.items?.length || 0} items · {order.fulfillment === 'pickup' ? 'Pickup' : 'Delivery'} · Payment: {order.payment_status}</Text>
            <Text style={rs.muted}>{order.created_at ? new Date(order.created_at).toLocaleString() : ''}</Text>
            <Text style={{ color: t.primary, fontSize: 12, fontWeight: '800' }}>View order details →</Text>
          </Pressable>
        ))
      )}
    </RestaurantPage>
  );
}
