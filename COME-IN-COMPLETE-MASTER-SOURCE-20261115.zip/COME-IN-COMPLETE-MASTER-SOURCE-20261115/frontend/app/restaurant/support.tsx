/** Compatibility route: all customer support is handled by the shared CHAND Help & Support flow. */
import { Redirect, useLocalSearchParams } from 'expo-router';
export default function RestaurantSupportAlias() {
  const { order_id, order_kind } = useLocalSearchParams<{ order_id?: string; order_kind?: string }>();
  const suffix = order_id ? `&order_id=${encodeURIComponent(order_id)}&order_kind=${order_kind === 'grocery' ? 'grocery' : 'restaurant'}` : '';
  return <Redirect href={`/chand?openHelp=1${suffix}` as never} />;
}
