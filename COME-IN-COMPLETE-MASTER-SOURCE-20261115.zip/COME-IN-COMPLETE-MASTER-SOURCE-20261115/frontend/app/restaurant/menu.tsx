export { default } from './categories';
