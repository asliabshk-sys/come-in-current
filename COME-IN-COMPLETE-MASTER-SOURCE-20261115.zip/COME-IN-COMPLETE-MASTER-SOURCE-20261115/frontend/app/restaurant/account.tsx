/**
 * Restaurant Mode Account entry point.
 * Keep this route as a compatibility alias for existing Restaurant links,
 * but always use the one shared Shopping Account screen and AuthProvider.
 * Restaurant-specific order history remains available through its order routes.
 */
import { Redirect } from 'expo-router';

export default function RestaurantAccount() {
  return <Redirect href="/(tabs)/account" />;
}
