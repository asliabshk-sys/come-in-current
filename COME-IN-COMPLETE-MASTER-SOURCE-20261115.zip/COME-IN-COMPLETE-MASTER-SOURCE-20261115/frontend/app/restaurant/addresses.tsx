/** Compatibility route: saved addresses are managed by the shared account address book. */
import { Redirect } from 'expo-router';
export default function RestaurantAddressesAlias() { return <Redirect href="/addresses" />; }
