import Feather from "@react-native-vector-icons/feather";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AnnouncementBanner } from "@/src/components/AnnouncementBanner";
import { useT } from "@/src/i18n";
import { api } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { useTheme, spacing, radius } from "@/src/theme";

type Notice = { id: string; kind: string; title: string; body: string; read: boolean; created_at?: string; data?: Record<string, any> };
const ICONS: Record<string, React.ComponentProps<typeof Feather>["name"]> = { order_status: "package", order_help: "life-buoy", restock: "rotate-ccw", announcement: "volume-2", new_order: "shopping-cart" };

/** In-app notification center (Task 20). Push delivery is not configured; nothing is sent to devices. */
export default function NotificationsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { t } = useT();
  const { user } = useAuth();
  const [items, setItems] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(Boolean(user));
  const [error, setError] = useState("");

  const load = useCallback(() => {
    if (!user) return;
    setLoading(true);
    api.get<{ items: Notice[] }>("/notifications/mine")
      .then((r) => { setItems(r.items || []); setError(""); })
      .catch((e: any) => setError(e?.message || t("n.loadError")))
      .finally(() => setLoading(false));
  }, [user, t]);
  useEffect(() => { load(); }, [load]);

  const open = async (n: Notice) => {
    if (!n.read) { api.post(`/notifications/${n.id}/read`, {}).catch(() => {}); setItems((list) => list.map((x) => (x.id === n.id ? { ...x, read: true } : x))); }
    if (n.data?.seller) router.push((n.data.order_kind === "restaurant" ? "/restaurant/dashboard" : "/seller/orders") as never);
    else if (n.data?.product_id) router.push(`/product/${n.data.product_id}`);
    else if (n.data?.order_id) router.push({ pathname: "/order-tracking", params: { id: n.data.order_id, kind: n.data.order_kind || "grocery" } } as never);
  };
  const readAll = async () => { await api.post("/notifications/read-all", {}).catch(() => {}); setItems((list) => list.map((x) => ({ ...x, read: true }))); };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surfaceSecondary }} contentContainerStyle={{ padding: spacing.lg, paddingTop: insets.top + spacing.lg, gap: spacing.md }}>
      <Pressable accessibilityRole="button" testID="notifications-back" onPress={() => router.back()} style={styles.back}><Feather name="arrow-left" size={18} color={colors.onSurface}/><Text style={{ color: colors.onSurface, fontWeight: "700" }}>{t("n.back")}</Text></Pressable>
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
        <Text style={{ color: colors.onSurface, fontSize: 26, fontWeight: "900" }}>{t("n.title")}</Text>
        {items.some((x) => !x.read) && <Pressable testID="notifications-read-all" onPress={readAll}><Text style={{ color: colors.brandPrimary, fontWeight: "800" }}>{t("n.readAll")}</Text></Pressable>}
      </View>
      <AnnouncementBanner />
      {!user && <Text style={{ color: colors.muted }} testID="notifications-signin">{t("n.signIn")}</Text>}
      {loading && <ActivityIndicator color={colors.brandPrimary} />}
      {error ? <Text style={{ color: colors.error }} testID="notifications-error">{error}</Text> : null}
      {user && !loading && !error && items.length === 0 && <Text style={{ color: colors.muted }} testID="notifications-empty">{t("n.empty")}</Text>}
      {items.map((n) => (
        <Pressable key={n.id} testID={`notification-${n.id}`} onPress={() => void open(n)} style={[styles.card, { backgroundColor: n.read ? colors.surface : colors.brandTertiary, borderColor: colors.border }]}>
          <Feather name={ICONS[n.kind] || "bell"} size={18} color={colors.brandPrimary} />
          <View style={{ flex: 1, gap: 2 }}>
            <Text style={{ color: colors.onSurface, fontWeight: n.read ? "600" : "900" }}>{n.title}</Text>
            <Text style={{ color: colors.onSurfaceSecondary }}>{n.body}</Text>
            {n.created_at ? <Text style={{ color: colors.muted, fontSize: 11 }}>{new Date(n.created_at).toLocaleString()}</Text> : null}
          </View>
        </Pressable>
      ))}
      <View style={[styles.note, { borderColor: colors.border }]}>
        <Feather name="bell-off" size={16} color={colors.muted}/>
        <Text style={{ color: colors.muted, flex: 1, fontSize: 12 }}>{t("n.pushOff")}</Text>
      </View>
    </ScrollView>
  );
}
const styles = StyleSheet.create({ back: { flexDirection: "row", alignItems: "center", gap: 8, alignSelf: "flex-start", paddingVertical: 8 }, card: { flexDirection: "row", gap: spacing.md, borderWidth: 1, borderRadius: radius.lg, padding: spacing.md }, note: { flexDirection: "row", gap: 8, borderWidth: 1, borderRadius: radius.md, padding: spacing.md } });
