import Feather from "@react-native-vector-icons/feather";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/lib/api";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Tracking = { order_id: string; kind: string; status: string; status_history?: { status: string; at: string; note?: string }[]; tracking_active: boolean; location: null | { latitude: number; longitude: number; accuracy_m?: number | null; updated_at: string }; eta_minutes: number | null; map_provider: string | null; message: string };
type GroceryOrderDetails = { id: string; ref: string; status: string; items: { product_id: string; variant_id?: string | null; name: string; unit: string; qty: number; price: number }[]; subtotal: number; delivery_fee: number; total: number; payment_method: string; payment_status: string; delivery_address: string; status_history?: { status: string; at: string; note?: string }[] };

export default function OrderTrackingScreen() {
  const { id, kind } = useLocalSearchParams<{ id: string; kind?: string }>();
  const orderKind = kind === "restaurant" ? "restaurant" : kind === "local_shop" ? "local_shop" : "grocery";
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const styles = useStyles();
  const { colors } = useTheme();
  const [tracking, setTracking] = useState<Tracking | null>(null);
  const [order, setOrder] = useState<GroceryOrderDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    if (!id) return;
    try {
      const [nextTracking, nextOrder] = await Promise.all([
        api.get<Tracking>(`/orders/${encodeURIComponent(id)}/tracking?kind=${orderKind}`),
        orderKind === "grocery" ? api.get<GroceryOrderDetails>(`/orders/${encodeURIComponent(id)}`) : Promise.resolve(null),
      ]);
      setTracking(nextTracking);
      setOrder(nextOrder);
      setError("");
    }
    catch (e: any) {
      setTracking(null);
      setOrder(null);
      setError(e?.message || "Tracking could not be loaded. Sign in with the account that owns this order.");
    }
    finally { setLoading(false); }
  }, [id, orderKind]);
  useEffect(() => { void load(); const timer = setInterval(() => { void load(); }, 10000); return () => clearInterval(timer); }, [load]);

  return <View style={styles.root}>
    <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
      <Pressable accessibilityLabel="Go back" onPress={() => router.back()} style={styles.iconBtn}><Feather name="arrow-left" size={20} color={colors.onSurface} /></Pressable>
      <View style={{ flex: 1 }}><Text style={styles.title}>Delivery tracking</Text><Text style={styles.subtitle}>Updates refresh every 10 seconds while this screen is open.</Text></View>
    </View>
    <ScrollView contentContainerStyle={{ padding: spacing.lg, gap: spacing.md }}>
      {loading ? <ActivityIndicator color={colors.brandPrimary} /> : null}
      {error ? <View style={styles.card}><Text style={styles.error}>{error}</Text><Pressable onPress={() => { setLoading(true); void load(); }} style={styles.button}><Text style={styles.buttonText}>Try again</Text></Pressable></View> : null}
      {tracking ? <>
        {order ? <View style={styles.card}>
          <Text style={styles.eyebrow}>ORDER DETAILS · {order.ref}</Text>
          {order.items.map((line, index) => <View key={`${line.product_id}:${line.variant_id || "base"}:${index}`} style={styles.orderLine}>
            <Text style={styles.body}>{line.quantity_label ? `${line.quantity_label} × ${line.name} (₹${line.price}/${line.unit})` : `${line.qty} × ${line.name} (${line.unit})`}</Text>
            <Text style={styles.body}>₹{(line.line_total != null ? Number(line.line_total) : Number(line.price) * Number(line.qty)).toFixed(2)}</Text>
          </View>)}
          <View style={styles.orderTotals}><Text style={styles.body}>Subtotal ₹{order.subtotal} · Delivery ₹{order.delivery_fee}</Text><Text style={styles.total}>Total ₹{order.total}</Text></View>
          <Text style={styles.body}>Payment: {order.payment_method} · {order.payment_status}</Text>
          {order.delivery_address ? <Text style={styles.body}>Address: {order.delivery_address}</Text> : null}
          {order.status_history?.length ? <View style={styles.history}><Text style={styles.eyebrow}>STATUS HISTORY</Text>{order.status_history.map((entry, index) => <Text key={`${entry.status}:${index}`} style={styles.body}>{entry.status.replaceAll("_", " ")} · {new Date(entry.at).toLocaleString()}{entry.note ? ` · ${entry.note}` : ""}</Text>)}</View> : null}
        </View> : null}
        <View style={styles.card}>
          <Text style={styles.eyebrow}>ORDER STATUS</Text><Text style={styles.status}>{tracking.status.replaceAll("_", " ").toUpperCase()}</Text>
          <Text style={styles.body}>{tracking.message}</Text>
          {!order && tracking.status_history?.length ? <View style={styles.history}><Text style={styles.eyebrow}>STATUS HISTORY</Text>{tracking.status_history.map((entry, index) => <Text key={`${entry.status}:${index}`} style={styles.body}>{entry.status.replaceAll("_", " ")} · {new Date(entry.at).toLocaleString()}{entry.note ? ` · ${entry.note}` : ""}</Text>)}</View> : null}
          {tracking.location ? <><Text style={styles.body}>Latest coordinates: {tracking.location.latitude.toFixed(5)}, {tracking.location.longitude.toFixed(5)}</Text>{tracking.location.accuracy_m != null ? <Text style={styles.body}>Reported accuracy: ±{Math.round(tracking.location.accuracy_m)} m</Text> : null}<Text style={styles.body}>Last update: {new Date(tracking.location.updated_at).toLocaleString()}</Text><Text style={styles.body}>Map/route and ETA are unavailable because no mapping provider is configured.</Text></> : <Text style={styles.body}>No driver movement, route, or ETA is simulated. A location appears only after an authorized order operator submits a valid update.</Text>}
        </View>
        <View style={styles.card}><Feather name="shield" size={20} color={colors.brandPrimary} /><Text style={styles.body}>This tracking information is private to the order's customer and authorized shop/restaurant operator.</Text></View>
      </> : null}
    </ScrollView>
  </View>;
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surfaceSecondary },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.md, paddingHorizontal: spacing.lg, paddingBottom: spacing.md, backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  iconBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 18, fontWeight: "800", color: colors.onSurface }, subtitle: { fontSize: 11, color: colors.muted, marginTop: 3 },
  card: { backgroundColor: colors.surface, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, gap: spacing.sm },
  orderLine: { flexDirection: "row", justifyContent: "space-between", gap: spacing.md },
  orderTotals: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border, paddingTop: spacing.sm, gap: 4 },
  total: { fontSize: 15, fontWeight: "900", color: colors.brandPrimary },
  history: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border, paddingTop: spacing.sm, gap: 5 },
  eyebrow: { fontSize: 10, fontWeight: "800", color: colors.muted, letterSpacing: 1 }, status: { fontSize: 17, fontWeight: "900", color: colors.brandPrimary }, body: { fontSize: 13, lineHeight: 19, color: colors.onSurfaceSecondary }, error: { fontSize: 13, color: colors.error }, button: { backgroundColor: colors.brandPrimary, borderRadius: radius.md, padding: spacing.md, alignItems: "center" }, buttonText: { color: colors.onBrandPrimary, fontWeight: "800" },
}));
