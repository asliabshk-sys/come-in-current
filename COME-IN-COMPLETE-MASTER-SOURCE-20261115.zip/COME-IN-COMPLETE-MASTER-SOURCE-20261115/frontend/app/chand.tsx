import Feather from "@react-native-vector-icons/feather";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioRecorder } from "expo-audio";
import { useRouter } from "expo-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocalSearchParams } from "expo-router";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, resolveImage } from "@/src/lib/api";
import { Product } from "@/src/data/catalog";
import { formatAmount, isMeasured, lineAmount } from "@/src/lib/measure";
import { buildPartyPlanGroups, DEFAULT_PARTY_SERVING_ASSUMPTIONS, PARTY_OCCASION_SERVING_ASSUMPTIONS, type PartyNeed, type PartyServingAssumptions } from "@/src/lib/chand-party-planner";
import { ProductCard } from "@/src/components/ProductCard";
import { useCart } from "@/src/store/cart";
import { useT } from "@/src/i18n";
import { useAuth } from "@/src/store/auth";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

// Legacy DEMO label is now localized as chand.demo; Original Hindi brand welcome wording preserved in locale resources: "आपका अपना स्मार्ट साथी".
// Security reminder shown in localized help copy: Never share passwords, OTPs or payment credentials.
type RoleMode = "customer" | "shopkeeper" | "restaurant" | "services";
type Message = { id: string; from: "assistant" | "user"; text: string; products?: Product[] };
type ChandPlanLine = { product: Product; quantity: number; variantId?: string; verifiedTotal?: number; partyNeed?: PartyNeed };
type SupportOrder = { id: string; ref?: string; status?: string; payment_status?: string; refund_status?: string; total?: number; restaurant_name?: string; created_at?: string; kind: "grocery" | "restaurant" };
type SupportTicket = { id: string; ref: string; category: string; message: string; status: string; order_id?: string; created_at?: string };
const ROLE_KEYS: Record<RoleMode, string> = { customer: "chand.role.customer", shopkeeper: "chand.role.shopkeeper", restaurant: "chand.role.restaurant", services: "chand.role.services" };
const SUGGESTION_KEYS: Record<RoleMode, string[]> = {
  customer: ["chand.suggest.customer.1", "chand.suggest.customer.2", "chand.suggest.customer.3"],
  shopkeeper: ["chand.suggest.shopkeeper.1", "chand.suggest.shopkeeper.2", "chand.suggest.shopkeeper.3"],
  restaurant: ["chand.suggest.restaurant.1", "chand.suggest.restaurant.2", "chand.suggest.restaurant.3"],
  services: ["chand.suggest.services.1", "chand.suggest.services.2", "chand.suggest.services.3"],
};

function demoReply(message: string, role: RoleMode): string {
  const q = message.toLowerCase();
  // Deterministic, offline guidance only. Never claim that an order, payment,
  // complaint, cancellation, or refund has been changed by this chat.
  if (/(payment.*(deduct|debit).*(order|missing)|deduct.*but.*order|order.*not.*placed|ऑर्डर.*नहीं.*मिला)/i.test(q)) {
    return "Demo Mode: Agar payment deduct hui hai lekin order COME-IN mein nahi dikh raha, pehle Orders aur payment app/bank ka status check karein. Dobara payment turant na karein. Help & Support mein payment issue select karke date, amount aur transaction reference (sensitive credentials nahi) likhein. CHAND yahan payment ya order verify nahi kar raha.";
  }
  if (/(duplicate.*(payment|charge)|double.*(payment|charge)|twice.*paid|दो बार.*(पेमेंट|पैसे))/i.test(q)) {
    return "Demo Mode: Duplicate payment ke liye dono transaction references aur amounts note karein, aur Help & Support mein Payment issue submit karein. OTP, PIN, CVV ya password share na karein. Yeh chat duplicate charge verify ya reverse nahi karti.";
  }
  if (/(missing item|item missing|item.*not.*received|कम.*आया|सामान.*नहीं.*मिला|छूटा हुआ)/i.test(q)) {
    return "Demo Mode: Missing item ke liye order select karke item ka naam, quantity aur package/photo ka detail Help & Support mein dein. CHAND order inspect nahi kar raha aur complaint tabhi record hogi jab existing support API se confirmation mile.";
  }
  if (/(delay|delayed|late delivery|not arrived|नहीं पहुँचा|देरी)/i.test(q)) {
    return "Demo Mode: Delayed order ke liye existing Orders/Order Tracking screen par latest backend status check karein. Agar status stale ho ya order na aaye, Help & Support mein order reference aur delay details bhejein. Main live location ya delivery time confirm nahi kar sakta.";
  }
  if (/(wrong item|incorrect item|damaged|broken|खराब|गलत सामान|टूटा)/i.test(q)) {
    return "Demo Mode: Wrong ya damaged item ke liye order select karein aur item, quantity, issue aur available photo details Help & Support mein dein. Return/replacement ya refund approve nahi hua hai; actual next step support team ke backend status par depend karega.";
  }
  if (/(cancel|cancellation|रद्द)/i.test(q)) {
    return "Demo Mode: Cancellation ke liye existing Orders screen par us order ke available actions aur current status check karein. Main yahan order cancel nahi kar sakta. Agar cancel option nahi hai ya status unclear hai, Help & Support mein order reference ke saath request bhejein.";
  }
  if (/(refund.*status|status.*refund|refund kab|रिफंड.*(स्टेटस|कब)|पैसे.*वापस)/i.test(q)) {
    return "Demo Mode: Actual refund status sirf authenticated order/support details mein backend se report hua status hai. Help & Support mein apna order select karke jo status dikhaya gaya hai woh check karein. Customer refund-request API available nahi hai; support case refund approval ya completed payment nahi hota.";
  }
  if (/(refund|रिफंड)/i.test(q)) {
    return "Demo Mode: Refund help ke liye Help & Support mein apna order select karke details submit kar sakte hain. Existing API sirf support case banati hai; CHAND refund request, approval ya payment execute nahi karta. Backend status confirmation ke bina refund complete nahi maana ja sakta.";
  }
  if (/(order|ऑर्डर|status|स्टेटस|track)/i.test(q)) {
    return "Demo Mode: Main yahan aapka real order record access nahi kar raha. Apne actual orders aur backend-reported status ke liye COME-IN ke Orders/Order Tracking page par jaayein.";
  }
  if (/(electrician|plumb|clean|service|provider|सेवा|इलेक्ट्रीशियन)/i.test(q) || role === "services") {
    return "Demo Mode: Home Services integration abhi live provider availability se connected nahi hai. Aap existing Home Services page khol kar available categories dekh sakte hain; yahan koi provider ya booking confirm nahi ki ja rahi.";
  }
  if (/(restaurant|dinner|food|menu|खाना|डिनर)/i.test(q) || role === "restaurant") {
    return "Demo Mode: Restaurant Mode ka live menu yahan query nahi hua. Actual restaurants aur menu dekhne ke liye Restaurant Mode kholein. Main sample recommendation ya order availability ko real nahi bataunga.";
  }
  if (/(stock|product|seller|shop|sales|स्टॉक|दुकान)/i.test(q) || role === "shopkeeper") {
    return "Demo Mode: Seller records aur stock live backend se load nahi kiye gaye. Apne authorized listings aur orders ke liye existing seller screens use karein. Main yahan sirf reply draft aur planning mein madad kar sakta hoon.";
  }
  if (/(ration|grocery|₹|budget|cheap|cheapest|सस्ता|किराना)/i.test(q)) {
    return "Demo Mode: Budget samajh gaya. Live catalog, stock aur prices abhi CHAND se connected nahi hain, isliye main products ya prices invent nahi karunga. COME-IN Categories/Search mein current options check karein.";
  }
  return "Namaste! Main CHAND by COME-IN hoon — aapka apna smart saathi. Yeh no-cost Demo Mode hai; abhi live AI ya private account data connected nahi hai. Main general guidance aur reply drafts mein madad kar sakta hoon. Agar request live order, payment, booking ya account data maangti hai, to main use yahan verify nahi kar sakta; relevant existing COME-IN screen ya Help & Support use karein. Main unavailable information invent nahi karunga.";
}


type AssistantProduct = {
  id: string; name: string; brand?: string; category?: string; category_id?: string; price_inr?: number; mrp_inr?: number | null; price?: number; mrp?: number | null;
  stock?: number; unit?: string; shop_id?: string; shop_name?: string; shop_type?: string; description?: string; image_url?: string | null;
  available?: boolean; shop_delivery_available?: boolean; shop_pickup_available?: boolean;
  sell_by?: "pack" | "weight" | "volume"; measure?: Product["measure"];
  variants?: Array<{ id: string; name?: string; unit?: string; price_inr?: number; mrp_inr?: number; price?: number; mrp?: number; stock?: number; available?: boolean }>;
};
type AssistantContext = {
  source: string; answer?: string | null; ai_provider?: string; categories: string[];
  products: AssistantProduct[];
  shops: Array<{ name: string; shop_type?: string; area?: string; category?: string }>;
  restaurants: Array<{ name: string; cuisine?: string; available?: boolean }>;
  restaurant_menu_items: Array<{ name: string; restaurant_name?: string; category?: string; price_inr?: number; description?: string }>;
  home_services: Array<{ name: string; category?: string; service_area?: string; visit_fee_inr?: number | null }>;
  counts: { products: number; shops: number; restaurants: number; home_services: number };
};

function mapAssistantProducts(items: AssistantProduct[] = []): Product[] {
  return items.filter((item) => item.id && item.name && item.available !== false).map((item): Product => {
    const categoryId = item.category_id || "grocery";
    return {
      id: item.id, name: item.name, brand: item.brand || "", unit: item.unit || "unit",
      price: Number(item.variants?.[0]?.price_inr ?? item.variants?.[0]?.price ?? item.price_inr ?? item.price ?? 0),
      mrp: (item.variants?.[0]?.mrp_inr ?? item.variants?.[0]?.mrp) == null ? ((item.mrp_inr ?? item.mrp) == null ? undefined : Number(item.mrp_inr ?? item.mrp)) : Number(item.variants?.[0]?.mrp_inr ?? item.variants?.[0]?.mrp),
      image: resolveImage(item.image_url) || "", categoryId, description: item.description || "",
      stock: item.stock, source: "live", shopId: item.shop_id, shopName: item.shop_name, shopType: item.shop_type,
      shopDeliveryAvailable: item.shop_delivery_available, shopPickupAvailable: item.shop_pickup_available,
      sellBy: item.sell_by || "pack", measure: item.measure,
      variants: (item.variants || []).filter((variant) => variant.id).map((variant) => ({
        id: variant.id, unit: variant.unit || item.unit || "unit", price: Number(variant.price_inr ?? variant.price ?? item.price_inr ?? item.price ?? 0),
        mrp: (variant.mrp_inr ?? variant.mrp) == null ? undefined : Number(variant.mrp_inr ?? variant.mrp), stock: variant.stock, available: variant.available,
      })),
    };
  });
}

function groundedReply(data: AssistantContext, lang: string, t: (key: string) => string): string {
  const lines: string[] = [];
  if (data.products.length) {
    lines.push(`${t("chand.results.products")}:`);
    for (const p of data.products.slice(0, 6)) {
      lines.push(`• ${p.name} — ${p.price_inr == null ? "Price unavailable" : `₹${p.price_inr}`} · ${t("chand.shop")}: ${p.shop_name || "—"}${p.stock != null ? ` · ${t("chand.stock")}: ${p.stock}` : ""}${p.description ? `\n  ${p.description}` : ""}`);
    }
  }
  if (data.shops.length) lines.push(`${t("chand.results.shops")}:\n${data.shops.slice(0, 5).map(x => `• ${x.name}${x.category ? ` · ${x.category}` : ""}${x.area ? ` · ${t("chand.area")}: ${x.area}` : ""}`).join("\n")}`);
  if (data.restaurants.length) lines.push(`${t("chand.results.restaurants")}:\n${data.restaurants.slice(0, 5).map(x => `• ${x.name}${x.cuisine ? ` · ${x.cuisine}` : ""}${x.available ? " · Available" : ""}`).join("\n")}`);
  if (data.restaurant_menu_items?.length) lines.push(`${t("chand.results.menu")}:\n${data.restaurant_menu_items.slice(0, 6).map(x => `• ${x.name} — ${x.price_inr == null ? "Price unavailable" : `₹${x.price_inr}`} · ${x.restaurant_name || ""}${x.description ? `\n  ${x.description}` : ""}`).join("\n")}`);
  if (data.home_services.length) lines.push(`${t("chand.results.services")}:\n${data.home_services.slice(0, 5).map(x => `• ${x.name} — ${x.category || ""}${x.service_area ? ` · ${x.service_area}` : ""}${x.visit_fee_inr != null ? ` · ${t("chand.servicefee")}: ₹${x.visit_fee_inr}` : ""}`).join("\n")}`);
  if (data.categories.length) lines.push(`${t("chand.results.categories")}: ${data.categories.slice(0, 12).join(", ")}`);
  if (!lines.length) return t("chand.noresults");
  const prefix = lang === "hi" ? "COME-IN के मौजूदा सार्वजनिक डेटा से मिली जानकारी:" : lang === "pa" ? "COME-IN ਦੇ ਮੌਜੂਦਾ ਜਨਤਕ ਡਾਟੇ ਤੋਂ ਜਾਣਕਾਰੀ:" : "Results from current public COME-IN listings:";
  return `${prefix}\n\n${lines.join("\n\n")}\n\n${t("chand.disclaimer")}`;
}

export default function ChandScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const styles = useStyles();
  const { colors } = useTheme();
  const { user } = useAuth();
  const { addProduct, setAmount } = useCart();
  const audioRecorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const { lang, t } = useT();
  const routeParams = useLocalSearchParams<{ openHelp?: string; order_id?: string; order_kind?: string; voice?: string }>();
  const initialRole: RoleMode = user?.role === "shopkeeper" ? "shopkeeper" : "customer";
  const [role, setRole] = useState<RoleMode>(initialRole);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [requestError, setRequestError] = useState("");
  const [retryQuery, setRetryQuery] = useState("");
  const messageInputRef = useRef<TextInput | null>(null);
  const [voiceTypingHint, setVoiceTypingHint] = useState(false);
  const [voiceLanguage, setVoiceLanguage] = useState<"auto" | "hi" | "en">("auto");
  const [voiceRecording, setVoiceRecording] = useState(false);
  const [voiceBusy, setVoiceBusy] = useState(false);
  const [voiceReview, setVoiceReview] = useState(false);
  const [voiceError, setVoiceError] = useState("");
  const [photoAsset, setPhotoAsset] = useState<ImagePicker.ImagePickerAsset | null>(null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [photoError, setPhotoError] = useState("");
  const [photoNotice, setPhotoNotice] = useState("");
  const [photoClues, setPhotoClues] = useState("");
  const [photoMatches, setPhotoMatches] = useState<Product[]>([]);
  const [providerStatus, setProviderStatus] = useState<"checking" | "not_configured" | "configured_unverified" | "live" | "unavailable">("checking");
  useEffect(() => {
    if (routeParams.voice === "1") {
      setVoiceTypingHint(true);
      messageInputRef.current?.focus();
    }
  }, [routeParams.voice]);
  const [messages, setMessages] = useState<Message[]>([{
    id: "welcome", from: "assistant",
    text: `${t("brand.tagline")} ${t("chand.subtitle")}. ${t("chand.provider.note")}`,
  }]);
  const suggestions = useMemo(() => SUGGESTION_KEYS[role].map((key) => t(key)), [role, t, lang]);
  useEffect(() => {
    let active = true;
    api.get<any>("/assistant/health", false).then((health) => {
      if (active) setProviderStatus((current) => current === "live" ? current : health?.configured ? "configured_unverified" : "not_configured");
    }).catch(() => { if (active) setProviderStatus((current) => current === "live" ? current : "unavailable"); });
    return () => { active = false; };
  }, []);
  useEffect(() => {
    setMessages((current) => current.length === 1 && current[0]?.id === "welcome"
      ? [{ ...current[0], text: `${t("brand.tagline")} ${t("chand.subtitle")}. ${t("chand.provider.note")}` }]
      : current);
  }, [lang, t]);
  const [helpOpen, setHelpOpen] = useState(false);
  const [helpLoading, setHelpLoading] = useState(false);
  const [helpError, setHelpError] = useState("");
  const [helpNotice, setHelpNotice] = useState("");
  const [orders, setOrders] = useState<SupportOrder[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<SupportOrder | null>(null);
  const [supportCategory, setSupportCategory] = useState<string>("order_late");
  const [supportMessage, setSupportMessage] = useState("");
  const [submittingSupport, setSubmittingSupport] = useState(false);
  const [confirmSupport, setConfirmSupport] = useState(false);
  const [supportRequestId, setSupportRequestId] = useState("");
  const [feedbackRating, setFeedbackRating] = useState<"positive" | "negative" | "">("");
  const [feedbackComment, setFeedbackComment] = useState("");
  const [feedbackNotice, setFeedbackNotice] = useState("");
  const [feedbackBusy, setFeedbackBusy] = useState(false);
  const [budgetCap, setBudgetCap] = useState<number | null>(null);
  const [planItems, setPlanItems] = useState<ChandPlanLine[]>([]);
  const [planNotice, setPlanNotice] = useState("");
  const [partyOpen, setPartyOpen] = useState(false);
  const [partyOccasion, setPartyOccasion] = useState<"birthday" | "family gathering" | "small party">("birthday");
  const [partyGuests, setPartyGuests] = useState("10");
  const [partyBudget, setPartyBudget] = useState("1500");
  const [partyServing, setPartyServing] = useState<PartyServingAssumptions>(DEFAULT_PARTY_SERVING_ASSUMPTIONS);
  const [partyGroups, setPartyGroups] = useState<ReturnType<typeof buildPartyPlanGroups>>([]);
  const [partyLoading, setPartyLoading] = useState(false);
  const [planRefreshing, setPlanRefreshing] = useState(false);
  const planLineAmount = (line: ChandPlanLine) => {
    if (line.verifiedTotal !== undefined) return line.verifiedTotal;
    if (isMeasured(line.product)) return lineAmount(line.product, line.quantity);
    const variant = line.variantId ? line.product.variants?.find((item) => item.id === line.variantId) : undefined;
    return Math.max(0, Number(variant?.price ?? line.product.price) || 0) * line.quantity;
  };
  const planTotal = useMemo(() => planItems.reduce((sum, line) => sum + planLineAmount(line), 0), [planItems]);

  const addToPlan = (product: Product, variantId?: string) => {
    if (product.source !== "live" || !Number.isFinite(product.price) || product.price <= 0) {
      setPlanNotice("Only current live catalog products can be added to this list.");
      return;
    }
    if (product.variants?.length && !variantId) {
      setPlanNotice("Choose a product variant before adding it to the budget list.");
      return;
    }
    const selectedVariant = variantId ? product.variants?.find((item) => item.id === variantId) : undefined;
    if (variantId && (!selectedVariant || selectedVariant.available === false || Number(selectedVariant.stock ?? 0) <= 0)) {
      setPlanNotice("That product variant is currently unavailable.");
      return;
    }
    const initialQty = isMeasured(product) ? Number(product.measure?.min_qty || 250) : 1;
    setPlanItems((current) => {
      const existing = current.find((line) => line.product.id === product.id && line.variantId === variantId);
      if (existing) return current;
      return [...current, { product, quantity: initialQty, variantId }];
    });
    setPlanNotice("");
  };

  const generatePartyPlan = async () => {
    const guests = Number(partyGuests);
    const budget = Number(partyBudget);
    if (!Number.isInteger(guests) || guests < 1 || guests > 500 || !Number.isFinite(budget) || budget <= 0 || partyLoading) return;
    const servingValues = Object.values(partyServing);
    if (servingValues.some((value) => !Number.isFinite(value) || value <= 0 || value > 5000)) {
      setPlanNotice("Serving assumptions must be positive and no more than 5,000 per guest.");
      return;
    }
    setPartyLoading(true);
    setPlanNotice("Loading current catalog listings and calculating quantities from your serving assumptions…");
    try {
      const rows = await api.get<any[]>("/catalog/products", false);
      const liveProducts = mapAssistantProducts(rows as AssistantProduct[]);
      const groups = buildPartyPlanGroups(liveProducts, guests, partyServing);
      const lines: ChandPlanLine[] = groups.flatMap((group) => {
        const candidate = group.candidates[0];
        return candidate ? [{ product: candidate.product, quantity: candidate.quantity, variantId: candidate.variantId, partyNeed: group.need }] : [];
      });
      setPartyGroups(groups);
      setBudgetCap(budget);
      setPlanItems(lines);
      const missing = groups.filter((group) => group.candidates.length === 0).map((group) => group.need);
      const estimate = lines.reduce((sum, line) => {
        if (isMeasured(line.product)) return sum + lineAmount(line.product, line.quantity);
        const variant = line.variantId ? line.product.variants?.find((item) => item.id === line.variantId) : undefined;
        return sum + Number(variant?.price ?? line.product.price) * line.quantity;
      }, 0);
      const notes = missing.length ? ` No suitable live listing with a readable pack size or compatible measured contract was found for: ${missing.join(", ")}.` : "";
      setPlanNotice(lines.length ? `Calculated from ${guests} guests and current catalog listings. Estimated total ₹${estimate.toFixed(2)}; ${estimate > budget ? `over budget by ₹${(estimate - budget).toFixed(2)}. Review or substitute items.` : `within the ₹${budget.toFixed(2)} budget.`}${notes}` : `No suitable current catalog matches could be calculated. No demo products or assumed prices were added.${notes}`);
      setPartyOpen(false);
    } catch (error: any) {
      setPlanNotice(error?.message || "Could not load the current catalog. No party list was generated.");
    } finally { setPartyLoading(false); }
  };

  const substitutePartyLine = (line: ChandPlanLine) => {
    if (!line.partyNeed) return;
    const group = partyGroups.find((item) => item.need === line.partyNeed);
    if (!group || group.candidates.length < 2) return;
    const currentIndex = group.candidates.findIndex((item) => item.product.id === line.product.id && item.variantId === line.variantId);
    const next = group.candidates[(currentIndex + 1) % group.candidates.length];
    setPlanItems((items) => items.map((item) => item.partyNeed === line.partyNeed ? { product: next.product, quantity: next.quantity, variantId: next.variantId, partyNeed: line.partyNeed } : item));
    setPlanNotice(`Substituted ${line.partyNeed} with ${next.product.name}, using its current catalog price and pack size.`);
  };

  const transferPlanToCart = async () => {
    if (!planItems.length || planRefreshing) return;
    if (budgetCap !== null && planTotal > budgetCap) { setPlanNotice("This list is above your budget. Reduce quantities or remove items before transferring."); return; }
    setPlanRefreshing(true); setPlanNotice("Refreshing current catalog prices and stock…");
    try {
      const latestRows = await api.get<any[]>("/catalog/products", false);
      const latest = mapAssistantProducts(latestRows as AssistantProduct[]);
      const refreshed: ChandPlanLine[] = [];
      for (const line of planItems) {
        const current = latest.find((item) => item.id === line.product.id);
        if (!current) throw new Error(`${line.product.name} is no longer available in the live catalog. Remove it or search again.`);
        if (isMeasured(current) !== isMeasured(line.product)) throw new Error(`${current.name} changed its sale/quantity contract. Remove it and add the current catalog listing again.`);
        if (isMeasured(current)) {
          const quote = await api.post<{ line_total: number; qty: number }>("/grocery/measured-price", { product_id: current.id, qty: line.quantity });
          if (quote.qty !== line.quantity || !Number.isFinite(quote.line_total)) throw new Error(`Could not verify the current measured price for ${current.name}.`);
          refreshed.push({ ...line, product: current, verifiedTotal: Number(quote.line_total) });
          continue;
        } else if (line.variantId) {
          const variant = current.variants?.find((item) => item.id === line.variantId);
          if (!variant || variant.available === false || Number(variant.stock ?? 0) < line.quantity) throw new Error(`${current.name} variant is unavailable or has insufficient stock.`);
        } else if (current.variants?.length || (current.stock !== undefined && current.stock < line.quantity)) {
          throw new Error(`${current.name} pack is unavailable or has insufficient stock. Refresh the list.`);
        }
        refreshed.push({ ...line, product: current });
      }
      const refreshedTotal = refreshed.reduce((sum, line) => sum + planLineAmount(line), 0);
      if (budgetCap !== null && refreshedTotal > budgetCap) throw new Error("Current catalog prices put this list above your budget. Review the updated prices before adding it to Cart.");
      for (const line of refreshed) {
        if (isMeasured(line.product)) {
          const error = setAmount(line.product, line.quantity);
          if (error) throw new Error(`${line.product.name}: ${error}`);
        } else {
          for (let i = 0; i < line.quantity; i += 1) addProduct(line.product, line.variantId);
        }
      }
      setPlanNotice("Current catalog prices and stock were refreshed. Products were transferred to your existing COME-IN Cart; review the server checkout quote there.");
      setPlanItems([]);
    } catch (error: any) {
      setPlanNotice(error?.message || "The catalog could not be refreshed. Nothing was transferred; please retry.");
    } finally { setPlanRefreshing(false); }
  };

  const chooseProductPhoto = async (source: "camera" | "gallery") => {
    if (!user) { setPhotoError("Please sign in before using photo shopping."); return; }
    setPhotoError(""); setPhotoNotice(""); setPhotoClues(""); setPhotoMatches([]);
    try {
      let result: ImagePicker.ImagePickerResult;
      if (source === "camera") {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) { setPhotoError("Camera permission was not granted. You can allow it in device settings or choose a photo from Gallery."); return; }
        result = await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], quality: 0.85, allowsEditing: false });
      } else {
        const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!permission.granted) { setPhotoError("Photo library permission was not granted. You can allow it in device settings or use Camera."); return; }
        result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.85, allowsEditing: false });
      }
      if (result.canceled || !result.assets?.[0]) return;
      setPhotoAsset(result.assets[0]);
      setPhotoNotice("Photo selected. Review it, then tap Find matching products.");
    } catch (error: any) {
      setPhotoError(error?.message || "Could not open the camera or photo library.");
    }
  };

  const searchPhotoCatalog = async () => {
    if (!photoAsset || photoBusy) return;
    if (!user) { setPhotoError("Please sign in before uploading a product photo."); return; }
    setPhotoBusy(true); setPhotoError(""); setPhotoNotice("Uploading photo and searching the live COME-IN catalog…");
    try {
      const mimeType = photoAsset.mimeType || "image/jpeg";
      const extension = mimeType === "image/png" ? "png" : mimeType === "image/webp" ? "webp" : "jpg";
      const result = await api.chandVision({ uri: photoAsset.uri, name: photoAsset.fileName || `chand-product.${extension}`, mimeType }, lang);
      const clues = String(result?.recognized_text || "").trim();
      const matches = mapAssistantProducts(result?.products || []);
      setPhotoClues(clues);
      setPhotoMatches(matches);
      setPhotoNotice(matches.length ? `Found ${matches.length} current catalog match${matches.length === 1 ? "" : "es"}. Confirm a product below to continue.` : clues ? "Product clues were recognized, but no current catalog match was found." : "The photo was unclear. Try a brighter, closer photo with the product label visible.");
    } catch (error: any) {
      setPhotoError(error?.message || "Photo matching failed. Check your connection and try again.");
      setPhotoNotice("");
    } finally { setPhotoBusy(false); }
  };

  const confirmPhotoProduct = (product: Product) => {
    if (product.variants?.length || isMeasured(product)) {
      router.push(`/product/${product.id}`);
      setPhotoNotice(`Choose the exact option or measured quantity for ${product.name} on its product page.`);
      return;
    }
    addProduct(product);
    setPhotoNotice(`${product.name} was sent to your existing COME-IN Cart. Review it in Cart before checkout.`);
  };

  const startVoiceRecording = async () => {
    if (!user) { setVoiceError("Please sign in before using voice shopping."); return; }
    setVoiceError(""); setVoiceReview(false);
    try {
      const permission = await AudioModule.requestRecordingPermissionsAsync();
      if (!permission.granted) { setVoiceError("Microphone permission was not granted. Allow it in device settings or type your request instead."); return; }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await audioRecorder.prepareToRecordAsync();
      audioRecorder.record({ forDuration: 90 });
      setVoiceRecording(true);
    } catch (error: any) {
      setVoiceError(error?.message || "Could not start microphone recording.");
      setVoiceRecording(false);
    }
  };

  const stopAndTranscribeVoice = async () => {
    if (!voiceRecording || voiceBusy) return;
    setVoiceBusy(true); setVoiceError("");
    try {
      await audioRecorder.stop();
      setVoiceRecording(false);
      const uri = audioRecorder.uri;
      if (!uri) throw new Error("The recording file was not created. Please record again.");
      const result = await api.chandTranscribe({ uri, name: "chand-shopping-request.m4a", mimeType: "audio/mp4" }, voiceLanguage === "auto" ? undefined : voiceLanguage);
      const transcript = String(result?.text || "").trim();
      if (!transcript) throw new Error("No speech was recognized. Please try again or type your request.");
      setDraft(transcript);
      setVoiceReview(true);
      setVoiceTypingHint(false);
    } catch (error: any) {
      setVoiceError(error?.message || "Voice transcription failed. Please try again or type your request.");
    } finally { setVoiceBusy(false); }
  };

  const cancelVoiceRecording = async () => {
    try { if (voiceRecording) await audioRecorder.stop(); } catch {}
    setVoiceRecording(false); setVoiceBusy(false); setVoiceReview(false); setVoiceError("");
  };

  const submitChandFeedback = async () => {
    if (!user || !feedbackRating || feedbackBusy) return;
    const lastAssistant = [...messages].reverse().find((item) => item.from === "assistant");
    if (!lastAssistant) return;
    setFeedbackBusy(true); setFeedbackNotice("");
    try {
      await api.post("/chand/feedback", {
        rating: feedbackRating,
        category: "answer_quality",
        comment: feedbackComment.trim(),
        conversation_ref: lastAssistant.id,
        request_id: `chand-feedback-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      });
      setFeedbackNotice("Thank you. Your feedback was sent to the COME-IN review team.");
      setFeedbackComment(""); setFeedbackRating("");
    } catch (e: any) {
      setFeedbackNotice(e?.message || "Feedback could not be submitted. Please try again later.");
    } finally { setFeedbackBusy(false); }
  };

  const loadHelpData = useCallback(async () => {
    setHelpLoading(true); setHelpError("");
    if (!user) {
      setHelpError("Sign in to load your private order history and submit a support request. Demo help topics remain available without signing in.");
      setHelpLoading(false); return;
    }
    const [groceryResult, restaurantResult, ticketResult] = await Promise.allSettled([
      api.get<any[]>("/orders/mine"),
      api.get<any[]>("/restaurant/orders/mine"),
      api.get<any[]>("/restaurant/support/mine"),
    ]);
    const mapped: SupportOrder[] = [];
    if (groceryResult.status === "fulfilled") for (const o of groceryResult.value) mapped.push({ ...o, kind: "grocery" });
    if (restaurantResult.status === "fulfilled") for (const o of restaurantResult.value) mapped.push({ ...o, kind: "restaurant" });
    mapped.sort((a,b) => String(b.created_at || "").localeCompare(String(a.created_at || "")));
    setOrders(mapped);
    if (ticketResult.status === "fulfilled") setTickets(ticketResult.value);
    if (groceryResult.status === "rejected" && restaurantResult.status === "rejected") {
      setHelpError("Could not load order history from the configured backend. Check the connection and retry.");
    } else if (ticketResult.status === "rejected") {
      setHelpError("Orders loaded, but the shared support ticket endpoint is unavailable. You can retry.");
    }
    setHelpLoading(false);
  }, [user?.id]);

  useEffect(() => {
    if (routeParams.openHelp === "1") {
      setHelpOpen(true);
      void loadHelpData();
    }
  }, [routeParams.openHelp, loadHelpData]);

  useEffect(() => {
    if (!routeParams.order_id || !orders.length) return;
    const match = orders.find((order) => order.id === routeParams.order_id && order.kind === (routeParams.order_kind === "grocery" ? "grocery" : "restaurant"));
    if (match) setSelectedOrder(match);
  }, [routeParams.order_id, routeParams.order_kind, orders]);

  const openHelp = () => {
    setHelpOpen((current) => !current);
    if (!helpOpen) void loadHelpData();
  };

  const submitSupport = async () => {
    const clean = supportMessage.trim();
    if (!clean || clean.length < 5 || clean.length > 2000 || submittingSupport) return;
    if (!user) { setHelpError("Please sign in before submitting a real support request."); return; }
    setSubmittingSupport(true); setHelpError(""); setHelpNotice("");
    const payload: { category: string; message: string; request_id: string; order_id?: string; order_kind?: "grocery" | "restaurant" } = {
      category: supportCategory,
      message: clean,
      request_id: supportRequestId || `support-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`,
    };
    if (selectedOrder) { payload.order_id = selectedOrder.id; payload.order_kind = selectedOrder.kind; }
    try {
      const created = await api.post<SupportTicket>("/restaurant/support", payload);
      setSupportMessage("");
      setSupportRequestId("");
      setConfirmSupport(false);
      await loadHelpData();
      setHelpNotice(`Support request submitted. Reference: ${created.ref}. Current status: ${created.status}. This is a support request, not a refund approval or payment.`);
    } catch (e: any) {
      setHelpError(e?.message || "Support request could not be submitted. No refund was issued.");
    } finally { setSubmittingSupport(false); }
  };

  const send = async (text = draft) => {
    const clean = text.trim();
    if (!clean || sending || clean.length > 1000) return;
    const budgetMatch = clean.match(/(?:₹|rs\.?|rupees?)\s*(\d{1,6})/i) || clean.match(/budget[^0-9]{0,20}(\d{1,6})/i);
    if (budgetMatch) setBudgetCap(Number(budgetMatch[1]));
    setDraft(""); setVoiceReview(false); setSending(true);
    const userMessage: Message = { id: `u-${Date.now()}`, from: "user", text: clean };
    setMessages((current) => [...current, userMessage]);
    let answer = "";
    try {
      const history = [...messages.slice(-7).map((item) => ({ role: item.from, content: item.text })), { role: "user" as const, content: clean }];
      const data = await api.post<AssistantContext>("/assistant/context", { query: clean, language: lang, limit: 6, history }, false);
      answer = data.answer?.trim() || groundedReply(data, lang, t);
      setProviderStatus(data.answer?.trim() && data.ai_provider && !["not_configured", "temporarily_unavailable"].includes(data.ai_provider) ? "live" : data.ai_provider === "temporarily_unavailable" ? "unavailable" : data.ai_provider === "not_configured" ? "not_configured" : providerStatus);
      setRequestError("");
      setRetryQuery("");
      const products = mapAssistantProducts(data.products || []);
      setMessages((current) => [...current, { id: `a-${Date.now()}`, from: "assistant", text: answer, products }]);
      setSending(false);
      return;
    } catch {
      // Deterministic local response is only a safe fallback when live catalog retrieval is unavailable.
      setRetryQuery(clean);
      setProviderStatus("unavailable");
      setRequestError("Could not reach the live COME-IN catalog service. The reply below is offline guidance only.");
      answer = `${t("chand.providerunavailable")}\n\n${demoReply(clean, role)}`;
    }
    setMessages((current) => [...current, { id: `a-${Date.now()}`, from: "assistant", text: answer }]);
    setSending(false);
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={[styles.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="chand-back" accessibilityRole="button" accessibilityLabel={t("tab.home")} onPress={() => router.back()} style={styles.back}>
          <Feather name="arrow-left" size={20} color={colors.onSurface} />
        </Pressable>
        <View style={styles.brandMark}><Feather name="moon" size={22} color="#FFFFFF" /><View style={styles.brandHeart}><Feather name="heart" size={9} color="#FDE68A" /></View></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>CHAND</Text>
          <Text style={styles.subtitle}>{lang === "hi" ? "आपका स्मार्ट शॉपिंग असिस्टेंट" : "Your Smart Shopping Assistant"}</Text>
        </View>
        <View style={styles.demoPill}><Text style={styles.demoPillText}>{providerStatus === "live" ? "AI LIVE" : providerStatus === "configured_unverified" ? "AI READY · UNVERIFIED" : providerStatus === "checking" ? "AI CHECKING" : "AI OFFLINE"}</Text></View>
      </View>

      <View style={styles.modeWrap}>
        <Text style={styles.sectionLabel}>{t("chand.mode")}</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.modeRow}>
          {(Object.keys(ROLE_KEYS) as RoleMode[]).map((item) => (
            <Pressable key={item} testID={`chand-role-${item}`} accessibilityRole="button" accessibilityState={{ selected: role === item }} onPress={() => setRole(item)} style={[styles.modeChip, role === item && styles.modeChipActive]}>
              <Text style={[styles.modeChipText, role === item && styles.modeChipTextActive]}>{t(ROLE_KEYS[item])}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <ScrollView testID="chand-conversation" style={styles.conversation} contentContainerStyle={styles.messages} keyboardShouldPersistTaps="handled">
        <View style={styles.mediaPanel} testID="chand-photo-shopping">
          <Text style={styles.feedbackTitle}>Shop from a photo</Text>
          <View style={styles.mediaActions}>
            <Pressable testID="chand-photo-camera" onPress={() => void chooseProductPhoto("camera")} style={styles.mediaButton}><Feather name="camera" size={16} color={colors.brandForest} /><Text style={styles.mediaButtonText}>Camera</Text></Pressable>
            <Pressable testID="chand-photo-gallery" onPress={() => void chooseProductPhoto("gallery")} style={styles.mediaButton}><Feather name="image" size={16} color={colors.brandForest} /><Text style={styles.mediaButtonText}>Gallery</Text></Pressable>
          </View>
          {photoAsset ? <>
            <Image source={{ uri: photoAsset.uri }} contentFit="contain" style={styles.photoPreview} />
            <View style={styles.mediaActions}>
              <Pressable testID="chand-photo-find" disabled={photoBusy} onPress={() => void searchPhotoCatalog()} style={[styles.mediaPrimary, photoBusy && styles.sendDisabled]}><Text style={styles.mediaPrimaryText}>{photoBusy ? "Searching…" : "Find matching products"}</Text></Pressable>
              <Pressable testID="chand-photo-replace" disabled={photoBusy} onPress={() => void chooseProductPhoto("gallery")} style={styles.mediaButton}><Text style={styles.mediaButtonText}>Replace</Text></Pressable>
              <Pressable testID="chand-photo-cancel" disabled={photoBusy} onPress={() => { setPhotoAsset(null); setPhotoMatches([]); setPhotoClues(""); setPhotoNotice(""); setPhotoError(""); }} style={styles.mediaButton}><Text style={styles.mediaButtonText}>Cancel</Text></Pressable>
            </View>
          </> : null}
          {photoBusy ? <View style={styles.mediaStatus}><ActivityIndicator color={colors.brandPrimary} /><Text style={styles.feedbackHint}>Uploading and checking catalog…</Text></View> : null}
          {photoClues ? <Text style={styles.feedbackHint}>Recognized clues: {photoClues}</Text> : null}
          {photoNotice ? <Text accessibilityRole="status" style={styles.feedbackHint}>{photoNotice}</Text> : null}
          {photoError ? <Text accessibilityRole="alert" style={styles.mediaError}>{photoError}</Text> : null}
          {photoMatches.map((product) => <View key={product.id} style={styles.photoMatch}>
            <ProductCard product={product} />
            <Pressable testID={`chand-photo-confirm-${product.id}`} onPress={() => confirmPhotoProduct(product)} style={styles.mediaPrimary}><Text style={styles.mediaPrimaryText}>{product.variants?.length || isMeasured(product) ? "Confirm & choose options" : "Confirm & add to Cart"}</Text></Pressable>
          </View>)}
        </View>
        {messages.map((message) => (
          <View key={message.id} style={[styles.messageRow, message.from === "user" && styles.userRow]}>
            {message.from === "assistant" && <View style={styles.miniMark}><Feather name="moon" size={14} color="#FFFFFF" /></View>}
            <View style={{ flex: 1, gap: spacing.sm }}>
              <View style={[styles.bubble, message.from === "user" ? styles.userBubble : styles.assistantBubble]}>
                <Text style={[styles.messageText, message.from === "user" && styles.userMessageText]}>{message.text}</Text>
              </View>
              {message.products?.length ? <View style={styles.recommendations} testID="chand-product-recommendations">
                <Text style={styles.recommendationHeading}>LIVE COME-IN PRODUCTS</Text>
                {message.products.map((product) => <View key={product.id} style={styles.recommendationItem}>
                  <ProductCard product={product} />
                  {!product.variants?.length && <Pressable testID={`chand-plan-add-${product.id}`} onPress={() => addToPlan(product)} style={styles.planAddButton}><Text style={styles.planAddText}>{isMeasured(product) ? "Add measured item" : "Add to budget list"}</Text></Pressable>}
                  {product.variants?.map((variant) => <Pressable key={variant.id} testID={`chand-plan-add-${product.id}-${variant.id}`} onPress={() => addToPlan(product, variant.id)} style={styles.planAddButton}><Text style={styles.planAddText}>Add {variant.unit} · ₹{variant.price}</Text></Pressable>)}
                  <Text style={styles.recommendationMeta}>
                    {product.shopType === "online" ? "Online shop" : product.shopType === "both" ? "Online + local shop" : "Local shop"}
                    {product.stock != null ? ` · Stock: ${product.stock} ${product.sellBy === "weight" ? "g" : product.sellBy === "volume" ? "ml" : product.unit}` : " · Stock not reported"}
                    {product.shopDeliveryAvailable ? " · Shop declares delivery" : ""}
                    {product.shopPickupAvailable ? " · Shop declares pickup" : ""}
                  </Text>
                </View>)}
              </View> : null}
            </View>
          </View>
        ))}
        {sending && <View style={styles.loadingRow}><ActivityIndicator size="small" color={colors.brandPrimary} /><Text style={styles.loadingText}>{t("chand.loading")}</Text></View>}
        {requestError ? <View style={styles.errorRow}>
          <Text style={styles.errorText}>{requestError}</Text>
          <Pressable testID="chand-retry" onPress={() => void send(retryQuery)} disabled={sending || !retryQuery} style={styles.retryButton}><Text style={styles.retryText}>Retry</Text></Pressable>
        </View> : null}
        {planItems.length > 0 && <View style={styles.planPanel} testID="chand-budget-plan">
          <Text style={styles.feedbackTitle}>Your editable shopping list</Text>
          <Text style={styles.feedbackHint}>{budgetCap === null ? "No budget limit detected. Add a budget in chat to set a cap." : `Budget: ₹${budgetCap.toFixed(2)}`} · Estimated catalog total: ₹{planTotal.toFixed(2)}</Text>
          {planItems.map((line) => {
            const measured = isMeasured(line.product);
            const variant = line.variantId ? line.product.variants?.find((item) => item.id === line.variantId) : undefined;
            const step = measured ? Number(line.product.measure?.step || 50) : 1;
            const min = measured ? Number(line.product.measure?.min_qty || step) : 1;
            const max = measured ? Number(line.product.measure?.max_qty || 10000) : Number(variant?.stock ?? line.product.stock ?? 99);
            return <View key={`${line.product.id}:${line.variantId || "base"}`} style={styles.planLine}>
              <View style={{ flex: 1 }}><Text style={styles.planName}>{line.product.name}{variant ? ` · ${variant.unit}` : ""}</Text><Text style={styles.feedbackHint}>{line.partyNeed ? `${line.partyNeed} · ` : ""}{measured ? `${formatAmount(line.product, line.quantity)} · ₹${planLineAmount(line).toFixed(2)} (current estimate)` : `₹${Number(variant?.price ?? line.product.price).toFixed(2)} × ${line.quantity} = ₹${planLineAmount(line).toFixed(2)}`}</Text>{line.partyNeed && (partyGroups.find((group) => group.need === line.partyNeed)?.candidates.length || 0) > 1 ? <Pressable testID={`chand-party-substitute-${line.partyNeed}`} onPress={() => substitutePartyLine(line)}><Text style={styles.retryText}>Use another catalog match</Text></Pressable> : null}</View>
              <Pressable accessibilityLabel={`Decrease ${line.product.name}`} onPress={() => setPlanItems((rows) => rows.map((row) => row.product.id === line.product.id && row.variantId === line.variantId ? { ...row, quantity: Math.max(min, row.quantity - step), verifiedTotal: undefined } : row))} style={styles.planQty}><Feather name="minus" size={14} color={colors.brandForest} /></Pressable>
              <Text style={styles.planQtyText}>{measured ? formatAmount(line.product, line.quantity) : line.quantity}</Text>
              <Pressable accessibilityLabel={`Increase ${line.product.name}`} onPress={() => setPlanItems((rows) => rows.map((row) => row.product.id === line.product.id && row.variantId === line.variantId ? { ...row, quantity: Math.min(row.quantity + step, max), verifiedTotal: undefined } : row))} style={styles.planQty}><Feather name="plus" size={14} color={colors.brandForest} /></Pressable>
              <Pressable accessibilityLabel={`Remove ${line.product.name}`} onPress={() => setPlanItems((rows) => rows.filter((row) => !(row.product.id === line.product.id && row.variantId === line.variantId)))}><Feather name="trash-2" size={15} color={colors.muted} /></Pressable>
            </View>;
          })}
          {budgetCap !== null && planTotal > budgetCap ? <Text style={styles.feedbackHint}>Over budget by ₹{(planTotal - budgetCap).toFixed(2)}. Reduce the list before transfer.</Text> : null}
          {planNotice ? <Text style={styles.feedbackHint}>{planNotice}</Text> : null}
          <Pressable testID="chand-plan-transfer-cart" disabled={planRefreshing || (budgetCap !== null && planTotal > budgetCap)} onPress={() => void transferPlanToCart()} style={[styles.feedbackSubmit, (planRefreshing || (budgetCap !== null && planTotal > budgetCap)) && styles.sendDisabled]}><Text style={styles.feedbackSubmitText}>{planRefreshing ? "Refreshing & verifying…" : "Verify & add list to Cart"}</Text></Pressable>
          <Text style={styles.feedbackHint}>Measured quantities use the existing Task 5 base-unit rules. Before transfer, current catalog availability and measured server quotes are checked; checkout remains authoritative for final price and stock.</Text>
        </View>}
        <Text style={styles.disclaimer}>{t("chand.disclaimer")}</Text>
        <View style={styles.feedbackPanel} testID="chand-feedback-panel">
          <Text style={styles.feedbackTitle}>Was this Chand response helpful?</Text>
          {!user ? <Text style={styles.feedbackHint}>Sign in to send private feedback.</Text> : <>
            <View style={styles.feedbackChoices}>
              <Pressable testID="chand-feedback-positive" accessibilityRole="button" accessibilityState={{ selected: feedbackRating === "positive" }} onPress={() => setFeedbackRating("positive")} style={[styles.feedbackChoice, feedbackRating === "positive" && styles.feedbackChoiceActive]}><Feather name="thumbs-up" size={15} color={colors.brandForest} /><Text style={styles.feedbackHint}>Helpful</Text></Pressable>
              <Pressable testID="chand-feedback-negative" accessibilityRole="button" accessibilityState={{ selected: feedbackRating === "negative" }} onPress={() => setFeedbackRating("negative")} style={[styles.feedbackChoice, feedbackRating === "negative" && styles.feedbackChoiceActive]}><Feather name="thumbs-down" size={15} color={colors.brandForest} /><Text style={styles.feedbackHint}>Needs improvement</Text></Pressable>
            </View>
            {feedbackRating ? <><TextInput testID="chand-feedback-comment" value={feedbackComment} onChangeText={setFeedbackComment} maxLength={1000} placeholder="Optional comment (do not include OTPs or payment details)" placeholderTextColor={colors.muted} style={styles.feedbackInput} />
              <Pressable testID="chand-feedback-submit" disabled={feedbackBusy} onPress={() => void submitChandFeedback()} style={[styles.feedbackSubmit, feedbackBusy && styles.sendDisabled]}><Text style={styles.feedbackSubmitText}>{feedbackBusy ? "Sending…" : "Send feedback"}</Text></Pressable></> : null}
          </>}
          {feedbackNotice ? <Text accessibilityRole="status" style={styles.feedbackHint}>{feedbackNotice}</Text> : null}
        </View>
      </ScrollView>

      <View style={styles.helpEntryWrap}>
        <Pressable testID="chand-help-toggle" accessibilityRole="button" accessibilityState={{ expanded: helpOpen }} onPress={openHelp} style={styles.helpEntry}>
          <Feather name="life-buoy" size={18} color="#FFFFFF" />
          <View style={{ flex: 1 }}>
            <Text style={styles.helpEntryTitle}>{t("chand.help")}</Text>
            <Text style={styles.helpEntrySubtitle}>{t("chand.help.subtitle")}</Text>
          </View>
          <Feather name={helpOpen ? "chevron-up" : "chevron-down"} size={18} color="#FFFFFF" />
        </Pressable>
        {helpOpen && <ScrollView style={styles.helpPanel} nestedScrollEnabled contentContainerStyle={{ gap: 10 }}>
          <Text style={styles.helpHeading}>{t("chand.help.heading")}</Text>
          <Text style={styles.helpBody}>{t("chand.help.body")}</Text>
          {!user && <Text style={styles.helpWarning}>{t("chand.signin")}</Text>}
          {helpLoading && <ActivityIndicator testID="chand-help-loading" color={colors.brandPrimary} />}
          {user && orders.map((o) => <Pressable key={`${o.kind}-${o.id}`} testID={`chand-order-${o.id}`} onPress={() => { setSelectedOrder(o); setSupportCategory(o.refund_status ? "refund" : "order"); }} style={[styles.orderChoice, selectedOrder?.id === o.id && selectedOrder.kind === o.kind && styles.orderChoiceActive]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.orderTitle}>{o.ref || o.id} · {o.kind === "restaurant" ? (o.restaurant_name || "Restaurant") : "Grocery / Shop"}</Text>
              <Text style={styles.helpBody}>Order: {o.status || "status unavailable"} · Payment: {o.payment_status || "not provided"}</Text>
              {o.refund_status ? <Text style={styles.refundStatus}>Refund status from backend: {o.refund_status}</Text> : <Text style={styles.helpBody}>Refund status: no status reported for this order.</Text>}
            </View>
            <Feather name={selectedOrder?.id === o.id && selectedOrder.kind === o.kind ? "check-circle" : "circle"} size={18} color={colors.brandPrimary} />
          </Pressable>)}
          {user && !helpLoading && orders.length === 0 && <Text style={styles.helpBody}>No orders were returned, or the order APIs are unavailable. Use Retry to check again.</Text>}
          <View style={styles.supportCategoryRow}>{(["order_late", "wrong_or_missing_item", "damaged_item", "cancellation_help", "payment_issue", "refund_status", "other"] as const).map((cat) => <Pressable key={cat} onPress={() => setSupportCategory(cat as any)} style={[styles.supportCategory, supportCategory === cat && styles.supportCategoryActive]}><Text style={[styles.supportCategoryText, supportCategory === cat && styles.supportCategoryTextActive]}>{cat === "order_late" ? "Order late" : cat === "wrong_or_missing_item" ? "Wrong / missing item" : cat === "damaged_item" ? "Damaged item" : cat === "cancellation_help" ? "Cancellation help" : cat === "payment_issue" ? "Payment issue" : cat === "refund_status" ? "Refund status" : "Other issue"}</Text></Pressable>)}</View>
          <TextInput testID="chand-support-message" value={supportMessage} onChangeText={setSupportMessage} placeholder="Describe the issue (5–2000 characters)" placeholderTextColor={colors.muted} multiline maxLength={2000} style={styles.supportInput} accessibilityLabel="Describe your support issue" />
          {helpError ? <Text accessibilityRole="alert" style={styles.helpError}>{helpError}</Text> : null}
          {helpNotice ? <Text accessibilityRole="status" style={styles.helpSuccess}>{helpNotice}</Text> : null}
          {confirmSupport && <View style={styles.confirmCard}>
            <Text style={styles.orderTitle}>Confirm support submission</Text>
            <Text style={styles.helpBody}>Submit this message to the existing COME-IN support endpoint? This creates a support case only. It does not approve, initiate, or complete a refund.</Text>
            <View style={styles.supportActions}>
              <Pressable testID="chand-support-cancel-confirm" onPress={() => setConfirmSupport(false)} style={styles.supportSecondary}><Text style={styles.supportSecondaryText}>Edit message</Text></Pressable>
              <Pressable testID="chand-support-confirm" disabled={submittingSupport} onPress={() => void submitSupport()} style={[styles.supportSubmit, submittingSupport && styles.sendDisabled]}><Text style={styles.supportSubmitText}>{submittingSupport ? "Submitting…" : "Confirm & submit"}</Text></Pressable>
            </View>
          </View>}
          <View style={styles.supportActions}>
            <Pressable testID="chand-support-retry" onPress={() => void loadHelpData()} style={styles.supportSecondary}><Text style={styles.supportSecondaryText}>Refresh orders / cases</Text></Pressable>
            <Pressable testID="chand-support-submit" disabled={!user || supportMessage.trim().length < 5 || submittingSupport} onPress={() => { setSupportRequestId((current) => current || `support-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`); setConfirmSupport(true); }} style={[styles.supportSubmit, (!user || supportMessage.trim().length < 5 || submittingSupport) && styles.sendDisabled]}><Text style={styles.supportSubmitText}>Review & submit</Text></Pressable>
          </View>
          {user && tickets.length > 0 && <><Text style={styles.helpHeading}>Your support cases</Text>{tickets.map((ticket) => <View key={ticket.id} style={styles.ticketCard}><Text style={styles.orderTitle}>{ticket.ref} · {ticket.category}</Text><Text style={styles.helpBody}>Actual case status: {ticket.status}</Text><Text style={styles.helpBody}>{ticket.message}</Text></View>)}</>}
          <Text style={styles.helpFinePrint}>Backend capability note: support tickets can link to a customer-owned Grocery or Restaurant order using the explicit order kind and ID. Ticket creation is not refund approval or payment execution. No customer-facing refund request API exists; actual refund execution is admin-only. No refund dates or eligibility are inferred.</Text>
        </ScrollView>}
      </View>

      <View style={styles.composerArea}>
        <Text style={styles.sectionLabel}>{t("chand.suggest.customer.1") === "Find groceries under ₹500" ? "TRY ASKING" : (lang === "hi" ? "यह पूछकर देखें" : lang === "pa" ? "ਇਹ ਪੁੱਛ ਕੇ ਵੇਖੋ" : "TRY ASKING")}</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.suggestionRow}>
          {suggestions.map((suggestion) => (
            <Pressable key={suggestion} testID="chand-suggestion" onPress={() => send(suggestion)} style={styles.suggestion}><Text style={styles.suggestionText}>{suggestion}</Text></Pressable>
          ))}
        </ScrollView>
        {voiceTypingHint ? <Text style={styles.voiceHint}>Native recording is available below. The recording is uploaded only after you tap Stop & transcribe. No audio is sent automatically. You can also use your keyboard microphone and review the text before sending.</Text> : null}
        <View style={styles.voicePanel} testID="chand-voice-shopping">
          <View style={styles.voiceLanguages}>
            {(["auto", "hi", "en"] as const).map((value) => <Pressable key={value} testID={`chand-voice-language-${value}`} onPress={() => setVoiceLanguage(value)} style={[styles.voiceLanguage, voiceLanguage === value && styles.voiceLanguageActive]}><Text style={styles.voiceLanguageText}>{value === "auto" ? "Auto" : value === "hi" ? "हिन्दी" : "English"}</Text></Pressable>)}
          </View>
          <Text style={styles.feedbackHint}>Voice clips are limited to 90 seconds. You can review and edit the transcript before sending it to catalog search.</Text>
          <View style={styles.mediaActions}>
            {!voiceRecording ? <Pressable testID="chand-voice-start" disabled={voiceBusy || sending} onPress={() => void startVoiceRecording()} style={[styles.mediaButton, (voiceBusy || sending) && styles.sendDisabled]}><Feather name="mic" size={16} color={colors.brandForest} /><Text style={styles.mediaButtonText}>Record shopping request</Text></Pressable> : <>
              <Pressable testID="chand-voice-stop" onPress={() => void stopAndTranscribeVoice()} style={styles.mediaPrimary}><Feather name="square" size={14} color="#FFFFFF" /><Text style={styles.mediaPrimaryText}>Stop & transcribe</Text></Pressable>
              <Pressable testID="chand-voice-cancel" onPress={() => void cancelVoiceRecording()} style={styles.mediaButton}><Text style={styles.mediaButtonText}>Cancel recording</Text></Pressable>
            </>}
          </View>
          {voiceBusy ? <View style={styles.mediaStatus}><ActivityIndicator color={colors.brandPrimary} /><Text style={styles.feedbackHint}>Transcribing your recording…</Text></View> : null}
          {voiceRecording ? <Text accessibilityRole="status" style={styles.mediaError}>Recording… Tap Stop & transcribe when you are finished.</Text> : null}
          {voiceReview ? <Text accessibilityRole="status" style={styles.feedbackHint}>Transcription ready. Edit the text in the message box, then tap Send to search the live COME-IN catalog.</Text> : null}
          {voiceError ? <Text accessibilityRole="alert" style={styles.mediaError}>{voiceError}</Text> : null}
        </View>
        <View style={styles.inputRow}>
          <TextInput ref={messageInputRef} testID="chand-message-input" value={draft} onChangeText={setDraft} onSubmitEditing={() => send()} returnKeyType="send" maxLength={1000} multiline placeholder={t("chand.input.placeholder")} placeholderTextColor={colors.muted} style={styles.input} accessibilityLabel="Message CHAND" />
          <Pressable testID="chand-voice-typing" accessibilityRole="button" accessibilityLabel="Open device keyboard for voice typing" onPress={() => { setVoiceTypingHint(true); messageInputRef.current?.focus(); }} style={styles.voiceButton}>
            <Feather name="edit-3" size={18} color={colors.brandForest} />
          </Pressable>
          <Pressable testID="chand-send" accessibilityRole="button" accessibilityLabel={t("chand.send")} disabled={!draft.trim() || sending} onPress={() => send()} style={[styles.sendButton, (!draft.trim() || sending) && styles.sendDisabled]}>
            <Feather name="send" size={18} color="#FFFFFF" />
          </Pressable>
        </View>
        {partyOpen && <View style={styles.partyPanel} testID="chand-party-planner">
          <Text style={styles.feedbackTitle}>Plan a birthday or small gathering</Text>
          <View style={styles.feedbackChoices}>
            {(["birthday", "family gathering", "small party"] as const).map((occasion) => <Pressable key={occasion} onPress={() => { setPartyOccasion(occasion); setPartyServing(PARTY_OCCASION_SERVING_ASSUMPTIONS[occasion]); }} style={[styles.feedbackChoice, partyOccasion === occasion && styles.feedbackChoiceActive]}><Text style={styles.feedbackHint}>{occasion}</Text></Pressable>)}
          </View>
          <View style={styles.partyInputs}>
            <View style={{ flex: 1 }}><Text style={styles.feedbackHint}>Guests</Text><TextInput testID="chand-party-guests" value={partyGuests} onChangeText={(value) => setPartyGuests(value.replace(/[^0-9]/g, "").slice(0, 3))} keyboardType="number-pad" maxLength={3} style={styles.feedbackInput} /></View>
            <View style={{ flex: 1 }}><Text style={styles.feedbackHint}>Budget (₹)</Text><TextInput testID="chand-party-budget" value={partyBudget} onChangeText={(value) => setPartyBudget(value.replace(/[^0-9]/g, "").slice(0, 6))} keyboardType="number-pad" maxLength={6} style={styles.feedbackInput} /></View>
          </View>
          <Text style={styles.feedbackTitle}>Editable serving assumptions · per guest</Text>
          <View style={styles.partyInputs}>
            <View style={{ flex: 1 }}><Text style={styles.feedbackHint}>Snacks (g)</Text><TextInput testID="chand-party-snacks-serving" value={String(partyServing.snacksGramsPerGuest)} onChangeText={(v) => setPartyServing((a) => ({ ...a, snacksGramsPerGuest: Number(v.replace(/[^0-9]/g, "")) }))} keyboardType="number-pad" style={styles.feedbackInput} /></View>
            <View style={{ flex: 1 }}><Text style={styles.feedbackHint}>Drinks (ml)</Text><TextInput testID="chand-party-drinks-serving" value={String(partyServing.drinksMlPerGuest)} onChangeText={(v) => setPartyServing((a) => ({ ...a, drinksMlPerGuest: Number(v.replace(/[^0-9]/g, "")) }))} keyboardType="number-pad" style={styles.feedbackInput} /></View>
          </View>
          <View style={styles.partyInputs}>
            <View style={{ flex: 1 }}><Text style={styles.feedbackHint}>Bakery (pieces)</Text><TextInput testID="chand-party-bakery-serving" value={String(partyServing.bakeryPiecesPerGuest)} onChangeText={(v) => setPartyServing((a) => ({ ...a, bakeryPiecesPerGuest: Number(v.replace(/[^0-9]/g, "")) }))} keyboardType="number-pad" style={styles.feedbackInput} /></View>
            <View style={{ flex: 1 }}><Text style={styles.feedbackHint}>Fruit (g)</Text><TextInput testID="chand-party-fruit-serving" value={String(partyServing.fruitGramsPerGuest)} onChangeText={(v) => setPartyServing((a) => ({ ...a, fruitGramsPerGuest: Number(v.replace(/[^0-9]/g, "")) }))} keyboardType="number-pad" style={styles.feedbackInput} /></View>
          </View>
          <Text style={styles.feedbackHint}>These are editable planning assumptions, not nutrition advice. CHAND uses only live catalog listings with a known pack size or a valid Task 5 measured contract. Missing categories stay empty; no sample product or price is invented.</Text>
          <Pressable testID="chand-party-generate" disabled={!Number(partyGuests) || !Number(partyBudget) || partyLoading || sending} onPress={() => void generatePartyPlan()} style={styles.feedbackSubmit}><Text style={styles.feedbackSubmitText}>{partyLoading ? "Calculating from live catalog…" : "Calculate party quantities"}</Text></Pressable>
        </View>}
        <View style={styles.quickLinks}>
          <Pressable testID="chand-party-open" onPress={() => setPartyOpen((open) => !open)} style={styles.quickLink}><Feather name="gift" size={14} color={colors.brandPrimary} /><Text style={styles.quickLinkText}>Birthday / Party</Text></Pressable>
          <Pressable onPress={() => router.push("/(tabs)/categories")} style={styles.quickLink}><Feather name="grid" size={14} color={colors.brandPrimary} /><Text style={styles.quickLinkText}>{t("categories.title")}</Text></Pressable>
          <Pressable onPress={() => router.push("/restaurant")} style={styles.quickLink}><Feather name="coffee" size={14} color={colors.brandPrimary} /><Text style={styles.quickLinkText}>{t("chand.role.restaurant")}</Text></Pressable>
          <Pressable onPress={() => router.push("/services")} style={styles.quickLink}><Feather name="tool" size={14} color={colors.brandPrimary} /><Text style={styles.quickLinkText}>{t("services.title")}</Text></Pressable>
          <Pressable onPress={() => router.push("/orders")} style={styles.quickLink}><Feather name="package" size={14} color={colors.brandPrimary} /><Text style={styles.quickLinkText}>{t("account.pastOrders")}</Text></Pressable>
          <Pressable onPress={() => router.push("/request")} style={styles.quickLink}><Feather name="truck" size={14} color={colors.brandPrimary} /><Text style={styles.quickLinkText}>Pickup & Drop</Text></Pressable>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const useStyles = makeStyles((colors) => ({
  root: { flex: 1, backgroundColor: colors.surfaceSecondary },
  mediaPanel: { marginHorizontal: spacing.md, marginTop: spacing.sm, padding: spacing.md, gap: spacing.sm, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface },
  mediaActions: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: spacing.sm },
  mediaButton: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceTertiary },
  mediaButtonText: { color: colors.brandForest, fontWeight: "700", fontSize: 12 },
  mediaPrimary: { minHeight: 40, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: spacing.md, borderRadius: radius.md, backgroundColor: colors.brandPrimary },
  mediaPrimaryText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 12 },
  photoPreview: { width: "100%", height: 180, borderRadius: radius.md, backgroundColor: colors.surfaceTertiary },
  photoMatch: { gap: spacing.xs, paddingTop: spacing.sm, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  mediaStatus: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  mediaError: { color: colors.error, fontSize: 12, fontWeight: "700" },
  voicePanel: { marginHorizontal: spacing.md, marginTop: spacing.sm, padding: spacing.sm, gap: spacing.sm, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface },
  voiceLanguages: { flexDirection: "row", gap: spacing.sm },
  voiceLanguage: { minWidth: 58, alignItems: "center", paddingHorizontal: spacing.sm, paddingVertical: 6, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.border },
  voiceLanguageActive: { backgroundColor: colors.brandTertiary, borderColor: colors.brandPrimary },
  voiceLanguageText: { color: colors.brandForest, fontSize: 12, fontWeight: "700" },
  header: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: spacing.md, paddingBottom: spacing.md, backgroundColor: colors.brandHeader, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  back: { width: 38, height: 38, borderRadius: 19, backgroundColor: "#FFFFFFA8", alignItems: "center", justifyContent: "center" },
  brandMark: { width: 40, height: 40, borderRadius: 14, backgroundColor: colors.brandForest, alignItems: "center", justifyContent: "center", position: "relative" },
  brandHeart: { position: "absolute", right: 4, bottom: 4, width: 14, height: 14, borderRadius: 7, backgroundColor: colors.brandForest, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 19, fontWeight: "900", color: colors.brandForest, letterSpacing: 1 },
  subtitle: { fontSize: 10, fontWeight: "600", color: colors.brandForest, marginTop: 1 },
  demoPill: { paddingHorizontal: 9, paddingVertical: 5, borderRadius: radius.pill, backgroundColor: colors.brandForest },
  demoPillText: { fontSize: 10, fontWeight: "900", color: "#FFFFFF", letterSpacing: 0.6 },
  modeWrap: { paddingTop: spacing.md, paddingBottom: spacing.sm, backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border },
  sectionLabel: { marginHorizontal: spacing.lg, fontSize: 10, letterSpacing: 1, fontWeight: "900", color: colors.muted },
  modeRow: { paddingHorizontal: spacing.md, paddingTop: spacing.sm, gap: 8 },
  modeChip: { paddingHorizontal: 13, paddingVertical: 9, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceSecondary },
  modeChipActive: { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary },
  modeChipText: { color: colors.onSurface, fontSize: 12, fontWeight: "700" },
  modeChipTextActive: { color: "#FFFFFF" },
  conversation: { flex: 1 },
  messages: { padding: spacing.lg, gap: spacing.md, flexGrow: 1 },
  messageRow: { flexDirection: "row", alignItems: "flex-end", gap: 7, maxWidth: "96%" },
  userRow: { alignSelf: "flex-end", justifyContent: "flex-end" },
  miniMark: { width: 25, height: 25, borderRadius: 9, backgroundColor: colors.brandForest, alignItems: "center", justifyContent: "center", marginBottom: 2 },
  bubble: { paddingHorizontal: 14, paddingVertical: 11, borderRadius: 17, maxWidth: "100%" },
  assistantBubble: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderBottomLeftRadius: 5 },
  userBubble: { backgroundColor: colors.brandPrimary, borderBottomRightRadius: 5 },
  messageText: { fontSize: 14, lineHeight: 21, color: colors.onSurface },
  recommendations: { gap: spacing.sm, width: "100%" },
  recommendationItem: { gap: 4 },
  recommendationMeta: { color: colors.muted, fontSize: 10, lineHeight: 14, paddingHorizontal: 2 },
  recommendationHeading: { color: colors.brandForest, fontSize: 10, fontWeight: "900", letterSpacing: 0.8 },
  userMessageText: { color: "#FFFFFF" },
  loadingRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingLeft: 30 },
  loadingText: { color: colors.muted, fontSize: 12 },
  errorRow: { padding: spacing.sm, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, gap: 6 },
  errorText: { color: colors.muted, fontSize: 11, lineHeight: 15 },
  retryButton: { alignSelf: "flex-start", paddingHorizontal: 12, paddingVertical: 7, borderRadius: radius.md, backgroundColor: colors.brandPrimary },
  retryText: { color: "#FFFFFF", fontSize: 11, fontWeight: "800" },
  disclaimer: { color: colors.muted, fontSize: 10, lineHeight: 15, textAlign: "center", marginTop: "auto", paddingTop: spacing.md },
  partyPanel: { padding: 12, marginHorizontal: spacing.md, marginBottom: spacing.sm, gap: 9, borderRadius: radius.md, borderWidth: 1, borderColor: colors.brandPrimary, backgroundColor: colors.surface },
  partyInputs: { flexDirection: "row", gap: 10 },
  planPanel: { padding: 12, marginTop: spacing.md, gap: 9, borderRadius: radius.md, borderWidth: 1, borderColor: colors.brandPrimary, backgroundColor: colors.surface },
  planAddButton: { alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 7, borderRadius: radius.md, backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border },
  planAddText: { color: colors.brandForest, fontSize: 11, fontWeight: "800" },
  planLine: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 5, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  planName: { color: colors.onSurface, fontSize: 12, fontWeight: "700" },
  planQty: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  planQtyText: { color: colors.onSurface, fontSize: 12, fontWeight: "700", minWidth: 14, textAlign: "center" },
  feedbackPanel: { padding: 12, marginTop: spacing.md, gap: 8, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface },
  feedbackTitle: { color: colors.onSurface, fontSize: 12, fontWeight: "800" },
  feedbackHint: { color: colors.muted, fontSize: 10, lineHeight: 14 },
  feedbackChoices: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  feedbackChoice: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, paddingHorizontal: 10, paddingVertical: 8 },
  feedbackChoiceActive: { borderColor: colors.brandPrimary, backgroundColor: colors.surfaceSecondary },
  feedbackInput: { minHeight: 42, maxHeight: 90, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: 9, color: colors.onSurface, fontSize: 12 },
  feedbackSubmit: { alignSelf: "flex-start", paddingHorizontal: 13, paddingVertical: 9, borderRadius: radius.md, backgroundColor: colors.brandPrimary },
  feedbackSubmitText: { color: "#FFFFFF", fontSize: 11, fontWeight: "800" },
  helpEntryWrap: { backgroundColor: colors.surface, paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  helpEntry: { minHeight: 54, flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 13, paddingVertical: 10, borderRadius: radius.md, backgroundColor: colors.brandForest },
  helpEntryTitle: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  helpEntrySubtitle: { color: "#E5F4E9", fontSize: 10, marginTop: 2 },
  helpPanel: { maxHeight: 330, marginTop: 8, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceSecondary, padding: spacing.md },
  helpHeading: { fontSize: 14, fontWeight: "900", color: colors.onSurface },
  helpBody: { fontSize: 11, lineHeight: 16, color: colors.muted },
  helpWarning: { fontSize: 11, lineHeight: 16, color: colors.onSurface, backgroundColor: colors.surface, padding: 10, borderRadius: radius.sm },
  orderChoice: { flexDirection: "row", alignItems: "center", gap: 8, padding: 10, borderRadius: radius.md, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  orderChoiceActive: { borderColor: colors.brandPrimary, borderWidth: 2 },
  orderTitle: { fontSize: 11, fontWeight: "800", color: colors.onSurface },
  refundStatus: { fontSize: 11, fontWeight: "800", color: colors.brandPrimary, marginTop: 3 },
  supportCategoryRow: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  supportCategory: { paddingHorizontal: 10, paddingVertical: 7, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface },
  supportCategoryActive: { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary },
  supportCategoryText: { color: colors.onSurface, fontSize: 10, fontWeight: "700" },
  supportCategoryTextActive: { color: "#FFFFFF" },
  supportInput: { minHeight: 70, maxHeight: 110, padding: 10, borderRadius: radius.md, borderWidth: 1, borderColor: colors.borderStrong, color: colors.onSurface, backgroundColor: colors.surface, fontSize: 12, textAlignVertical: "top" },
  helpError: { color: "#B00020", fontSize: 11, lineHeight: 16 },
  helpSuccess: { color: "#176B42", fontSize: 11, lineHeight: 16 },
  supportActions: { flexDirection: "row", gap: 8, flexWrap: "wrap" },
  supportSecondary: { minHeight: 38, justifyContent: "center", paddingHorizontal: 10, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border },
  supportSecondaryText: { color: colors.onSurface, fontSize: 10, fontWeight: "800" },
  supportSubmit: { minHeight: 38, justifyContent: "center", paddingHorizontal: 12, borderRadius: radius.md, backgroundColor: colors.brandPrimary },
  supportSubmitText: { color: "#FFFFFF", fontSize: 10, fontWeight: "900" },
  ticketCard: { padding: 10, gap: 4, borderRadius: radius.md, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  confirmCard: { padding: 11, gap: 8, borderRadius: radius.md, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.brandPrimary },
  helpFinePrint: { fontSize: 10, lineHeight: 15, color: colors.muted },
  composerArea: { backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.md, paddingBottom: Platform.OS === "ios" ? spacing.lg : spacing.md, gap: spacing.sm },
  suggestionRow: { paddingHorizontal: spacing.md, gap: 8 },
  suggestion: { maxWidth: 250, paddingHorizontal: 11, paddingVertical: 8, borderRadius: radius.md, backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border },
  suggestionText: { fontSize: 11, color: colors.onSurface, fontWeight: "600" },
  inputRow: { flexDirection: "row", alignItems: "flex-end", gap: 8, marginHorizontal: spacing.md, padding: 7, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: 18, backgroundColor: colors.surfaceSecondary },
  input: { flex: 1, maxHeight: 100, minHeight: 40, paddingHorizontal: 9, paddingVertical: 9, fontSize: 14, color: colors.onSurface, textAlignVertical: "center" },
  voiceButton: { width: 40, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface },
  voiceHint: { marginHorizontal: spacing.md, color: colors.muted, fontSize: 10, lineHeight: 15 },
  sendButton: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: colors.brandPrimary },
  sendDisabled: { opacity: 0.45 },
  quickLinks: { flexDirection: "row", justifyContent: "space-around", paddingHorizontal: spacing.xs },
  quickLink: { minHeight: 34, paddingHorizontal: 5, flexDirection: "row", alignItems: "center", gap: 4 },
  quickLinkText: { color: colors.brandPrimary, fontSize: 11, fontWeight: "700" },
}));
