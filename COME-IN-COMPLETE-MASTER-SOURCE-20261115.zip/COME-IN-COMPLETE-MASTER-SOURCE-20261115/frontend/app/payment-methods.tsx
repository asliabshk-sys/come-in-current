import Feather from "@react-native-vector-icons/feather";
import { useRouter } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme, spacing, radius , colors as themeColors } from "@/src/theme";

/** Describes only payment methods implemented by the candidate checkout flows. */
export default function PaymentMethodsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.surfaceSecondary }} contentContainerStyle={{ padding: spacing.lg, paddingTop: insets.top + spacing.lg, gap: spacing.md }}>
      <Pressable accessibilityRole="button" onPress={() => router.back()} style={styles.back}><Feather name="arrow-left" size={18} color={colors.onSurface}/><Text style={{ color: colors.onSurface, fontWeight: "700" }}>Back</Text></Pressable>
      <Text style={{ color: colors.onSurface, fontSize: 26, fontWeight: "900" }}>Payment methods</Text>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Feather name="dollar-sign" size={24} color={colors.brandPrimary}/>
        <Text style={{ color: colors.onSurface, fontSize: 16, fontWeight: "800" }}>Cash on Delivery — Shopping</Text>
        <Text style={{ color: colors.muted, lineHeight: 21 }}>The grocery checkout currently supports COD. Online Stripe/Razorpay options are not available in the customer checkout flow.</Text>
      </View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Feather name="shopping-bag" size={24} color={colors.brandPrimary}/>
        <Text style={{ color: colors.onSurface, fontSize: 16, fontWeight: "800" }}>Restaurant orders</Text>
        <Text style={{ color: colors.muted, lineHeight: 21 }}>The restaurant checkout supports COD for delivery or pay-at-pickup when the restaurant allows it. Availability is checked by the backend at order creation.</Text>
      </View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={{ color: colors.onSurface, fontSize: 16, fontWeight: "800" }}>Continue with a supported checkout</Text>
        <Text style={{ color: colors.muted, lineHeight: 21 }}>Payment options are selected and validated when an order is checked out; this account page does not store card or bank details.</Text>
        <Pressable accessibilityRole="button" onPress={() => router.push("/(tabs)/cart")} style={styles.action}><Text style={{ color: colors.onBrandPrimary, fontWeight: "800" }}>Shopping checkout · COD</Text></Pressable>
        <Pressable accessibilityRole="button" onPress={() => router.push("/restaurant/cart")} style={[styles.action, { backgroundColor: colors.brandForest }]}><Text style={{ color: "#FFFFFF", fontWeight: "800" }}>Restaurant checkout · COD / pickup</Text></Pressable>
      </View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Feather name="lock" size={24} color={colors.muted}/>
        <Text style={{ color: colors.onSurface, fontSize: 16, fontWeight: "800" }}>Online payments unavailable</Text>
        <Text style={{ color: colors.muted, lineHeight: 21 }}>Razorpay server endpoints exist for restaurant payments, but a customer-facing gateway checkout is not integrated here. No payment was initiated and no payment method is saved on this screen.</Text>
      </View>
    </ScrollView>
  );
}
const styles = StyleSheet.create({ back: { flexDirection: "row", alignItems: "center", gap: 8, alignSelf: "flex-start", paddingVertical: 8 }, card: { borderWidth: 1, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.md }, action: { backgroundColor: themeColors.brandPrimary, borderRadius: radius.md, paddingVertical: 12, paddingHorizontal: spacing.lg, alignItems: "center" } });
