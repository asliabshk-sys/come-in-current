// Local demo data and browse-only reference catalog for Come In app.
import { REFERENCE_CATALOG } from "@/src/data/catalog-reference";

export type ProductVariant = {
  /** Stable, product-scoped identifier; do not derive from display labels. */
  id: string;
  unit: string;
  price: number;
  mrp?: number;
  stock?: number;
  available?: boolean;
};

export type Product = {
  id: string;
  name: string;
  brand: string;
  unit: string;
  price: number;
  mrp?: number;
  image: string;
  categoryId: string;
  description: string;
  popular?: boolean;
  /** Optional explicit sellable variants. Legacy products remain single-variant. */
  variants?: ProductVariant[];
  /** Stock for legacy single-variant products; undefined means not specified in demo catalog. */
  stock?: number;
  source?: "demo" | "catalog" | "live";
  shopId?: string;
  shopName?: string;
  shopType?: string;
  shopDeliveryAvailable?: boolean;
  shopPickupAvailable?: boolean;
  masterProductId?: string;
  masterVariantId?: string;
  /** Measured products: price per kg / L, stock in g / ml. */
  sellBy?: "pack" | "weight" | "volume";
  measure?: { min_qty: number; max_qty: number; step: number; presets: number[] };
};

export type Category = {
  id: string;
  name: string;
  image: string;
  tint: string;
};

export type Service = {
  id: string;
  title: string;
  tagline: string;
  price: string;
  image: string;
};

export const CATEGORIES: Category[] = [
  { id: "atta-rice-dal", name: "Grocery & Staples", image: "https://images.unsplash.com/photo-1610725664285-7c57e6eeac3f?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FEF3C7" },
  { id: "masalas-oils", name: "Cooking Essentials", image: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FFEDD5" },
  { id: "snacks", name: "Snacks & Namkeen", image: "https://images.unsplash.com/photo-1621939514649-280e2ee25f60?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FEE2E2" },
  { id: "bakery", name: "Biscuits, Cookies & Bakery", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#F9E8CF" },
  { id: "beverages", name: "Cold Drinks & Beverages", image: "https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#DBEAFE" },
  { id: "tea-coffee", name: "Tea & Coffee", image: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FDE68A" },
  { id: "dairy-breakfast", name: "Dairy Products", image: "https://images.unsplash.com/photo-1634141510639-d691d86f47be?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#D1FAE5" },
  { id: "fruits", name: "Fruits", image: "https://images.unsplash.com/photo-1610832958506-aa56368176cf?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FDE68A" },
  { id: "fruits-veggies", name: "Vegetables", image: "https://images.unsplash.com/photo-1542838132-92c53300491e?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#DCFCE7" },
  { id: "personal-care", name: "Personal Care", image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FCE7F3" },
  { id: "household", name: "Cleaning & Household", image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#E0E7FF" },
  { id: "frozen-foods", name: "Frozen Foods & Ice Cream", image: "https://images.unsplash.com/photo-1501446529957-6226bd447c46?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#DBEAFE" },
  { id: "packaged-foods", name: "Packaged Foods", image: "https://images.unsplash.com/photo-1606787366850-de6330128bfc?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FEF3C7" },
  { id: "eggs", name: "Eggs", image: "https://images.unsplash.com/photo-1506976785307-8732e854ad03?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FEF3C7" },
  { id: "stationery", name: "Stationery", image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#E0E7FF" },
  { id: "baby-care", name: "Baby Care", image: "https://images.unsplash.com/photo-1519689680058-324335c77eba?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#FCE7F3" },
  { id: "pet-supplies", name: "Pet Supplies", image: "https://images.unsplash.com/photo-1450778869180-41d0601e046e?crop=entropy&cs=srgb&fm=jpg&w=400&q=80", tint: "#D1FAE5" },
];

const DEMO_PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "Aashirvaad Atta",
    brand: "Aashirvaad",
    unit: "5 kg",
    price: 280,
    mrp: 320,
    image:
      "https://images.unsplash.com/photo-1610725664285-7c57e6eeac3f?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "atta-rice-dal",
    description:
      "Made from 100% whole wheat, Aashirvaad Atta gives you soft, fluffy rotis that stay fresh for hours.",
    popular: true,
  },
  {
    id: "p2",
    name: "Amul Taaza Toned Milk",
    brand: "Amul",
    unit: "1 L",
    price: 65,
    mrp: 68,
    image:
      "https://images.unsplash.com/photo-1634141510639-d691d86f47be?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "dairy-breakfast",
    description:
      "Pasteurized toned milk, rich in calcium and protein. Delivered fresh to your doorstep.",
    popular: true,
  },
  {
    id: "p3",
    name: "Tata Salt",
    brand: "Tata",
    unit: "1 kg",
    price: 30,
    image:
      "https://images.unsplash.com/photo-1634612831148-03a8550e1d52?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "atta-rice-dal",
    description:
      "India's trusted iodized salt. Essential for every kitchen, every meal.",
    popular: true,
  },
  {
    id: "p4",
    name: "India Gate Basmati Rice",
    brand: "India Gate",
    unit: "5 kg",
    price: 749,
    mrp: 820,
    image:
      "https://images.unsplash.com/photo-1586201375761-83865001e31c?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "atta-rice-dal",
    description:
      "Premium long-grain basmati rice, perfectly aged for aromatic biryanis and pulao.",
    popular: true,
  },
  {
    id: "p5",
    name: "Toor Dal",
    brand: "Tata Sampann",
    unit: "1 kg",
    price: 165,
    image:
      "https://images.unsplash.com/photo-1596097635121-14b63b7a0c33?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "atta-rice-dal",
    description: "Unpolished premium toor dal with high protein content.",
  },
  {
    id: "p6",
    name: "Amul Butter",
    brand: "Amul",
    unit: "500 g",
    price: 275,
    image:
      "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "dairy-breakfast",
    description: "Pasteurised salted butter made from fresh cream.",
  },
  {
    id: "p7",
    name: "Mother Dairy Dahi",
    brand: "Mother Dairy",
    unit: "400 g",
    price: 50,
    image:
      "https://images.unsplash.com/photo-1571212515416-fef01fc43637?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "dairy-breakfast",
    description: "Thick and creamy dahi, perfect with every Indian meal.",
  },
  {
    id: "p8",
    name: "Fresh Tomato",
    brand: "Local Farm",
    unit: "500 g",
    price: 25,
    mrp: 35,
    image:
      "https://images.unsplash.com/photo-1546470427-227df6ee1a3b?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "fruits-veggies",
    description: "Juicy, farm-fresh tomatoes handpicked from local farms.",
    popular: true,
  },
  {
    id: "p9",
    name: "Fresh Onion",
    brand: "Local Farm",
    unit: "1 kg",
    price: 42,
    image:
      "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "fruits-veggies",
    description: "Everyday onions, carefully graded and cleaned.",
  },
  {
    id: "p10",
    name: "Shimla Apple",
    brand: "Fresh Picks",
    unit: "1 kg",
    price: 180,
    mrp: 220,
    image:
      "https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "fruits",
    description: "Crispy, sweet apples straight from the hills of Himachal.",
    popular: true,
  },
  {
    id: "p11",
    name: "Lay's Classic Salted",
    brand: "Lay's",
    unit: "52 g",
    price: 20,
    image:
      "https://images.unsplash.com/photo-1613919113640-25732ec5e61f?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "snacks",
    description: "Crispy potato chips with a perfect pinch of salt.",
  },
  {
    id: "p12",
    name: "Parle-G Biscuits",
    brand: "Parle",
    unit: "800 g",
    price: 85,
    image:
      "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "snacks",
    description: "The original glucose biscuit loved by generations.",
    popular: true,
  },
  {
    id: "p13",
    name: "Coca-Cola",
    brand: "Coca-Cola",
    unit: "750 ml",
    price: 40,
    image:
      "https://images.unsplash.com/photo-1554866585-cd94860890b7?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "beverages",
    description: "The classic refreshing cola.",
  },
  {
    id: "p14",
    name: "Real Mixed Fruit Juice",
    brand: "Real",
    unit: "1 L",
    price: 115,
    mrp: 135,
    image:
      "https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "beverages",
    description: "A blend of 7 real fruits with no added preservatives.",
  },
  {
    id: "p15",
    name: "Surf Excel Easy Wash",
    brand: "Surf Excel",
    unit: "1 kg",
    price: 140,
    image:
      "https://images.unsplash.com/photo-1583947215259-38e31be8751f?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "household",
    description: "Removes tough stains in just one wash.",
  },
  {
    id: "p16",
    name: "Vim Dishwash Bar",
    brand: "Vim",
    unit: "250 g",
    price: 25,
    image:
      "https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "household",
    description: "Tough on grease, gentle on hands.",
  },
  {
    id: "p17",
    name: "Dove Beauty Bar",
    brand: "Dove",
    unit: "100 g",
    price: 65,
    image:
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "personal-care",
    description: "¼ moisturising cream for soft, radiant skin.",
  },
  {
    id: "p18",
    name: "Colgate MaxFresh",
    brand: "Colgate",
    unit: "150 g",
    price: 90,
    image:
      "https://images.unsplash.com/photo-1559591935-c6c92c6a84a1?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "personal-care",
    description: "Freshness that lasts, with cooling crystals.",
  },
  {
    id: "p19",
    name: "Fortune Sunflower Oil",
    brand: "Fortune",
    unit: "1 L",
    price: 160,
    mrp: 180,
    image:
      "https://images.unsplash.com/photo-1620706857370-e1b9770e8bb1?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "masalas-oils",
    description: "Light, healthy, and rich in Vitamin A, D & E.",
  },
  {
    id: "p20",
    name: "MDH Garam Masala",
    brand: "MDH",
    unit: "100 g",
    price: 85,
    image:
      "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
    categoryId: "masalas-oils",
    description: "Authentic Indian garam masala for rich, aromatic curries.",
  },
];

// Existing sample products remain explicitly preview-only; they are never live inventory.
const DEMO_PRODUCTS_WITH_SOURCE: Product[] = DEMO_PRODUCTS.map((product) => ({ ...product, source: "demo" }));

const REFERENCE_CATEGORY_IDS: Record<string, string> = {
  "grocery-staples": "atta-rice-dal",
  "cooking-essentials": "masalas-oils",
  "snacks-namkeen": "snacks",
  "biscuits-bakery": "bakery",
  "beverages": "beverages",
  "tea-coffee": "tea-coffee",
  "dairy-products": "dairy-breakfast",
  "fruits": "fruits",
  "vegetables": "fruits-veggies",
  "personal-care": "personal-care",
  "cleaning-household": "household",
  "frozen-foods": "frozen-foods",
  "packaged-foods": "packaged-foods",
  "eggs": "eggs",
  "stationery": "stationery",
  "baby-care": "baby-care",
  "pet-supplies": "pet-supplies",
};

function referenceId(categoryId: string, name: string): string {
  const slug = name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 64);
  return `ref-${categoryId}-${slug}`;
}

const DEMO_NAME_KEYS = new Set(DEMO_PRODUCTS_WITH_SOURCE.map((p) => `${p.categoryId}:${p.name.trim().toLocaleLowerCase()}`));
const REFERENCE_PRODUCTS: Product[] = Object.entries(REFERENCE_CATALOG).flatMap(([referenceCategory, names]) => {
  const categoryId = REFERENCE_CATEGORY_IDS[referenceCategory];
  if (!categoryId) return [];
  const seen = new Set<string>();
  return names.filter((name) => {
    const key = name.trim().toLocaleLowerCase();
    if (seen.has(key) || DEMO_NAME_KEYS.has(`${categoryId}:${key}`)) return false;
    seen.add(key);
    return true;
  }).map((name) => ({
    id: referenceId(categoryId, name), name, brand: "", unit: "", price: 0,
    image: referenceProductImage(categoryId, name),
    categoryId, description: "Catalog reference only. A shop must publish its own verified listing, pack size, price and stock before this item can be ordered.", source: "catalog" as const,
  }));
});

// Product-specific illustrative image mapping for browse-only master references.
// These images are presentation assets only; they do not imply verified stock, price or brand.
function referenceProductImage(categoryId: string, name: string): string {
  const n = name.toLowerCase();
  const imageByTerm: Array<[RegExp, string]> = [
    [/\b(rice|basmati|poha|puffed rice)\b/, "https://images.unsplash.com/photo-1586201375761-83865001e31c?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(dal|dhal|lentil|chana|chickpea|rajma|kidney bean|moong|masoor|toor)\b/, "https://images.unsplash.com/photo-1596097635121-14b63b7a0c33?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(atta|flour|wheat|maida|besan)\b/, "https://images.unsplash.com/photo-1610725664285-7c57e6eeac3f?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(sugar|jaggery)\b/, "https://images.unsplash.com/photo-1581441363689-1f3c3c414635?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(milk|curd|yogurt|paneer|butter|cheese|ghee)\b/, "https://images.unsplash.com/photo-1634141510639-d691d86f47be?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(oil|masala|spice|turmeric|chilli|cumin|garam)\b/, "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(biscuit|cookie|bread|bakery|rusk)\b/, "https://images.unsplash.com/photo-1509440159596-0249088772ff?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(apple|banana|mango|orange|fruit)\b/, "https://images.unsplash.com/photo-1610832958506-aa56368176cf?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
    [/\b(vegetable|tomato|potato|onion|spinach)\b/, "https://images.unsplash.com/photo-1542838132-92c53300491e?crop=entropy&cs=srgb&fm=jpg&w=600&q=80"],
  ];
  const match = imageByTerm.find(([pattern]) => pattern.test(n));
  if (match) return match[1];
  return CATEGORIES.find((category) => category.id === categoryId)?.image || CATEGORIES[0].image;
}

// Reference catalog records are browseable but never represented as shop inventory or orderable offers.
export const PRODUCTS: Product[] = [...DEMO_PRODUCTS_WITH_SOURCE, ...REFERENCE_PRODUCTS];

/** Bundled category illustrations are deterministic offline fallbacks, not claimed product-packaging photos. */
export function getProductPlaceholder(categoryId: string): number {
  const placeholders: Record<string, number> = {
    "atta-rice-dal": require("../../assets/images/placeholders/atta-rice-dal.png"),
    "dairy-breakfast": require("../../assets/images/placeholders/dairy-breakfast.png"),
    "fruits-veggies": require("../../assets/images/placeholders/fruits-veggies.png"),
    snacks: require("../../assets/images/placeholders/snacks.png"),
    beverages: require("../../assets/images/placeholders/beverages.png"),
    household: require("../../assets/images/placeholders/household.png"),
    bakery: require("../../assets/images/placeholders/bakery.png"),
    "personal-care": require("../../assets/images/placeholders/personal-care.png"),
    "masalas-oils": require("../../assets/images/placeholders/masalas-oils.png"),
    "tea-coffee": require("../../assets/images/placeholders/tea-coffee.png"),
    "fruits": require("../../assets/images/placeholders/fruits.png"),
    "frozen-foods": require("../../assets/images/placeholders/frozen-foods.png"),
    "packaged-foods": require("../../assets/images/placeholders/packaged-foods.png"),
    "eggs": require("../../assets/images/placeholders/eggs.png"),
    "stationery": require("../../assets/images/placeholders/stationery.png"),
    "baby-care": require("../../assets/images/placeholders/baby-care.png"),
    "pet-supplies": require("../../assets/images/placeholders/pet-supplies.png"),
  };
  return placeholders[categoryId] ?? placeholders.household;
}

export const SERVICES: Service[] = [
  {
    id: "s1",
    title: "Home Cleaning",
    tagline: "Deep clean by trained pros",
    price: "₹499 onwards",
    image:
      "https://images.unsplash.com/photo-1581578731548-c64695cc6952?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
  },
  {
    id: "s2",
    title: "Plumber on-demand",
    tagline: "Leak, tap, geyser fix",
    price: "₹149 visit",
    image: "https://images.pexels.com/photos/6195899/pexels-photo-6195899.jpeg",
  },
  {
    id: "s3",
    title: "Electrician",
    tagline: "Fans, switches, wiring",
    price: "₹149 visit",
    image:
      "https://images.unsplash.com/photo-1621905252507-b35492cc74b4?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
  },
  {
    id: "s4",
    title: "AC Service",
    tagline: "Deep service & gas refill",
    price: "₹599 onwards",
    image:
      "https://images.unsplash.com/photo-1631545308456-1839f04b4e23?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
  },
  {
    id: "s5",
    title: "Salon at home",
    tagline: "Hair, beauty, grooming",
    price: "₹299 onwards",
    image:
      "https://images.unsplash.com/photo-1562322140-8baeececf3df?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
  },
  {
    id: "s6",
    title: "Laundry pickup",
    tagline: "Wash & iron at your door",
    price: "₹70/kg",
    image:
      "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?crop=entropy&cs=srgb&fm=jpg&w=600&q=80",
  },
];

export const QUICK_DELIVERY_PRODUCTS = PRODUCTS.filter((p) =>
  ["p2", "p8", "p11", "p13", "p12"].includes(p.id),
);

export const POPULAR_PRODUCTS = PRODUCTS.filter((p) => p.popular);

export function getProductById(id: string): Product | undefined {
  return PRODUCTS.find((p) => p.id === id);
}

export function getProductsByCategory(categoryId: string): Product[] {
  return PRODUCTS.filter((p) => p.categoryId === categoryId);
}

export function getCategoryById(id: string): Category | undefined {
  return CATEGORIES.find((c) => c.id === id);
}

export function searchProducts(query: string): Product[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return PRODUCTS.filter(
    (p) =>
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.unit.toLowerCase().includes(q),
  );
}
