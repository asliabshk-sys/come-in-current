import { useEffect, useState } from "react";

import { Product, ProductVariant } from "@/src/data/catalog";
import { api, resolveImage } from "@/src/lib/api";

export type CatalogState = { liveProducts: Product[]; loading: boolean; error: string | null };

function mapLiveProduct(row: any): Product {
  const variants: ProductVariant[] = Array.isArray(row.variants)
    ? row.variants.map((v: any) => ({ id: String(v.id), unit: String(v.unit || ""), price: Number(v.price), mrp: v.mrp == null ? undefined : Number(v.mrp), stock: Number(v.stock ?? 0), available: v.available !== false }))
      .filter((v: ProductVariant) => v.available !== false && Number(v.stock ?? 0) > 0)
    : [];
  const unit = String(row.unit || variants[0]?.unit || "");
  return {
    id: String(row.id), name: String(row.name || "Product"), brand: String(row.brand || ""), unit,
    price: Number(variants[0]?.price ?? row.price ?? 0), mrp: variants[0]?.mrp ?? row.mrp,
    image: resolveImage(row.image_url) || "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80",
    categoryId: String(row.category_id || "uncategorized"), description: String(row.description || ""),
    variants, stock: Number(row.stock ?? 0), source: "live", shopId: String(row.shop_id || ""),
    shopName: String(row.shop_name || ""), shopType: String(row.shop_type || "offline"),
    ...(row.master_product_id && row.master_variant_id ? { masterProductId: String(row.master_product_id), masterVariantId: String(row.master_variant_id) } : {}),
    ...((row.sell_by === "weight" || row.sell_by === "volume") && row.measure && !variants.length ? {
      sellBy: row.sell_by,
      measure: { min_qty: Number(row.measure.min_qty), max_qty: Number(row.measure.max_qty), step: Number(row.measure.step), presets: Array.isArray(row.measure.presets) ? row.measure.presets.map(Number) : [] },
    } : {}),
  };
}

export function useCatalogProducts(): CatalogState {
  const [liveProducts, setLiveProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    api.get<any[]>("/catalog/products", false).then((rows) => {
      if (!active) return;
      setLiveProducts(rows.map(mapLiveProduct).filter((p) => p.id && p.shopId && p.source === "live"));
      setError(null);
    }).catch((e: any) => {
      if (!active) return;
      setLiveProducts([]);
      setError(e?.message || "Live catalog is unavailable. Demo previews remain separate.");
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  return { liveProducts, loading, error };
}
