import { useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";

import { useT } from "@/src/i18n";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

export type SellBy = "pack" | "weight" | "volume";
export type MeasureDraft = { min_qty: number; max_qty: number; step: number; presets: number[] };
type Props = {
  sellBy: SellBy;
  measure?: MeasureDraft | null;
  stock: number;
  onChange: (next: { sell_by: SellBy; measure: MeasureDraft | null; stock?: number }) => void;
};

const DEFAULTS: MeasureDraft = { min_qty: 250, max_qty: 5000, step: 250, presets: [250, 500, 1000] };
const OPTIONS: Array<{ id: SellBy; label: string }> = [{ id: "pack", label: "m.optPack" }, { id: "weight", label: "m.optWeight" }, { id: "volume", label: "m.optVolume" }];

export function SellerMeasuredFields({ sellBy, measure, stock, onChange }: Props) {
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  const m = measure || DEFAULTS;
  const small = sellBy === "volume" ? "ml" : "g";
  const big = sellBy === "volume" ? "L" : "kg";
  const [stockText, setStockText] = useState(String(stock / 1000));
  const [presetText, setPresetText] = useState(m.presets.join(", "));
  const set = (patch: Partial<MeasureDraft>) => onChange({ sell_by: sellBy, measure: { ...m, ...patch } });
  const num = (v: string) => Math.max(0, Math.round(Number(v) || 0));

  return (
    <View style={styles.wrap} testID="seller-sell-by">
      <Text style={styles.label}>{t("m.sellQuestion")}</Text>
      <View style={styles.row}>
        {OPTIONS.map((o) => (
          <Pressable key={o.id} testID={`seller-sell-by-${o.id}`} onPress={() => onChange({ sell_by: o.id, measure: o.id === "pack" ? null : m })} style={[styles.chip, sellBy === o.id && { backgroundColor: colors.brandPrimary }]}>
            <Text style={[styles.chipText, sellBy === o.id && { color: colors.onBrandPrimary }]}>{t(o.label)}</Text>
          </Pressable>
        ))}
      </View>
      {sellBy !== "pack" && (
        <View style={{ gap: spacing.xs }}>
          <Text style={styles.meta}>{t("m.sellerHint", { unit: big })}</Text>
          <Input label={t("m.stockLabel", { unit: big })} value={stockText} testID="seller-measured-stock" onChange={(v: string) => { setStockText(v); const n = Number(v); if (Number.isFinite(n) && n >= 0) onChange({ sell_by: sellBy, measure: m, stock: Math.round(n * 1000) }); }} />
          <View style={styles.row}>
            <Input label={t("m.minLabel", { unit: small })} value={String(m.min_qty)} testID="seller-measured-min" onChange={(v: string) => set({ min_qty: num(v) })} />
            <Input label={t("m.maxLabel", { unit: small })} value={String(m.max_qty)} testID="seller-measured-max" onChange={(v: string) => set({ max_qty: num(v) })} />
            <Input label={t("m.stepLabel", { unit: small })} value={String(m.step)} testID="seller-measured-step" onChange={(v: string) => set({ step: num(v) })} />
          </View>
          <Input label={t("m.presetsLabel", { unit: small })} value={presetText} testID="seller-measured-presets" onChange={(v: string) => { setPresetText(v); set({ presets: v.split(",").map((x) => num(x)).filter((x) => x > 0).slice(0, 8) }); }} />
        </View>
      )}
    </View>
  );
}

function Input({ label, value, onChange, testID }: { label: string; value: string; onChange: (v: string) => void; testID: string }) {
  const styles = useStyles();
  const { colors } = useTheme();
  return (
    <View style={{ flex: 1, minWidth: 90 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput testID={testID} value={value} onChangeText={onChange} keyboardType="decimal-pad" placeholderTextColor={colors.muted} style={styles.input} />
    </View>
  );
}

export function measureError(sellBy: SellBy, m?: MeasureDraft | null): string | null {
  if (sellBy === "pack") return null;
  if (!m || m.min_qty < 1 || m.step < 1 || m.max_qty < m.min_qty) return "Measured products need min ≥ 1, step ≥ 1 and max ≥ min.";
  if (m.presets.some((p) => p < m.min_qty || p > m.max_qty || (p - m.min_qty) % m.step)) return "Each quick amount must be between min and max and match the step size.";
  return null;
}

const useStyles = makeStyles((colors) => ({
  wrap: { marginTop: spacing.md, gap: spacing.xs },
  row: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  chip: { paddingHorizontal: spacing.md, paddingVertical: 8, borderRadius: radius.pill, backgroundColor: colors.surfaceTertiary },
  chipText: { fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary },
  label: { marginTop: spacing.sm, marginBottom: 6, fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary },
  meta: { fontSize: 11, color: colors.muted },
  input: { backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: 10, fontSize: 14, color: colors.onSurface },
}));
