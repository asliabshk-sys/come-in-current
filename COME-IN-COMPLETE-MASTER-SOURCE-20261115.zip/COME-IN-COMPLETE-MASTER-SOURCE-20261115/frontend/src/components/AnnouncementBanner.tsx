import Feather from "@react-native-vector-icons/feather";
import { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";

import { useT } from "@/src/i18n";
import { api } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Announcement = { id: string; title: string; body: string };

/** Admin announcements (Task 15) shown to the audience the admin targeted. */
export function AnnouncementBanner() {
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  const { user } = useAuth();
  const [rows, setRows] = useState<Announcement[]>([]);
  const [hidden, setHidden] = useState<string[]>([]);

  useEffect(() => {
    let active = true;
    api.get<Announcement[]>("/announcements/active", Boolean(user))
      .then((r) => { if (active) setRows(Array.isArray(r) ? r : []); })
      .catch(() => { if (active) setRows([]); });
    return () => { active = false; };
  }, [user]);

  const visible = rows.filter((r) => !hidden.includes(r.id)).slice(0, 2);
  if (!visible.length) return null;
  return (
    <View style={{ gap: spacing.sm }} testID="announcement-banner">
      {visible.map((a) => (
        <View key={a.id} style={styles.card} testID={`announcement-${a.id}`}>
          <Feather name="volume-2" size={16} color={colors.brandPrimary} />
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>{a.title}</Text>
            <Text style={styles.body}>{a.body}</Text>
          </View>
          <Pressable accessibilityLabel={t("n.dismiss")} testID={`announcement-dismiss-${a.id}`} onPress={() => setHidden((h) => [...h, a.id])} hitSlop={8}>
            <Feather name="x" size={16} color={colors.muted} />
          </Pressable>
        </View>
      ))}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  card: { flexDirection: "row", gap: spacing.sm, alignItems: "flex-start", padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.brandTertiary },
  title: { fontSize: 13, fontWeight: "800", color: colors.onSurface },
  body: { fontSize: 12, color: colors.onSurfaceSecondary, marginTop: 2 },
}));
