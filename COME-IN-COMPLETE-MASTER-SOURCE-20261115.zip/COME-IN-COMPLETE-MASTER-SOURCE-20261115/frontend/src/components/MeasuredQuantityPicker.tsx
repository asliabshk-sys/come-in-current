import { useEffect, useState } from "react";
import { Pressable, Text, TextInput, View } from "react-native";

import type { Product } from "@/src/data/catalog";
import { useT } from "@/src/i18n";
import { api } from "@/src/lib/api";
import { amountError, bigUnit, formatAmount, lineAmount, smallUnit } from "@/src/lib/measure";
import { makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Props = { product: Product; cartQty: number; onSave: (qty: number) => string | null };
type ServerPrice = { qty: number; line_total: number; quantity_label: string };

export function MeasuredQuantityPicker({ product, cartQty, onSave }: Props) {
  const styles = useStyles();
  const { colors } = useTheme();
  const { t } = useT();
  const m = product.measure!;
  const presets = m.presets.length ? m.presets : [m.min_qty];
  const [amount, setAmount] = useState(cartQty || presets[0]);
  const [custom, setCustom] = useState("");
  const [server, setServer] = useState<ServerPrice | null>(null);
  const [message, setMessage] = useState("");
  const error = amountError(product, amount, t);

  useEffect(() => { if (cartQty) setAmount(cartQty); }, [cartQty]);
  useEffect(() => {
    let active = true;
    setServer(null);
    if (error) return () => { active = false; };
    const timer = setTimeout(() => {
      api.post<ServerPrice>("/grocery/measured-price", { product_id: product.id, qty: amount })
        .then((r) => { if (active) setServer(r); })
        .catch((e: any) => { if (active) setMessage(e?.message || t("m.priceError")); });
    }, 300);
    return () => { active = false; clearTimeout(timer); };
  }, [amount, product.id, error]);

  const applyCustom = (text: string) => {
    setCustom(text);
    setMessage("");
    const n = Number(text);
    if (!text.trim()) setAmount(cartQty || presets[0]);
    else setAmount(/^\d+$/.test(text.trim()) && Number.isFinite(n) ? n : 0);
  };
  const save = () => { const err = onSave(amount); setMessage(err || t("m.saved", { amount: formatAmount(product, amount) })); };

  return (
    <View style={styles.wrap} testID="measured-picker">
      <Text style={styles.title}>{t("m.chooseAmount", { price: product.price, unit: bigUnit(product) })}</Text>
      <View style={styles.chips}>
        {presets.map((p) => {
          const selected = p === amount && !custom;
          const disabled = Boolean(amountError(product, p));
          return (
            <Pressable key={p} testID={`measured-preset-${p}`} disabled={disabled} onPress={() => { setCustom(""); setMessage(""); setAmount(p); }} style={[styles.chip, selected && styles.chipOn, disabled && { opacity: 0.4 }]}>
              <Text style={[styles.chipText, selected && { color: colors.brandPrimary }]}>{formatAmount(product, p)}</Text>
              <Text style={styles.chipSub}>₹{lineAmount(product, p).toFixed(2)}</Text>
            </Pressable>
          );
        })}
      </View>
      <Text style={styles.label}>{t("m.typeExact", { small: smallUnit(product), min: formatAmount(product, m.min_qty), max: formatAmount(product, m.max_qty), step: m.step })}</Text>
      <TextInput testID="measured-custom-input" value={custom} onChangeText={applyCustom} keyboardType="number-pad" placeholder={`e.g. ${m.min_qty + m.step}`} placeholderTextColor={colors.muted} style={styles.input} />
      {error ? <Text style={styles.error} accessibilityRole="alert" testID="measured-error">{error}</Text> : (
        <Text style={styles.price} testID="measured-server-price">
          {server && server.qty === amount ? t("m.exactPrice", { total: server.line_total.toFixed(2), amount: server.quantity_label }) : t("m.confirming")}
        </Text>
      )}
      <Pressable testID="measured-save-btn" disabled={Boolean(error)} onPress={save} style={[styles.button, error && { opacity: 0.45 }]}>
        <Text style={styles.buttonText}>{t(cartQty ? "m.updateCart" : "m.addToCart", { amount: formatAmount(product, amount) })}</Text>
      </Pressable>
      {message ? <Text style={styles.note} testID="measured-message">{message}</Text> : null}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  wrap: { marginTop: spacing.md, gap: spacing.sm, padding: spacing.md, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md },
  title: { fontSize: 15, fontWeight: "800", color: colors.onSurface },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  chip: { minWidth: 84, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, gap: 2 },
  chipOn: { borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary },
  chipText: { fontSize: 13, fontWeight: "800", color: colors.onSurface },
  chipSub: { fontSize: 11, color: colors.muted },
  label: { fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary },
  input: { backgroundColor: colors.surfaceTertiary, borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: 10, fontSize: 14, color: colors.onSurface },
  price: { fontSize: 14, fontWeight: "800", color: colors.onSurface },
  error: { color: colors.error, fontSize: 12, fontWeight: "600" },
  note: { color: colors.muted, fontSize: 12 },
  button: { minHeight: 44, borderRadius: radius.md, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" },
  buttonText: { color: colors.onBrandPrimary, fontWeight: "800", fontSize: 14 },
}));
