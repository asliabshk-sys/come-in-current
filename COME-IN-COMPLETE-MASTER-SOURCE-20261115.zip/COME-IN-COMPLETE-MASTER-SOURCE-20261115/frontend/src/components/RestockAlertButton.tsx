import { useEffect, useState } from "react";
import { Pressable, Text } from "react-native";

import { useT } from "@/src/i18n";
import { api } from "@/src/lib/api";
import { useAuth } from "@/src/store/auth";
import { makeStyles, radius, spacing } from "@/src/theme";

/** Task 20: in-app "back in stock" alert subscription for an unavailable live product. */
export function RestockAlertButton({ productId }: { productId: string }) {
  const styles = useStyles();
  const { t } = useT();
  const { user } = useAuth();
  const [subscribed, setSubscribed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    let active = true;
    if (user) api.get<{ subscribed: boolean }>(`/products/${productId}/restock-alert`).then((r) => { if (active) setSubscribed(Boolean(r.subscribed)); }).catch(() => {});
    return () => { active = false; };
  }, [productId, user]);

  const toggle = async () => {
    if (!user) { setMessage(t("n.notifySignIn")); return; }
    setBusy(true);
    try {
      const r = subscribed ? await api.del<{ subscribed: boolean }>(`/products/${productId}/restock-alert`) : await api.post<{ subscribed: boolean }>(`/products/${productId}/restock-alert`, {});
      setSubscribed(Boolean(r?.subscribed));
      setMessage("");
    } catch (e: any) { setMessage(e?.message || t("n.loadError")); }
    finally { setBusy(false); }
  };

  return (
    <>
      <Pressable testID="restock-alert-btn" accessibilityRole="button" disabled={busy} onPress={toggle} style={[styles.btn, busy && { opacity: 0.6 }]}>
        <Text style={styles.text}>{subscribed ? t("n.notifyOn") : t("n.notifyMe")}</Text>
      </Pressable>
      {message ? <Text style={styles.msg} testID="restock-alert-message">{message}</Text> : null}
    </>
  );
}

const useStyles = makeStyles((colors) => ({
  btn: { minWidth: 120, minHeight: 46, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.brandPrimary, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center", paddingHorizontal: spacing.md },
  text: { fontSize: 13, fontWeight: "800", color: colors.brandPrimary },
  msg: { fontSize: 11, color: colors.muted },
}));
