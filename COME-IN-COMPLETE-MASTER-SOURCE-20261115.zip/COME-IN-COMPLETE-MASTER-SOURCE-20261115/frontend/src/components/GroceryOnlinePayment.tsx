import { useState } from "react";
import { Pressable, Text, View } from "react-native";

import { api } from "@/src/lib/api";
import { openRazorpay, RazorpayIntent } from "@/src/lib/razorpay";
import { makeStyles, radius, spacing } from "@/src/theme";

type Props = { order: any; onChange: (order: any) => void };

/** Task 17: pay / retry / cancel an unpaid Grocery Razorpay order. Paid state comes only from the server. */
export function GroceryOnlinePayment({ order, onChange }: Props) {
  const styles = useStyles();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const pay = async () => {
    setBusy(true); setMessage("");
    try {
      const intent = await api.post<RazorpayIntent>(`/orders/${order.id}/payment-intent`, {});
      const result = await openRazorpay(intent);
      setMessage("Confirming payment with the server…");
      const verified = await api.post<{ verified: boolean; order: any }>("/grocery/payments/verify", { order_id: order.id, ...result });
      if (verified.verified) { onChange(verified.order); setMessage("Payment confirmed."); }
    } catch (e: any) { setMessage(e?.message || "Payment was not confirmed. You have not been charged unless your bank shows a debit."); }
    finally { setBusy(false); }
  };
  const cancel = async () => {
    setBusy(true); setMessage("");
    try { onChange(await api.post<any>(`/orders/${order.id}/cancel`, {})); setMessage("Order cancelled. No payment was taken."); }
    catch (e: any) { setMessage(e?.message || "Could not cancel the order."); }
    finally { setBusy(false); }
  };

  if (order.payment_status !== "razorpay_pending" || order.status !== "pending_payment") return null;
  return (
    <View style={styles.wrap} testID={`grocery-online-payment-${order.id}`}>
      <Text style={styles.note}>Online payment pending. Stock is held for a limited time; unpaid orders are cancelled when the window ends.</Text>
      <View style={styles.row}>
        <Pressable testID={`grocery-pay-now-${order.id}`} disabled={busy} onPress={pay} style={[styles.btn, busy && { opacity: 0.5 }]}><Text style={styles.btnText}>Pay ₹{Number(order.total).toFixed(2)} online</Text></Pressable>
        <Pressable testID={`grocery-pay-cancel-${order.id}`} disabled={busy} onPress={cancel} style={[styles.ghost, busy && { opacity: 0.5 }]}><Text style={styles.ghostText}>Cancel order</Text></Pressable>
      </View>
      {message ? <Text style={styles.note} testID={`grocery-pay-message-${order.id}`}>{message}</Text> : null}
    </View>
  );
}

const useStyles = makeStyles((colors) => ({
  wrap: { gap: spacing.sm, marginTop: spacing.sm },
  row: { flexDirection: "row", gap: spacing.sm, flexWrap: "wrap" },
  btn: { minHeight: 44, paddingHorizontal: spacing.lg, borderRadius: radius.md, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" },
  btnText: { color: colors.onBrandPrimary, fontWeight: "800" },
  ghost: { minHeight: 44, paddingHorizontal: spacing.lg, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, alignItems: "center", justifyContent: "center" },
  ghostText: { color: colors.onSurface, fontWeight: "700" },
  note: { fontSize: 12, color: colors.muted },
}));
