import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { PRODUCTS, Product, ProductVariant } from "@/src/data/catalog";
import { amountError, isMeasured, lineAmount, stepDown, stepUp } from "@/src/lib/measure";
import { storage } from "@/src/utils/storage";

type CartState = Record<string, number>; // legacy productId or productId::variant::variantId -> qty

type CartLine = {
  key: string;
  product: Product;
  qty: number;
  variant?: ProductVariant;
};

type CartContextValue = {
  items: CartState;
  totalCount: number;
  subtotal: number;
  deliveryFee: number;
  total: number;
  getQty: (productId: string, variantId?: string) => number;
  add: (productId: string, variantId?: string, productSnapshot?: Product) => void;
  addProduct: (product: Product, variantId?: string) => void;
  increment: (productId: string, variantId?: string, productSnapshot?: Product) => void;
  decrement: (productId: string, variantId?: string) => void;
  remove: (productId: string, variantId?: string) => void;
  removeKey: (key: string) => void;
  setAmount: (product: Product, qty: number) => string | null;
  replaceLine: (productId: string, variantId: string | undefined, replacement: Product, replacementVariantId: string | undefined, qty: number) => void;
  clear: () => void;
  cartLines: CartLine[];
  unresolvedKeys: string[];
  buyNowLine: CartLine | null;
  startBuyNow: (product: Product, variantId: string | undefined, qty: number) => boolean;
  clearBuyNow: () => void;
};

const CartContext = createContext<CartContextValue | undefined>(undefined);

const STORAGE_KEY = "@comein_cart_v1";
const SNAPSHOTS_KEY = "@comein_cart_product_snapshots_v1";
export const DELIVERY_FEE_THRESHOLD = 199;
export const DELIVERY_FEE = 29;
const VARIANT_KEY_SEPARATOR = "::variant::";

/** Legacy products keep their old productId key; variants get independent keys. */
export function getCartItemKey(productId: string, variantId?: string): string {
  return variantId ? `${productId}${VARIANT_KEY_SEPARATOR}${variantId}` : productId;
}

function resolveCartLine(key: string, qty: number, snapshots: Record<string, Product>): CartLine | null {
  if (!Number.isFinite(qty) || qty <= 0) return null;
  const variantSeparatorIndex = key.indexOf(VARIANT_KEY_SEPARATOR);
  const productId = variantSeparatorIndex < 0 ? key : key.slice(0, variantSeparatorIndex);
  const variantId = variantSeparatorIndex < 0 ? undefined : key.slice(variantSeparatorIndex + VARIANT_KEY_SEPARATOR.length);
  const product = PRODUCTS.find((candidate) => candidate.id === productId) ?? snapshots[productId];
  if (!product) return null;

  if (!variantId) return { key, product, qty };
  const variant = product.variants?.find((candidate) => candidate.id === variantId);
  // Do not silently price an unknown variant as the base product.
  if (!variant) return null;
  return {
    key,
    product: { ...product, unit: variant.unit, price: variant.price, mrp: variant.mrp },
    qty,
    variant,
  };
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartState>({});
  const [snapshots, setSnapshots] = useState<Record<string, Product>>({});
  const [buyNowLine, setBuyNowLine] = useState<CartLine | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        // Keep accepting the legacy productId -> qty persisted cart shape.
        const stored = (await storage.getItem<string>(STORAGE_KEY, "")) as
          | string
          | CartState
          | null;
        let parsed: unknown;
        if (typeof stored === "string" && stored.length > 0) {
          try { parsed = JSON.parse(stored); } catch { parsed = undefined; }
        } else if (stored && typeof stored === "object") {
          parsed = stored;
        }
        const rawSnapshots = await storage.getItem<string>(SNAPSHOTS_KEY, "");
        if (typeof rawSnapshots === "string" && rawSnapshots) {
          try { const parsedSnapshots = JSON.parse(rawSnapshots); if (parsedSnapshots && typeof parsedSnapshots === "object" && !Array.isArray(parsedSnapshots)) setSnapshots(parsedSnapshots); } catch {}
        }
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          const valid: CartState = {};
          for (const [key, qty] of Object.entries(parsed)) {
            if (typeof qty === "number" && Number.isFinite(qty) && qty > 0) valid[key] = Math.floor(qty);
          }
          setItems(valid);
          if (typeof stored !== "string") {
            await storage.setItem(STORAGE_KEY, JSON.stringify(valid));
          }
        }
      } catch {}
      setHydrated(true);
    })();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    storage.setItem(STORAGE_KEY, JSON.stringify(items));
    storage.setItem(SNAPSHOTS_KEY, JSON.stringify(snapshots));
  }, [items, snapshots, hydrated]);

  const getQty = useCallback((id: string, variantId?: string) => items[getCartItemKey(id, variantId)] ?? 0, [items]);

  const add = useCallback((id: string, variantId?: string, productSnapshot?: Product) => {
    const product = productSnapshot ?? PRODUCTS.find((candidate) => candidate.id === id) ?? snapshots[id];
    if (!product || product.source !== "live") return;
    const variant = variantId ? product.variants?.find((candidate) => candidate.id === variantId) : undefined;
    if (variantId && (!variant || variant.available === false || (variant.stock !== undefined && variant.stock <= 0))) return;
    if (!variantId && product.stock !== undefined && product.stock <= 0) return;
    const key = getCartItemKey(id, variantId);
    if (productSnapshot) setSnapshots((prev) => ({ ...prev, [id]: productSnapshot }));
    if (isMeasured(product) && !variantId) {
      setItems((prev) => {
        const current = prev[key] ?? 0;
        const next = stepUp(product, current);
        return next === current ? prev : { ...prev, [key]: next };
      });
      return;
    }
    setItems((prev) => {
      const current = prev[key] ?? 0;
      const maxStock = variant?.stock ?? (!variantId ? product.stock : undefined);
      if (current >= 1000 || (maxStock !== undefined && current >= maxStock)) return prev;
      return { ...prev, [key]: current + 1 };
    });
  }, [snapshots]);

  const addProduct = useCallback((product: Product, variantId?: string) => add(product.id, variantId, product), [add]);
  const increment = add;

  const decrement = useCallback((id: string, variantId?: string) => {
    const key = getCartItemKey(id, variantId);
    const product = snapshots[id] ?? PRODUCTS.find((candidate) => candidate.id === id);
    setItems((prev) => {
      const next = { ...prev };
      const current = next[key] ?? 0;
      if (!Number.isFinite(current) || current <= 0) { delete next[key]; return next; }
      const q = !variantId && product && isMeasured(product) ? stepDown(product, current) : current - 1;
      if (q <= 0) delete next[key];
      else next[key] = q;
      return next;
    });
  }, [snapshots]);

  const setAmount = useCallback((product: Product, qty: number) => {
    if (product.source !== "live" || !isMeasured(product)) return "This product is sold in fixed packs.";
    const error = amountError(product, qty);
    if (error) return error;
    setSnapshots((prev) => ({ ...prev, [product.id]: product }));
    setItems((prev) => ({ ...prev, [product.id]: qty }));
    return null;
  }, []);

  const remove = useCallback((id: string, variantId?: string) => {
    const key = getCartItemKey(id, variantId);
    setItems((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }, []);

  const removeKey = useCallback((key: string) => setItems((prev) => { const next = { ...prev }; delete next[key]; return next; }), []);
  const replaceLine = useCallback((productId: string, variantId: string | undefined, replacement: Product, replacementVariantId: string | undefined, qty: number) => {
    if (replacement.source !== "live" || !replacement.shopId || !Number.isInteger(qty) || qty < 1) return;
    const original = snapshots[productId] ?? PRODUCTS.find((candidate) => candidate.id === productId);
    if (isMeasured(replacement) || isMeasured(original)) return;
    if (!original || original.source !== "live" || original.shopId !== replacement.shopId || original.categoryId !== replacement.categoryId) return;
    const replacementVariant = replacementVariantId
      ? replacement.variants?.find((variant) => variant.id === replacementVariantId)
      : undefined;
    if (replacementVariantId && (!replacementVariant || replacementVariant.available === false || Number(replacementVariant.stock ?? 0) < qty)) return;
    if (!replacementVariantId && (replacement.variants?.length || Number(replacement.stock ?? 0) < qty)) return;
    const oldKey = getCartItemKey(productId, variantId);
    const newKey = getCartItemKey(replacement.id, replacementVariantId);
    if (newKey === oldKey) return;
    setItems((prev) => {
      const existingReplacementQty = prev[newKey] ?? 0;
      const maxStock = replacementVariant ? Number(replacementVariant.stock ?? 0) : Number(replacement.stock ?? 0);
      if (existingReplacementQty + qty > maxStock) return prev;
      const next = { ...prev };
      delete next[oldKey];
      next[newKey] = existingReplacementQty + qty;
      return next;
    });
    setSnapshots((prev) => ({ ...prev, [replacement.id]: replacement }));
  }, [snapshots]);
  const startBuyNow = useCallback((product: Product, variantId: string | undefined, qty: number) => {
    if (product.source !== "live" || !product.shopId || !Number.isInteger(qty) || qty < 1) return false;
    if (isMeasured(product)) {
      if (variantId || amountError(product, qty)) return false;
      setBuyNowLine({ key: product.id, product, qty });
      return true;
    }
    if (qty > 1000) return false;
    if (product.variants?.length && !variantId) return false;
    const variant = variantId ? product.variants?.find((candidate) => candidate.id === variantId) : undefined;
    if (variantId && !variant) return false;
    if (variant?.available === false) return false;
    const stock = variant ? variant.stock : product.stock;
    if (stock !== undefined && (!Number.isFinite(stock) || stock < qty)) return false;
    const lineProduct = variant
      ? { ...product, unit: variant.unit, price: variant.price, mrp: variant.mrp }
      : product;
    setBuyNowLine({ key: getCartItemKey(product.id, variantId), product: lineProduct, qty, variant });
    return true;
  }, []);
  const clearBuyNow = useCallback(() => setBuyNowLine(null), []);
  const clear = useCallback(() => { setItems({}); setSnapshots({}); setBuyNowLine(null); }, []);

  const cartLines = useMemo(
    () => Object.entries(items).map(([key, qty]) => resolveCartLine(key, qty, snapshots)).filter((line): line is CartLine => line !== null),
    [items, snapshots],
  );
  const unresolvedKeys = useMemo(() => Object.entries(items).filter(([key, qty]) => qty > 0 && !resolveCartLine(key, qty, snapshots)).map(([key]) => key), [items, snapshots]);

  const totalCount = useMemo(() => cartLines.reduce((sum, line) => sum + (isMeasured(line.product) ? 1 : line.qty), 0), [cartLines]);
  const subtotal = useMemo(() => Math.round(cartLines.reduce((sum, line) => sum + lineAmount(line.product, line.qty), 0) * 100) / 100, [cartLines]);
  const deliveryFee = subtotal === 0 ? 0 : subtotal >= DELIVERY_FEE_THRESHOLD ? 0 : DELIVERY_FEE;
  const total = subtotal + deliveryFee;

  const value: CartContextValue = { items, totalCount, subtotal, deliveryFee, total, getQty, add, addProduct, increment, decrement, remove, removeKey, setAmount, replaceLine, clear, cartLines, unresolvedKeys, buyNowLine, startBuyNow, clearBuyNow };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
