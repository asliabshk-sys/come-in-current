// Cross-platform Alert. React Native Web's Alert.alert is a no-op, so confirmation
// dialogs (role change, import confirm, referral approval…) silently did nothing on web.
// Native keeps the system dialog; web falls back to the browser confirm/alert dialogs.
import { Alert as NativeAlert, AlertButton, Platform } from "react-native";

function alert(title: string, message?: string, buttons?: AlertButton[]) {
  if (Platform.OS !== "web") {
    NativeAlert.alert(title, message, buttons);
    return;
  }
  const text = message ? `${title}\n\n${message}` : title;
  const actions = (buttons || []).filter((b) => b.style !== "cancel");
  if (!buttons || buttons.length <= 1) {
    window.alert(text);
    buttons?.[0]?.onPress?.();
    return;
  }
  if (window.confirm(text)) actions[actions.length - 1]?.onPress?.();
  else buttons.find((b) => b.style === "cancel")?.onPress?.();
}

export const Alert = { alert };
