import type { Product } from "@/src/data/catalog";
import { EN } from "@/src/i18n/translations";

export type Tr = (key: string, vars?: Record<string, string | number>) => string;
const enT: Tr = (key, vars) => Object.entries(vars || {}).reduce((s, [k, v]) => s.split(`{${k}}`).join(String(v)), EN[key] ?? key);

// Measured products: price is per kg / L; cart qty and stock are whole grams / ml.
export type MeasureConfig = { min_qty: number; max_qty: number; step: number; presets: number[] };

const UNITS = { weight: { small: "g", big: "kg" }, volume: { small: "ml", big: "L" } } as const;

export const isMeasured = (p?: Pick<Product, "sellBy" | "measure"> | null) =>
  Boolean(p && (p.sellBy === "weight" || p.sellBy === "volume") && p.measure);

export const smallUnit = (p: Pick<Product, "sellBy">) => (p.sellBy === "volume" ? UNITS.volume.small : UNITS.weight.small);
export const bigUnit = (p: Pick<Product, "sellBy">) => (p.sellBy === "volume" ? UNITS.volume.big : UNITS.weight.big);

export function formatAmount(p: Pick<Product, "sellBy">, qty: number): string {
  return qty >= 1000 ? `${Number((qty / 1000).toFixed(3))} ${bigUnit(p)}` : `${qty} ${smallUnit(p)}`;
}

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export function lineAmount(p: Pick<Product, "price" | "sellBy" | "measure">, qty: number, price = p.price): number {
  return isMeasured(p) ? round2((price * qty) / 1000) : price * qty;
}

export function maxAmount(p: Product): number {
  const m = p.measure!;
  const cap = Math.min(m.max_qty, p.stock ?? m.max_qty);
  return cap < m.min_qty ? 0 : cap - ((cap - m.min_qty) % m.step);
}

export function stepUp(p: Product, current: number): number {
  const m = p.measure!;
  const next = current <= 0 ? m.min_qty : current + m.step;
  return next > maxAmount(p) ? current : next;
}

export function stepDown(p: Product, current: number): number {
  const m = p.measure!;
  const next = current - m.step;
  return next < m.min_qty ? 0 : next;
}

export function amountError(p: Product, qty: number, t: Tr = enT): string | null {
  const m = p.measure!;
  const u = smallUnit(p);
  if (!Number.isInteger(qty) || qty < m.min_qty || qty > m.max_qty) return t("m.errRange", { min: formatAmount(p, m.min_qty), max: formatAmount(p, m.max_qty) });
  if ((qty - m.min_qty) % m.step) return t("m.errStep", { step: `${m.step} ${u}`, min: `${m.min_qty} ${u}` });
  if (p.stock !== undefined && qty > p.stock) return t("m.errStock", { amount: formatAmount(p, p.stock) });
  return null;
}

export const soldByLabel = (p: Product, t: Tr = enT) =>
  t(p.sellBy === "volume" ? "m.soldByVolumeFrom" : "m.soldByWeightFrom", { amount: formatAmount(p, p.measure!.min_qty) });
