import type { Product, ProductVariant } from "@/src/data/catalog";

export type PartyOccasion = "birthday" | "family gathering" | "small party";
export type PartyServingAssumptions = {
  snacksGramsPerGuest: number;
  drinksMlPerGuest: number;
  bakeryPiecesPerGuest: number;
  fruitGramsPerGuest: number;
};
export type PartyNeed = "snacks" | "beverages" | "bakery" | "fruits";
export type PartyPlanCandidate = { product: Product; quantity: number; variantId?: string; estimatedTotal: number; need: PartyNeed };
export type PartyPlanGroup = { need: PartyNeed; requiredAmount: number; unit: "g" | "ml" | "pcs"; candidates: PartyPlanCandidate[] };

export const PARTY_OCCASION_SERVING_ASSUMPTIONS: Record<PartyOccasion, PartyServingAssumptions> = {
  birthday: { snacksGramsPerGuest: 120, drinksMlPerGuest: 300, bakeryPiecesPerGuest: 1, fruitGramsPerGuest: 80 },
  "family gathering": { snacksGramsPerGuest: 100, drinksMlPerGuest: 250, bakeryPiecesPerGuest: 1, fruitGramsPerGuest: 100 },
  "small party": { snacksGramsPerGuest: 80, drinksMlPerGuest: 200, bakeryPiecesPerGuest: 1, fruitGramsPerGuest: 80 },
};

export const DEFAULT_PARTY_SERVING_ASSUMPTIONS = PARTY_OCCASION_SERVING_ASSUMPTIONS.birthday;

const CATEGORY_FOR_NEED: Record<PartyNeed, string> = {
  snacks: "snacks",
  beverages: "beverages",
  bakery: "bakery",
  fruits: "fruits",
};

function packageAmount(value: string | undefined, targetUnit: "g" | "ml" | "pcs"): number | null {
  if (!value) return null;
  const normalized = value.trim().toLowerCase().replace(/,/g, "");
  if (targetUnit === "pcs") {
    const pieces = normalized.match(/(?:^|\s)(\d+(?:\.\d+)?)\s*(?:pcs?|pieces?|count)\b/);
    return pieces ? Number(pieces[1]) : null;
  }
  const match = normalized.match(/(\d+(?:\.\d+)?)\s*(kg|g|l|ml)\b/);
  if (!match) return null;
  const amount = Number(match[1]);
  if (!Number.isFinite(amount) || amount <= 0) return null;
  const unit = match[2];
  if (targetUnit === "g") return unit === "kg" ? amount * 1000 : unit === "g" ? amount : null;
  return unit === "l" ? amount * 1000 : unit === "ml" ? amount : null;
}

function availableVariant(product: Product): ProductVariant | undefined {
  if (!product.variants?.length) return undefined;
  return product.variants
    .filter((variant) => variant.available !== false && variant.stock !== undefined && variant.stock > 0 && Number.isFinite(variant.price) && variant.price > 0)
    .sort((a, b) => a.price - b.price)[0];
}

function candidateFor(product: Product, need: PartyNeed, requiredAmount: number, unit: "g" | "ml" | "pcs"): PartyPlanCandidate | null {
  if (product.source !== "live" || product.categoryId !== CATEGORY_FOR_NEED[need]) return null;
  const variant = availableVariant(product);
  if (product.variants?.length && !variant) return null;
  const variantId = variant?.id;
  const unitLabel = variant?.unit || product.unit;
  const price = Number(variant?.price ?? product.price);
  if (!Number.isFinite(price) || price <= 0) return null;

  if (unit === "g" && product.sellBy === "weight" && product.measure) {
    const measure = product.measure;
    const qty = Math.max(measure.min_qty, Math.ceil(requiredAmount / measure.step) * measure.step);
    if (qty > measure.max_qty || (product.stock !== undefined && qty > product.stock)) return null;
    return { product, quantity: qty, estimatedTotal: Math.round((price * qty / 1000 + Number.EPSILON) * 100) / 100, need };
  }
  if (unit === "ml" && product.sellBy === "volume" && product.measure) {
    const measure = product.measure;
    const qty = Math.max(measure.min_qty, Math.ceil(requiredAmount / measure.step) * measure.step);
    if (qty > measure.max_qty || (product.stock !== undefined && qty > product.stock)) return null;
    return { product, quantity: qty, estimatedTotal: Math.round((price * qty / 1000 + Number.EPSILON) * 100) / 100, need };
  }

  const packSize = packageAmount(unitLabel, unit);
  if (!packSize) return null;
  const quantity = Math.ceil(requiredAmount / packSize);
  const stock = variant?.stock ?? product.stock;
  if (!Number.isInteger(quantity) || quantity < 1 || (stock !== undefined && quantity > stock)) return null;
  return { product, quantity, variantId, estimatedTotal: Math.round((price * quantity + Number.EPSILON) * 100) / 100, need };
}

export function buildPartyPlanGroups(
  products: Product[],
  guests: number,
  assumptions: PartyServingAssumptions,
): PartyPlanGroup[] {
  if (!Number.isInteger(guests) || guests < 1 || guests > 500) return [];
  const needs: Array<{ need: PartyNeed; amount: number; unit: "g" | "ml" | "pcs" }> = [
    { need: "snacks", amount: guests * assumptions.snacksGramsPerGuest, unit: "g" },
    { need: "beverages", amount: guests * assumptions.drinksMlPerGuest, unit: "ml" },
    { need: "bakery", amount: guests * assumptions.bakeryPiecesPerGuest, unit: "pcs" },
    { need: "fruits", amount: guests * assumptions.fruitGramsPerGuest, unit: "g" },
  ];
  return needs.map(({ need, amount, unit }) => ({
    need,
    requiredAmount: amount,
    unit,
    candidates: products
      .map((product) => candidateFor(product, need, amount, unit))
      .filter((candidate): candidate is PartyPlanCandidate => candidate !== null)
      .sort((a, b) => a.estimatedTotal - b.estimatedTotal || a.product.name.localeCompare(b.product.name)),
  }));
}
