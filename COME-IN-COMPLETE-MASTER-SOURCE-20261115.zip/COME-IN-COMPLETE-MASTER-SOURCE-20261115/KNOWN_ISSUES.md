# COME-IN — Known Issues (2026-11-14)

All issues below are pre-existing in the received source. None were introduced by packaging. None were fixed (no authorization to change application code/UI in this packaging task).

| ID | Area | Issue | Evidence | Suggested fix |
|---|---|---|---|---|
| KI-1 | Home UI / contract test | `test_frontend_contracts.py::test_shopping_home_theme_contract_and_separate_mode_routes` expects `testID="request-anything-card"` in `frontend/app/(tabs)/index.tsx`; absent | `reports/testing/offline-contract-junit.xml` | Owner decides: restore the card, or update the test |
| KI-2 | Home UI / contract test | `test_bakery_has_no_fabricated_sample_inventory_and_voice_is_honest` expects literal `Voice search unavailable` in Home | same | Owner decision (UI text) |
| KI-3 | Catalogue import | CSV sniffer picks `|` as delimiter when a cell contains `|` → header collapses (`KeyError: 'name'`) | `test_universal_catalogue_import_engine.py::test_csv_formula_like_cells_are_preserved_as_untrusted_source_text` | Restrict sniffer delimiters / prefer comma when header parses (NT-1) |
| KI-4 | Catalogue import | `confirm-apply` records `APPLY_PENDING_EMERGENT` but performs no Product/Inventory writes | `backend/server.py` `confirm_catalogue_import_apply` | NT-2 |
| KI-5 | Frontend types | `yarn typecheck` → 29 errors (seller/products 12, order-tracking 4, chand 3, services 2 incl. duplicate `photo_url`, seller/support 2, checkout 2, others) | `reports/testing/frontend-typecheck-2026-11-14.log` | NT-3 |
| KI-6 | Frontend lint | `yarn lint` → 54 errors, 40 warnings | `reports/testing/frontend-lint-2026-11-14.log` | NT-4 |
| KI-7 | Legacy tests | `backend/tests/backend_test.py` uses outdated contracts (expects 400 on duplicate register — API returns 409; product create payload lacks now-required fields) → 2 fail, 3 error | `reports/testing/backend_test-junit.xml` | NT-5 |
| KI-8 | Lockfile | Original `frontend/yarn.lock` lacked `expo-audio`, `expo-image-picker`, `expo-image-loader` entries so `--frozen-lockfile` failed. **Fixed 2026-11-14** by genuine `yarn install` (additive only, 0 lines removed). | `CHANGELOG.md` | – |
| KI-9 | Docs drift | `COME-IN-CODEX-IMPORT-README.md` says Expo 57 / RN 0.86 and `yarn start = expo start --web --port 3000`; actual `package.json`: Expo 58.0.17, RN 0.88.0, `start = expo start --port ${PORT:-8081}`, `web = expo start --web` | `frontend/package.json` | Trust package.json |
| KI-10 | Manifest drift | Inner `MANIFEST.sha256` (537 lines) is stale: 10 files changed by later phases. Authoritative manifest of the received package matched 631/631. | `reports/audit/PROJECT_DISCOVERY_AUDIT.md` | Regenerated file list in `PROJECT_MANIFEST.json` |
| KI-11 | Tracker drift | `COME_IN_MASTER_TASK_TRACKER.md` summary says Task 5 PARTIAL, row says COMPLETED | tracker | Treat as COMPLETED (preview scope) |
| KI-12 | Historical UI bugs | From `COME-IN-CODEX-IMPORT-README.md`: tracking "ended" early, `become-seller` chip styles, seller/products header wrapping on mobile, red "Address saved" toast, "atta" search relevance, UPI confirm not runtime-tested. `/restaurant/orders` index route now exists (`frontend/app/restaurant/orders/index.tsx`) — not re-verified in UI. | historical | Re-verify in Expo web preview |
| KI-13 | Not run | Native Android/iOS builds, device E2E, browser UI E2E this session, push, Razorpay TEST, SMTP, AI provider, OTP/Aadhaar/PAN | – | Requires providers/devices |
