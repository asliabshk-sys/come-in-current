# COME-IN — Pending Tasks (2026-11-11)

Original 22-task roadmap numbering is unchanged. Status remains evidence-based; source tests do not imply runtime verification.

| Task # | Status | Remaining work | Dependency / blocker | Next safe action |
|---:|---|---|---|---|
| 5 | PARTIAL | Phase 4 source is present; 12 new customer measured-shopping source-contract tests added. Remaining: seller/customer Preview, seven replica-set transaction scenarios, measured repeat-order E2E, transaction-backed CSV/Excel apply. | Expo Preview dependencies/configuration and disposable transaction-capable MongoDB replica set are unavailable in this environment. | Run the listed live checks only in an isolated disposable replica set and configured Expo Preview; retain PARTIAL until all pass. |
| 11 | PARTIAL | Automatic Grocery provider refunds; live Restaurant/Grocery refund lifecycle; customer/seller/admin status synchronization; refund-specific in-app notifications and reconciliation. | Disposable DB + approved Razorpay TEST or mocked provider. | Use a mocked provider/disposable DB first; no production refund actions. |
| 16 | PARTIAL | Password-reset SMTP delivery; OTP configuration/implementation; logout-all/all-session revocation; restore drill; deployed production CORS origin verification; external security audit. | SMTP/OTP provider configuration, disposable DB, deployment config and owner/security approval. | Preserve current password-reset route; do not claim OTP or logout-all support until implemented and tested. |
| 17 | PARTIAL | Razorpay TEST payment/verify/webhook, cancellation/refund synchronization, native payment sheet and push notification integration. | Owner-approved TEST credentials + native build + disposable DB/mock provider. | Keep Grocery online payment disabled until safe TEST flow passes. |
| 18 | PARTIAL | Full backend runtime collection, full TypeScript typecheck, web build, Expo runtime, MongoDB/provider/native-device regression. | `/app/frontend/.env` preview configuration, Expo dependencies/CLI, MongoDB replica set, provider TEST setup. | Re-run 52-file offline suite (333/333 PASS); then run blocked suites only after prerequisites are available. |
| 19 | BLOCKED | Production build and launch. | Explicit owner approval, production secrets, deployment and cost approval. | Do not start without explicit approval. |
| 20 | PARTIAL | Native push delivery; current in-app notification center/read-state remains available. | Firebase configuration + native build. | Next eligible task after current batch; verify push token registration and delivery using test devices. |
| 21 | PARTIAL | Live linked-master price comparison endpoint verification and trusted distance/location data. | Approved catalog master linkage + reliable location/distance source. | Next eligible task after Task 20; validate exact master variant, approved in-stock offers and distance ordering. |

## Next batch availability

Only Tasks **20** and **21** are not-yet-selected PARTIAL main tasks. Task 19 is owner-blocked. Tasks 5/11/16/17/18 remain active with external blockers documented above; the remaining canonical tasks are already marked COMPLETED. There are not five additional eligible tasks, so no artificial five-task batch is created.


### Task 5 Phase 4 execution note — 2026-11-11
- Focused Task 5/cart/Buy Now: 30/30 PASS; offline suite: 345/345 PASS; backend compileall PASS; 8 relevant TS/TSX syntax transpiles with 0 diagnostics.
- Seven MongoDB transaction scenarios are individually BLOCKED/NOT RUN; no replica-set infrastructure or MongoDB drivers/tools are available. Preview, measured repeat-order E2E and transactional import apply remain blocked. See `COME_IN_TASK5_PHASE4_EXECUTION_REPORT_2026-11-11.md`.


### Task 5 live verification follow-up — 2026-11-11
- Focused selection 35 PASS / 0 FAIL; offline regression 345 PASS / 0 FAIL across 53 files; compileall PASS.
- Seven MongoDB transaction scenarios: all individually BLOCKED / NOT RUN. Seller/customer Preview, measured repeat-order E2E, and transaction-backed import apply: BLOCKED / NOT RUN.
- No Task 5 defect reproduced; no application source changes. Task 5 remains PARTIAL. See `COME_IN_TASK5_LIVE_VERIFICATION_2026-11-11.md`.


## Task 5 — live provisioning closure (2026-11-11)
- **Status: PARTIAL / NOT COMPLETE.**
- Focused offline set: 66 PASS / 0 FAIL. Broad offline regression: 345 PASS / 0 FAIL, 23 skipped. Backend compileall PASS.
- MongoDB runtime provisioning: BLOCKED (no mongod/mongosh, Docker/Podman/socket, PyMongo/Motor, or approved disposable endpoint).
- Expo Preview: BLOCKED / NOT RUN (pinned Yarn 1.22.22 not locally cached, no frontend/node_modules or Expo CLI; direct `npm run start -- --non-interactive` returns `expo: not found`).
- Seven transaction scenarios, Seller/Customer Preview, measured Repeat Order E2E, and transaction-backed CSV/Excel import apply remain BLOCKED / NOT RUN.
- No app source changed; no defect reproduced; no other Main Task started. Evidence: `COME_IN_TASK5_LIVE_PROVISIONING_CLOSURE_2026-11-11.md`.


## Task 5 live resumption — 2026-11-11
- Status remains PARTIAL. Baseline hashes verified; 595/595 manifest PASS; 43 focused tests PASS; compileall PASS.
- External prerequisites: authorized disposable MongoDB replica-set URI/database/test credentials (secure env only); approved project-pinned Yarn 1.22.22 + Expo SDK 58.0.17 dependency cache/workspace; non-production frontend API `.env`.
- No production connection, dependency download, package version change, app source edit, or other Main Task. See `COME_IN_TASK5_LIVE_RESUMPTION_2026-11-11.md`.
