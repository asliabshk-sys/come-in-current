# COME-IN — Manual Testing Checklist (customer-facing)

**How to test:** use Expo Go (scan the QR code beside the preview) or the web preview, with the **TEST accounts** in `memory/test_credentials.md`. Never use real customer data.

**Result columns:** "Actual (web E2E 2026-11-11)" is the automated web run by the testing agent. The PASS/FAIL column is for the owner to fill on a real phone, so it is left blank.

| # | Area | Steps | Expected result | Actual (web E2E 2026-11-11) | PASS / FAIL (phone) |
|---|---|---|---|---|---|
| 1 | Launch | Open the app | Yellow header, search, banner, 4 mode cards, category grid, bottom tabs | As expected | ☐ |
| 2 | Login | Account → Sign in as the customer | Logged in; Account shows your name | As expected | ☐ |
| 3 | Wrong password | Enter a wrong password 11 times | "Invalid email or password", then "Too many attempts" | API PASS (429) | ☐ |
| 4 | Variant cart | Open TEST Kirana Store → TEST Basmati Rice → choose 1 kg, Add; choose 5 kg, Add | The cart shows two separate lines | Two lines | ☐ |
| 5 | Buy Now | On Toor Dal, tap Buy Now | Checkout shows only Toor Dal | Only Toor Dal | ☐ |
| 6 | Cart preserved | Go back from checkout → open Cart | The rice lines are still there | Preserved | ☐ |
| 7 | Checkout quote | Cart → Checkout → fill name/phone/address → Review quote | Server-confirmed quote with an expiry time | Shown | ☐ |
| 8 | Place COD order | Confirm and place | Success screen with an order reference | CI-7E3014 | ☐ |
| 9 | Loose / measured | TEST Loose Sugar → enter 750 g → Save → Checkout, Pickup, Cash at shop | Total ₹36, no delivery fee | ₹36 | ☐ |
| 10 | Wrong amount | Enter 300 g for sugar | Rejected (must follow the 250 g step) | API PASS | ☐ |
| 11 | Orders | Account → Orders | All placed orders listed | Listed | ☐ |
| 12 | Notification | Seller accepts the order → customer opens Home | Bell shows a red badge; Notifications lists "accepted" | Badge 1 | ☐ |
| 13 | Read all | Notifications → Mark all read | Badge disappears | As expected | ☐ |
| 14 | Restaurant Mode | Home → Restaurants → TEST Spice Kitchen → add an item → cart → pickup checkout | Order FO-… placed, no delivery fee | FO-62684CCB50 | ☐ |
| 15 | Seller | Log in as seller → Seller orders → Accept | Status changes; customer is notified | As expected | ☐ |
| 16 | Seller notification | Seller → Notifications | "New order" items | As expected | ☐ |
| 17 | Admin overview | Log in as admin → Account → Admin | Overview counts; tapping a row opens its tab | As expected | ☐ |
| 18 | Admin announcement | Announcements → publish → Edit → Save → Deactivate | Each step updates the list; Home banner follows | As expected | ☐ |
| 19 | Admin restriction | A customer opens /admin | "Restricted to Come In admins" | As expected | ☐ |
| 20 | Online payment | Checkout → online payment option | Not shown (Razorpay disabled) | Not shown | ☐ (BLOCKED for live test) |
| 21 | Push | Close the app, seller changes status | No phone push (not configured); the in-app notification exists | — | ☐ (BLOCKED) |
