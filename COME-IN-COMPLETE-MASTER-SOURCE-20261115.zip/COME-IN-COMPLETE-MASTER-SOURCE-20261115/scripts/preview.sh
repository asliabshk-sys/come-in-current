#!/usr/bin/env bash
# One-command, frontend-only preview launcher for supported cloud workspaces.
# It never starts the backend, configures secrets, or performs a production deploy.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FRONTEND_DIR="$ROOT/frontend"
PORT="${PORT:-3000}"

fail() { printf '[COME-IN Preview] ERROR: %s\n' "$*" >&2; exit 1; }
log() { printf '[COME-IN Preview] %s\n' "$*"; }

command -v node >/dev/null 2>&1 || fail 'Node.js is required. Use a workspace image with Node.js compatible with the Expo SDK.'
command -v bash >/dev/null 2>&1 || fail 'Bash is required to run this script.'
[[ -f "$FRONTEND_DIR/package.json" ]] || fail "Frontend package.json not found at $FRONTEND_DIR. Open the extracted project root, not its parent."

if [[ ! -d "$FRONTEND_DIR/node_modules/expo" ]]; then
  log 'Expo dependencies are not installed; resolving the project-declared Yarn package manager.'
  if command -v yarn >/dev/null 2>&1; then
    (cd "$FRONTEND_DIR" && yarn install --non-interactive) || fail 'Yarn dependency installation failed. Check workspace registry/network logs; no automatic retry was attempted.'
  elif command -v corepack >/dev/null 2>&1; then
    (cd "$FRONTEND_DIR" && corepack yarn install --non-interactive) || fail 'Corepack/Yarn dependency installation failed. Check registry/network logs; no automatic retry was attempted.'
  else
    fail 'Frontend dependencies are missing, and neither Yarn nor Corepack is available. Use a Node.js workspace with Corepack enabled; do not switch package managers or fabricate a lockfile.'
  fi
fi

[[ -x "$FRONTEND_DIR/node_modules/.bin/expo" ]] || fail 'Expo CLI is still missing after dependency resolution. Inspect the install output above.'
log "Starting the existing Expo Router web app on port ${PORT}."
log 'Frontend UI preview only: backend-dependent features require a reachable configured API; no mock backend or fake payment/tracking is started.'
cd "$FRONTEND_DIR"
exec ./node_modules/.bin/expo start --web --host lan --port "$PORT"
