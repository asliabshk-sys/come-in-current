#!/usr/bin/env bash
# Verifies the Expo/Node toolchain against the project pins. Exit 1 on any mismatch.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FE="$ROOT/frontend"
FAIL=0
ok()  { printf '  PASS  %s\n' "$*"; }
bad() { printf '  FAIL  %s\n' "$*"; FAIL=1; }
pkgver() { node -p "require('$FE/node_modules/$1/package.json').version" 2>/dev/null || echo missing; }

echo "[verify-env] toolchain"
NODE_V="$(node -v 2>/dev/null || echo none)"
node -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit((a===20&&b>=19)||(a===22&&b>=13)||a>=24?0:1)' 2>/dev/null \
  && ok "node $NODE_V (needs ^20.19.4 | ^22.13 | >=24.3)" || bad "node $NODE_V (needs ^20.19.4 | ^22.13 | >=24.3)"
[[ "$(yarn -v 2>/dev/null)" == "1.22.22" ]] && ok "yarn 1.22.22" || bad "yarn $(yarn -v 2>/dev/null || echo none) (needs 1.22.22)"
PY_V="$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null || echo none)"
[[ "$PY_V" == "3.11" ]] && ok "python $PY_V" || bad "python $PY_V (needs 3.11)"

echo "[verify-env] lockfile + pinned packages"
[[ -f "$FE/yarn.lock" ]] && ok "frontend/yarn.lock sha256 $(sha256sum "$FE/yarn.lock" | cut -c1-16)…" || bad "frontend/yarn.lock missing"
for spec in expo@58.0.17 react-native@0.88.0 react@19.3.0 react-native-web@0.21.4 expo-router@58.0.25 typescript@6.0.3; do
  n="${spec%@*}"; want="${spec##*@}"; have="$(pkgver "$n")"
  [[ "$have" == "$want" ]] && ok "$n $have" || bad "$n $have (pinned $want; run: cd frontend && yarn install --frozen-lockfile)"
done
[[ -x "$FE/node_modules/.bin/expo" ]] && ok "expo CLI present" || bad "expo CLI missing"

echo "[verify-env] environment files"
[[ -f "$FE/.env" ]] && grep -q '^EXPO_PUBLIC_BACKEND_URL=' "$FE/.env" && ok "frontend/.env has EXPO_PUBLIC_BACKEND_URL" || bad "frontend/.env missing EXPO_PUBLIC_BACKEND_URL (copy frontend/.env.example)"
for k in MONGO_URL DB_NAME JWT_SECRET CORS_ORIGINS; do
  grep -q "^$k=" "$ROOT/backend/.env" 2>/dev/null && ok "backend/.env has $k" || bad "backend/.env missing $k (copy backend/.env.example)"
done

echo "[verify-env] python packages"
for p in pymongo==4.18.2 motor==3.7.1 fastapi==0.110.1; do
  python3 -c "import importlib.metadata as m,sys;sys.exit(0 if m.version('${p%==*}')=='${p#*==}' else 1)" 2>/dev/null && ok "$p" || bad "$p (pip install -r backend/requirements.txt)"
done
[[ $FAIL -eq 0 ]] && echo "[verify-env] RESULT: PASS" || echo "[verify-env] RESULT: FAIL"
exit $FAIL
