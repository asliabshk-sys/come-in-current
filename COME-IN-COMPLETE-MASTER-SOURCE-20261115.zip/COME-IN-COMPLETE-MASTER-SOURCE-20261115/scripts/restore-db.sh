#!/usr/bin/env bash
# Restore only into a disposable database. Production/live restore is deliberately unsupported.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ARCHIVE="${1:?Usage: scripts/restore-db.sh <archive.gz>}"
if [ -z "${MONGO_URL:-}" ] && [ -f "$ROOT/backend/.env" ]; then set -a; . "$ROOT/backend/.env"; set +a; fi
: "${MONGO_URL:?MONGO_URL is required}"; : "${DB_NAME:?DB_NAME is required}"
TARGET_DB="${TARGET_DB:-comein_disposable_test_restore_$(date -u +%Y%m%dT%H%M%SZ)}"
export TARGET_DB
if [ "$TARGET_DB" = "$DB_NAME" ]; then
  echo "Refusing to restore into the configured source database." >&2
  exit 2
fi
if [[ ! "$TARGET_DB" =~ ^comein_disposable_test_[A-Za-z0-9_-]+$ ]]; then
  echo "Refusing restore: TARGET_DB must start with comein_disposable_test_." >&2
  exit 2
fi
# Restores are never allowed against non-disposable data or a remote cluster,
# even if TARGET_DB happens to have a safe-looking name. Require an explicit
# confirmation, a local unauthenticated test instance and an empty target.
[ "${APP_ENV:-}" = "test" ] || { echo "Refusing restore: APP_ENV=test required" >&2; exit 2; }
[[ "$DB_NAME" =~ ^comein_disposable_test_[A-Za-z0-9_-]+$ ]] || { echo "Refusing restore: source DB must be disposable" >&2; exit 2; }
[ "${CONFIRM_DISPOSABLE_RESTORE_DB:-}" = "$TARGET_DB" ] || { echo "Refusing restore: confirm exact TARGET_DB with CONFIRM_DISPOSABLE_RESTORE_DB" >&2; exit 2; }
python3 - <<'PYCHECK'
import os, sys
from urllib.parse import urlsplit
u = urlsplit(os.environ['MONGO_URL'])
if u.scheme != 'mongodb' or u.hostname not in {'localhost', '127.0.0.1', '::1'} or u.username or u.password:
    sys.exit('Refusing restore: only an unauthenticated localhost test MongoDB is allowed')
PYCHECK
[ -f "$ARCHIVE" ] || { echo "Archive not found: $ARCHIVE" >&2; exit 2; }
command -v mongorestore >/dev/null || { echo "mongorestore (MongoDB Database Tools) is required" >&2; exit 1; }

# Pass the URI through a mode-0600 tool config file, not process arguments.
MONGO_TOOL_CONFIG="$(mktemp)"
chmod 600 "$MONGO_TOOL_CONFIG"
python3 - "$MONGO_TOOL_CONFIG" <<'PYCFG'
import json, os, sys
path, uri = sys.argv[1], os.environ["MONGO_URL"]
with open(path, "w", encoding="utf-8") as handle:
    handle.write("uri: " + json.dumps(uri) + "\n")
os.chmod(path, 0o600)
PYCFG
trap 'rm -f "$MONGO_TOOL_CONFIG"' EXIT
command -v sha256sum >/dev/null || { echo "sha256sum is required" >&2; exit 1; }
[ -f "$ARCHIVE.sha256" ] || { echo "Archive SHA-256 sidecar is required: $ARCHIVE.sha256" >&2; exit 2; }
(cd "$(dirname "$ARCHIVE")" && sha256sum -c "$(basename "$ARCHIVE").sha256")
# Reject a nonempty target instead of silently --drop'ing any existing data.
python3 - <<'PYEMPTY'
import os
from pymongo import MongoClient
client = MongoClient(os.environ['MONGO_URL'], serverSelectionTimeoutMS=8000)
try:
    if client[os.environ['TARGET_DB']].list_collection_names():
        raise SystemExit('Refusing restore: destination already has collections')
finally:
    client.close()
PYEMPTY
mongorestore --config="$MONGO_TOOL_CONFIG" --archive="$ARCHIVE" --gzip --nsFrom="${DB_NAME}.*" --nsTo="${TARGET_DB}.*" --quiet
# Verify that document counts and index definitions survived the round trip.
MONGO_URL="$MONGO_URL" DB_NAME="$DB_NAME" TARGET_DB="$TARGET_DB" python3 "$ROOT/scripts/mongo/verify_disposable_restore.py"
# Verify the complete source-declared index set after restore; never report success on drift.
MONGO_URL="$MONGO_URL" DB_NAME="$TARGET_DB" python3 "$ROOT/scripts/mongo/comein_mongo.py" verify-indexes
printf 'Restored and index-verified disposable database: %s\n' "$TARGET_DB"
