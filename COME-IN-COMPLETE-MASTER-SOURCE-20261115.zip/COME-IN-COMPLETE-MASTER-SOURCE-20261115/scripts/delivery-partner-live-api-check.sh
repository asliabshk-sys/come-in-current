#!/usr/bin/env bash
# Live Delivery Partner API smoke check. Use ONLY against a local/disposable backend. Requires backend/tests/preview_test_env.sh exported and seeded accounts.
B="${COMEIN_API_BASE:?set COMEIN_API_BASE e.g. http://127.0.0.1:8001/api (NEVER production)}"
tok(){ curl -s -X POST $B/auth/login -H 'Content-Type: application/json' -d "{\"email\":\"$1\",\"password\":\"$2\"}" | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])"; }
C=$(tok "$COMEIN_TEST_CUSTOMER_EMAIL" "$COMEIN_TEST_CUSTOMER_PASSWORD"); A=$(tok "$COMEIN_TEST_ADMIN_EMAIL" "$COMEIN_TEST_ADMIN_PASSWORD")
echo "1 provider-status: $(curl -s -o /dev/null -w '%{http_code}' $B/delivery-partner/provider-status -H "Authorization: Bearer $C")"
echo "2 draft save: $(curl -s -w ' HTTP %{http_code}' -X PUT $B/delivery-partner/application -H "Authorization: Bearer $C" -H 'Content-Type: application/json' -d '{"full_name":"TEST Preview Rider","mobile":"9876500001","residential_address":"TEST 12 Preview Street, Pune","alternate_contact":"9876500002","consent_identity_verification":true,"consent_data_processing":true,"consent_declaration":true}' | head -c 400)"
echo "3 mine: $(curl -s -w ' HTTP %{http_code}' $B/delivery-partner/application/mine -H "Authorization: Bearer $C" | head -c 300)"
echo "4 submit (expect fail-closed): $(curl -s -w ' HTTP %{http_code}' -X POST $B/delivery-partner/application/submit -H "Authorization: Bearer $C" | head -c 300)"
echo "5 otp request (expect 503): $(curl -s -w ' HTTP %{http_code}' -X POST $B/delivery-partner/otp/request -H "Authorization: Bearer $C" -H 'Content-Type: application/json' -d '{}' | head -c 200)"
echo "6 admin queue as customer (expect 403): $(curl -s -o /dev/null -w '%{http_code}' $B/delivery-partner/admin/applications -H "Authorization: Bearer $C")"
echo "7 admin queue as admin: $(curl -s -w ' HTTP %{http_code}' $B/delivery-partner/admin/applications -H "Authorization: Bearer $A" | head -c 300)"
echo "8 access (expect denied): $(curl -s -w ' HTTP %{http_code}' $B/delivery-partner/access -H "Authorization: Bearer $C" | head -c 200)"
