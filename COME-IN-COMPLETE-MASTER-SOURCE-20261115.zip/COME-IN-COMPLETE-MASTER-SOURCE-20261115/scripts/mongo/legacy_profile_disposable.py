#!/usr/bin/env python3
"""Read-only legacy integrity profile for a *disposable local MongoDB test DB*.

Generates counts and warnings only, never documents, identity numbers, names,
addresses, values of unique keys, auth tokens, or connection strings.
"""
import json
import os
import sys
from urllib.parse import urlsplit

from comein_mongo import collections_used, index_specs, preflight_unique_indexes

PREFIX = 'comein_disposable_test_'


def check_target(env):
    if env.get('APP_ENV') != 'test':
        raise ValueError('Only APP_ENV=test is supported for profiling')
    db_name = env.get('DB_NAME', '')
    if not db_name.startswith(PREFIX):
        raise ValueError('Only a disposable test database may be profiled')
    uri = urlsplit(env.get('MONGO_URL', ''))
    if uri.scheme != 'mongodb' or uri.hostname not in {'localhost', '127.0.0.1', '::1'} or uri.username or uri.password:
        raise ValueError('Only a local unauthenticated test MongoDB instance is supported')
    if env.get('CONFIRM_DISPOSABLE_PROFILE_DB') != db_name:
        raise ValueError('Explicit CONFIRM_DISPOSABLE_PROFILE_DB must match DB_NAME')
    return db_name


def profile(db):
    declared = set(collections_used())
    actual = set(db.list_collection_names())
    missing = sorted(declared - actual)
    extra = sorted(actual - declared)
    counts = {name: db[name].count_documents({}) for name in sorted(actual) if not name.startswith('system.')}
    # Aggregations do not return grouped key values, only counts. All checks
    # are read-only. Missing fields are counted but never auto-filled.
    products = db['products']
    product_anomalies = {
        'missing_shop_id': products.count_documents({'shop_id': {'$exists': False}}),
        'missing_stock': products.count_documents({'stock': {'$exists': False}}),
        'negative_stock': products.count_documents({'stock': {'$lt': 0}}),
        'noninteger_stock': products.count_documents({'stock': {'$exists': True, '$not': {'$type': ['int', 'long']}}}),
        'legacy_missing_quantity_mode': products.count_documents({'quantity_mode': {'$exists': False}}),
    }
    uniqueness = preflight_unique_indexes(db)
    return {
        'read_only': True,
        'declared_collections': len(declared),
        'collections_missing': missing,
        'collections_extra': extra,
        'document_counts': counts,
        'declared_indexes': len(index_specs()),
        'unique_index_preflight': uniqueness,
        'product_anomaly_counts': product_anomalies,
        'ready_for_non_destructive_index_review': uniqueness['ok'],
        'legacy_schema_validator_approval': False,
    }


def main():
    name = check_target(os.environ)
    try:
        from pymongo import MongoClient
    except ImportError as exc:
        sys.exit('PyMongo is required to profile a disposable local database')
    client = MongoClient(os.environ['MONGO_URL'], serverSelectionTimeoutMS=8000)
    try:
        result = profile(client[name])
        print(json.dumps(result, indent=2, default=str))
        if not result['ready_for_non_destructive_index_review']:
            raise SystemExit('Duplicate index keys detected; migration is blocked')
    finally:
        client.close()


if __name__ == '__main__':
    main()
