#!/usr/bin/env python3
"""Conservative persistent $jsonSchema for the NEW catalogue_import_audit collection.

No network connection in plan mode. Apply only to an explicitly confirmed,
throwaway COME-IN database. Core legacy collection validation is intentionally
NOT guessed before real data profiling and backward-compatibility tests.
"""
from __future__ import annotations
import argparse
import json
import os
from urllib.parse import urlsplit

SCHEMA = {
    'bsonType': 'object',
    'required': ['apply_key', 'shop_id', 'seller_id', 'job_id', 'record_count', 'product_ids', 'created_at'],
    'properties': {
        'apply_key': {'bsonType': 'string', 'pattern': '^catalogue-import:'},
        'shop_id': {'bsonType': 'string'},
        'seller_id': {'bsonType': 'string'},
        'job_id': {'bsonType': 'string'},
        'record_count': {'bsonType': ['int', 'long'], 'minimum': 1},
        'product_ids': {'bsonType': 'array', 'items': {'bsonType': 'string'}},
        'created_at': {'bsonType': 'date'},
    },
}
VALIDATOR = {'$jsonSchema': SCHEMA}
COLLECTION = 'catalogue_import_audit'
TEST_PREFIX = 'comein_disposable_test_'


def validate_disposable_target(env, db_name, confirmed_name):
    if env.get('APP_ENV', '').lower() != 'test':
        raise ValueError('APP_ENV=test required; deployment to any other environment is forbidden')
    if not db_name.startswith(TEST_PREFIX) or db_name != confirmed_name:
        raise ValueError('Only an explicitly confirmed disposable test database is allowed')
    url = env.get('MONGO_URL')
    if not url:
        raise ValueError('MONGO_URL required to apply against a disposable database')
    parsed = urlsplit(url)
    # This destructive-capable migration runner intentionally accepts only a local
    # test MongoDB server; do not redirect it to production or shared infrastructure.
    if parsed.scheme != 'mongodb' or parsed.hostname not in {'localhost', '127.0.0.1', '::1'} or parsed.username or parsed.password:
        raise ValueError('Only unauthenticated localhost MongoDB URI is allowed for disposable migration')


def install_validator(db):
    """Non-destructive; do not modify pre-existing nonempty collections."""
    names = db.list_collection_names()
    if COLLECTION not in names:
        db.create_collection(COLLECTION, validator=VALIDATOR, validationLevel='strict', validationAction='error')
        return {'collection': COLLECTION, 'created': True}
    if db[COLLECTION].count_documents({}) != 0:
        raise RuntimeError('Existing audit records require compatibility profiling; no collMod performed')
    db.command({'collMod': COLLECTION, 'validator': VALIDATOR,
                'validationLevel': 'strict', 'validationAction': 'error'})
    return {'collection': COLLECTION, 'created': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true', help='Apply ONLY to an explicitly confirmed disposable test DB')
    parser.add_argument('--confirm-disposable-db', default='')
    args = parser.parse_args()
    if not args.apply:
        print(json.dumps({'mode': 'PLAN_ONLY', 'collection': COLLECTION, 'validator': VALIDATOR}, indent=2))
        return
    name = os.environ.get('DB_NAME', '')
    validate_disposable_target(os.environ, name, args.confirm_disposable_db)
    from pymongo import MongoClient
    client = MongoClient(os.environ['MONGO_URL'], serverSelectionTimeoutMS=8000)
    try:
        hello = client.admin.command('hello')
        if not hello.get('setName') and hello.get('msg') != 'isdbgrid':
            raise RuntimeError('Replica set required; no validators installed')
        print(json.dumps(install_validator(client[name])))
    finally:
        client.close()


if __name__ == '__main__':
    main()
