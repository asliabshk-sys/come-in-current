#!/usr/bin/env bash
# One-command MongoDB setup + verification. MODE=local starts a dev replica set; MODE=external uses MONGO_URL as given.
#   bash scripts/mongo/setup.sh            # local (default)
#   MODE=external bash scripts/mongo/setup.sh
#   Overrides: MONGO_RS_PORT, MONGO_RS_DBPATH, LAUNCHER=nohup (skip supervisor), PYTHON
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
MODE="${MODE:-local}"
PY="${PYTHON:-$(command -v python3 || command -v python)}"
log() { printf '[mongo-setup] %s\n' "$*"; }

if [[ "$MODE" == "local" ]]; then
  PORT="${MONGO_RS_PORT:-27018}"
  if mongosh --quiet --port "$PORT" --eval 'db.hello().isWritablePrimary' 2>/dev/null | grep -q true; then
    log "replica set already PRIMARY on port $PORT"
  elif [[ "${LAUNCHER:-auto}" != "nohup" ]] && command -v supervisorctl >/dev/null && [[ -d /etc/supervisor/conf.d ]]; then
    PROG="mongodb-rs0$([[ "$PORT" == 27018 ]] || echo "-$PORT")"
    log "installing supervisor program $PROG (rendered from infra/mongodb/supervisor-mongodb-rs0.conf)"
    sed -e "s#/app/scripts/mongo/start-replset.sh#$ROOT/scripts/mongo/start-replset.sh#" \
        -e "s#program:mongodb-rs0#program:$PROG#" -e "s#mongodb-rs0\.\(out\|err\)\.log#$PROG.\1.log#g" \
        -e "s#MONGO_RS_PORT=\"27018\"#MONGO_RS_PORT=\"$PORT\"#" \
        -e "s#MONGO_RS_DBPATH=\"/root/mongo-rs0-data\"#MONGO_RS_DBPATH=\"${MONGO_RS_DBPATH:-/root/mongo-rs0-data}\"#" \
        "$ROOT/infra/mongodb/supervisor-mongodb-rs0.conf" > "/etc/supervisor/conf.d/$PROG.conf"
    supervisorctl reread >/dev/null; supervisorctl update >/dev/null; supervisorctl start "$PROG" >/dev/null 2>&1 || true
  else
    log "starting replica set in background (logs: /tmp/mongodb-rs0-$PORT.log)"
    nohup bash "$ROOT/scripts/mongo/start-replset.sh" > "/tmp/mongodb-rs0-$PORT.log" 2>&1 &
  fi
  for _ in $(seq 1 90); do
    mongosh --quiet --port "$PORT" --eval 'db.hello().isWritablePrimary' 2>/dev/null | grep -q true && break; sleep 1
  done
  mongosh --quiet --port "$PORT" --eval 'db.hello().isWritablePrimary' | grep -q true || { log "ERROR: replica set did not become PRIMARY"; exit 1; }
  log "PRIMARY ready on 127.0.0.1:$PORT (expected MONGO_URL=mongodb://127.0.0.1:$PORT/?replicaSet=rs0)"
fi

log "initialising collections and indexes"; "$PY" "$ROOT/scripts/mongo/comein_mongo.py" init
log "disposable test database cycle";       "$PY" "$ROOT/scripts/mongo/comein_mongo.py" testdb-cycle >/tmp/mongo-testdb-cycle.json && log "testdb-cycle PASS"
log "health check";                          "$PY" "$ROOT/scripts/mongo/comein_mongo.py" health
