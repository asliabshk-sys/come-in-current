#!/usr/bin/env bash
# Runs a single-node MongoDB replica set in the foreground (supervisor/systemd friendly) and initiates it once.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PORT="${MONGO_RS_PORT:-27018}"
RS="${MONGO_RS_NAME:-rs0}"
BIND="${MONGO_RS_BIND:-127.0.0.1}"
DBPATH="${MONGO_RS_DBPATH:-/root/mongo-rs0-data}"
CACHE_GB="${MONGO_RS_CACHE_GB:-0.5}"
export MONGO_RS_NAME="$RS" MONGO_RS_HOST="${MONGO_RS_HOST:-127.0.0.1:$PORT}"

command -v mongod >/dev/null || { echo "[start-replset] mongod not found (need MongoDB 7.0.x server)" >&2; exit 1; }
command -v mongosh >/dev/null || { echo "[start-replset] mongosh not found" >&2; exit 1; }
mkdir -p "$DBPATH"

mongod --replSet "$RS" --port "$PORT" --bind_ip "$BIND" --dbpath "$DBPATH" --wiredTigerCacheSizeGB "$CACHE_GB" &
PID=$!
trap 'kill -TERM "$PID" 2>/dev/null; wait "$PID"' TERM INT

for _ in $(seq 1 60); do
  mongosh --quiet --port "$PORT" --eval 'db.adminCommand({ping:1}).ok' >/dev/null 2>&1 && break
  kill -0 "$PID" 2>/dev/null || { echo "[start-replset] mongod exited early" >&2; exit 1; }
  sleep 1
done
mongosh --quiet --port "$PORT" --file "$ROOT/infra/mongodb/rs-init.js"
wait "$PID"
