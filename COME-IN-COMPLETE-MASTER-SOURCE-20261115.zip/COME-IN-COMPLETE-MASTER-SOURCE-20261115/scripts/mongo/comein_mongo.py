#!/usr/bin/env python3
"""COME-IN MongoDB portability toolkit: init | health | tx-verify | testdb-cycle | testdb-drop | spec."""
import argparse
import ast
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SERVER = ROOT / "backend" / "server.py"
HC_COLL = "_portability_healthcheck"
TEST_DB_PREFIX = "comein_disposable_test_"


def load_env():
    env_file = ROOT / "backend" / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            m = re.match(r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$", line)
            if m and m.group(1) not in os.environ:
                os.environ[m.group(1)] = m.group(2).strip().strip('"').strip("'")
    for k in ("MONGO_URL", "DB_NAME"):
        if not os.environ.get(k):
            sys.exit(f"[mongo] {k} is required (backend/.env or environment)")
    return os.environ["MONGO_URL"], os.environ["DB_NAME"]


def redact(url):
    # Do not disclose either URI username or password in operational output.
    return re.sub(r"//[^/@]+@", "//***@", url)


def _is_startup_initializer(node):
    for decorator in node.decorator_list:
        if not (isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute)):
            continue
        if decorator.func.attr != "on_event" or not isinstance(decorator.func.value, ast.Name) or decorator.func.value.id != "app":
            continue
        if decorator.args and isinstance(decorator.args[0], ast.Constant) and decorator.args[0].value == "startup":
            return True
    return False


def index_specs():
    """Return every literal db.<collection>.create_index declaration in app startup handlers.

    Discover startup handlers from their decorators so a future initializer is not
    silently omitted from spec/init/health/restore verification.
    """
    tree = ast.parse(SERVER.read_text())
    functions = [
        node for node in ast.walk(tree)
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)) and _is_startup_initializer(node)
    ]
    if not functions:
        raise RuntimeError("No FastAPI startup initializer was found while extracting MongoDB indexes")

    specs = []
    for fn in sorted(functions, key=lambda item: item.lineno):
        function_name = fn.name
        for node in ast.walk(fn):
            if not isinstance(node, ast.Await):
                continue
            call = node.value
            if not (isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "create_index"):
                continue
            owner = call.func.value
            if not (isinstance(owner, ast.Attribute) and isinstance(owner.value, ast.Name) and owner.value.id == "db"):
                continue
            if not call.args:
                raise RuntimeError(f"Unparseable create_index call in {function_name}: missing key argument")
            keys = ast.literal_eval(call.args[0])
            keys = [(keys, 1)] if isinstance(keys, str) else [tuple(k) for k in keys]
            opts = {kw.arg: ast.literal_eval(kw.value) for kw in call.keywords}
            specs.append({"collection": owner.attr, "keys": keys, "options": opts, "initializer": function_name})
    return specs


def index_matches(spec, actual):
    """Compare key pattern and all explicitly declared semantic index options."""
    expected_keys = [list(pair) for pair in spec["keys"]]
    actual_keys = [list(pair) for pair in actual.get("key", [])]
    if actual_keys != expected_keys:
        return False
    options = spec.get("options", {})
    for option in ("unique", "sparse", "expireAfterSeconds", "partialFilterExpression", "name"):
        expected = options.get(option)
        observed = actual.get(option)
        if option == "name":
            if option in options and observed != expected:
                return False
            continue
        if option in options:
            if observed != expected:
                return False
        elif observed is not None and observed is not False:
            return False
    return True


def collections_used():
    src = SERVER.read_text()
    names = set(re.findall(r"\bdb\.([a-z_][a-z0-9_]*)\.", src)) | set(re.findall(r"\bdb\[\"([a-z_][a-z0-9_]*)\"\]", src))
    return sorted(n for n in names if n not in {"command", "client"})


def client_for(url):
    from pymongo import MongoClient
    return MongoClient(
        url,
        maxPoolSize=50,
        minPoolSize=0,
        maxConnecting=4,
        serverSelectionTimeoutMS=8000,
        connectTimeoutMS=5000,
        socketTimeoutMS=20000,
        waitQueueTimeoutMS=10000,
        retryReads=True,
        retryWrites=True,
        tz_aware=True,
    )


def init_db(db):
    # Fail before the first collection or index write when a declared unique
    # constraint already conflicts with existing documents. Do not silently
    # remove, merge, or rewrite legacy records to make indexes install.
    preflight = preflight_unique_indexes(db)
    if not preflight["ok"]:
        raise RuntimeError("MongoDB unique-index preflight found duplicate groups; no index migration started")
    existing = set(db.list_collection_names())
    created = [c for c in collections_used() if c not in existing]
    for c in created:
        db.create_collection(c)
    specs = index_specs()
    for spec in specs:
        db[spec["collection"]].create_index(spec["keys"], **spec["options"])
    missing = missing_indexes(db)
    if missing:
        raise RuntimeError(f"MongoDB index initialization left required indexes missing: {missing}")
    return {"collections_total": len(collections_used()), "collections_created": len(created), "indexes_ensured": len(specs), "indexes_verified": len(specs)}


def missing_indexes(db):
    missing = []
    for spec in index_specs():
        actual_indexes = db[spec["collection"]].index_information().values()
        if not any(index_matches(spec, actual) for actual in actual_indexes):
            missing.append(f'{spec["collection"]}:{spec["keys"]}')
    return missing


def verify_indexes(db):
    specs = index_specs()
    missing = missing_indexes(db)
    return {
        "indexes_expected": len(specs),
        "indexes_missing": missing,
        "indexes_ok": not missing,
        "collections_with_declared_indexes": len({spec["collection"] for spec in specs}),
        "ok": not missing,
    }


def preflight_unique_indexes(db, max_time_ms=30000):
    """Read-only duplicate scan before unique-index deployment; never returns key values."""
    findings = []
    for spec in index_specs():
        options = spec.get("options", {})
        if not options.get("unique"):
            continue
        match_parts = []
        if options.get("partialFilterExpression"):
            match_parts.append(options["partialFilterExpression"])
        if options.get("sparse"):
            match_parts.append({"$or": [{field: {"$exists": True}} for field, _ in spec["keys"]]})
        pipeline = []
        if match_parts:
            pipeline.append({"$match": match_parts[0] if len(match_parts) == 1 else {"$and": match_parts}})
        group_id = {f"k{index}": f"${field}" for index, (field, _direction) in enumerate(spec["keys"])}
        pipeline.extend([
            {"$group": {"_id": group_id, "count": {"$sum": 1}}},
            {"$match": {"count": {"$gt": 1}}},
            {"$limit": 5},
            {"$project": {"_id": 0, "count": 1}},
        ])
        duplicate_groups = list(db[spec["collection"]].aggregate(pipeline, maxTimeMS=max_time_ms))
        if duplicate_groups:
            findings.append({
                "collection": spec["collection"],
                "keys": spec["keys"],
                "duplicate_groups_found": len(duplicate_groups),
                "sample_group_counts": [row.get("count") for row in duplicate_groups],
            })
    return {"unique_indexes_checked": sum(bool(item.get("options", {}).get("unique")) for item in index_specs()), "duplicates": findings, "ok": not findings}


def verify_transactions(client, db):
    coll = db[HC_COLL]
    marker = f"tx-{time.time_ns()}"
    with client.start_session() as s:
        with s.start_transaction():
            coll.insert_one({"_id": marker + "-commit", "at": datetime.now(timezone.utc)}, session=s)
    committed = coll.count_documents({"_id": marker + "-commit"}) == 1
    with client.start_session() as s:
        s.start_transaction()
        coll.insert_one({"_id": marker + "-abort"}, session=s)
        s.abort_transaction()
    aborted = coll.count_documents({"_id": marker + "-abort"}) == 0
    coll.delete_many({"_id": {"$regex": f"^{marker}"}})
    return {"commit_visible": committed, "abort_rolled_back": aborted, "ok": committed and aborted}


def health(url, name, require_indexes=True):
    c = client_for(url)
    db = c[name]
    out = {"mongo_url": "REDACTED", "db_name": name, "checked_at": datetime.now(timezone.utc).isoformat()}
    out["ping"] = c.admin.command("ping")["ok"] == 1.0
    out["server_version"] = c.server_info()["version"]
    hello = c.admin.command("hello")
    out["replica_set"] = hello.get("setName")
    out["is_writable_primary"] = bool(hello.get("isWritablePrimary"))
    out["fcv"] = c.admin.command({"getParameter": 1, "featureCompatibilityVersion": 1})["featureCompatibilityVersion"]["version"]
    out["transactions"] = verify_transactions(c, db) if out["replica_set"] else {"ok": False, "reason": "standalone mongod: transactions unsupported"}
    index_status = verify_indexes(db)
    out.update(index_status)
    out["ok"] = all([out["ping"], out["replica_set"], out["is_writable_primary"], out["transactions"]["ok"], not (require_indexes and out["indexes_missing"])])
    c.close()
    return out


def testdb_cycle(url):
    name = f"{TEST_DB_PREFIX}{datetime.now(timezone.utc):%Y%m%d%H%M%S}"
    c = client_for(url)
    result = {"disposable_db": name}
    try:
        result["init"] = init_db(c[name])
        result["health"] = health(url, name)
    finally:
        c.drop_database(name)
        result["dropped"] = name not in c.list_database_names()
    c.close()
    result["ok"] = result["health"]["ok"] and result["dropped"]
    return result


def testdb_drop(url):
    c = client_for(url)
    dropped = [n for n in c.list_database_names() if n.startswith(TEST_DB_PREFIX)]
    for n in dropped:
        c.drop_database(n)
    c.close()
    return {"dropped": dropped, "ok": True}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command", choices=["init", "health", "tx-verify", "testdb-cycle", "testdb-drop", "spec", "verify-indexes", "preflight-indexes"])
    a = ap.parse_args()
    if a.command == "spec":
        print(json.dumps({"collections": collections_used(), "indexes": index_specs()}, indent=2, default=str))
        return
    url, name = load_env()
    if a.command == "init":
        c = client_for(url)
        r = {"db_name": name, **init_db(c[name]), "ok": True}
    elif a.command == "health":
        r = health(url, name)
    elif a.command == "verify-indexes":
        c = client_for(url)
        r = {"db_name": name, **verify_indexes(c[name])}
        c.close()
    elif a.command == "preflight-indexes":
        c = client_for(url)
        r = {"db_name": name, **preflight_unique_indexes(c[name])}
        c.close()
    elif a.command == "tx-verify":
        c = client_for(url)
        r = verify_transactions(c, c[name])
    elif a.command == "testdb-cycle":
        r = testdb_cycle(url)
    else:
        r = testdb_drop(url)
    print(json.dumps(r, indent=2, default=str))
    sys.exit(0 if r.get("ok") else 1)


if __name__ == "__main__":
    main()
