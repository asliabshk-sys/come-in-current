#!/usr/bin/env python3
"""Export a SANITIZED preview/test MongoDB backup and verify it by restoring into disposable DBs.

Never run against production. Usage:
  APP_ENV=development ALLOW_SANITIZED_PREVIEW_SOURCE=yes \
  MONGO_URL=... DB_NAME=comein_preview_test \
  python3 scripts/mongo/export_sanitized_preview_backup.py OUT_DIR
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from pymongo import MongoClient

REDACT = "REDACTED_FOR_BACKUP"
SENSITIVE_FIELDS = {
    "users": ["password_hash", "push_token", "reset_token"],
    "delivery_partner_applications": ["full_name_enc", "mobile_enc", "residential_address_enc", "alternate_contact_enc"],
    "payout_bank_accounts": ["account_number_encrypted", "ifsc_encrypted"],
}
EMPTY_COLLECTIONS = ["auth_rate_limits", "password_resets", "assistant_rate_limits", "grocery_quotes"]


def run(cmd):
    subprocess.run(cmd, check=True)


def stats(db):
    out = {}
    for name in sorted(db.list_collection_names()):
        info = db.command("listCollections", filter={"name": name})["cursor"]["firstBatch"][0]
        out[name] = {
            "documents": db[name].count_documents({}),
            "indexes": sorted(json.dumps(i["key"], sort_keys=True) + json.dumps({k: v for k, v in i.items() if k not in ("key", "v", "ns")}, sort_keys=True, default=str) for i in db[name].list_indexes()),
            "options": info.get("options", {}),
        }
    return out


def main():
    url, src = os.environ.get("MONGO_URL", ""), os.environ.get("DB_NAME", "")
    app_env = (os.environ.get("APP_ENV") or "development").lower()
    if not url or not src:
        sys.exit("MONGO_URL and DB_NAME are required")
    if app_env == "production" or not re.search(r"(?:_dev|_test|_preview)$", src, re.I):
        sys.exit("Refusing: sanitized preview export requires a non-production DB_NAME ending _dev, _test or _preview")
    if os.environ.get("ALLOW_SANITIZED_PREVIEW_SOURCE") != "yes":
        sys.exit("Refusing: set ALLOW_SANITIZED_PREVIEW_SOURCE=yes only for an authorized disposable source DB")

    out = Path(sys.argv[1]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    work = f"comein_disposable_test_sanitize_{stamp}"
    verify = f"comein_disposable_test_restore_verify_{stamp}"
    client = MongoClient(
        url, maxPoolSize=20, serverSelectionTimeoutMS=8000,
        connectTimeoutMS=5000, socketTimeoutMS=20000, retryReads=True,
        retryWrites=True, tz_aware=True,
    )
    raw = out / f".raw-{stamp}.archive.gz"
    archive = out / f"COME-IN-PREVIEW-TEST-DB-SANITIZED-{stamp}.archive.gz"
    config_path = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", prefix="comein-mongo-tools-", suffix=".yaml", delete=False) as config:
            config_path = Path(config.name)
            os.chmod(config_path, 0o600)
            # JSON string syntax is valid YAML scalar quoting; URI never appears in argv.
            config.write("uri: " + json.dumps(url) + "\n")

        run(["mongodump", f"--config={config_path}", f"--db={src}", f"--archive={raw}", "--gzip", "--quiet"])
        client.drop_database(work)
        run(["mongorestore", f"--config={config_path}", f"--archive={raw}", "--gzip", f"--nsFrom={src}.*", f"--nsTo={work}.*", "--quiet"])
        raw.unlink(missing_ok=True)

        db = client[work]
        redactions = {}
        for coll, fields in SENSITIVE_FIELDS.items():
            for field in fields:
                n = db[coll].update_many({field: {"$exists": True}}, {"$set": {field: REDACT}}).modified_count
                if n:
                    redactions[f"{coll}.{field}"] = n
        for coll in EMPTY_COLLECTIONS:
            n = db[coll].delete_many({}).deleted_count
            if n:
                redactions[f"{coll} (all documents removed)"] = n
        db["_backup_metadata"].insert_one({
            "label": "PREVIEW / TEST DATA ONLY - NOT PRODUCTION CUSTOMER DATA",
            "source_database": src,
            "created_at": datetime.now(timezone.utc),
            "redactions": redactions,
            "note": "Passwords, tokens and encrypted PII were redacted. Accounts in this backup cannot log in.",
        })
        run(["mongodump", f"--config={config_path}", f"--db={work}", f"--archive={archive}", "--gzip", "--quiet"])
        expected = stats(db)

        client.drop_database(verify)
        run(["mongorestore", f"--config={config_path}", f"--archive={archive}", "--gzip", f"--nsFrom={work}.*", f"--nsTo={verify}.*", "--quiet"])
        restored = stats(client[verify])
        mismatches = [collection for collection in expected if expected[collection] != restored.get(collection)]
        leftover = [
            f"{collection}.{field}"
            for collection, fields in SENSITIVE_FIELDS.items()
            for field in fields
            if client[verify][collection].count_documents({field: {"$exists": True, "$ne": REDACT}})
        ]
        sha = hashlib.sha256(archive.read_bytes()).hexdigest()
        (out / f"{archive.name}.sha256").write_text(f"{sha}  {archive.name}\n")
        report = {
            "archive": archive.name, "sha256": sha, "size_bytes": archive.stat().st_size,
            "source_database": src, "restore_verify_database": verify,
            "collections": len(expected), "documents_total": sum(v["documents"] for v in expected.values()),
            "indexes_total": sum(len(v["indexes"]) for v in expected.values()),
            "per_collection": {k: {"documents": v["documents"], "indexes": len(v["indexes"]), "options": v["options"]} for k, v in expected.items()},
            "redactions": redactions, "restore_mismatches": mismatches, "unredacted_sensitive_fields": leftover,
            "restore_verification": "PASS" if not mismatches and not leftover else "FAIL",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        (out / "BACKUP_VERIFICATION_REPORT.json").write_text(json.dumps(report, indent=2, default=str))
        if mismatches or leftover:
            raise RuntimeError("Sanitized backup restore verification failed; see BACKUP_VERIFICATION_REPORT.json")
        print(json.dumps({k: report[k] for k in ("archive", "sha256", "collections", "documents_total", "indexes_total", "restore_verification")}, indent=2))
    finally:
        raw.unlink(missing_ok=True)
        if config_path:
            config_path.unlink(missing_ok=True)
        # Both namespaces are generated disposable-only names. Cleanup never targets src.
        client.drop_database(work)
        client.drop_database(verify)
        client.close()


if __name__ == "__main__":
    main()
