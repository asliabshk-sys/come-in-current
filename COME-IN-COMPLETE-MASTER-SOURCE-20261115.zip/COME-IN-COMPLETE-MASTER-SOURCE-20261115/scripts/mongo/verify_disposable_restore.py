#!/usr/bin/env python3
"""Read-only post-restore acceptance: names, counts, and index semantics.

Both DBs must be disposable databases on a local unauthenticated server.
No document contents, credentials, or personally identifying data are printed.
"""
import json
import os
from urllib.parse import urlsplit

PREFIX = 'comein_disposable_test_'
INDEX_FIELDS = ('key', 'unique', 'sparse', 'expireAfterSeconds', 'partialFilterExpression', 'collation')


def validate_environment(env):
    if env.get('APP_ENV') != 'test':
        raise ValueError('APP_ENV=test required')
    source, target = env.get('DB_NAME', ''), env.get('TARGET_DB', '')
    if not source.startswith(PREFIX) or not target.startswith(PREFIX) or source == target:
        raise ValueError('Distinct disposable source and target DB names required')
    parsed = urlsplit(env.get('MONGO_URL', ''))
    if parsed.scheme != 'mongodb' or parsed.hostname not in {'localhost', '127.0.0.1', '::1'} or parsed.username or parsed.password:
        raise ValueError('Only unauthenticated local test MongoDB is supported')
    return source, target


def _index_signature(index):
    return {key: index[key] for key in INDEX_FIELDS if key in index}


def check_restore(source_db, target_db):
    source_collections = set(source_db.list_collection_names())
    target_collections = set(target_db.list_collection_names())
    issues = []
    if not source_collections:
        issues.append({'type': 'empty_source_database'})
    if source_collections != target_collections:
        issues.append({'type': 'collection_names', 'source_only': sorted(source_collections - target_collections),
                       'target_only': sorted(target_collections - source_collections)})
    rows = []
    for name in sorted(source_collections & target_collections):
        original = source_db[name]
        recovered = target_db[name]
        source_count = original.count_documents({})
        restored_count = recovered.count_documents({})
        source_indexes = {idx['name']: _index_signature(idx) for idx in original.list_indexes()}
        restored_indexes = {idx['name']: _index_signature(idx) for idx in recovered.list_indexes()}
        if source_count != restored_count:
            issues.append({'type': 'document_count', 'collection': name,
                           'source': source_count, 'restored': restored_count})
        if source_indexes != restored_indexes:
            issues.append({'type': 'index_specification', 'collection': name,
                           'source_names': sorted(source_indexes), 'restored_names': sorted(restored_indexes)})
        rows.append({'collection': name, 'documents': restored_count, 'indexes': len(restored_indexes)})
    return {'verified': not issues, 'collections': rows, 'issues': issues}


def main():
    source, target = validate_environment(os.environ)
    from pymongo import MongoClient
    client = MongoClient(os.environ['MONGO_URL'], serverSelectionTimeoutMS=8000)
    try:
        result = check_restore(client[source], client[target])
        print(json.dumps(result, indent=2, default=str))
        if not result['verified']:
            raise SystemExit('Restore verification failed: collection, count or index drift')
    finally:
        client.close()


if __name__ == '__main__':
    main()
