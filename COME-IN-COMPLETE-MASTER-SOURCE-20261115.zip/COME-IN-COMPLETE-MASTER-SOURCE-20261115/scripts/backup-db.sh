#!/usr/bin/env bash
# COME-IN Task 16 — MongoDB backup. Reads MONGO_URL and DB_NAME from the environment
# (or backend/.env). Writes a timestamped gzip archive; never prints credentials.
set -euo pipefail
umask 077
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [ -z "${MONGO_URL:-}" ] && [ -f "$ROOT/backend/.env" ]; then set -a; . "$ROOT/backend/.env"; set +a; fi
: "${MONGO_URL:?MONGO_URL is required}"; : "${DB_NAME:?DB_NAME is required}"
command -v mongodump >/dev/null || { echo "mongodump (MongoDB Database Tools) is required" >&2; exit 1; }

# Pass the URI through a mode-0600 tool config file, not process arguments.
MONGO_TOOL_CONFIG="$(mktemp)"
chmod 600 "$MONGO_TOOL_CONFIG"
python3 - "$MONGO_TOOL_CONFIG" <<'PYCFG'
import json, os, sys
path, uri = sys.argv[1], os.environ["MONGO_URL"]
with open(path, "w", encoding="utf-8") as handle:
    handle.write("uri: " + json.dumps(uri) + "\n")
os.chmod(path, 0o600)
PYCFG
trap 'rm -f "$MONGO_TOOL_CONFIG"' EXIT
OUT_DIR="${BACKUP_DIR:-$ROOT/backups}"; mkdir -p "$OUT_DIR"
# mktemp guarantees a fresh destination even when multiple jobs run in one second.
# Never overwrite an existing archive, checksum or original recovery artifact.
RUN_DIR="$(mktemp -d "$OUT_DIR/${DB_NAME}-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXXXX")"
FILE="$RUN_DIR/${DB_NAME}.archive.gz"
mongodump --config="$MONGO_TOOL_CONFIG" --db="$DB_NAME" --archive="$FILE" --gzip --quiet
sha256sum "$FILE" > "$FILE.sha256"
echo "Backup written: $FILE"
echo "A backup is only proven recoverable after scripts/restore-db.sh succeeds against a test database."
