# COME-IN — Emergent MongoDB Integration Handoff

**Scope:** Universal Catalogue Import — approved staging records to the existing Product catalogue.  
**Codex boundary:** source-level and mocked verification only. No live MongoDB connection, credentials, deployment edits, or transaction probe was performed.

## 1. Current staging data model

Collection: `catalogue_import_jobs` (introduced by the existing checkpoint implementation).

A job contains:
- `job_id`, `shop_id`, `seller_id`, `status`, `created_at`, `updated_at`
- `source_files[]`: filename, detected type, SHA-256, page/sheet count, extraction warnings
- `records[]`: `source_file`, `source_location`, `source_sha256`, `raw_values`, `normalized`, CHAND structured fields, seller-edited values and field states, approval/rejection metadata
- `applied: false` until Emergent completes the transactional write (Codex does not set it true)
- error summary and CHAND status/message

Staging records are not customer products. Upload/extraction, CHAND interpretation, editing, approval, rejection, and preflight confirmation write only `catalogue_import_jobs`.

## 2. Current import-job APIs

All seller endpoints require the existing authenticated user and `_assert_shop_owner(shop, user)`; reads and writes additionally scope by `shop_id` and `seller_id`.

- `POST /shops/{shop_id}/catalogue-import/jobs` — extract files, create staging job, invoke configured CHAND adapter if configured.
- `GET /shops/{shop_id}/catalogue-import/jobs` — list the seller's jobs.
- `GET /shops/{shop_id}/catalogue-import/jobs/{job_id}` — fetch job and record previews.
- `GET /shops/{shop_id}/catalogue-import/categories` — return category IDs already used by master/shop products.
- `PATCH /shops/{shop_id}/catalogue-import/jobs/{job_id}/records/{record_index}` — edit allowed fields; marks fields `SELLER_EDITED`.
- `POST .../records/{record_index}/approve` — validate and approve one record.
- `POST .../records/{record_index}/reject` — reject one record with optional reason.
- `POST .../bulk-approve` — approve only complete, validation-passing records without CHAND suggestions/uncertainty; others are skipped with reasons.
- `POST .../confirm-apply` — requires `{ "confirm": true }`, validates all approved rows and atomically changes job status to `APPLY_PENDING_EMERGENT`. This is a preflight/handoff only; it does **not** create products or update stock.

Existing legacy `POST /shops/{shop_id}/products/import` remains separate and unchanged. It already uses a transaction for apply and fails closed if transaction commit is unavailable.

## 3. Approved-record application contract

Emergent must only process jobs in `APPLY_PENDING_EMERGENT` with:
- `seller_confirmed_by == seller_id`
- current authenticated seller still owns the shop
- `applied != true`
- each selected record has `review_status == APPROVED`
- every record passes the same `ProductIn` / measured-contract validation again
- no record has already been applied or mapped to a product

The server, not the client, must supply `shop_id`, owner fields, publication markers, and source provenance. Never trust a client-supplied owner, shop, price, stock, category, or approval flag without revalidation.

For each created Product document, persist provenance fields such as:
- `catalogue_import_job_id`
- `catalogue_import_record_index`
- `catalogue_import_source` (filename/location/SHA-256)
- `catalogue_import_approved: true`
- `catalogue_import_applied: true`

Only after the transaction commits may the job be marked `applied: true` and records marked `APPLIED`. If the transaction aborts, no Product/stock writes or applied markers may remain.

## 4. Existing Product and Inventory representation

The current backend uses `db.products` as the Product collection. Product data is validated through `ProductIn` / `ProductVariantIn`.

Stock is represented on the Product document:
- single/fixed-pack product: `Product.stock`
- variant product: each `variants[].stock`
- Task 5 measured product: base-unit stock on `Product.stock`, with `sell_by` and `measure` contract; measured quantity validation and pricing must remain unchanged.

The current backend source does not expose a separate `db.inventory` collection. Do not invent a second inventory store as part of this handoff. Follow the existing Product stock and order-reservation code paths.

## 5. Required transaction boundaries

Use the existing MongoDB transaction/session pattern already used by the legacy product import and checkout code. A single import job should be atomic unless the product owner explicitly approves a separately documented chunked-import design.

Within one transaction:
1. Re-read and validate the job and shop ownership.
2. Claim the job using a conditional state transition from `APPLY_PENDING_EMERGENT` and `applied != true`.
3. Revalidate every approved record and existing category/product constraints.
4. Check duplicate/idempotency keys.
5. Insert each Product document with `available` only as permitted by the existing seller workflow and with both import publication markers true only in the committing transaction.
6. Initialize `stock` or `variants[].stock` according to the existing product model; preserve measured base-unit semantics.
7. Store product IDs and per-record application result in the job.
8. Write import audit metadata and mark the job applied.

Do not expose imported products to customers until the same transaction commits the Product and both publication markers. Customer catalogue and cart/checkout checks already treat legacy products without import markers as legacy-compatible; imported products carrying import provenance require both `catalogue_import_approved == true` and `catalogue_import_applied == true`.

## 6. Atomic product creation and inventory updates

- Create the Product document and its initial stock in the same transaction.
- For variants, validate every variant and initialize nested stock in the same Product insert.
- For measured products, call/reuse `_import_measure` and `ProductIn`; do not convert the approved integer base-unit stock to display units or recompute price independently.
- Do not run an additional stock mutation after inserting the Product unless a defined existing operation requires it.
- Do not touch Restaurant Mode products, collections, pricing, or order flows.

## 7. Idempotency and retry requirements

Use deterministic idempotency key: `catalogue-import:{shop_id}:{job_id}:{record_index}`.

Recommended unique index: `(catalogue_import_job_id, catalogue_import_record_index)` for imported Product records (partial filter for documents where both fields exist). A retry must return the existing Product ID/result, not create a second Product or re-add stock.

The job-level claim must be a conditional atomic update. Distinguish `IN_PROGRESS`, `APPLIED`, and retryable/failed outcomes. Do not reset an applied job to pending. A provider timeout before transaction start may be retried; an ambiguous commit must first be reconciled by idempotency keys and job state before retrying.

## 8. Rollback requirements

If any row fails validation, duplicate protection, product insertion, or audit update, abort the transaction. The job must not be marked applied. No partial Product documents or stock must remain. Store a bounded, non-sensitive failure summary outside the aborted transaction only after determining the transaction outcome; never log credentials or raw private uploads.

## 9. Cross-shop authorization requirements

Every operation must bind `job_id + shop_id + seller_id`. Re-fetch the shop and confirm `owner_id` still matches the authenticated seller immediately before application. Never allow a seller to edit, approve, reject, list, or apply another seller's job by guessing a job ID. Admin override, if ever required, must be a separately authorized and audited route.

## 10. Live MongoDB verification steps for Emergent

1. Confirm the deployed MongoDB topology supports transactions (replica set or supported sharded deployment); do not infer from local configuration.
2. Confirm the application database user has required read/write/index privileges without exposing credentials in logs or reports.
3. Apply the required unique idempotency index using a reviewed deployment migration; check for pre-existing duplicates first.
4. Exercise one-record and multi-record successful imports and verify Product fields, stock, provenance, job status, and customer visibility after commit.
5. Force a mid-batch validation/write failure and verify complete rollback.
6. Submit the same confirmation concurrently and verify exactly one transaction applies.
7. Retry after a simulated client timeout/ambiguous commit and verify no duplicate products or stock increments.
8. Attempt cross-shop access/edit/approve/apply and verify 403/404 without data leakage.
9. Verify staged, rejected, incomplete, unapproved, and `APPLY_PENDING_EMERGENT` records are not returned by customer catalogue and cannot be quoted or checked out.
10. Verify legacy products without import markers remain visible/quotable when their existing shop/availability/stock rules pass.
11. Verify inactive, out-of-stock, and unavailable variants remain excluded; test cart quote and final checkout revalidation.
12. Verify Task 5 fixed-pack and measured product quantity, price, stock deduction, cancellation restoration, and concurrency behavior.
13. Run Restaurant Mode catalogue/order regression tests against the same deployment.
14. Capture transaction commit/abort results, MongoDB server version/topology, index definitions, test IDs, and sanitized logs in Emergent's verification report.

## 11. Tests Emergent must run against actual deployment

- Mongo transaction capability and session commit/abort.
- Atomic multi-record import and rollback on a deliberately failing record.
- Concurrent double-confirm and repeated idempotent retry.
- Unique-index conflict and reconciliation after ambiguous commit.
- Product/variant initial stock correctness and Task 5 base-unit correctness.
- Cross-shop authorization at every job endpoint and at application time.
- Customer catalogue visibility before and after commit.
- Cart quote and checkout rejection for staged/unapproved/unapplied products.
- Legacy product compatibility.
- Existing CSV/XLSX import transaction regression.
- Restaurant Mode regression.

**Boundary:** None of these live MongoDB checks was executed by Codex. The Codex source-level tests are not substitutes for Emergent's live deployment verification.

---

## 12. Codex source implementation update — 2026-11-14

The implementation described above as Emergent-only is now present in the current preserved Phase 2 source. The existing `confirm-apply` endpoint invokes `_apply_catalogue_import_job_transactionally` using Motor `session.with_transaction`. It revalidates job/shop/seller ownership, inserts Products through `ProductIn` / `_import_measure`, writes initial Product stock and provenance, records product IDs and an audit row, and commits `APPLIED` state atomically. A unique partial index protects per-job/per-record Product identity. See `docs/COME-IN-UNIVERSAL-CATALOGUE-IMPORT-TRANSACTIONAL-APPLY-IMPLEMENTATION-2026-11-14.md`.

The following limitations remain explicit: no Product update/merge policy is defined by this handoff; universal-import variants do not have a complete staged/editor schema; barcode is not a ProductIn field; imported Products default to `available: false`; existing categories only; and per-shop SKU uniqueness is not globally enforced without a duplicate preflight and separate approval.

This is source implementation, not live MongoDB acceptance. All replica-set transaction, retry, rollback, concurrency, index creation, schema validator and publication tests remain `BLOCKED_BY_NON_PAID_ENVIRONMENT_DEPENDENCY` until a compatible disposable environment is available. This update does not alter the original approved contract sections above.
