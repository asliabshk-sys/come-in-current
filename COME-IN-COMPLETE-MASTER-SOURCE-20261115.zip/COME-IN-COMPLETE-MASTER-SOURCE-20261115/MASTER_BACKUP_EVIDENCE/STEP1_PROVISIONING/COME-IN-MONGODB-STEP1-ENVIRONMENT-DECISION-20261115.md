# COME-IN MongoDB Step 1 — Free Replica-Set Environment Feasibility Decision

Date: 2026-11-15 (UTC). Scope: environment investigation only; Step 1, no application changes.

**Decision:** `BLOCKED_BY_EXTERNAL_TEST_ENVIRONMENT`. No available, connected, compatible MongoDB 8.0 replica set was identified or verified in the current execution environment. Do not treat either the Debian 12 deployment design or Atlas Free as provisioned. Real replica-set transactions verified: **0**.

## Preserved authoritative baseline

- Verified source directory (inspected, not modified): `/mnt/data/COME-IN-MONGODB-STEP1-FINAL-20261115`
- Existing separate live acceptance extraction (inspected, not modified): `/mnt/data/COME-IN-MONGODB-STEP1-LIVE-ACCEPTANCE-20261115/COME-IN-MONGODB-STEP1-FINAL-20261115`
- Final ZIP baseline: `/mnt/data/COME-IN-MONGODB-STEP1-FINAL-SOURCE-CHECKPOINT-20261115.zip`, previously independently verified SHA-256 `5f7253bb61d5d6ebd9e404ba9f9ab7e159082cb43cae123c22c47926ad910071`.
- Existing environment evidence examined: `docs/mongodb/STEP1_ENVIRONMENT_AUDIT.md`, `docs/mongodb/STEP1_REPLICA_SET_SETUP.md` from the isolated extraction.
- No ZIP extraction, application edit, dependency installation, database connection, database migration, backup, restore, or cloud resource creation was done during this investigation.

## Actual read-only runtime findings

| Check | Observation | Status |
| --- | --- | --- |
| OS/architecture | Debian GNU/Linux 13.3 (trixie), x86_64, Linux 6.18.57 | VERIFIED |
| Python | 3.13.5 at `/opt/pyvenv/bin/python` | VERIFIED |
| Project dependencies | `backend/requirements.txt`: `pymongo==4.18.2`, `motor==3.7.1` | VERIFIED SOURCE |
| Runtime Python packages | `pymongo`, `motor` absent from interpreter | MISSING |
| Server/shell/tools | `mongod`, `mongosh`, `mongodump`, `mongorestore` absent | MISSING |
| VM/container engine | `docker`, `podman`, `qemu-system-x86_64`, `systemd-nspawn`, `lxc`, `proot`, `debootstrap` absent; `/dev/kvm` absent | MISSING |
| Existing Debian 12 image | No matching Bookworm/rootfs/VM image found in inspected standard directories | NOT FOUND |
| Existing MongoDB listener | Connection attempts to `127.0.0.1:27017`, `:27018`, `:27019` refused | NOT AVAILABLE |
| Remote test database URI | No `MONGO`/`ATLAS` environment variables for authorized test endpoint were configured; no actual endpoint provided | NOT AVAILABLE |
| DNS | `pypi.org`, `repo.mongodb.org`, `fastdl.mongodb.org`, `cloud.mongodb.com`, `www.mongodb.com` failed with temporary name resolution errors | BLOCKED |
| Raw outgoing TCP | `1.1.1.1:443` and `8.8.8.8:443` refused | BLOCKED |
| HTTPS HEAD checks | `https://repo.mongodb.org`, `https://pypi.org`, `https://www.mongodb.com/docs/v8.0/` returned curl HTTP 000 due to DNS timeout/failure | BLOCKED |

No package installation was attempted after connectivity failed. The presence of `chroot` and `unshare` alone is not a usable Debian 12 environment without a valid rootfs and compatible binaries. No remote replica set was contacted, and no `hello`/`replSetGetStatus` command was executed against a real MongoDB server.

## Compatibility confirmed from official product documentation

- MongoDB Community **8.0** documents **Debian 12 x86_64**, **not Debian 13**, as the supported Debian platform. Source: https://www.mongodb.com/docs/v8.0/tutorial/install-mongodb-on-debian/.
- Motor **3.7.1** supports CPython **3.13**, PyMongo **4.9+**, and MongoDB **8.0** in its published version matrix. Therefore the project's existing pins `motor==3.7.1` + `pymongo==4.18.2` are compatible with the target platform/database by documented version range, but not installed or runtime-verified here. Source: https://motor.readthedocs.io/en/3.7.1/requirements.html.
- Motor 3.7 is not documented against MongoDB 9.x; do not substitute MongoDB 9 to sidestep OS restrictions. The project dependencies have not been upgraded.

## Free environment options and selection

**Preferred option: separately provisioned no-cost Debian 12 x86_64 machine/container/VM** with MongoDB Community 8.0 and a disposable single-node replica set `rs0`; MongoDB Database Tools and Python drivers at existing pins. Keep the Come-In application source unchanged and use a synthetic-only test database. Local bind should be `127.0.0.1` (or a private authenticated endpoint where runner executes remotely). This option is compatible on paper, but **not provisionable from the present environment**: no Debian 12 rootfs/VM engine, binaries/wheels, working network, or pre-authorized remote machine. Topology: none.

**Alternate option: MongoDB Atlas Free (formerly M0)**: official docs say the Free cluster uses MongoDB 8.0, and allows up to 500 collections across 100 databases, with 0.5 GB data+index storage, 100 ops/second and 500 connections; these limits may affect load tests. Administrative replication commands such as `replSetGetStatus`, `replSetInitiate`, `replSetStepDown` are restricted; do not assume administrative failure injection is supported. `mongodump`/`mongorestore` are possible for supported ordinary collections, but Free does not support `--oplog`, `--oplogReplay`, users/roles options or `--preserveUUID`. Cloud free-cluster automated backups are an optional **paid** preview subscription ($0.10/day, up to $3/month) and must remain disabled. Atlas was **not configured or connected**; it additionally requires authorized Atlas account/project, a synthetic database, private credentials, secure network allowlist and functional network access from the test runner. Official sources: https://www.mongodb.com/docs/atlas/reference/free-shared-limitations/ ; https://www.mongodb.com/docs/atlas/unsupported-commands/ ; https://www.mongodb.com/docs/atlas/backup/cloud-backup/free-cluster-backup/ .

Atlas Free could support a subset of acceptance tests if a separate accessible runner were provided. It cannot be declared an equivalent replacement for full self-managed replica-set administrative acceptance without checking each command. Do not activate optional paid backup or other paid tiers.

## Required next external action

**Provide access to an independent disposable Debian 12 x86_64 execution environment**, with outgoing package access **or** offline official MongoDB 8.0 packages/Database Tools and wheels for project pins (`pymongo==4.18.2`, `motor==3.7.1`). Open the verified source ZIP there without changing the originals. The runner should be capable of starting a localhost-only `rs0` using a disposable DB with synthetic data, and running the existing project scripts and test suites. The current container cannot administer an independent remote host through the tools currently available.

On that environment, first verify `mongod --version`, `mongodump --version`, `mongorestore --version`, Python imported driver versions; then start the isolated `rs0`, run `db.hello()` and `rs.status()` as appropriate, confirm `setName`, primary state and a real commit+abort. Only after the results exist should Step 1 acceptance phases 3–9 proceed. Record actual output and never claim availability based on an untested URI. Never use production credentials, production data, or paid services.

**Current status:** Step 1 `PARTIAL` (live acceptance blocked), Step 2 `NOT STARTED`. Original checkpoints and source preserved.
