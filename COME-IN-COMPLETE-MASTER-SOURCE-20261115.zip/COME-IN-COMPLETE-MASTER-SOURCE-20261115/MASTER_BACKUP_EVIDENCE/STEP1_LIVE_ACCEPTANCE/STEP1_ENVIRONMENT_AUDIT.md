# COME-IN — MongoDB Step 1, Phase 1 Environment & Driver Audit

**Date:** 2026-11-15. **Status:** BLOCKED for live execution; read-only verification and offline helper tests completed. No production access.

## Authoritative source
- Exact verified final source ZIP: `/mnt/data/COME-IN-MONGODB-STEP1-FINAL-SOURCE-CHECKPOINT-20261115.zip`
- ZIP SHA-256: `5f7253bb61d5d6ebd9e404ba9f9ab7e159082cb43cae123c22c47926ad910071` — MATCH expected `5f7253bb61d5d6ebd9e404ba9f9ab7e159082cb43cae123c22c47926ad910071`.
- Earlier verified ZIP: `/mnt/data/COME-IN-MONGODB-STEP1-SOURCE-CHECKPOINT-20261115.zip`; SHA-256 `12c98826a73f2590d66b51bff8a9871d28825c7199d037d959ce47023e9f95af` — MATCH expected `12c98826a73f2590d66b51bff8a9871d28825c7199d037d959ce47023e9f95af`.
- ZIP CRC: PASS; final ZIP 620 file entries. Each of these 620 ZIP file contents matches the corresponding file in the **separate extracted working copy** `/mnt/data/COME-IN-MONGODB-STEP1-LIVE-ACCEPTANCE-20261115/COME-IN-MONGODB-STEP1-FINAL-20261115`. Original ZIP and source directory remain unchanged.
- No original `.git` in the source snapshot; original Git commit status not recoverable from this ZIP.

### Important pre-existing `SHA256SUMS` inconsistency
The `SHA256SUMS` *inside the final ZIP* describes an earlier/different 680-entry file selection, and **does not validate the 620-file final archive**: 541 entries match ZIP contents, 24 entries have different hashes, 115 listed paths are absent (many are excluded historical backups), and 54 included files are missing from the old manifest (excluding the manifest itself). This is not proof of corruption: the expected whole-ZIP hash and its CRC pass, and all ZIP bytes match the extracted baseline.

A **fresh, independent** SHA-256 list of all 620 actual ZIP entries was generated at `/mnt/data/COME-IN-MONGODB-STEP1-LIVE-ACCEPTANCE-20261115/VERIFIED_20261115_FINAL_ZIP_620_FILES.sha256`. Exact discrepancies recorded at `/mnt/data/COME-IN-MONGODB-STEP1-LIVE-ACCEPTANCE-20261115/EXISTING_ZIP_SHA256SUMS_RECONCILIATION.txt`. The old manifest has **not** been overwritten. A future phase-9 ZIP must include a current, matching manifest.

## Runtime capability matrix
| Capability | Finding | Status |
|---|---|---|
| OS | Debian GNU/Linux 13.3 (trixie), x86_64 | VERIFIED |
| Python | CPython 3.13.5 at `/opt/pyvenv/bin/python` | VERIFIED |
| Existing environment | `/opt/pyvenv` exists; no project-local venv found | VERIFIED |
| Dependencies declared | `motor==3.7.1`, `pymongo==4.18.2`, `pytest>=8`, `pytest-xdist>=3.6` | VERIFIED |
| Motor/PyMongo modules | Not importable from active interpreter | MISSING |
| pytest | Executable and usable with `-c /dev/null` | AVAILABLE |
| pytest-xdist | Missing (project test config normally loads it) | MISSING |
| mongod / mongosh | No binaries on PATH; no usable cached server | MISSING |
| mongodump / mongorestore | No real tools on PATH; test-created fake executables in `/tmp` are **not** usable MongoDB Tools | MISSING |
| Docker/Podman | Not available | MISSING |
| VM/chroot image | No Debian 12 image or supported deployment provisioned; `/dev/kvm` unavailable | BLOCKED |
| DNS | `pypi.org`, `repo.mongodb.org`, `fastdl.mongodb.org` all failed name resolution (gaierror -3) | BLOCKED |
| Apt | No mongodb-org candidate in current package metadata | MISSING |
| MongoDB connection | No authorized free test URI supplied; no local server listening as verified by executable checks | BLOCKED |
| Driver compatibility | Motor 3.7.1 supports Python 3.13, PyMongo 4.9+ and MongoDB through 8.0 (official compatibility matrix). Current pin 4.18.2 is within compatible range. | VERIFIED DOCUMENTATION (not runtime) |
| Source transactions | 20 `run_transaction(client, ...)` call sites in backend/server.py; wrapper uses Motor `session.with_transaction(callback)` | VERIFIED SOURCE ONLY |

**Platform caution:** MongoDB 8.0 Community officially supports Debian 12, **not Debian 13**. MongoDB 9.x supports Debian 13, but the project-pinned Motor 3.7.1 compatibility matrix does not cover MongoDB 9.x. Do not install an unsupported pairing just to claim success.

## Actual local commands and results
1. `sha256sum` on both expected ZIPs — MATCH.
2. `ZipFile.testzip()` — PASS, final ZIP 620 files.
3. Compare every final ZIP file against extracted separate working copy — 620/620 exact contents MATCH.
4. `command -v mongod mongosh mongodump mongorestore docker podman` — no usable executable.
5. `python -c ... importlib.util.find_spec` — Motor/PyMongo missing.
6. `python -c ... socket.getaddrinfo` — `gaierror -3` on pypi.org, repo.mongodb.org, fastdl.mongodb.org.
7. `apt-cache policy mongodb-org mongodb-server` — no candidate in existing metadata.
8. `rg 'run_transaction\(' backend/server.py` — 20 source call sites.
9. **Actual offline test**: `PYTHONPATH="$ROOT:$ROOT/backend" pytest -c /dev/null -q backend/tests/test_mongo_config.py backend/tests/test_mongo_transactions.py backend/tests/test_mongo_portability_tool.py` from project root — **27 passed in 6.21s; exit 0**. Output: `/mnt/data/COME-IN-MONGODB-STEP1-LIVE-ACCEPTANCE-20261115/PHASE1-OFFLINE-TEST.log`.

## Missing prerequisites and effect
- No compatible running replica set, Motor/PyMongo, or MongoDB Database Tools. Network is unavailable to provision them. No permitted existing Atlas account/cluster connection is present.
- Consequently live transaction commits/aborts, unknown-commit fault injection, concurrency, 67 index installations, validator enforcement, real dump/restore, and all 20 flow acceptance tests were **NOT RUN**.
- Phase 1 driver installation is BLOCKED. Do not call Phase 2 provisioned or Phase 3–9 executed. **Step 1 remains PARTIAL**.

## External references (verified 2026-11-15)
- MongoDB community platform matrix: https://www.mongodb.com/docs/community-platform-support/
- MongoDB 8.0 Debian installation prerequisites: https://www.mongodb.com/docs/v8.0/tutorial/install-mongodb-on-debian/
- Motor 3.7.1 requirements / compatibility: https://motor.readthedocs.io/en/3.7.1/requirements.html
