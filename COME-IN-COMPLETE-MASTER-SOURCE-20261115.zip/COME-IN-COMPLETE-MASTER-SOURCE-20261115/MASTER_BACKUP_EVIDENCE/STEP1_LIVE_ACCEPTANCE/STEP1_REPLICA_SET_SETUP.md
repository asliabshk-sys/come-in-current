# COME-IN — MongoDB Step 1, Phase 2 Free Replica Set Feasibility & Setup

**Date:** 2026-11-15. **Status:** BLOCKED — no replica set provisioned. This is a verified feasibility/runbook, **not** evidence that Phase 2 or its later acceptance tests ran.

## Preferred technical target — local free environment (not currently accessible)
- Supported **Debian 12 x86_64** disposable local VM/host/container with **MongoDB Community 8.0.x**, preferably latest supported 8.0 patch, no paid cloud.
- Single-node `rs0` for database multi-document transaction acceptance; `127.0.0.1:27018` only (no public network); use synthetic records and disposable DB names only.
- Project pins: `motor==3.7.1`, `pymongo==4.18.2`, supported with MongoDB 8.0 by published Motor compatibility.
- Existing scripts to reuse: `scripts/mongo/start-replset.sh`, `infra/mongodb/rs-init.js`, `scripts/mongo/comein_mongo.py`, `scripts/mongo/setup.sh`, `scripts/backup-db.sh`, `scripts/restore-db.sh`. **Do not** run `setup.sh` against any non-disposable target; it performs collection/index writes. Inspect all environment variables and scripts again on the selected host.

### Safe preparation on an authorized Debian 12 environment (NOT EXECUTED)
1. Install MongoDB **Community 8.0** and `mongosh`, MongoDB Database Tools from the vendor's Debian 12 instructions. Verify binaries and exact versions first. Do not overwrite existing MongoDB on a non-disposable host.
2. Create a project-local Python virtual environment; install requirements at existing project pins (no blind upgrades).
3. Use a private temporary local directory for database files; restrict permissions. Set `MONGO_RS_BIND=127.0.0.1`, `MONGO_RS_PORT=27018`, `MONGO_RS_NAME=rs0`, and `MONGO_RS_DBPATH` to that disposable directory; start `scripts/mongo/start-replset.sh` only when the host is isolated.
4. Verify `db.hello().isWritablePrimary` and `db.hello().setName == 'rs0'` using local mongosh, then verify actual session commit/abort and read-after-commit with synthetic data.
5. Set `APP_ENV=test`, `DB_NAME=comein_disposable_*` and `MONGO_EXPECTED_DB_NAME` exactly equal. Use local `mongodb://127.0.0.1:27018/?replicaSet=rs0`; do not place passwords or Atlas URIs in source.
6. Run read-only preflight and duplicate/index checks before creating schema/indexes; verify 51 collection declarations / 67 index declarations against `listCollections`, `listIndexes` and validator `listCollections` options after authorized non-production installation.
7. Run each callback flow and rollback/retry/concurrency tests, using synthetic data and forced exceptions; never call external payment providers inside retried callback.
8. Run `mongodump`/`mongorestore` using the project's disposable-only guard scripts and verify counts/indexes/validators/relationships against a **different** empty test DB, never production and never `--drop`.
9. Cleanup after explicit review: stop only the disposable `mongod` process and keep evidence/backup files for acceptance. No automatic directory deletion.

## Atlas Free (formerly M0) alternative — NOT PROVISIONED
Official Atlas docs say free tier currently uses **MongoDB 8.0** and exists for development, but its commands/permissions and backup options are restricted; cloud-backup feature is not available, and `mongodump` / `mongorestore` have option limitations (including `--oplogReplay`, `--preserveUUID`, users/roles options). A free cluster cannot be assumed to provide fault injection, replica-set administration, or identical validator/index privileges without validation. Atlas requires user account access, DB credential provisioning, secure network allowlisting, and a permitted **synthetic-only** test database. None are currently available in this execution environment. **No Atlas cluster was created, accessed or charged.**

## Rejected or unavailable current-host choices
- Host **Debian 13 x86_64** + MongoDB 8.0: unsupported OS combination per vendor matrix.
- Host Debian 13 + MongoDB 9.x: Motor 3.7.1 compatibility matrix does not certify 9.x. Do not force.
- Docker/Podman, Debian 12 VM/rootfs: none available.
- Network install: blocked at DNS, and no official MongoDB executables or driver wheels cached.

## Actual topology and verification status
**Selected intended target:** isolated Debian 12 + MongoDB Community 8.0 single-node rs0 (no environment provisioned).
**Actual current topology:** none. **Transactions run:** 0. **Backup/restore drills run:** 0. **Atlas account used:** no. **Paid service:** no.

**Phase 2 remains BLOCKED** until a compatible local host/container with available packages or authorized free test endpoint and pinned driver availability exists. Phase 3–9 tests must not be marked PASS.

## Sources checked
- https://www.mongodb.com/docs/community-platform-support/
- https://www.mongodb.com/docs/v8.0/tutorial/install-mongodb-on-debian/
- https://motor.readthedocs.io/en/3.7.1/requirements.html
- https://www.mongodb.com/docs/atlas/reference/free-shared-limitations/
- https://www.mongodb.com/docs/atlas/unsupported-commands/
- https://www.mongodb.com/docs/atlas/backup-restore-cluster/
- https://www.mongodb.com/docs/database-tools/mongorestore/mongorestore-behavior-access-usage/
