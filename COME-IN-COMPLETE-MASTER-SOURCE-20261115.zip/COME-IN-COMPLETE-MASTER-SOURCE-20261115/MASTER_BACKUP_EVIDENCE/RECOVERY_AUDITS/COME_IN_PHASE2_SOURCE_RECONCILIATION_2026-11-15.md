# COME-IN Phase 2 — Source Reconciliation Audit (READ-ONLY)
**Date:** 2026-11-15  
**Scope:** Static comparison of recovered partial checkpoint with actual available historical ZIP source, historic MongoDB reports, archived Git metadata, index/validation declarations. **No implementation, tests requiring a DB, Git operation, restore or data migration.**

## 1. Provenance, archive boundaries, and central findings
- **Recovered source inspected:** `/mnt/data/COME-IN-MONGODB-READONLY-RECOVERY-20261115/COME-IN-MONGODB-PHASE2-WORK`. It is an extracted **partial checkpoint**, not an active, Git-backed workspace. The source root has no `.git`.
- **MASTER archive (READ-ONLY):** `COME-IN-MASTER-PROJECT-CODEX-READY 2.zip`; 1820 ZIP entries. Used direct ZIP member byte reads without restoring/extracting historical versions.
- **PRECHANGE archive (READ-ONLY):** `COME-IN-MONGODB-MISSION-PRECHANGE-20261114.zip`; 1451 ZIP entries. Used direct ZIP member byte reads without restoring/extracting historical versions.
- **PARTIAL archive (READ-ONLY):** `COME-IN-MONGODB-MISSION-PARTIAL-CHECKPOINT-20261114 (1).zip`; 681 ZIP entries. Used direct ZIP member byte reads without restoring/extracting historical versions.
- **Archived Git metadata:** `MASTER` and `PRECHANGE` contain `.git/HEAD` = `ref: refs/heads/main`; `.git/refs/heads/main` = `4681a4c0ca3e45787825f4b196b3284daa23a1f0`. `PARTIAL` has no `.git` history. This does not reconstruct the original uncommitted Git tree.
- **Checksum reconciliation:** 14 `PROJECT_MANIFEST.json` mismatches and 22 older `MANIFEST.sha256` mismatches were rederived from actual source bytes; **none missing**. All 14 `PROJECT_MANIFEST` expected SHA-256 values match the same files inside `MASTER`. The `SHA256SUMS` 680/680 pass and archive CRC pass were independently recorded in the preceding recovery audit, not rerun as a runtime/backend test here.
- **Version sequence by content:** MASTER → PRECHANGE → PARTIAL is consistent with the inspected file contents; only `backend/server.py`, `backend/tests/test_grocery_checkout_security_contract.py`, and `scripts/mongo/comein_mongo.py` differ between MASTER and PRECHANGE among the 14 Project Manifest mismatches. Date/order beyond file-content relationships is not independently proven by the preserved Git commit metadata.
- **No authoritative latest original Phase 2 working tree has been recovered.** Do not merge historical archives or back-port sources automatically.

## 2. All 14 PROJECT_MANIFEST.json differences (original historical version located)
Every row shows `MASTER match = yes` by recomputed SHA-256. `PRECHANGE intermediate` means the PRECHANGE copy does not match either MASTER or recovered content. SHA values below are **real file-content hashes**, not archive CRCs.

| Relative file | Expected / MASTER SHA-256 | Recovered SHA-256 | PRECHANGE vs MASTER | Historical/source finding |
|---|---|---|---|---|
| `CHANGELOG.md` | `d5e6f1d602dc75a3ce381baf46565282de4e363fd62b36acbfa21899b7968d08` | `574ef4c7ab85e3a8dd0d095fd8bd74b50091d6f3f12bf310d4474151c64673e4` | same as MASTER | Changelog updated after older source packaging (+9/−0 lines PRECHANGE→PARTIAL) |
| `CODEX_HANDOFF.md` | `adeac351284e27255a5e1c6e497646728fb658fac37f22bc23c92959c58c04a6` | `adc0ec9c9e4352d02c1315ace9ec3d1d5e8410741fec759d6bd95029d471d3de` | same as MASTER | Handoff updated (+14/−0 lines PRECHANGE→PARTIAL) |
| `COME_IN_MONGODB_PORTABILITY_STATUS.md` | `62fdb4bcbf8de9eec25298f0843b51fd14d99d9f5e691c5068ac855bda0ade41` | `3b8c4ac0b622ecb9ca9b3fd76146233f5e6b1addeb3b2d708b08e265a89052af` | same as MASTER | Portability status updated (+9/−0 lines PRECHANGE→PARTIAL) |
| `MASTER_TASK_TRACKER.md` | `3adf20e7eebea097e8396ab2dfe778b3a4b71487a0b27817941bdb5ecbba4bd8` | `0fd4b1708e62b2cc9a9563e6580c3fda5d1e249f18104608a317158566279cb6` | same as MASTER | Tracker updated (+22/−0 lines PRECHANGE→PARTIAL) |
| `backend/.env.example` | `1d074e56fb3ac2f0fbf2c054a365f6a9c46414e904f0c345c029cc01a518442f` | `ae0bf64874cb5db9a1dd0d077f165133fd105c039e0a0b8afa62d5bb637d4477` | same as MASTER | Mongo configuration TEMPLATE extended; contents not reproduced (+11/−0 lines PRECHANGE→PARTIAL) |
| `backend/server.py` | `b93824f983eb424d8626ec921f662cf186e9dc65663449dcd1c3631118f10a4e` | `1756b0544d71742e4ffe1096dc6b065a9c48ee6963f549d3b5c3dfb3b4ec9b5a` | intermediate version | Transactions/startup, checkout and Grocery capture changes; intermediate prechange version exists (+100/−18 lines PRECHANGE→PARTIAL) |
| `backend/tests/test_grocery_checkout_security_contract.py` | `3280bc9a50dbf9385fa25610974ed59f0aa7d66126404e6fcb9dd58a3d669013` | `da5b8ae3df4d25d82dd416ec5d6289735fe2446bfc8e2ed1bcafcaa34eec46eb` | intermediate version | Offline checkout/security contract tests extended; intermediate prechange version exists (+10/−0 lines PRECHANGE→PARTIAL) |
| `docs/mongodb/MONGODB_SETUP.md` | `0f0e27d931fa7b952d289f1e6da91f57f6d203c4ddc6033b622800a01328be2b` | `1b1f2c330a1e1170ef3fcc86e5cbdfc7f21c6cdbe5bfe4822aeb47f75fd88eb3` | same as MASTER | Connection/setup documentation changed (+11/−5 lines PRECHANGE→PARTIAL) |
| `docs/mongodb/SCHEMA_AND_VALIDATION.md` | `29f7828e75c08f255144d0fe586869b931fd4e334912d2185ff80d8f2f8ee870` | `08ff0d1d46429311bd3cb0f2afc7d9c22ee0fafef5cf0d961179a1eb9a7bae33` | same as MASTER | Schema/validator status documentation changed (+35/−30 lines PRECHANGE→PARTIAL) |
| `docs/mongodb/TRANSACTIONS.md` | `d6d56084b715e1782d6b4b6395faf4f0e157ac9c813312ac0f46c66adfd4449f` | `50e0ebaf1f5c7fcb9e0f8612fc724e6cc7533d2985fe258368b4f64f5ccea069` | same as MASTER | Transaction handling documentation changed (+50/−22 lines PRECHANGE→PARTIAL) |
| `scripts/backup-db.sh` | `5516f50888cfe6371d22adc269c57625105e92c3ffdb4a9c5bf80001deb01b52` | `7c26a96fc23b2a35faaefbfbdc7f9703291f226cb6bad0164fe57d30e9249097` | same as MASTER | Backup safety/integrity script changed (+13/−1 lines PRECHANGE→PARTIAL) |
| `scripts/mongo/comein_mongo.py` | `4ad1fae6f9b04fb8cbc5ba1110ee46e04983c2abf251c2650868bb39042ce460` | `ce358480b49604e7ae3084e131813ec0219ede0b779c1da85af429c9eb45d0a7` | intermediate version | Index discovery/preflight/health script changed; intermediate prechange version exists (+105/−28 lines PRECHANGE→PARTIAL) |
| `scripts/mongo/export_sanitized_preview_backup.py` | `c8bf4c67f34783765cde49cf60916f417eaa25f790723ffc474436353acdc57f` | `15e56ea455b3aaba09f1f464df37f49e18253febc222079584541a3fc99e6ba3` | same as MASTER | Sanitized backup export behavior changed (+91/−52 lines PRECHANGE→PARTIAL) |
| `scripts/restore-db.sh` | `8790d5d5d6473d1330cd911f42416f8b2aee2f732121649bbf271b85b1d656d0` | `58834a4ec79558b1c603379a8d45753160ce89f148da6977561a9ccdefc5745e` | same as MASTER | Restore safeguards/index verification script changed (+30/−9 lines PRECHANGE→PARTIAL) |

**Interpretation:** The earlier expected bytes are available and authentic within the inspected MASTER archive, but neither they nor archived Git HEAD prove that the newer edits are unsafe. The exact editor, authorization, or commit provenance of uncommitted changes is **not** established. None were reverted, rehashed in place or overwritten.

## 3. All 22 MANIFEST.sha256 differences (a distinct, older baseline)
The old `MANIFEST.sha256` is not the same snapshot as `PROJECT_MANIFEST.json`. Its 22 differences span frontend files and earlier project/tracker changes as well as MongoDB code. `MASTER equality` answers whether historical Master contains the OLD manifest's byte hash; `PRECHANGE equality` is also computed separately.

| Relative file | Legacy expected SHA-256 | Recovered SHA-256 | MASTER equality | PRECHANGE equality |
|---|---|---|---|---|
| `.gitignore` | `62574f867122fbca37a0b38ba81eb1aa8710bec627edd196747b1782c04f593b` | `7e22b1272c71a72c988d3a4ecf2f0c867e1ffece56bfe558699a300772897313` | NO | NO |
| `CHANGELOG.md` | `1b32b203cc180c7e7c28de83217529ef10fcf16f182c6ac723658dd98a6a4112` | `574ef4c7ab85e3a8dd0d095fd8bd74b50091d6f3f12bf310d4474151c64673e4` | NO | NO |
| `COME_IN_MASTER_TASK_TRACKER.json` | `e34dd8e9c79af162edf1a80ed6a0da948f589327b7d5b0524bd297958502cad2` | `569dedc3def2c3d469172b3aff10f7266455bfe01c87afe2146830d16c359431` | NO | NO |
| `COME_IN_MASTER_TASK_TRACKER.md` | `680bd76bd1f95eaf300eb828ae625f1b77f45e5e8e391cb163927e477e435fb6` | `6e72e363530683a469714523817b66ffb99b01cbd839c6c9aadd868cd8b0e0f4` | NO | NO |
| `COME_IN_MONGODB_PORTABILITY_STATUS.md` | `62fdb4bcbf8de9eec25298f0843b51fd14d99d9f5e691c5068ac855bda0ade41` | `3b8c4ac0b622ecb9ca9b3fd76146233f5e6b1addeb3b2d708b08e265a89052af` | YES | YES |
| `README.md` | `150c862ac480b75cf20229b6dcc808a245401ddb44df409c6c5611d4530e8597` | `0094004a6ef0baed0c6399d46be9053cf391bf1c60d5ccfff6c411bea06e2113` | NO | NO |
| `backend/.env.example` | `43ff79ceed0fb13f07bcfcd4f3dd36dc3907c1c0e616fb6b5b1b46ca7b4f8935` | `ae0bf64874cb5db9a1dd0d077f165133fd105c039e0a0b8afa62d5bb637d4477` | NO | NO |
| `backend/server.py` | `b8cc8a2ade19cb15680b304d3eef4f630029af02e8888ed45d1d251149056e03` | `1756b0544d71742e4ffe1096dc6b065a9c48ee6963f549d3b5c3dfb3b4ec9b5a` | NO | NO |
| `backend/tests/test_chand_feedback_contract.py` | `1e8c0f265110673b4f3993117b09453c44140d08f9fe32041565f84b67e936fc` | `f01889102344304592f8107ead6ddb190ba7344e8359b20e1ec26e373ee766be` | NO | NO |
| `backend/tests/test_grocery_checkout_security_contract.py` | `3280bc9a50dbf9385fa25610974ed59f0aa7d66126404e6fcb9dd58a3d669013` | `da5b8ae3df4d25d82dd416ec5d6289735fe2446bfc8e2ed1bcafcaa34eec46eb` | YES | NO |
| `backend/tests/test_shopping_catalog_contract.py` | `213adff768e2c12c44a5f0872dc572a38ee3385c45d5285844724efac1fc7d38` | `c090d00bae13d0f267900596e024e83ec51f6fad502738e6c166887bb07e1987` | NO | NO |
| `docs/mongodb/MONGODB_SETUP.md` | `0f0e27d931fa7b952d289f1e6da91f57f6d203c4ddc6033b622800a01328be2b` | `1b1f2c330a1e1170ef3fcc86e5cbdfc7f21c6cdbe5bfe4822aeb47f75fd88eb3` | YES | YES |
| `docs/mongodb/SCHEMA_AND_VALIDATION.md` | `29f7828e75c08f255144d0fe586869b931fd4e334912d2185ff80d8f2f8ee870` | `08ff0d1d46429311bd3cb0f2afc7d9c22ee0fafef5cf0d961179a1eb9a7bae33` | YES | YES |
| `docs/mongodb/TRANSACTIONS.md` | `d6d56084b715e1782d6b4b6395faf4f0e157ac9c813312ac0f46c66adfd4449f` | `50e0ebaf1f5c7fcb9e0f8612fc724e6cc7533d2985fe258368b4f64f5ccea069` | YES | YES |
| `frontend/app/(tabs)/account.tsx` | `38d73ceba0b407761c5577f522fd9defbb22da1068b62778d8bffb00a6d30afe` | `fa81036283a3e962533fc8d7b0d4521a60412ece8f6775ca955e54eeb9d2623c` | NO | NO |
| `frontend/app/chand.tsx` | `0914a3228f1d14585544eac2bee6a20f8d21bffa6acae2ae1ff34069fe7abdee` | `9785bc1ff883807f4c3942d37316cb77ed6dd6ae05d2980762c584fee0c903a3` | NO | NO |
| `frontend/app/seller/products.tsx` | `64962ffff8415c14e7e1e563e791727b642222356f534310f1cfdf379c9d3549` | `b9658c44fe36aa82de314ea20eb13731adc6e02595363deea1c25855c694493b` | NO | NO |
| `frontend/src/lib/api.ts` | `0ec1f597904afc5b64ad51a5be928b5692bbaed10e353739cb320b63ce62cca4` | `5eb84c952369340f047e44b38a5bc3b90068802530daa6d772ff456297b28a0c` | NO | NO |
| `frontend/yarn.lock` | `aed4ccbb6995093dd9b813fa67f6f762f81c13d88ed08d9f4aa8a845fa395371` | `e632b4c9690934907af0f56cf0b4ea236d9636da83976f9367becd00955dbdf7` | NO | NO |
| `scripts/backup-db.sh` | `5516f50888cfe6371d22adc269c57625105e92c3ffdb4a9c5bf80001deb01b52` | `7c26a96fc23b2a35faaefbfbdc7f9703291f226cb6bad0164fe57d30e9249097` | YES | YES |
| `scripts/mongo/comein_mongo.py` | `4ad1fae6f9b04fb8cbc5ba1110ee46e04983c2abf251c2650868bb39042ce460` | `ce358480b49604e7ae3084e131813ec0219ede0b779c1da85af429c9eb45d0a7` | YES | NO |
| `scripts/restore-db.sh` | `8790d5d5d6473d1330cd911f42416f8b2aee2f732121649bbf271b85b1d656d0` | `58834a4ec79558b1c603379a8d45753160ce89f148da6977561a9ccdefc5745e` | YES | YES |

**Counts:** 8 of 22 legacy expected hashes equal MASTER bytes; 6 equal PRECHANGE bytes. Several older hashes **already disagreed with MASTER**, including frontend files; do not attribute every legacy-manifest difference to the MongoDB Phase 2 mission. All current files exist. SHA mismatches alone do not prove ZIP corruption.

## 4. Implementation evidence recovered versus later reports
| Domain | Actual recovered implementation | Historical report/evidence | Status/gap |
|---|---|---|---|
| Connection and safeguards | `backend/mongo_config.py` validates DB target, APP_ENV, Mongo URI, TLS and bounded pool/timeouts; `backend/server.py::_startup` pings and checks replica/sharded topology. | `MONGODB_MASTER_COMPLETION_REPORT.md`, `MONGODB_FINAL_TEST_EVIDENCE.md` record offline contract passes. | Source present; live connectivity/recovery not verified |
| Session and transaction lifecycle | 11 `async with await client.start_session()` + `async with session.start_transaction()` scopes found; driver-managed context commits/aborts where operations are successful/raised. | `MONGODB_TRANSACTION_AUDIT.md` enumerates scopes and session propagation. | Source present; actual commit/abort/cleanup on server not verified |
| Labeled transient errors | `backend/mongo_transactions.py::has_transaction_error_label` and `proven_insufficient_stock_conflict` classify labeled abort only when fresh stock read proves 409. | Phase 2 investigation documents checkout 503-vs-409 issue. | Classification exists; not transaction callback retry |
| Unknown commit result / retry | No `with_transaction()` callback or full transaction-retry/reconciliation loop in recovered `backend/server.py`. `retryWrites`/`retryReads` config is not the same thing. | Historical transaction audit explicitly identifies this gap. | MISSING retry implementation and live unknown-commit tests |
| Grocery checkout/order | `create_order` transaction conditionally consumes quote, decrements stock, inserts order, consumes reward; unique sparse `grocery_idempotency_scope` index is declared. Notifications follow transaction scope. | Existing focused tests (92 passed reported, historical only). | Source implemented; concurrency/rollback/live index not verified |
| Grocery cancellation | `_cancel_grocery_order` guards unpaid/unaccepted orders and transactionally restores product stock and changes order state. | Transaction audit, source tests. | Source implemented; cancellation race live validation missing |
| Grocery payment capture | `_mark_grocery_paid` transactionally changes payment and order, records late/duplicate-capture reconciliation, notification after scope. | Completion report and transaction audit. | Source implemented; intent races, gateway ID unique indexes, live callback testing missing |
| Restaurant payment/refund | `verify_restaurant_payment`, `razorpay_webhook`, and `admin_refund_restaurant_order` exist with payment/event/ledger idempotency guards. | `MONGODB_TRANSACTION_AUDIT.md` documents separate writes and external provider boundaries. | Multi-document atomicity incomplete in this snapshot; real callbacks/refunds not tested |
| Universal Catalogue Import review | Upload/staging, seller-scoped job and record reads, edits, single/bulk approve/reject, field validation with `ProductIn` and `_import_measure`. | `COME_IN_EMERGENT_MONGODB_INTEGRATION_HANDOFF.md`, catalogue contract tests. | Source implemented for staging/review only |
| Universal Catalogue Import apply | `confirm_catalogue_import_apply` only sets `APPLY_PENDING_EMERGENT`, returns `applied:false`, explicitly says **no Product/Inventory write**. | Handoff defines deterministic row idempotency, Product provenance and transactional apply; Master Completion report says newer source absent. | MISSING transactional Product creation and audit in this checkpoint; no rollback/concurrency proof |
| MongoDB indexes | Index extractor discovers 59 `backend/server.py::_startup` + 6 `ensure_delivery_partner_indexes`; 65 total. | `MONGODB_INDEX_INVENTORY.md`; fake DB tests historically passed. | Source declaration inventory complete; actual DB state and duplicate preflight BLOCKED |
| Schema validators | Pydantic models and typed endpoint checks exist. No persistent startup `$jsonSchema` or `collMod` installation. | `MONGODB_SCHEMA_VALIDATION_REPORT.md`, `SCHEMA_VALIDATOR_ASSESSMENT_2026-11-14.md`. | Need clone document profiling before safe validator rollout |
| Backup/restore | Scripts for backup/export and disposable-only restore exist; prior audit verified sanitized archive checksum/gzip. | `reports/mongodb/BACKUP_VERIFICATION_REPORT.json`: 52 collections, 38 docs, 117 indexes on preview/test restore; historical, not rerun. | Historical archive verification and restore *report*; no independent live restore in this audit |
| Authorization/secret handling | Shop owner/cross-seller checks in staging; JWT, role checks, config redaction, encrypted bank/partner fields described. | `MONGODB_SECURITY_AUDIT.md` and secret-scan report. | Source present; live least privilege/TLS/PII and cross-tenant verification pending |

## 5. Transaction scope inventory and failure semantics
The 11 transaction scopes below are in the actual recovered `backend/server.py`, not an extrapolation from a later report:

1. `_maybe_create_referral_reward` — referral threshold, reward/audit; Manual context, no callback retry.
2. `admin_review_referral` — referral review/audit; Manual context, no callback retry.
3. `admin_update_referral_reward` — reward status/ledger/audit; Manual context, no callback retry.
4. `import_shop_products` — legacy CSV/XLSX product import; Manual context; not the Universal Catalogue Import apply.
5. `admin_retail_price_import` — price records/audit/history; Manual context, no callback retry.
6. `create_order` — Grocery quote, inventory, order/reward; Manual; conditional stock update; post-abort conflict classifier.
7. `_cancel_grocery_order` — Grocery cancellation and stock restoration; Manual; returns 409/503 on safe failure paths.
8. `request_shop_settlement` — shop settlement allocations and audit; Manual context.
9. `request_restaurant_settlement` — restaurant settlement allocations and audit; Manual context.
10. `admin_settlement_decision` — state/allocation/audit changes; Manual context.
11. `_mark_grocery_paid` — Grocery capture + order state; Manual; notification after commit; no callback retry.

- **Session lifecycle:** `async with await client.start_session()` scopes manage session termination on ordinary exit/exception. Actual network/server behavior was not exercised. The audit does not certify that all helper queries use the session without runtime instrumentation.
- **Commit/abort:** `async with session.start_transaction()` commits on normal exit and aborts after a raised exception under Motor/PyMongo contract; this is a **source-level guarantee conditional on real driver operation**, not observed database evidence.
- **TransientTransactionError:** source checks label for stock-diagnostic classification only, not general transaction retries.
- **UnknownTransactionCommitResult:** no dedicated driver-managed commit retry/reconciliation implementation was found; a 503 may be returned despite ambiguous commit. Client retry idempotency/index and committed-state reconciliation must be verified before altering behavior.
- **External side effects:** `_notify_new_grocery_order` and Grocery capture `_notify` occur after their transaction scopes in inspected paths; Restaurant provider calls and multi-write sequences need separate correctness/fault-injection review. This is not an assertion that every notification path has been fully audited.

## 6. Source-declared MongoDB index inventory — all 65 (LIVE STATE UNVERIFIED)
**Independent read-only static extractor result:** `50 collections`, `65 indexes`: `_startup` 59, `ensure_delivery_partner_indexes` 6.

| # | Collection | Keys | Options | Declared in | Live index / duplicate proof |
|---:|---|---|---|---|---|
| 1 | `notifications` | `user_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 2 | `assistant_rate_limits` | `rate_key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 3 | `assistant_rate_limits` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` | **NOT RUN** |
| 4 | `chand_feedback` | `user_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 5 | `chand_feedback` | `user_id:1, request_id:1` | `unique=true` | `_startup` | **NOT RUN** |
| 6 | `chand_feedback` | `status:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 7 | `notifications` | `user_id:1, read:1` | `—` | `_startup` | **NOT RUN** |
| 8 | `auth_rate_limits` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` | **NOT RUN** |
| 9 | `restock_alerts` | `product_id:1, active:1` | `—` | `_startup` | **NOT RUN** |
| 10 | `users` | `email:1` | `unique=true` | `_startup` | **NOT RUN** |
| 11 | `users` | `referral_code:1` | `unique=true, sparse=true` | `_startup` | **NOT RUN** |
| 12 | `referrals` | `referred_user_id:1` | `unique=true` | `_startup` | **NOT RUN** |
| 13 | `referrals` | `referrer_id:1, status:1` | `—` | `_startup` | **NOT RUN** |
| 14 | `referrals` | `qualifying_order_id:1` | `unique=true, partialFilterExpression={"qualifying_order_id":{"$type":"string"}}` | `_startup` | **NOT RUN** |
| 15 | `referral_rewards` | `reward_key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 16 | `referral_rewards` | `referrer_id:1, status:1` | `—` | `_startup` | **NOT RUN** |
| 17 | `referral_ledger` | `idempotency_key:1` | `unique=true, sparse=true` | `_startup` | **NOT RUN** |
| 18 | `referral_ledger` | `user_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 19 | `referral_audit` | `created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 20 | `referral_link_events` | `referrer_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 21 | `payout_bank_accounts` | `beneficiary_type:1, beneficiary_id:1` | `unique=true` | `_startup` | **NOT RUN** |
| 22 | `settlement_requests` | `beneficiary_user_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 23 | `settlement_requests` | `beneficiary_user_id:1, beneficiary_type:1, beneficiary_id:1, idempotency_key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 24 | `settlement_requests` | `status:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 25 | `settlement_order_allocations` | `order_key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 26 | `settlement_order_allocations` | `settlement_id:1` | `—` | `_startup` | **NOT RUN** |
| 27 | `financial_audit` | `created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 28 | `financial_ledger` | `idempotency_key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 29 | `financial_ledger` | `beneficiary_user_id:1, recorded_at:-1` | `—` | `_startup` | **NOT RUN** |
| 30 | `financial_ledger` | `order_id:1, recorded_at:-1` | `—` | `_startup` | **NOT RUN** |
| 31 | `shops` | `owner_id:1` | `—` | `_startup` | **NOT RUN** |
| 32 | `shops` | `status:1` | `—` | `_startup` | **NOT RUN** |
| 33 | `products` | `shop_id:1` | `—` | `_startup` | **NOT RUN** |
| 34 | `products` | `owner_id:1` | `—` | `_startup` | **NOT RUN** |
| 35 | `orders` | `customer_id:1` | `—` | `_startup` | **NOT RUN** |
| 36 | `orders` | `shop_id:1` | `—` | `_startup` | **NOT RUN** |
| 37 | `orders` | `grocery_idempotency_scope:1` | `unique=true, sparse=true` | `_startup` | **NOT RUN** |
| 38 | `grocery_quotes` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` | **NOT RUN** |
| 39 | `grocery_quotes` | `scope:1, status:1` | `—` | `_startup` | **NOT RUN** |
| 40 | `files` | `owner_id:1` | `—` | `_startup` | **NOT RUN** |
| 41 | `restaurants` | `owner_id:1` | `—` | `_startup` | **NOT RUN** |
| 42 | `restaurants` | `status:1, available:1, city:1` | `—` | `_startup` | **NOT RUN** |
| 43 | `restaurant_menu` | `restaurant_id:1, available:1` | `—` | `_startup` | **NOT RUN** |
| 44 | `addresses` | `user_id:1, is_default:-1` | `—` | `_startup` | **NOT RUN** |
| 45 | `restaurant_orders` | `customer_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 46 | `restaurant_orders` | `restaurant_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 47 | `restaurant_orders` | `customer_id:1, idempotency_key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 48 | `restaurant_payments` | `gateway_order_id:1` | `unique=true, sparse=true` | `_startup` | **NOT RUN** |
| 49 | `restaurant_payment_events` | `event_id:1` | `unique=true, sparse=true` | `_startup` | **NOT RUN** |
| 50 | `restaurant_reviews` | `restaurant_id:1, customer_id:1` | `unique=true` | `_startup` | **NOT RUN** |
| 51 | `password_resets` | `expires_at:1` | `expireAfterSeconds=0` | `_startup` | **NOT RUN** |
| 52 | `restaurant_support` | `user_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 53 | `restaurant_support` | `user_id:1, request_id:1` | `unique=true, partialFilterExpression={"request_id":{"$type":"string"}}` | `_startup` | **NOT RUN** |
| 54 | `restaurant_carts` | `user_id:1` | `unique=true` | `_startup` | **NOT RUN** |
| 55 | `service_providers` | `owner_id:1` | `unique=true, sparse=true` | `_startup` | **NOT RUN** |
| 56 | `service_appointments` | `customer_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 57 | `service_appointments` | `provider_id:1, created_at:-1` | `—` | `_startup` | **NOT RUN** |
| 58 | `home_service_slot_reservations` | `provider_id:1, slot_key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 59 | `home_service_settings` | `key:1` | `unique=true` | `_startup` | **NOT RUN** |
| 60 | `delivery_partner_applications` | `user_id:1` | `unique=true` | `ensure_delivery_partner_indexes` | **NOT RUN** |
| 61 | `delivery_partner_applications` | `referral_code:1` | `unique=true, sparse=true` | `ensure_delivery_partner_indexes` | **NOT RUN** |
| 62 | `delivery_partner_applications` | `status:1, updated_at:-1` | `—` | `ensure_delivery_partner_indexes` | **NOT RUN** |
| 63 | `delivery_partner_audit` | `application_id:1, created_at:-1` | `—` | `ensure_delivery_partner_indexes` | **NOT RUN** |
| 64 | `delivery_partner_referrals` | `referred_application_id:1` | `unique=true` | `ensure_delivery_partner_indexes` | **NOT RUN** |
| 65 | `delivery_partner_referrals` | `referrer_application_id:1, created_at:-1` | `—` | `ensure_delivery_partner_indexes` | **NOT RUN** |

Index option coverage in source: **25 unique**, **4 TTL**, **2 partial-filter** declarations (some overlap). Live `list_indexes`, creation, unique preflight, existing-record duplicates, explain plans and latency were **not** checked.

**Additional index candidates (not installed):** `grocery_payments.gateway_order_id` and `.gateway_payment_id` unique sparse; `catalogue_import_jobs.job_id` and seller listing compound; `retail_price_offers` identity compound; `master_products` identity partial unique. Legacy duplicates and workload/query performance must be examined before any rollout. `catalogue_import` row idempotency unique partial index specified in the later handoff is **not** in these 65 declarations.

**Count reconciliation:** source `50 collections + 65 explicit non-_id indexes` is compatible with historical backup report `52 collections + 117 total indexes`: the backup reports 2 metadata/health collections and per-collection default `_id` indexes. The 117 value is *historical report data*, not independently read from a live replica set.

## 7. Schema and collection validation
The available assessment lists all 50 backend-referenced collections and prioritizes financial/settlement/payment records before account/catalog/order, partner onboarding, and flexible history. No installed `validator`/`$jsonSchema`/production `collMod` was found in the startup and portability initialization. A test file may temporarily use a validator for a disposable test; that **does not prove production validators**.

| Priority | Collections/requirements | Evidence condition |
|---|---|---|
| P0 | `financial_ledger`, `settlement_requests`, `settlement_order_allocations`, `grocery_payments`, `restaurant_payments`, `restaurant_payment_events`, payout accounts and financial audit | Stable IDs/types/statuses and amount semantics must be profiled; existing legacy records unknown |
| P1 | `users`, `shops`, `products`, `orders`, `grocery_quotes`, `restaurants`, `restaurant_menu`, `restaurant_orders`, `master_products`, `catalogue_import_jobs` | Fixed-pack, measured and variant union shapes; all writer paths; no legacy breakage |
| P1 partner | `delivery_partner_applications`, `delivery_partner_referrals`, `delivery_partner_audit` | Encrypted personal document shape, owner status, migration compatibility |
| P2/P3 | addresses, cart, service bookings, notifications, support, audit and flexible import/AI payload collections | Enforce only proven invariants; consider no validator for extensible blobs |

**Safe gate, not executed:** obtain sanitized sample from authorized disposable clone; profile null/missing/type distributions; compare all writers and frontend/API contracts; start `validationAction: warn` and a reviewed `validationLevel: moderate` in clone; test old/new writes and rollback. **No `collMod` was run and no validator was deployed.**

## 8. Catalogue Import reconciliation
**Confirmed source:** `backend/server.py` contains Universal Catalogue Import upload/staging to `catalogue_import_jobs`, source-file SHA-256/filename metadata, CHAND interpretation, owned job views, seller edits, per-record and bulk approvals, record rejection, `_catalogue_record_validation` using `ProductIn` and `_import_measure`, and seller confirmation. `confirm_catalogue_import_apply` is explicitly *preflight only*, with `status="APPLY_PENDING_EMERGENT"`, `applied:false`, and no Product insert. These are different from legacy `import_shop_products` CSV/XLSX transactions.

**Historical contract only, not actual implementation:** Handoff says future apply should re-fetch current shop ownership, revalidate approved records, write Product and integer measured base-unit stock in same transaction, store source/job/record provenance and audit, set `APPLIED` only after commit, add deterministic idempotency `catalogue-import:{shop_id}:{job_id}:{record_index}` and partial unique Product index, reject existing SKU collisions without an unauthorized merge/update policy, keep `available:false` until seller publishing, and test multi-row rollback and concurrent replay. These contractual requirements are not evidence of source completion.

**Missing in this checkpoint:** real transactional apply helper; Product insert from confirmed job; post-commit APPLIED reconciliation; per-record unique partial Product idempotency index; replay-safe stock, transaction audit row; real cross-seller/concurrent/rollback tests. No alternate newer implemention was found in inspected accessible MASTER/PRECHANGE/PARTIAL archive code members. A later working-session implementation is **reported elsewhere** but its source bytes and Git state are not in these inspected archives. Do not reconstruct it from narrative.

## 9. Grocery / Restaurant money-and-stock consistency
| Workflow | Static controls verified in snapshot | Remaining unverified/missing |
|---|---|---|
| Grocery checkout | Fresh quote+stock/price re-read, consumed quote claim, conditional stock decrement, order insert and reward update within one transaction; idempotency scope unique-sparse index declared | Actual concurrent last-unit 200/409/503 behavior, transient retry/commit ambiguity, live index present |
| Grocery cancellation | Stock restore + conditional order cancel in transaction, double cancel returns existing state | Actual concurrent cancel/capture / failure rollback |
| Grocery gateway intent | Gateway intent creation and payment record insertion present | Concurrent creation can produce multiple intents; missing declared gateway ID uniqueness; gateway provider mocks/live verification required |
| Grocery capture | Payment/order state transaction, late/duplicate reconciliation markers, notify after commit | Unknown commit result, duplicate callback and payment gateway intent race against test replica set |
| Restaurant order creation | Order idempotency index (`customer_id`, `idempotency_key`) declared | Live race/idempotency enforcement |
| Restaurant verification/webhook | Gateway signature/event/ledger idempotency and conditional payment states in source | Multiple payment/order/ledger/event writes not in one transaction in this checkpoint; live failure/duplicate/capture consistency missing |
| Restaurant refund | Refund claim/reconciliation around external provider documented | Provider I/O must not occur inside retried transaction; post-provider writes are not one atomic unit; live timeout and replay verification required |

## 10. Historical-only implementation and conflicting versions
**Version-specific evidence available:**
- `MASTER`: prior source files and Git archive with `main`/`4681a4c`; these match all 14 project-manifest expected digests. That is earlier byte-level evidence, not authority to overwrite.
- `PRECHANGE`: intermediary changes to server, grocery checkout security test and portability script, with `.git` archive and same reported HEAD; source changes need not have been committed.
- `PARTIAL`: later source including `mongo_config.py`, `mongo_transactions.py`, offline tests and reports, but **without `.git`** and **without transactional Universal Catalogue Import apply**.
- `MONGODB_PHASE2_INVESTIGATION_2026-11-14.md` records 43 offline tests at an intermediate point; `MONGODB_FINAL_TEST_EVIDENCE.md` records **92 passed in 4.30s** for a wider focused selection. These are different suite scopes, not necessarily contradictory; neither was rerun here.
- `reports/mongodb/BACKUP_VERIFICATION_REPORT.json` reports a preview/test restore with 52 collections, 38 documents, 117 indexes. Prior recovery independently checked the sanitized `.archive.gz` SHA and gzip envelope; the current audit did not run `mongorestore`, so restore internals remain historical evidence.
**Reported elsewhere but source absent in this recovered ZIP and searched historical archive source:**
- `docs/mongodb/MONGODB_DEVELOPMENT_COMPLETION_MATRIX_2026-11-14.md` and newer detailed MongoDB completion reports; not included here. The separately existing documentation-only directory is not a substitute for this missing source.
- Transactional Universal Catalogue Import apply using driver `with_transaction`, deterministic imported Product row idempotency, audit and APPLIED state; current `confirm-apply` is preflight-only.
- Newer Restaurant payment/verification/refund `with_transaction` callback refactors, broader source-specific tests, extra unique import indexes and a `scripts/mongo/financial_integrity_audit.py` report/script mentioned in later completion accounts. These were not found in the inspected source.
**Conflict:** A later session reported `with_transaction`-based Catalogue Import and Restaurant fixes, but actual PARTIAL checkpoint is an older source version. Until exact newer files/commit/checkpoints are provided, classify as `HISTORICALLY REPORTED — SOURCE UNAVAILABLE`, not implemented in this recovery base. The presence of indexed historical Git objects in older archives does not alone establish that the missing uncommitted newer source is recoverable.

## 10A. Additional documentation-only handoff conflict — confirmed by file comparison

A separate existing path, `/mnt/data/COME-IN-MONGODB-PHASE2-WORK`, contains **37 documentation/report files but no application source or `.git`**. Direct SHA-256 comparison against the corresponding recovered source documents shows **35 files byte-identical** and **2 different/missing**:

1. **`COME_IN_EMERGENT_MONGODB_INTEGRATION_HANDOFF.md`**: the documentation-only copy has an additional **§12 “Codex source implementation update — 2026-11-14”**. It explicitly reports that `confirm-apply` now calls `_apply_catalogue_import_job_transactionally` with Motor `session.with_transaction`, creates Products with existing stock, writes provenance/audit/APPLIED state, adds a unique partial per-record index, and keeps imported products `available:false`. This is **real later documentary evidence** of a reported implementation, but **not recovered source evidence**: the partial checkpoint `backend/server.py` has the older preflight-only endpoint and no such function.
2. **`reports/MONGODB_LIVE_VERIFICATION_INFRASTRUCTURE_2026-11-14.md`**: appears only in the separate documentation-only path. It reports an unprovisioned runtime (Debian 13, absent MongoDB tools/drivers, DNS failures), and its §7 **also identifies the Catalogue Import source as preflight-only**. It states the inspected source lacks the transactional apply. The time/order of these two documents relative to the alleged later implementation is **not proven** and their claims conflict.

**Reconciliation:** This provides a more precise historical sequence of *claims*, but not a recoverable last-write-wins source tree. The additional §12 handoff cannot be used to recreate missing backend code or falsely mark Catalogue Import implemented in the recovered checkpoint. It strengthens the case for recovering the exact later `backend/server.py`, MongoDB tests, index declarations and named 2026-11-14 transactional-apply implementation report before any code work. The separate documentation-only path was **read-only inspected**, not merged, deleted or substituted.

## 11. Unverified assumptions, blocking dependencies, and non-actions
**Unverified:** that this is original live Codex project; that 65 source declarations exist in a real DB; any unique index is applied or duplicate-free; that historical restore truly matches current source; that production has TLS/least-privilege/private networking; that `TransientTransactionError` or unknown commit retry is safe; and that either version of Catalogue Import has been live verified.

**Environment executable/module observations (read-only):**
- `mongod`: NOT FOUND
- `mongosh`: NOT FOUND
- `mongorestore`: NOT FOUND
- `mongodump`: NOT FOUND
- `docker`: NOT FOUND
- `podman`: NOT FOUND
- Python `motor` module: NOT FOUND
- Python `pymongo` module: NOT FOUND
**Test commands not run:** no `pytest`, MongoDB `init`, `tx-verify`, live `preflight-indexes`, `verify-indexes` against DB, `mongorestore`, `collMod`, backend server startup, cloud or production operation. Previous 92-passed evidence remains historical. This is a source-reconciliation audit, not an execution campaign.

**No modifications:** no application code, manifest, historical ZIP, Git repository, backup, or DB was edited/overwritten/restored/deleted. Report generated outside the recovered project only.

## 12. Exact next implementation task (NOT AUTHORIZED / NOT STARTED)
**First gate (read-only):** recover/identify the actual **newer Phase 2 source** with its original `.git` modified/untracked files or an exact verified later checkpoint, and compare `backend/server.py`, `backend/mongo_transactions.py`, the transaction/catalogue tests, indices, and completion matrix to this partial checkpoint. Do not silently replace files or treat a historical ZIP as the active branch.

**Next authorized implementation only after reconciliation approval:** within MongoDB Step 1, take the verified authoritative source and complete the first source-confirmed missing database integrity operation. If newer transactional apply is truly absent, the specific first task is **Universal Catalogue Import transactional Product creation and idempotent apply**, preserving Product stock representation and seller approval; require focused fake/offline tests before any live disposable-replica verification. In parallel only after explicit next-phase authorization, address generalized retry/unknown-commit reconciliation and Restaurant multi-write atomicity. Do not add unique production indexes/validators until sanitized duplicate/type preflight.

**Stop and review:** this document is for review; implementation deliberately NOT started. Remain within approved project Step 1; never start Steps 2–9 from the project roadmap.

## 13. Read-only commands / evidence-generating operations
- `sha256` comparison of actual recovered bytes against both manifests and byte-level `ZipFile.read()` comparison against MASTER and PRECHANGE archive members (no historical archive extraction).
- Python `difflib.SequenceMatcher` line-count comparisons for the 14 changed files; line deltas are included in §2 and are descriptive, not code changes.
- Static `rg`/`sed` inspection of `backend/server.py`, `backend/mongo_config.py`, `backend/mongo_transactions.py`, `scripts/mongo/comein_mongo.py`, handoffs and audit reports.
- `PYTHONDONTWRITEBYTECODE=1 python scripts/mongo/comein_mongo.py spec` — **PASS**, 50 source collections and 65 source-declared indexes; it does not connect to MongoDB.
- `ZipFile` member discovery and Python `shutil.which`/`importlib.util.find_spec` dependency presence checks — no service/network access.
- Read-only comparison of the 37-file documentation-only `/mnt/data/COME-IN-MONGODB-PHASE2-WORK` with recovered source documents, plus inspection of its newer handoff §12 and infrastructure report.
- Older recovery report: `COME_IN_MONGODB_READ_ONLY_RECOVERY_AUDIT_2026-11-15.md`. It is retained unchanged.
