# Historical uncommitted changes — no source replacement

- Extracted from: `COME-IN-MONGODB-MISSION-PRECHANGE-20261114.zip`
- Verified branch: `main`
- Verified HEAD: `4681a4c0ca3e45787825f4b196b3284daa23a1f0`
- Modified paths in this historical checkout: **17**
- Untracked paths in this historical checkout: **3**
- Prior uncommitted tracked changes preserved as `PRECHANGE_UNCOMMITTED_TRACKED_CHANGES.patch`.
- The latest Nov 15 source ZIP has **no `.git`**. Its exact uncommitted status cannot be recovered or described as Git-verified.
- This historical patch must NOT automatically be applied to the current source: its changes may already be superseded.
- Actual historical `.git` object store was deliberately *not included* because the older repository tracks a MongoDB `.archive.gz` database snapshot, and its privacy cannot be fully certified. The original history remains in the protected prechange ZIP. This prevents silently packaging unknown private data in a new master source ZIP.

## Historical modified paths

- `backend/server.py` — path present in latest source
- `backend/tests/test_grocery_checkout_security_contract.py` — path present in latest source
- `frontend/scripts/cmd-guard.js` — path present in latest source
- `frontend/scripts/install-guard.sh` — path present in latest source
- `frontend/scripts/reset-project.js` — path present in latest source
- `frontend/scripts/sync-shims.sh` — path present in latest source
- `scripts/backup-db.sh` — path present in latest source
- `scripts/delivery-partner-live-api-check.sh` — path present in latest source
- `scripts/mongo/comein_mongo.py` — path present in latest source
- `scripts/mongo/export_sanitized_preview_backup.py` — path present in latest source
- `scripts/mongo/setup.sh` — path present in latest source
- `scripts/mongo/start-replset.sh` — path present in latest source
- `scripts/preview.sh` — path present in latest source
- `scripts/replit-install.sh` — path present in latest source
- `scripts/replit-run.sh` — path present in latest source
- `scripts/restore-db.sh` — path present in latest source
- `scripts/verify-env.sh` — path present in latest source

## Historical untracked paths

- `backend/tests/test_mongo_portability_tool.py` — path present in latest source
- `docs/mongodb/SCHEMA_VALIDATOR_ASSESSMENT_2026-11-14.md` — path present in latest source
- `reports/MONGODB_PHASE2_INVESTIGATION_2026-11-14.md` — path present in latest source
