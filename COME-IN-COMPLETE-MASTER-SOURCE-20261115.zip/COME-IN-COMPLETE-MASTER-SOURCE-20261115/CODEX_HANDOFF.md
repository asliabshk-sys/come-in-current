# COME-IN — Codex Handoff (continue exactly from here)

Prepared 2026-11-14 (container clock, UTC). Self-contained: no previous Emergent conversation is required.

---
## A. Project identity
- **Project name:** COME-IN ("Come In" in `frontend/app.json`, slug `come-in`)
- **What it is:** Hyperlocal commerce app for India — grocery shopping (fixed-pack + measured/loose), shops, Restaurant Mode, home services, referral & earn, seller and admin panels, Chand AI shopping assistant, delivery-partner onboarding.
- **Stack:** Expo SDK 58.0.17 / React Native 0.88.0 / React 19.3.0 / Expo Router 58.0.25 / TypeScript 6.0.3 / Yarn 1.22.22 (frontend) · FastAPI 0.110.1 / Motor 3.7.1 / PyMongo 4.18.2 / Python 3.11 (backend) · MongoDB 7.0.x replica set (database).
- **Frontend architecture:** File-based routing in `frontend/app/` (53 route files). Tabs in `frontend/app/(tabs)/` (index, categories, search, cart, account). Feature routes: `product/[id]`, `category/[slug]`, `shop/[id]`, `checkout`, `orders`, `order-tracking`, `seller/{products,orders,support}`, `admin`, `admin-earnings`, `admin-delivery-partners`, `delivery-partner`, `chand`, `restaurant/*` (separate Restaurant Mode shell `src/restaurant/RestaurantModeShell.tsx`), `services`, `request`, `referral*`, `retail-prices`, `language`, `addresses`, `payment-methods`, `notifications`, `auth`, `password-reset`, `become-seller`. Shared code in `frontend/src/` (`lib/api.ts` API client, `store/{auth,cart,location}.tsx`, `i18n/`, `theme.ts`, `components/`, `data/`, `restaurant/`).
- **Backend architecture:** Single FastAPI app `backend/server.py` (6.2k lines) with `APIRouter` prefix `/api` (177 routes, listed in `docs/api/API_ROUTES.md`). JWT auth (`get_current_user`, `require_role("admin")`), Pydantic request models, Motor async Mongo client, multi-document transactions via `client.start_session()` + `session.start_transaction()` (11 call sites). Pure business-rule modules imported by server.py. Startup (`_startup`) creates all indexes and optionally seeds an admin from env.
- **Database architecture:** One database (`DB_NAME`), 52 collections in the live spec (50 created by `comein_mongo.py init` + 2 tooling/scratch), 59 non-`_id` indexes declared in `_startup()`. Transactions require a replica set.

### Workspace merge note
The user asked to merge the uploaded ZIP with the current Emergent workspace. The Emergent workspace (`/app`) was inspected on 2026-11-14: it contained only the Emergent default template (CRA `frontend/`, a hello-world FastAPI `backend/server.py`, empty `memory/test_credentials.md`) and **no COME-IN source**. Merging it would have created competing `frontend/`/`backend/` roots, so nothing from it was copied. The single source of truth is the uploaded package's `APPLICATION_SOURCE/COME-IN-WORKING-COPY-RECOVERED-V1/`, now promoted to `COME-IN-MASTER-PROJECT/` with original relative paths preserved.

---
## B. Existing features (evidence-based)
Legend: IMPLEMENTED = source present + verified at runtime (historical or 2026-11-14) · PARTIAL = source present, parts blocked/unimplemented · BLOCKED = needs external provider/approval.

| Feature | Status | Source evidence | Verification evidence |
|---|---|---|---|
| Chand AI | PARTIAL | `frontend/app/chand.tsx`, `frontend/src/lib/chand-party-planner.ts`, `backend/server.py` `/api/assistant/{context,health,transcribe,vision}`, `/api/chand/feedback*`, `/api/admin/chand/feedback*`, `backend/catalogue_chand_adapter.py` | Catalog-only mode runtime PASS (historical); party-planner 11 assertions PASS 2026-11-14; Chand contract tests PASS. Generative answers / STT / vision BLOCKED: `COMEIN_AI_*` provider not configured. |
| Customer application | IMPLEMENTED | `frontend/app/(tabs)/*`, `product/[id]`, `category/[slug]`, `shops`, `shop/[id]`, `services`, `request` | `test_preview_runtime_e2e.py` 26/26 PASS 2026-11-14 (API level). `yarn build:web` PASS. Browser UI not exercised this session. |
| Seller Dashboard | IMPLEMENTED | `frontend/app/seller/{products,orders,support}.tsx`, `seller-earnings.tsx`, `become-seller.tsx` | Seller flows in live suites PASS 2026-11-14; 12 TS errors in `seller/products.tsx` (types only). |
| Admin Panel | IMPLEMENTED | `frontend/app/admin.tsx` (17 tabs incl. chandFeedback), `admin-earnings.tsx`, `admin-delivery-partners.tsx` | Admin approval/role/notification flows PASS in live suites 2026-11-14. |
| Product catalogue | IMPLEMENTED | `/api/catalog/products`, `/api/catalog/master-products`, `frontend/src/data/*` | Live e2e PASS. |
| Universal Catalogue Import | PARTIAL | `backend/catalogue_import_engine.py`, `/api/shops/{id}/catalogue-import/jobs*` (create, list, get, categories, record patch/approve/reject, bulk-approve, confirm-apply), seller UI in `seller/products.tsx` | Staging + review implemented. **`confirm-apply` is preflight only — it sets `APPLY_PENDING_EMERGENT` and writes NO products** (server.py ~line 2219). CSV delimiter-sniffing bug (1 failing test). Mobile picker/camera, OCR deps, transactional apply pending. |
| Legacy Excel/CSV product import | IMPLEMENTED | `/api/shops/{id}/products/import`, `/products/import-template`, `/admin/retail-price-import` | Transaction-backed measured import apply/rollback PASS (live T5 tests 2026-11-14). |
| Cart and Checkout | IMPLEMENTED | `frontend/app/(tabs)/cart.tsx`, `checkout.tsx`, `src/store/cart.tsx`, quote + idempotency in server.py | Grocery COD/pickup checkout PASS live 2026-11-14. Online payment gated off. |
| Orders | IMPLEMENTED | `orders.tsx`, `order-tracking.tsx`, `/api/orders*`, tracking endpoint | Live e2e PASS (create, seller status update, tracking). |
| MongoDB transactions | IMPLEMENTED | 11 `start_transaction` blocks in server.py (checkout stock decrement, settlements, imports, slot reservations…) | `test_task5_live_mongo_transactions.py` 9/9 PASS; `comein_mongo.py health` commit/abort PASS 2026-11-14. |
| Fixed-Pack and Measured Grocery | IMPLEMENTED | `MeasuredQuantityPicker.tsx`, `SellerMeasuredFields.tsx`, `src/lib/measure.ts`, server ProductIn measured fields | T5-MONGO-01..07, measured repeat order and import live PASS 2026-11-14. |
| Restaurant Mode | IMPLEMENTED | `frontend/app/restaurant/*` (15 routes), `src/restaurant/*`, `restaurant_pricing.py`, `restaurant_serviceability.py` | Restaurant COD order flow PASS in live e2e 2026-11-14. **Do not change without authorization.** |
| Delivery Partner onboarding | PARTIAL | `frontend/app/delivery-partner.tsx`, `admin-delivery-partners.tsx`, `/api/delivery-partner/*` (12 routes), Fernet encryption of PII | **First live run 2026-11-14:** draft save (PII stored encrypted), mine, submit fail-closed 409, OTP 503, admin queue RBAC 403/200, access denied 403 — all as designed (`reports/testing/delivery-partner-live-api-check-2026-11-14.txt`). OTP/Aadhaar/PAN/document storage BLOCKED (no authorized providers). |
| Payments | PARTIAL | `frontend/src/lib/razorpay.ts`, `GroceryOnlinePayment.tsx`, `/api/grocery/payments/*`, `/api/restaurant/payments/*` incl. webhook | COD / pay-at-shop / manual UPI work; Razorpay BLOCKED (no TEST keys; `GROCERY_ONLINE_PAYMENTS_ENABLED=false`). |
| Notifications | PARTIAL | `notifications.tsx`, `/api/notifications/*`, `backend/integrations/order_notifications.py` | In-app center 12/12 PASS (`test_iter_notifications_admin_measured.py`) 2026-11-14. Push delivery not configured (Firebase + native build). |
| Referral & Earn / Earnings | IMPLEMENTED | `referral*.tsx`, `seller-earnings.tsx`, `admin-earnings.tsx`, `referral_rules.py`, `financial_rules.py` | Contract tests PASS; historical runtime verification reports in `docs/history/`. |
| Auth & Account | IMPLEMENTED | `auth.tsx`, `password-reset.tsx`, `/api/auth/*`, rate limits | Login/register live PASS; SMTP reset email BLOCKED; OTP login not implemented. |

---
## C. MongoDB handoff
- **Version:** MongoDB 7.0.45 verified (FCV 7.0); pinned in `infra/mongodb/docker-compose.yml` (`mongo:7.0.45`) and `docs/mongodb/VERSIONS.md`.
- **Replica set:** single-node `rs0`. Local: `scripts/mongo/start-replset.sh` (port `MONGO_RS_PORT`, default 27018; dbpath `MONGO_RS_DBPATH`, default `/root/mongo-rs0-data`), initiated by `infra/mongodb/rs-init.js`. Supervisor template `infra/mongodb/supervisor-mongodb-rs0.conf`. Docker: `infra/mongodb/docker-compose.yml` (port 27017, `directConnection=true`).
- **Connection:** `MONGO_URL` + `DB_NAME` in `backend/.env`, loaded by `load_dotenv(ROOT_DIR/".env")` in server.py. Example `mongodb://127.0.0.1:27018/?replicaSet=rs0`. A standalone mongod makes grocery checkout return 503 (transactions required).
- **Collections (52):** see `reports/mongodb/live-mongo-spec-2026-11-14.json` and `docs/mongodb/SCHEMA_AND_VALIDATION.md` (that doc lists 44; newer: `catalogue_import_jobs`, `chand_feedback`, `assistant_rate_limits`, `delivery_partner_applications`, `delivery_partner_audit`, `delivery_partner_referrals`, plus tooling `_portability_healthcheck`).
- **Indexes:** 59 declared in `backend/server.py::_startup()`; `python3 scripts/mongo/comein_mongo.py spec` prints them from source (AST) so tooling never drifts. Health check reported `indexes_missing: []`.
- **Validators:** No `$jsonSchema` validators are configured by the app. Validation is Pydantic + unique indexes + transactional rules. Observation 2026-11-14: `products` and `orders` show `validationLevel: off` options (no validator) after the live test suite — harmless, recorded in the backup report.
- **Transactions / session lifecycle:** `async with await client.start_session() as session: async with session.start_transaction(): ...` — session is scoped per request operation and closed by the context manager; aborted automatically on exception. Docs: `docs/mongodb/TRANSACTIONS.md`.
- **Backup/restore:** `scripts/backup-db.sh` (mongodump gzip + sha256), `scripts/restore-db.sh <archive>` (restores to `<DB_NAME>_restore_test` unless `CONFIRM_LIVE_RESTORE=yes`), `scripts/mongo/export_sanitized_preview_backup.py` (sanitized export + restore verification; added 2026-11-14). Backup in `database-backup/` (see `database-backup/BACKUP_INSTRUCTIONS.md`).
- **Limitations:** single-node replica set only (no HA); no validators; Universal Catalogue Import idempotency index not yet added; no production DB has ever been connected from this package.
- **Remaining MongoDB issues:** transactional catalogue-import apply not implemented; cross-job import uniqueness; key rotation for Fernet-encrypted fields untested; restore drill against a managed (Atlas) cluster not run.
- **No real secrets or production credentials are included anywhere.**

---
## D. Task continuation
- **Completed:** Master tasks 1, 2, 3, 4, 5 (preview scope), 6, 7, 8, 9, 10, 12, 13, 14, 15, 22 (see `MASTER_TASK_TRACKER.md`).
- **Partially completed:** 11 (refund automation), 16 (OTP, logout-all, SMTP), 17 (Razorpay TEST, push), 18 (typecheck/lint failures, device tests), 20 (push), 21 (price comparison live data); add-ons: Chand AI, Universal Catalogue Import, Delivery Partner onboarding.
- **Pending:** none unassigned in the 22-task roadmap.
- **Blocked:** 19 Production build & launch (owner approval + secrets); provider-dependent items (Razorpay, SMTP, AI provider, OTP/Aadhaar/PAN, document storage, Firebase push).
- **Last verified checkpoint:** 2026-11-14 packaging run + clean-extraction replay (`reports/audit/CODEX_COMPATIBILITY_REPORT.md`) — git commit recorded in `PROJECT_MANIFEST.json` (`source_revision.commit`). Results in §E.
- **Exact next recommended task — NT-1:** Fix CSV delimiter detection in `backend/catalogue_import_engine.py` so a `name,description` header with `|` inside a cell is parsed as comma-separated (failing test `tests/test_universal_catalogue_import_engine.py::test_csv_formula_like_cells_are_preserved_as_untrusted_source_text`). Backend-only, no UI change.
  - Files: `backend/catalogue_import_engine.py`, `backend/tests/test_universal_catalogue_import_engine.py`.
- **Then NT-2:** Implement the transactional catalogue-import apply behind `/api/shops/{shop_id}/catalogue-import/jobs/{job_id}/confirm-apply` per `docs/UNIVERSAL_CATALOGUE_IMPORT_PENDING_BLOCKERS.md` (Product insert + stock/variants in one transaction, idempotency index, per-record product IDs). Files: `backend/server.py` (~lines 1978–2243), `backend/catalogue_import_engine.py`, `backend/tests/test_catalogue_import_*`.
- **Then NT-3:** Resolve the 29 TypeScript errors without visual change (`reports/testing/frontend-typecheck-2026-11-14.log`); main files `app/seller/products.tsx`, `app/order-tracking.tsx`, `app/chand.tsx`, `app/services.tsx`, `app/checkout.tsx`, `app/seller/support.tsx`.
- **Do not** "fix" the two failing Home contract tests by editing Home UI without owner authorization (`KNOWN_ISSUES.md` KI-1/KI-2).

---
## E. Testing evidence
Environment for all 2026-11-14 rows: Linux container, Python 3.11.18, Node 24.19.0, Yarn 1.22.22, MongoDB 7.0.45 single-node replica set `rs0` on 127.0.0.1:27018, database `comein_preview_test` (disposable), backend uvicorn on 127.0.0.1:8012. No production system touched.

### Current results (2026-11-14)
| Test / check | Command | Result | Passed | Failed | Skipped | Type |
|---|---|---|---:|---:|---:|---|
| Upload integrity vs latest package manifest | `sha256sum -c MANIFESTS/DELIVERY_PARTNER_ONBOARDING_SHA256_MANIFEST.txt` | PASS | 631 | 0 | 0 | static |
| MongoDB setup + health + tx commit/abort | `bash scripts/mongo/setup.sh` | PASS | – | – | – | live DB |
| Offline/contract backend suite | see CODEX_START_HERE §9 | FAIL (pre-existing) | 408 | 3 | 4 | static/contract |
| Live runtime suite (4 files) | `pytest -n 0 tests/test_preview_runtime_e2e.py tests/test_batch_5task_runtime.py tests/test_task5_live_mongo_transactions.py tests/test_iter_notifications_admin_measured.py` | PASS | 70 | 0 | 0 | live API + live DB |
| ↳ test_preview_runtime_e2e | | PASS | 26 | 0 | 0 | live |
| ↳ test_batch_5task_runtime | | PASS | 23 | 0 | 0 | live |
| ↳ test_task5_live_mongo_transactions | | PASS | 9 | 0 | 0 | live DB transactions |
| ↳ test_iter_notifications_admin_measured | | PASS | 12 | 0 | 0 | live |
| Legacy backend_test.py | `COMEIN_TEST_BASE_URL=... pytest -n 0 tests/backend_test.py` | FAIL (outdated contract) | 17 | 5 (2 fail + 3 error) | 1 | live |
| Delivery Partner live API check | `scripts/delivery-partner-live-api-check.sh` | PASS (8/8 expected) | 8 | 0 | 0 | live API + DB |
| DB backup → restore verification | `scripts/mongo/export_sanitized_preview_backup.py` | PASS | 52 collections | 0 mismatches | – | live DB |
| Frontend install | `yarn install` (lockfile regenerated, additive) | PASS | – | – | – | tooling |
| Frontend typecheck | `yarn typecheck` | FAIL (pre-existing) | – | 29 errors | – | static |
| Frontend lint | `yarn lint` | FAIL (pre-existing) | – | 54 errors, 40 warnings | – | static |
| Frontend web export | `CI=1 yarn build:web` | PASS | – | – | – | build |
| Chand party planner | `node frontend/scripts/test-chand-party-planner.cjs` | PASS | 11 | 0 | 0 | unit |
| ZIP clean-extraction + full replay (fresh env, new DB) | see `reports/audit/CODEX_COMPATIBILITY_REPORT.md` | PASS (frontend typecheck still FAIL) | 70 live + 408 offline | 3 offline | 4 | live + static |

Raw evidence: `reports/testing/*.xml` (JUnit), `reports/testing/*.log`, `reports/mongodb/*.json`.

### Historical results (NOT re-run unless listed above — kept for context)
- 2026-11-11 Emergent: T5-MONGO 9/9 PASS, Expo Customer + Seller Preview PASS (`COME_IN_TASK5_LIVE_MONGODB_COMPLETION_2026-11-11.md`).
- 2026-11-11: offline regression 345 PASS / 23 skipped (`COME_IN_TASK5_LIVE_PROVISIONING_CLOSURE_2026-11-11.md`).
- 2026-11-12: Delivery Partner focused tests 37 PASS (static only; `reports/audit/previous-handoff-package-2026-11-12/DELIVERY_PARTNER_ONBOARDING_EXECUTION_REPORT_2026-11-12.md`).
- 2026-11-12: Universal Catalogue Import 39 focused tests (`docs/COME-IN-UNIVERSAL-CATALOGUE-IMPORT-TEST-REPORT-2026-11-12.md`).
- Earlier reports: `project-reports/`, `docs/history/`.

---
## Instructions to Codex
1. Read CODEX_START_HERE.md → CODEX_HANDOFF.md → PROJECT_MANIFEST.json → MASTER_TASK_TRACKER.md.
2. Verify real files against them (`git log`, `git status`, paths in the manifest).
3. Continue from NT-1. Do not rebuild or re-scaffold. Do not repeat completed tasks. Do not overwrite working modules.
4. Do not change existing UI, theme, navigation or Restaurant Mode without explicit authorization.
5. Preserve MongoDB transaction code and the Chand AI integration.
6. Use isolated/disposable databases for any DB test. Never connect tests to production.
7. Never commit or print secrets; `backend/.env` and `frontend/.env` are git-ignored.

---
## 2026-11-14 — MongoDB master completion mission status

The current extracted working copy has safe, focused MongoDB changes and updated source-backed documentation. Do not infer production readiness from offline tests.

- `backend/mongo_config.py`: validates Mongo URI/DB name, expected DB target, production TLS, bounded pool/timeouts and retryable read/write options.
- `backend/server.py`: startup ping/topology guard; Grocery checkout maps a labeled transient transaction abort to 409 only when a fresh read proves insufficient stock; Grocery payment/order capture is now one transaction.
- `scripts/mongo/comein_mongo.py`: discovers all startup index handlers; 65 declarations (59 + 6), 50 app collections; init verifies, health reports, `verify-indexes` and `preflight-indexes` are available.
- `scripts/restore-db.sh`: only restores into `comein_disposable_test_*` and verifies the 65 source-declared indexes.
- New detailed reports: `docs/mongodb/MONGODB_MASTER_COMPLETION_REPORT.md`, `MONGODB_COLLECTION_INVENTORY.md`, `MONGODB_INDEX_INVENTORY.md`, `MONGODB_SCHEMA_VALIDATION_REPORT.md`, `MONGODB_TRANSACTION_AUDIT.md`, `MONGODB_SECURITY_AUDIT.md`, `MONGODB_BACKUP_RESTORE_GUIDE.md`, and `reports/MONGODB_FINAL_TEST_EVIDENCE.md`.
- Offline targeted regression: 92 passed; compileall and shell syntax checks passed. No live MongoDB test ran in this workspace: mongod, mongosh, Docker/Podman, mongorestore, Motor and PyMongo are absent.
- Remaining blockers: live disposable replica-set tests; transaction retry/unknown commit handling; live duplicate preflight for candidate unique indexes; schema document profiling and validators; payment/webhook multi-document race verification; data-integrity scan; production DB least privilege/TLS/network/key rotation/backup drill; newer Emergent source reconciliation for final Catalogue Import Product/stock apply.
- Catalogue Import is still staging/approval plus `APPLY_PENDING_EMERGENT` only in this source. Do not mark final Product/stock apply COMPLETE or begin unrelated roadmap work before the MongoDB completion matrix is reviewed.
